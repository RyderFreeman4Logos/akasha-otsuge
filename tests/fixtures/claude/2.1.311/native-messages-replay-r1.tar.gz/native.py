"""Native Claude Caller and Runner for the synthetic Messages replay."""

import argparse
import hashlib
import http.server
import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path
from types import SimpleNamespace

MSG = "Storm crossings in this synthetic atlas use the amber footbridge. Which crossing does the atlas specify for storms?"
KEY = "akasha-fixture-private-network-only"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(p):
    with Path(p).open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def encoded(x):
    return json.dumps(x, ensure_ascii=False).encode()


def write(p, x):
    p.write_bytes(encoded(x))


def render(x):
    if isinstance(x, str):
        return x
    if isinstance(x, list):
        return "".join(i["text"] for i in x if i.get("type") == "text")
    raise ValueError("tool result has no text")


def run():
    root = Path("/case")
    root.chmod(0o700)
    for sub in (
        "home",
        "claude-home",
        "codex-home",
        "pi-home",
        "work",
        "runtime",
        "tmp",
    ):
        (root / sub).mkdir(mode=0o700)
    args = SimpleNamespace(caller="claude", runner="claude", hint="storm crossing")
    report = dict(
        caller=args.caller,
        runner=args.runner,
        hint=args.hint,
        claude_runner_timeout_s=120,
        network="private namespace with restricted Messages relay",
        provider="controlled Caller, native Claude Runner",
    )
    rows = []
    errors = []
    selected = []
    server = http.server.ThreadingHTTPServer

    class Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def senddata(self, typ, data):
            self.send_response(200)
            self.send_header("Content-Type", typ)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def do_POST(self):
            try:
                raw = self.rfile.read(int(self.headers["Content-Length"]))
                if self.headers.get("Content-Encoding") == "zstd":
                    raw = subprocess.run(
                        ["/usr/bin/zstd", "-qd", "-c"],
                        input=raw,
                        stdout=subprocess.PIPE,
                        check=True,
                    ).stdout
                req = json.loads(raw)
                if self.path.startswith("/v1/messages/count_tokens"):
                    self.senddata("application/json", b'{"input_tokens":32}')
                    return
                if self.path.startswith("/v1/messages"):
                    assert self.headers.get("x-api-key") == KEY
                    tools = [t["name"] for t in req.get("tools", [])]
                    msgs = req["messages"]
                    caller = "mcp__akasha-otsuge__consult" in tools
                    if not caller and not any(
                        t.startswith("mcp__akasha-runner__") for t in tools
                    ):
                        self.anthropic(req, None, {}, "Fixture session.", None)
                        return
                    if not caller:
                        import http.client
                        import socket

                        class Dial(http.client.HTTPConnection):
                            def connect(self):
                                self.sock = socket.socket(
                                    socket.AF_UNIX, socket.SOCK_STREAM
                                )
                                self.sock.settimeout(55)
                                self.sock.connect("/fixture/messages.sock")

                        conn = Dial("localhost", timeout=55)
                        try:
                            conn.request(
                                "POST",
                                "/v1/messages",
                                encoded(req),
                                {"Content-Type": "application/json"},
                            )
                            r = conn.getresponse()
                            b = r.read()
                            self.send_response(r.status)
                            self.send_header(
                                "Content-Type",
                                r.getheader("Content-Type", "application/json"),
                            )
                            self.send_header("Content-Length", str(len(b)))
                            self.end_headers()
                            self.wfile.write(b)
                            return
                        finally:
                            conn.close()
                    prefix = (
                        "mcp__akasha-otsuge__" if caller else "mcp__akasha-runner__"
                    )
                    results = [
                        render(b["content"])
                        for m in msgs
                        if isinstance(m["content"], list)
                        for b in m["content"]
                        if b.get("type") == "tool_result"
                    ]
                    fn, params, answer = self.action(caller, results, req)
                    tool = prefix + fn if fn else None
                    assert tool is None or tool in tools, (tool, tools)
                    self.anthropic(req, tool, params, answer, len(results))
                    return
                raise ValueError(self.path)
            except Exception as exc:
                errors.append(f"{type(exc).__name__}: {str(exc)[:600]}")
                print("fixture protocol failure", type(exc).__name__, flush=True)
                self.send_error(400)

        def action(self, caller, results, req):
            assert len(rows) < 32
            n = len(results)
            fn = None
            params = {}
            answer = None
            if caller:
                assert MSG in str(req)
                if not n:
                    fn = "consult"
                    if args.hint is not None:
                        params = {"hint": args.hint}
                else:
                    assert n == 1
                    answer = "Submitted."
            rows.append(
                dict(
                    role="caller" if caller else "runner", tool=fn, preceding_results=n
                )
            )
            return fn, params, answer

        def anthropic(self, req, tool, params, answer, n):
            ident = "local" + str(len(rows)) + ("title" if n is None else "")
            block = (
                dict(type="tool_use", id="toolu_" + ident, name=tool, input={})
                if tool
                else dict(type="text", text="")
            )
            delta = (
                dict(type="input_json_delta", partial_json=json.dumps(params))
                if tool
                else dict(type="text_delta", text=answer)
            )
            msg = dict(
                id="msg_" + ident,
                type="message",
                role="assistant",
                model=req["model"],
                content=[],
                stop_reason=None,
                stop_sequence=None,
                usage=dict(input_tokens=32, output_tokens=0),
            )
            events = [
                dict(type="message_start", message=msg),
                dict(type="content_block_start", index=0, content_block=block),
                dict(type="content_block_delta", index=0, delta=delta),
                dict(type="content_block_stop", index=0),
                dict(
                    type="message_delta",
                    delta=dict(
                        stop_reason="tool_use" if tool else "end_turn",
                        stop_sequence=None,
                    ),
                    usage=dict(output_tokens=8),
                ),
                dict(type="message_stop"),
            ]
            self.senddata(
                "text/event-stream",
                b"".join(
                    b"event: " + e["type"].encode() + b"\ndata: " + encoded(e) + b"\n\n"
                    for e in events
                ),
            )

    srv = server(("127.0.0.1", 0), Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    url = "http://127.0.0.1:" + str(srv.server_port)
    env = dict(
        HOME="/case/home",
        XDG_RUNTIME_DIR="/case/runtime",
        TMPDIR="/case/tmp",
        USER="fixture",
        LOGNAME="fixture",
        PATH="/tools:/usr/bin:/bin",
        LANG="C.UTF-8",
        CLAUDE_CONFIG_DIR="/case/claude-home",
        ANTHROPIC_API_KEY=KEY,
        ANTHROPIC_BASE_URL=url,
        CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC="1",
        DISABLE_AUTOUPDATER="1",
        CLAUDE_CODE_DISABLE_CLAUDE_MDS="1",
        PI_CODING_AGENT_DIR="/case/pi-home",
        PI_SKIP_VERSION_CHECK="1",
        CODEX_HOME="/case/codex-home",
        PYTHONDONTWRITEBYTECODE="1",
        ANTHROPIC_MODEL="grok-4.7",
        ANTHROPIC_DEFAULT_SONNET_MODEL="grok-4.7",
        MAX_THINKING_TOKENS="0",
        CLAUDE_CODE_MAX_OUTPUT_TOKENS="1400",
        CLAUDE_CODE_MAX_RETRIES="0",
    )
    write(
        root / "claude-home/.claude.json",
        dict(
            hasCompletedOnboarding=True,
            lastOnboardingVersion="2.1.311",
            customApiKeyResponses=dict(approved=[KEY[-20:]], rejected=[]),
        ),
    )
    cfg = root / "akasha.toml"
    kind = "claude_code" if args.runner == "claude" else args.runner
    cfg.write_text(
        '[paths]\ndata_dir="/case/data"\nsocket_path="/case/runtime/akasha.sock"\n[access]\nread_roots=["/case"]\n[consult]\nexecutor="selected"\n[executors.selected]\nkind="'
        + kind
        + '"\nbinary="/tools/'
        + args.runner
        + '"\nnative_home="/case/'
        + args.runner
        + '-home"\n'
    )
    if args.runner == "claude":
        env["MATRIX_MODEL_DUMMY"] = KEY
        with cfg.open("a") as f:
            f.write(
                'timeout="120s"\nmodel="loopback"\n[models.loopback]\nkind="text"\nlocal=true\ncredential_ref="env:MATRIX_MODEL_DUMMY"\nmodel="grok-4.7"\nendpoint='
                + json.dumps(url + "/v1")
                + "\n"
            )
    app = "/tools/akasha-otsuge"
    base = [app, "--config", str(cfg)]

    def command(cmd, timeout=70):
        p = subprocess.run(
            cmd, cwd=root / "work", env=env, capture_output=True, timeout=timeout
        )
        if p.returncode:
            raise RuntimeError(
                "command "
                + str(cmd[:2])
                + " exit "
                + str(p.returncode)
                + " "
                + p.stderr.decode(errors="replace")[-650:]
                + " "
                + p.stdout.decode(errors="replace")[-400:]
            )
        return p.stdout

    def cli(*c):
        return json.loads(command([*base, *map(str, c)]))["data"]

    def wait_for(call):
        stop = time.monotonic() + 145
        while time.monotonic() < stop:
            result = call()
            if result:
                return result
            time.sleep(0.15)
        raise RuntimeError("timeout waiting for condition")

    report["versions"] = {
        h: command(["/tools/" + h, "--version"]).decode().strip()
        for h in {args.caller, args.runner}
    }
    report["other_host_clis_absent"] = {
        h: shutil.which(h, path=env["PATH"]) is None
        for h in ("claude", "codex", "hermes", "pi")
        if h not in (args.caller, args.runner)
    }
    assert all(report["other_host_clis_absent"].values())
    try:
        cli("daemon", "start")
        if args.caller == "claude":
            cli(
                "adapter",
                "install",
                "claude",
                "--binary",
                "/tools/claude",
                "--directory",
                "/case/plugin",
            )
            command(
                [
                    "/tools/claude",
                    "--plugin-dir",
                    "/case/plugin",
                    "-p",
                    MSG,
                    "--tools",
                    "ToolSearch",
                    "--strict-mcp-config",
                    "--mcp-config",
                    '{"mcpServers":{}}',
                    "--setting-sources",
                    "",
                    "--output-format",
                    "stream-json",
                    "--verbose",
                ]
            )
        jobs = wait_for(
            lambda: [
                i for i in cli("job", "list")["items"] if i["id"].startswith("consult/")
            ]
        )
        assert len(jobs) == 1, ("consult jobs", len(jobs), rows)
        ident = jobs[0]["id"]

        def terminal():
            j = cli("job", "show", ident)
            return j if j["state"] not in ("queued", "running") else None

        j = wait_for(terminal)
        print(
            "job",
            j["state"],
            j.get("error"),
            [
                (v["host"], v["state"], v.get("error"))
                for v in j.get("run_trace", {}).get("runs", [])
            ],
            flush=True,
        )
        plan = j["consult_plan"]
        (run,) = j["run_trace"]["runs"]
        assert (
            run["host"] == "claude_code"
            and run["origin"] == plan["invocation_id"]
            and run["fence"] == plan["fence"]
            and len(run["fence"]) == 64
        )
        assert plan["args"].get("hint") == args.hint
        report.update(
            job_state=j["state"],
            runner_state=run["state"],
            typed_error=j.get("error"),
            origin_and_fence_verified=True,
            stored_hint_verified=True,
            product_usage=j["run_trace"].get("usage"),
        )
        if j["state"] == "succeeded":
            public = cli("consult", "show", ident)
            receipt = cli("consult", "receipt", ident)
            assert (
                json.loads(receipt["data"]["output"]) == public
                and receipt["data"]["record"]["scope"] == public["scope"]
            )
            report.update(
                public_status=public["status"],
                source_count=len(public["evidence"]),
                gap_count=len(public["gaps"]),
                public_receipt_verified=True,
                scope_user_verified=public["scope"]["user"]
                == "uid:" + str(os.geteuid()),
            )
            exact = False
            for ix, source in enumerate(public["evidence"]):
                original = cli(
                    "show",
                    source["event_id"],
                    "--revision",
                    source["revision"],
                    "--range",
                    source["start"],
                    source["end"],
                )
                cited = cli("consult", "original", ident, ix)
                if (
                    original["output"] == cited.get("output", cited.get("text"))
                    and original["scope"] == public["scope"]
                    and original["output"] in MSG
                    and source["content_sha256"] == sha(MSG.encode())
                ):
                    exact = True
            report.update(
                original_verified=exact,
                answer_mentions_expected_crossing="amber footbridge"
                in public["answer"].lower(),
            )
        assert not errors, errors
        write(root / "verified.json", report)
    finally:
        try:
            cli("daemon", "stop")
        finally:
            srv.shutdown()
            srv.server_close()


def launch():
    parser = argparse.ArgumentParser(description=__doc__)
    for flag in ("product", "claude", "scratch", "output"):
        parser.add_argument("--" + flag, type=Path, required=True)
    args = parser.parse_args()
    commit = "4e7b3a2799ebc2055750eb044b056cc1d887625a"
    binary = "8c0114b2803df101fcebb934a9c1bd170abf67b522b5775c820b14e69c1c1133"
    assert file_sha(args.product) == binary
    versions = {"claude": file_sha(args.claude)}
    assert (
        versions["claude"]
        == "86dc1fcc69498159eaf15f446613e847010f9036bfbbdffd4c49350be8489ada"
    )
    with tempfile.TemporaryDirectory(dir=args.scratch) as scratch:
        root = Path(scratch)
        data = root / "data"
        data.mkdir(mode=0o700)
        cmd = [
            "bwrap",
            "--die-with-parent",
            "--new-session",
            "--unshare-all",
            "--ro-bind",
            "/usr",
            "/usr",
            "--symlink",
            "usr/bin",
            "/bin",
            "--symlink",
            "usr/lib",
            "/lib",
            "--symlink",
            "usr/lib64",
            "/lib64",
            "--proc",
            "/proc",
            "--dev",
            "/dev",
            "--tmpfs",
            "/tmp",
            "--dir",
            "/etc",
            "--ro-bind",
            "/etc/passwd",
            "/etc/passwd",
            "--dir",
            "/tools",
            "--dir",
            "/opt",
            "--dir",
            "/fixture",
            "--ro-bind",
            str(Path(__file__).resolve()),
            "/fixture/test",
            "--ro-bind",
            os.environ["AKASHA_MESSAGES_SOCKET"],
            "/fixture/messages.sock",
            "--ro-bind",
            str(args.product.resolve()),
            "/tools/akasha-otsuge",
            "--bind",
            str(data),
            "/case",
        ]
        cmd += ["--ro-bind", str(args.claude.resolve()), "/tools/claude"]
        cmd += [
            "--clearenv",
            "--setenv",
            "PATH",
            "/tools:/usr/bin:/bin",
            "--setenv",
            "HOME",
            "/tmp",
            "--chdir",
            "/case",
            "/usr/bin/python3",
            "-B",
            "/fixture/test",
            "inside",
        ]
        subprocess.run(cmd, timeout=210, check=True)
        result = json.loads((data / "verified.json").read_bytes())
    result.update(
        product_source=commit,
        product_sha256=binary,
        harness_sha256=file_sha(__file__),
        private_pid_mount_network=True,
        private_scratch_removed=True,
        native_executable_sha256=versions,
    )
    with args.output.open("x") as out:
        json.dump(result, out, sort_keys=True, indent=2)
        out.write("\n")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "inside":
        run()
    else:
        launch()
