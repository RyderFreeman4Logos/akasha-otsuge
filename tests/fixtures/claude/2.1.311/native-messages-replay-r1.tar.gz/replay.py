"""A single native Claude Consult using a bounded Messages relay."""

import argparse
import hashlib
import http.client
import http.server
import json
import os
import socketserver
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from contextlib import ExitStack
from pathlib import Path

parser = argparse.ArgumentParser(
    description="Replay synthetic Messages inside an isolated native Claude Consult."
)
parser.add_argument(
    "--paired", action="store_true", help="Start with a two-tool model response."
)
for flag in ("product", "claude", "scratch", "output"):
    parser.add_argument("--" + flag, type=Path, required=True)
args = parser.parse_args()
MODEL = "grok-4.7"
PREFIX = "mcp__akasha-runner__"
TOOLS = {
    PREFIX + x
    for x in (
        "context_describe",
        "context_list",
        "context_read",
        "context_search",
        "memory_get",
        "memory_search",
    )
}
CASE = "Storm crossings in this synthetic atlas use the amber footbridge. Which crossing does the atlas specify for storms?"
reports = []
guards = []
locked = threading.Lock()
wire = []


def encoded(v):
    return json.dumps(v, separators=(",", ":")).encode()


def complete(req, name=None, param=None, answer=None):
    cid = "local" + uuid.uuid4().hex
    block = (
        {"type": "tool_use", "id": "toolu_" + cid, "name": name, "input": {}}
        if name
        else {"type": "text", "text": ""}
    )
    delta = (
        {"type": "input_json_delta", "partial_json": json.dumps(param)}
        if name
        else {"type": "text_delta", "text": answer}
    )
    events = [
        dict(
            type="message_start",
            message=dict(
                id="msg_" + cid,
                type="message",
                role="assistant",
                model=MODEL,
                content=[],
                stop_reason=None,
                stop_sequence=None,
                usage=dict(input_tokens=15, output_tokens=0),
            ),
        ),
        dict(type="content_block_start", index=0, content_block=block),
        dict(type="content_block_delta", index=0, delta=delta),
        dict(type="content_block_stop", index=0),
        dict(
            type="message_delta",
            delta=dict(
                stop_reason="tool_use" if name else "end_turn", stop_sequence=None
            ),
            usage=dict(output_tokens=4),
        ),
        dict(type="message_stop"),
    ]
    return b"".join(
        b"event: " + ev["type"].encode() + b"\ndata: " + encoded(ev) + b"\n\n"
        for ev in events
    )


class Synthetic(http.server.BaseHTTPRequestHandler):
    def log_message(self, *unused):
        pass

    def do_POST(self):
        assert (
            self.path == "/v1/messages"
            and self.headers["Authorization"] == "Bearer offline-placeholder"
            and self.headers["anthropic-version"] == "2023-06-01"
        )
        req = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        assert req["model"] == MODEL and {x["name"] for x in req["tools"]} == TOOLS
        vals = [
            b["content"]
            for m in req["messages"]
            if isinstance(m["content"], list)
            for b in m["content"]
            if b.get("type") == "tool_result"
        ]
        if not vals and args.paired:
            uid = uuid.uuid4().hex
            raw0 = complete(req, PREFIX + "context_describe", {})
            events = [
                json.loads(line[6:])
                for line in raw0.splitlines()
                if line.startswith(b"data: ")
            ]
            events[0]["message"]["usage"] = {
                "input_tokens": 1500,
                "output_tokens": 0,
                "cache_read_input_tokens": 1152,
            }
            events[-2]["usage"]["output_tokens"] = 77
            events[4:4] = [
                {
                    "type": "content_block_start",
                    "index": 1,
                    "content_block": {
                        "type": "tool_use",
                        "id": "toolu_" + uid,
                        "name": PREFIX + "context_list",
                        "input": {},
                    },
                },
                {
                    "type": "content_block_delta",
                    "index": 1,
                    "delta": {
                        "type": "input_json_delta",
                        "partial_json": json.dumps({"limit": 8}),
                    },
                },
                {"type": "content_block_stop", "index": 1},
            ]
            raw = b"".join(
                b"event: " + ev["type"].encode() + b"\ndata: " + encoded(ev) + b"\n\n"
                for ev in events
            )
        elif not vals or (len(vals) == 2 and args.paired):
            raw = complete(req, PREFIX + "context_search", {"query": CASE, "limit": 16})
        else:
            v = vals[-1]
            v = json.loads(v if isinstance(v, str) else "".join(x["text"] for x in v))
            if isinstance(v, list):
                v = json.loads(v[0]["text"])
            if "text" in v and isinstance(v["text"], str):
                v = json.loads(v["text"])
            if v["kind"] == "page":
                page = v["value"]
                if page["events"]:
                    raw = complete(
                        req,
                        PREFIX + "context_read",
                        {
                            "handle": page["events"][0]["handle"],
                            "start": 0,
                            "max_bytes": 768,
                        },
                    )
                else:
                    assert page.get("next")
                    raw = complete(
                        req,
                        PREFIX + "context_search",
                        {"query": CASE, "cursor": page["next"], "limit": 16},
                    )

            else:
                assert v["kind"] == "text" and v["value"]["text"] == CASE
                raw = complete(
                    req,
                    answer=json.dumps(
                        dict(
                            status="found",
                            answer="The amber footbridge.",
                            sources=v["value"]["sources"],
                            memories=[],
                            conditions=[],
                            conflicts=[],
                            gaps=[],
                        )
                    ),
                )
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)


class Relay(http.server.BaseHTTPRequestHandler):
    def log_message(self, *unused):
        pass

    def reject(self, reason, status=400):
        guards.append(reason)
        self.send_error(status)

    def do_POST(self):
        if self.path != "/v1/messages":
            return self.reject("path")
        length = int(self.headers.get("Content-Length", 0))
        data = self.rfile.read(length) if 0 < length <= 256000 else b""
        if not data:
            return self.reject("size")
        req = json.loads(data)
        names = {x.get("name") for x in req.get("tools", [])}
        if (
            not TOOLS <= names
            or req.get("model") != MODEL
            or req.get("stream") is not True
        ):
            return self.reject("unexpected_tool_declaration_or_route")
        req["tools"] = [t for t in req["tools"] if t.get("name") in TOOLS]
        req["max_tokens"] = min(req["max_tokens"], 1400)
        # Keep only conversation protocol fields. Device metadata and ancillary billing headers stay local.
        req = {
            k: v
            for k, v in req.items()
            if k
            in (
                "model",
                "messages",
                "system",
                "stream",
                "max_tokens",
                "tools",
                "tool_choice",
                "temperature",
                "top_p",
                "stop_sequences",
            )
        }
        with locked:
            if len(reports) >= 6:
                return self.reject("request_cap", 429)
            obs = {"number": len(reports) + 1}
            reports.append(obs)
        conn = http.client.HTTPConnection("127.0.0.1", port, timeout=45)
        started = time.monotonic()
        try:
            conn.request(
                "POST",
                "/v1/messages",
                encoded(req),
                {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + key,
                    "anthropic-version": "2023-06-01",
                },
            )
            r = conn.getresponse()
            raw = r.read(2000001)
            obs["http_status"] = r.status
            ct = r.getheader("Content-Type", "")
            obs["events"] = []
            obs["requested_tools"] = []
            obs["usage"] = {}
            if (
                r.status != 200
                or len(raw) > 2_000_000
                or not ct.startswith("text/event-stream")
            ):
                # Product observes the rejection. Keep the upstream error class only.
                try:
                    err = json.loads(raw).get("error", {}).get("type")
                    obs["upstream_error_type"] = (
                        err
                        if err
                        in (
                            "invalid_request_error",
                            "authentication_error",
                            "permission_error",
                            "not_found_error",
                            "overloaded_error",
                            "rate_limit_error",
                            "api_error",
                        )
                        else "other"
                    )
                except Exception:
                    pass
                self.send_error(r.status if r.status >= 400 else 502)
                return
            for line in raw.splitlines():
                if not line.startswith(b"data: "):
                    continue
                event = json.loads(line[6:])
                typ = event.get("type")
                obs["events"].append(typ)
                if typ == "message_start":
                    model = event["message"].get("model")
                    obs["reported_model"] = (
                        model if isinstance(model, str) and len(model) < 80 else None
                    )
                if typ == "content_block_start" and event["content_block"]["type"] in (
                    "tool_use",
                    "server_tool_use",
                ):
                    tool = event["content_block"]["name"]
                    if tool not in TOOLS:
                        return self.reject("unadvertised_response_tool", 502)
                    obs["requested_tools"].append(tool[len(PREFIX) :])
                if typ == "message_delta":
                    obs["stop_reason"] = event.get("delta", {}).get("stop_reason")
                usage = (
                    event.get("usage") or event.get("message", {}).get("usage") or {}
                )
                for k in (
                    "input_tokens",
                    "output_tokens",
                    "cache_read_input_tokens",
                    "cache_creation_input_tokens",
                ):
                    if isinstance(usage.get(k), int):
                        obs["usage"][k] = max(obs["usage"].get(k, 0), usage[k])
            if "message_stop" not in obs["events"]:
                return self.reject("incomplete_stream", 502)
            obs["event_count"] = len(obs.pop("events"))
            self.send_response(200)
            self.send_header("Content-Type", ct)
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)
        except Exception as exc:
            obs["transport_error"] = type(exc).__name__
            self.send_error(502)
        finally:
            obs["elapsed_ms"] = round(1000 * (time.monotonic() - started))
            conn.close()


with ExitStack() as ctx:
    scratch = Path(
        ctx.enter_context(tempfile.TemporaryDirectory(prefix="a12-", dir=args.scratch))
    )
    sock = scratch / "relay.sock"
    fake = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Synthetic)
    threading.Thread(target=fake.serve_forever, daemon=True).start()
    ctx.callback(fake.server_close)
    ctx.callback(fake.shutdown)
    port = fake.server_port
    key = "offline-placeholder"
    srv = socketserver.UnixStreamServer(str(sock), Relay)
    sock.chmod(0o600)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    ctx.callback(srv.server_close)
    ctx.callback(srv.shutdown)
    product = args.product
    native_path = args.claude
    out = scratch / "native.json"
    env = dict(os.environ, AKASHA_MESSAGES_SOCKET=str(sock))
    proc = subprocess.run(
        [
            sys.executable,
            "-B",
            Path(__file__).with_name("native.py"),
            "--product",
            product,
            "--claude",
            native_path,
            "--scratch",
            scratch,
            "--output",
            out,
        ],
        capture_output=True,
        timeout=245,
        env=env,
    )
    native = json.loads(out.read_bytes()) if out.is_file() else {}
    if proc.returncode:
        print((proc.stderr + proc.stdout).decode(errors="replace")[-2200:], flush=True)
    data = {
        "native": native,
        "observer_exit": proc.returncode,
        "upstream": reports,
        "guards": guards,
        "route_protocol": "anthropic messages",
        "model": MODEL,
        "case_sha256": hashlib.sha256(CASE.encode()).hexdigest(),
        "max_upstream_requests": 6,
        "max_output_tokens_each": 1400,
        "real_native_jobs": 0,
        "task_is_frozen_benchmark": False,
    }
    with args.output.open("x") as target:
        json.dump(data, target, indent=2)
    print(
        "offline",
        "runner",
        native.get("job_state"),
        "calls",
        len(reports),
        "observer",
        proc.returncode,
        flush=True,
    )
    assert (
        proc.returncode == 0
        and native["origin_and_fence_verified"]
        and native["stored_hint_verified"]
    )
    assert (
        native["runner_state"] == native["job_state"] == "succeeded"
        and native["public_status"] == "found"
    )
    assert (
        native["public_receipt_verified"]
        and native["original_verified"]
        and native["scope_user_verified"]
    )
    assert (
        native["answer_mentions_expected_crossing"]
        and native["gap_count"] == 0
        and native["source_count"] == 1
    )
    assert reports[0]["requested_tools"] == (
        ["context_describe", "context_list"] if args.paired else ["context_search"]
    )
    assert (
        not guards
        and all(r["http_status"] == 200 for r in reports)
        and reports[-1]["stop_reason"] == "end_turn"
    )
