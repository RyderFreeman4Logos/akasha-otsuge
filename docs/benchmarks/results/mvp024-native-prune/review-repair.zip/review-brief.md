Perform an independent read-only conventional review of the entire frozen origin/main...HEAD range for native index maintenance: exclusive version pruning and merge-key BTree indexes. This is a partial #65 leaf, not full production-scale acceptance.

W=/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025
E=/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/.git/akasha-evidence
HEAD_SHA=b801af9409ef76519714ad0558314fe57a1ba114
TREE_SHA=a783ca14b4078986cccdccd71286b39f73019790
BASE_SHA=e7cef25276e0737d781b5cfac69504c70c15818d
origin/main=9f2ba152529a796383204a8a98dd89a5c6af6616 (merged PR68; merge-base is BASE_SHA).
Scope E/mvp024-index-prune-review-r1-scope.json: 19 paths, including six Rust implementation/test files and evidence/documentation.

Before source, read applicable actual-filesystem AGENTS.md/CLAUDE.md through symlinks, including ancestor/nested instructions; report logical paths, resolved paths and line counts or filesystem-confirmed absence. Git-tree absence is not proof. Use native-code-review criteria and regression-only attribution for origin/main...HEAD. Read full changed source and reachable callers. Do not edit tracked files, index, refs, config, source or docs; do not publish, install tools, inspect secrets or native-child transcripts, spawn another reviewer or rerun the canonical gate. Write only the named external report/test log and small review-owned receipts under E or ignored .review. Hermes failed earlier in this task; this is the native Codex fallback.

Owner constraints: no Daybreak or new red-team/adversarial campaigns. Ordinary maintained functional/lifecycle/concurrency regressions and existing failure-path tests are allowed. Reason statically about other boundaries. Do not execute archived drivers, reread corpus shards, start scale workloads or claim incomplete acceptance passed.

Trace src/daemon/retrieval.rs sync/rebuild/search-index ownership and reachable search callers; src/retrieval.rs initialization/sync/prune; and src/retrieval/vector.rs initialization/sync/table lifetime. After 32 authority windows or completion the builder tries the cache lock, requires pointer equality and exactly cache+builder Arc owners, then keeps that lock across native pruning. Existing readers defer cleanup and new readers must not enter while it runs. Verify every actual lexical/vector query retains the ownership that this proof relies on, no deadlock is introduced, and deferred cleanup is retried later. Every native prune checks permissions, job ownership/cancellation, stopping and original deadline. It uses older_than=0, delete_unverified=false, error_if_tagged=true. Current authority/history and prior vector generations remain preserved. Inspect the exact pinned native API when needed; do not infer its semantics from its name.

Both native table initialization paths now create missing key and scope BTree indexes through their existing API. Trace each caller, update/replay/delete behavior, index maintenance and potential regressions. The new maintained daemon test verifies key indexes and real key lookup ScalarIndexQuery plans on both tables with correct rows. It does not directly observe a merge execution plan, and must not be presented as such. The retrieval unit-test assertion is unchanged; only its index-count comment changed.

The two pruning regressions use real daemon/native tables and failed retained-version counts before the change: 6/7 versions and 4/4 instead of one. They verify full native ID/revision sets, current/history payloads, a held reader deferring cleanup and later idle sync reclaiming. Their original 179-line prefix remains unchanged. The key-index regression's first two attempts were fixture compile errors, not product RED; third attempt compiled and failed absent indexes/scanning plans. Same test bytes then pass. Fresh focused expectations are 8 library passes/1 ignored child plus 26 daemon retrieval passes, with Clippy. Check actual counts.

Evidence: verify each changed ZIP against its manifest and decompress/hash every member. The native-prune evidence.zip has 90 members and the identical 1024-record pilot passes all 1042 current hashes/eight scoped witnesses with 5,332,992 search allocation bytes/77 files/one version. scale-comparison.zip has 119 members, stores shared identical input/oracles once, and preserves the key regression plus TWO FAILED 8192-record pilots. Both pilots exceed sampled 640 MiB RSS and time out on daemon status before full index/output verification. R1 last progress 3140/8322 and peak RSS691466240; R2 3380/8322 and peak RSS689385472, anonymous562397184/file125710336 and memory.high69779. These partial points are not completed-run performance comparisons. Pressure is observed; exact IPC cause remains unclassified. Review this leaf's actual claims, not a claim to resolve that open scale failure. Do not fabricate a full-scale waiver or attribute old failures to this change without evidence.

Other changed archives finalize already merged PR67 and PR68 with gates, public review readbacks, CI and same-tree merges. PR68's Mempal production fix is in BASE_SHA, not this review's implementation diff. Its original unrelated full-gate MEMPAL_CONVERSION_BUSY occurrence remains unclassified despite independent deterministic lock repair. Historical 767b39e canonical PASS is not this candidate's gate. Use E/mvp024-index-prune-canonical-r3-verified.json and its complete raw log as supplied exact-HEAD gate evidence after re-attesting identity; do not rerun it or label it independently executed.

Run these maintained commands once, capture complete stdout/stderr and separate exits in E/mvp024-index-prune-review-r1-tests.log:
cargo test --locked --offline --lib retrieval::
cargo test --locked --offline --test daemon retrieval::
cargo clippy --workspace --all-targets --locked --offline -- -D warnings
Use pinned Rust1.99.1, existing SSD target/sccache/TMPDIR. Verify actual invocation provenance with cargo/rustc resolution/version; prefer non-login /bin/bash and explicit pinned environment. Absolute cargo/rustc are under /home/obj/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/. Preserve lexical CARGO_TARGET_DIR=/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/target and the existing target symlink; /ssd resolves to /mnt/ssd but the canonical lexical link is required. Require nonzero selected counts and propagate any command failure. Additional tests require a concrete scoped concern, not another campaign.

After head/tree/base/origin/clean/index-lock postflight, write E/mvp024-index-prune-review-r1.md. First and last nonempty lines identical VERDICT: PASS or VERDICT: FAIL. Include exact HEAD/TREE/BASE, ACTIONABLE_COUNT, explicit ORIGIN on findings, actual command exits/counts, test-log SHA256, supplied gate identity and precise path:line citations with the named operations actually on those lines. Zero actionable regressions/leaf contract gaps required for PASS; list pre-existing concerns separately. Keep report concise and evidence-bound. Hash final bytes externally after report write and re-attest source custody. Parent owns shared WD; do not start another watchdog.

Final response only, in this order:
VERDICT: PASS or FAIL
ACTIONABLE_COUNT: integer
REPORT: absolute path
REPORT_SHA256: digest
TEST_LOG: absolute path
TEST_LOG_SHA256: digest
HEAD_SHA: exact commit
