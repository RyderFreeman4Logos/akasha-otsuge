VERDICT: FAIL
ACTIONABLE_COUNT: 1

Independent native Codex fallback; conventional, read-only review of the entire frozen origin/main...HEAD range (19 paths). This is a partial #65 leaf. Hermes was not retried and no reviewer was spawned.

HEAD: b801af9409ef76519714ad0558314fe57a1ba114
TREE: a783ca14b4078986cccdccd71286b39f73019790
BASE (merge-base): e7cef25276e0737d781b5cfac69504c70c15818d
origin/main: 9f2ba152529a796383204a8a98dd89a5c6af6616
Branch: feat/mvp-024-index-maintenance

Finding — ORIGIN: REGRESSION; MODERATE leaf-contract gap: pruning does not recheck job ownership.

The new call at src/daemon/retrieval.rs:229 invokes prune_versions with authorize_index_work at :231. That helper reads the job at :91, calls authorize_job at :93, and checks cancellation, stopping and the original deadline at :95/:97/:99. It never verifies job.state == "running" or job.lease_owner == self.instance. The reachable authorize_job implementation only checks the retrieval job's Domain permission (src/daemon/jobs.rs:1041 through :1051); job() validates record shape, not current execution ownership (src/daemon/jobs.rs:911). Consequently the new per-table authorization at src/retrieval.rs:309 does not satisfy the brief's explicit requirement to check job ownership before every native prune. The actual running/lease-owner check is src/daemon/retrieval.rs:264, after retrieval_result has returned and cleanup has already happened.

Add the existing running/lease-owner predicate to the pre-prune authorization and cover rejection with a maintained lifecycle regression. Attribution is to the newly introduced destructive prune admission, not to the otherwise equivalent extraction of the older rebuild callback. Static inspection establishes the missing check; no takeover or data-loss race was reproduced. The current scheduler claims local jobs and retains an owned ID until its task returns (src/daemon/jobs.rs:1510, :1560, :1790), so this report does not claim an ordinary scheduler takeover was observed. Nevertheless, an entry-time ownership invariant is not the expressly requested per-prune ownership check. The zero-contract-gap acceptance rule makes this finding blocking.

Other reviewed behavior

- Reader exclusion is coherent. retrieval_index clones the cached Arc under search_index at src/daemon/retrieval.rs:64/:84; the builder mutex at :151 serializes sync/rebuild. At :221–:234, the prune branch requires completion or 32 windows, obtains try_lock, checks pointer identity and exactly two owners at :224, and retains the guard through the await at :233. A failed exclusion attempt does not reset the counter. Completion still retries cleanup on a later idle sync. Continuous readers may defer reclamation indefinitely; no bound is claimed.
- Both direct searches (:250) and consult memory_search (src/daemon/consult_research.rs:188/:193) transfer the parent Arc into Service::search. Its lexical query is awaited at src/daemon/retrieval/search.rs:32; the vector query is acquired at :111 and awaited at :118; the parent is explicitly dropped only at :406. Index::keyword consumes its stream before return (src/retrieval.rs:497); VectorIndex::search does likewise (src/retrieval/vector.rs:361). There is no detached query stream or vector handle escaping those actual daemon callers. The cache-to-vector lock order in prune (:307) has no reachable vector-to-cache reverse acquisition. Its authorization callback does not acquire admission; existing readers cause deferral instead of a lock wait cycle. No introduced deadlock was found.
- src/retrieval.rs:311 uses only Prune with zero age, delete_unverified=false and error_if_tagged_old_versions=true. The loop covers the lexical table and cached vector table (:308), not other generation tables. Authority/history storage is untouched. Explicit rebuild's existing retire_previous_tables behavior remains separate (:271); ordinary pruning does not retire prior vector generations.
- Both existing initialization paths create missing key/scope BTree indexes at src/retrieval.rs:424/:427 and src/retrieval/vector.rs:294/:297, then retain existing index optimization at :452 and :325 respectively. Initialization remains conditional on the existing sync/change paths, not an unconditional idle migration. NativeBatch still coalesces keys, deletes at src/retrieval/batch.rs:49 and merges updates/inserts at :56–:62. Replay and current-state revision filtering are unchanged. The pinned native implementation supports indexed merge-key lookup and scans unindexed fragments; the maintained regression observes ordinary key lookup plans, not a merge execution plan.

Pinned API inspection

Cargo.toml:28 pins LanceDB b1b080b97c3edd2fd9f2aae8a3b71ff19487b1f8; its local checkout HEAD matches and tracked files are clean (only .cargo-ok untracked). In /home/obj/.cargo/git/checkouts/lancedb-1a2acba6991cbf94/b1b080b/rust/lancedb/src/table/optimize.rs:229, Prune forwards the three options; :139 awaits Dataset::cleanup_old_versions, and :144 handles signature sidecars. Index optimization at :110 is followed by dataset.update at :111.

Cargo.lock:2985 pins lance 13.0.0. Its cached crate SHA-256 matches lock checksum 0e8dc0a0759fa0fcdbb970eec48ade5d02dbbd255147ff1f7b06d402d2f86b97, and the inspected dataset.rs, dataset/cleanup.rs and dataset/write/merge_insert.rs bytes match that archive. Under /home/obj/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/lance-13.0.0/src/, dataset.rs:1505 converts age to now-minus-age. dataset/cleanup.rs:603 protects current/newer manifests, :513 rejects tagged obsolete versions before deletion, and :1459/:1495 preserve the unverified-file policy. dataset/write/merge_insert.rs:1293 selects equality-capable indexes, :1317 identifies unindexed fragments, and :1598 selects indexed joins when all join keys qualify. These are source observations, not inferred API-name semantics or measured merge plans.

Fresh checks and supplied gate

Invocations used non-login /bin/bash, explicit pinned PATH/RUSTC/RUSTUP_TOOLCHAIN, and the unchanged lexical SSD target/symlink. cargo resolves to /home/obj/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/cargo, version 1.99.1 (5f94df478 2026-08-27); rustc resolves to the sibling rustc, version 1.99.1 (58cf8f9c3 2026-10-13). Existing sccache wrapper and TMPDIR were retained. Full combined stdout/stderr and individual exits are in /home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/.git/akasha-evidence/mvp024-index-prune-review-r1-tests.log.

| Command | Exit | Actual selected result |
| --- | ---: | --- |
| cargo test --locked --offline --lib retrieval:: | 0 | 8 passed, 1 ignored child, 103 filtered |
| cargo test --locked --offline --test daemon retrieval:: | 0 | 0 selected, 181 filtered; rejected as coverage evidence |
| cargo clippy --workspace --all-targets --locked --offline -- -D warnings | 0 | passed |
| cargo test --locked --offline --test daemon retrieval_tests:: | 0 | 26 passed, 0 ignored, 155 filtered |

Each requested command ran once. The sole additional invocation corrected the concrete empty-selector problem: tests/daemon.rs:24 names retrieval_tests. The zero-selection failure is retained explicitly in the log, not presented as a test pass. Corrected fresh coverage is 34 passes and one intentional ignored child.
TEST_LOG_SHA256: 262e9e504a4ee5749c4777d6957b79d750b9ce36f9fe726598ce4e7d88f276b7

Supplied, not independently executed: mvp024-index-prune-canonical-r3-verified.json, its admission/terminal receipts, and complete mvp024-index-prune-canonical-r3.log. Re-attested HEAD/TREE/BASE/origin and all 19 scoped blobs match. Raw-log SHA-256 is a2d60da2b569fcb3879a7d2c6cbe33c4f0ce967cce09bf2286af82cd5b0de392 (72,181 bytes); terminal exit is 0. Its 22 Rust summary blocks total 640 passes/39 ignores, with supplied Python 35, Node 7 and installed smoke PASS. This gate does not remove the static contract gap. Historical 767b39e PASS was not substituted.

Evidence audit and limits

All changed archives match their manifest ZIP sizes/digests; every member was decompressed and its size/SHA-256 checked, with exact membership and no duplicate names. Counts: native-prune/evidence.zip 90; native-prune/scale-comparison.zip 119; mempal-output-lock/finalization.zip 39; mvp024-production-pilot/finalization.zip 63. See mvp024-index-prune-review-r1-archives.json for archive digests.

The pruning RED log records [6,7] and [4,4] retained versions versus [1,1]. The original 179-line test prefix is byte-identical to its archived source. Tests inspect complete native ID/revision sets (tests/support/retrieval_maintenance.rs:61), current/history payloads (:98/:102), a held reader (:162/:165) and later reclamation (:174). The key test's first two attempts were E0603/E0277 fixture compilation failures; the third compiled and failed absent indexes/scanning plans. That third source equals HEAD bytes. It asserts correct rows (:237) and ScalarIndexQuery (:247) for both tables. src/retrieval/tests.rs:175 retains the same <=8 assertion; only its comment changed.

The 1,024-record pilot retains the recorded 1,042 current hashes/eight scoped witnesses, 5,332,992 search allocation bytes/77 files/one version. It is not ANN, full native-body, or full-scale proof. Both 8,192-record pilots remain FAILED: 3,140/8,322 at RSS 691,466,240 and 3,380/8,322 at RSS 689,385,472. Shared input/oracle hashes match both receipts; the second records anonymous 562,397,184/file 125,710,336 and memory.high 69,779. Both fail daemon status before full verification. Pressure is observed, exact IPC causality remains unclassified, and these partial points are not completed performance comparisons. The changed claims preserve these limits (docs/benchmarks/results/mvp024-native-prune/README.md:80, :99; docs/benchmarks/production-scale.md:74).

PR67/PR68 finalization archives preserve gates, public review readbacks, CI and merge receipts. CI gzip contents were also verified against raw-log hashes. Local Git objects confirm same-tree merges e5746ac→b71b18d and e7cef25→9f2ba15. These are archived publication observations, not fresh network readbacks. PR68's Mempal production fix is already in BASE, outside this implementation diff. No additional pre-existing code finding is asserted. The historical unrelated MEMPAL_CONVERSION_BUSY occurrence remains unclassified; the deterministic lock repair does not explain it. Full #65 acceptance remains open; no waiver is created.

Filesystem instructions and custody

Actual-filesystem checks preceded source inspection. All applicable AGENTS.md/CLAUDE.md paths are absent, including logical /home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025 and supplied /mnt/ssd/... checkout ancestors, and nested src, src/daemon, src/daemon/retrieval, src/retrieval, tests/support and changed documentation ancestors. mvp024-index-prune-review-r1-instructions.json lists every logical path, resolved path and filesystem-confirmed absence (58 entries); absence has no line count. The unrelated .spike-work/helix-db and .spike-work/lancedb-v040 symlink trees contain instructions, recorded separately with resolved paths/line counts (57, 150 and 157 lines), and do not govern this leaf. No Git-tree absence was used as filesystem proof.

Postflight confirms exact HEAD/tree/base/origin, clean tracked/untracked status, all 19 working bytes equal frozen blobs, unchanged target symlink and absent index.lock; see mvp024-index-prune-review-r1-postflight.json. Only this external report, test log and small review receipts were authored. Final report bytes are hashed externally and source custody is checked again after writing.

Skipped as instructed: canonical rerun, scale workloads, corpus rereads, archived-driver execution, native-child transcripts, publication, installation and new adversarial campaigns. Remaining risk: per-prune job ownership is unverified at the mutation boundary; full-scale acceptance is still incomplete.
VERDICT: FAIL
