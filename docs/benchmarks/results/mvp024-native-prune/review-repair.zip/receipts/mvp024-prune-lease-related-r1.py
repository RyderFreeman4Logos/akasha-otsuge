import json, subprocess, sys
commands = [['cargo', 'fmt', '--all', '--', '--check'], ['cargo', 'test', '--locked', '--offline', '--lib', 'retrieval::'], ['cargo', 'test', '--locked', '--offline', '--test', 'daemon', 'retrieval_tests::'], ['cargo', 'clippy', '--workspace', '--all-targets', '--locked', '--offline', '--', '-D', 'warnings']]
for command in commands:
    print(json.dumps({"command": command}), flush=True)
    result = subprocess.run(command)
    print(json.dumps({"exit_code": result.returncode, "command": command}), flush=True)
    if result.returncode: sys.exit(result.returncode)
