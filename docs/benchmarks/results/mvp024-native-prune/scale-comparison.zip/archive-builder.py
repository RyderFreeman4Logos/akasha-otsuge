import hashlib
import json
import pathlib
import subprocess
import zipfile

E = pathlib.Path(__file__).parent
W = pathlib.Path('/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025')
head = 'e36916ae640dbec501598c0b930532e8fc05c349'
git = lambda *args: subprocess.check_output(['git', '-C', str(W), *args])
assert git('rev-parse', 'HEAD').decode().strip() == head
assert not git('status', '--porcelain')
members = {}
for pattern in ('mvp024-merge-key-*', 'mvp024-production-scale-pilot-r*'):
    for path in sorted(E.glob(pattern)):
        assert path.is_file() and not path.is_symlink()
        members['receipts/' + path.name] = path.read_bytes()
shared = ['input-manifest.json', 'pilot.toml', 'binding.json', 'oracle.json', 'acks.jsonl']
for attempt in (1, 2):
    root = W / '.spike-work' / f'mvp024-production-scale-pilot-r{attempt}'
    assert not (root / 'data').exists()
    for path in sorted(root.iterdir()):
        assert path.is_file() and not path.is_symlink()
        data = path.read_bytes()
        name = 'shared/' + path.name if path.name in shared else f'pilot-r{attempt}/' + path.name
        if name in members:
            assert members[name] == data
        else:
            members[name] = data
    receipt = json.loads((E / f'mvp024-production-scale-pilot-r{attempt}-failure-verified.json').read_text())
    for name, expected in receipt['metadata'].items():
        data = (root / name).read_bytes()
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
for name in ('mvp024-index-prune-canonical-r2.log', 'mvp024-index-prune-canonical-r2.terminal.json',
             'mvp024-index-prune-canonical-r2-preflight.json', 'mvp024-index-prune-canonical-r2-verified.json'):
    members['historical-canonical/' + name] = (E / name).read_bytes()
paths = ['src/retrieval.rs', 'src/retrieval/vector.rs', 'src/retrieval/tests.rs',
         'tests/support/retrieval_maintenance.rs']
for pin in ('767b39e81a5faaf70533e8c395a4cda1bd2b11d1', head):
    for path in paths:
        members['source/' + pin + '/' + path] = git('show', pin + ':' + path)
identity = {
    'head': head, 'tree': git('rev-parse', head + '^{tree}').decode().strip(),
    'scope': 'Merge-key index RED/GREEN and two failed identical-input 8192-record production pilots. Neither scale run passed indexing or final content oracles. Historical canonical belongs to 767b39e only.',
    'shared_members': shared,
    'omitted': 'Native stores and socket roots were removed after guarded cleanup; their complete file hashes and allocation census remain. Reusable source corpus is not copied.',
}
members['identity.json'] = (json.dumps(identity, indent=2) + '\n').encode()
members['archive-builder.py'] = pathlib.Path(__file__).read_bytes()
archive = E / 'mvp024-index-maintenance-scale.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as target:
    for name, data in members.items():
        assert not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts
        info = zipfile.ZipInfo(name, (2026, 11, 11, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        target.writestr(info, data)
manifest = {**identity, 'zip_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
            'zip_bytes': archive.stat().st_size,
            'members': {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                        for name, data in members.items()}}
with zipfile.ZipFile(archive) as target:
    assert len(target.namelist()) == len(set(target.namelist())) == len(members)
    for name, expected in manifest['members'].items():
        data = target.read(name)
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
(E / 'mvp024-index-maintenance-scale-manifest.json').open('x').write(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'archive': str(archive), 'members': len(members), 'bytes': manifest['zip_bytes'], 'sha256': manifest['zip_sha256']}))
