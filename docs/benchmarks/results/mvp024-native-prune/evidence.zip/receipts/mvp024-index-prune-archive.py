"""Preserve the exact small maintenance attempt and paired pilot receipts."""
import hashlib
import json
import pathlib
import subprocess
import zipfile

w = pathlib.Path.cwd()
e = pathlib.Path(__file__).parent
destination = w / 'docs/benchmarks/results/mvp024-native-prune'
destination.mkdir(parents=True, exist_ok=False)
members = {}

def add(name, data):
    assert name not in members and not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts
    members[name] = data

for path in sorted(e.iterdir()):
    if path.is_file() and path.name.startswith(('mvp024-index-prune-', 'mvp024-production-pilot-r3')):
        add('receipts/' + path.name, path.read_bytes())
root = (w / '.spike-work/mvp024-production-pilot-r3').resolve()
verified = json.loads((e / 'mvp024-production-pilot-r3-verified.json').read_text())
assert not (root / 'data').exists()
for name, expected in sorted(verified['metadata'].items()):
    assert pathlib.Path(name).name == name
    data = (root / name).read_bytes()
    assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
    add('pilot-r3/' + name, data)
baseline = (w / '.spike-work/mvp024-production-pilot-r2').resolve()
for name in ['admission.json', 'result.json', 'state.json']:
    add('baseline-r2/' + name, (baseline / name).read_bytes())
pins = ['e5746acbaffbd6189fca51f9248249fb6d1f6585', 'c0b9a969cc151ddc059c464d5dde1d5dfcdd0c0b']
paths = ['src/daemon/retrieval.rs', 'src/retrieval.rs', 'src/retrieval/vector.rs', 'tests/support/daemon_retrieval.rs']
for pin in pins:
    for name in paths + (['tests/support/retrieval_maintenance.rs'] if pin == pins[1] else []):
        add(f'source/{pin}/{name}', subprocess.check_output(['git', 'show', f'{pin}:{name}']))
notes = {
    'scope': 'Reclaim obsolete derived native versions under exclusive index ownership; preserve authoritative history and defer to readers.',
    'red_green': 'Both unchanged real-daemon tests first failed only their final retained-version assertions, then passed; related retrieval tests and Clippy passed before the normal commit.',
    'paired_custody': 'R3 preserves all R2 inputs, policy, binding, acknowledgements and full current-claim oracle. Its seeder binary is unchanged; its daemon is bound to committed c0b9a96.',
    'cleanup_failure': 'The first global procfs guard refused 135 zombies and 26 unrelated pre-existing non-dumpable services before deletion. A subsequent scoped guard verified every pilot process absent and its owned cgroup gone; it recorded unrelated-service exclusions and retained all metadata before removing only the two exclusive disposable roots.',
    'limits': [
        'One 1024-source-record lexical pilot; no interval, cache eviction, full native-body oracle, ANN or full-scale acceptance.',
        'Ordinary held-query functional test is not a Daybreak or adversarial campaign.',
        'Pruning is attempted every 32 authority windows and at sync completion; active owners defer it. Continuous readers can defer reclamation.',
        'Recent unknown unreferenced native files are preserved; this is not all-file garbage collection or compaction.',
        'Prior vector generations and all authoritative histories are outside this version-pruning action.',
        'Final canonical gate, independent review and publication are separate receipts; #65 remains open.',
    ],
}
add('scope-and-custody.json', (json.dumps(notes, indent=2) + '\n').encode())
target = destination / 'evidence.zip'
with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(members.items()):
        info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
manifest = {'schema_version': 1, 'source_pins': pins, 'zip_sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
            'zip_bytes': target.stat().st_size,
            'members': {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in sorted(members.items())}}
(destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None and sorted(archive.namelist()) == sorted(members)
    for name, item in manifest['members'].items():
        data = archive.read(name)
        assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
print(json.dumps({'files': len(members), 'zip_bytes': manifest['zip_bytes'], 'zip_sha256': manifest['zip_sha256']}))
