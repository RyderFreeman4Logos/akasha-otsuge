import hashlib
import json
import pathlib
import subprocess
import sys
import zipfile

E = pathlib.Path(__file__).parent
W = pathlib.Path('/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025')
head = sys.argv[1]
git = lambda *args: subprocess.check_output(['git', '-C', str(W), *args])
assert git('rev-parse', 'HEAD').decode().strip() == head
assert not git('status', '--porcelain')
members = {}
for pattern in ('mvp024-prune-lease-*', 'mvp024-index-prune-review-r1*',
                'mvp024-index-prune-review-launch-r1*', 'mvp024-index-prune-canonical-r3*'):
    for path in sorted(E.glob(pattern)):
        if path.suffix in ('.stdout', '.stderr') or path.name.endswith('.final.txt'):
            continue
        assert path.is_file() and not path.is_symlink()
        members['receipts/' + path.name] = path.read_bytes()
members['review-brief.md'] = (W / '.review/mvp024-index-prune-r1-brief.md').read_bytes()
members['source/' + head + '/src/daemon/retrieval.rs'] = git('show', head + ':src/daemon/retrieval.rs')

def archive(stem, content, scope):
    identity = {'head': head, 'tree': git('rev-parse', head + '^{tree}').decode().strip(),
                'scope': scope, 'native_data': 'Removed after hash/ownership/cgroup/FD checks; inventories retained.'}
    content['identity.json'] = (json.dumps(identity, indent=2) + '\n').encode()
    content['archive-builder.py'] = pathlib.Path(__file__).read_bytes()
    path = E / (stem + '.zip')
    with zipfile.ZipFile(path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
        for name, data in content.items():
            assert not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts
            info = zipfile.ZipInfo(name, (2026, 11, 11, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            out.writestr(info, data)
    manifest = {**identity, 'zip_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                'zip_bytes': path.stat().st_size,
                'members': {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                            for name, data in content.items()}}
    with zipfile.ZipFile(path) as saved:
        assert len(saved.namelist()) == len(set(saved.namelist())) == len(content)
        for name, expected in manifest['members'].items():
            data = saved.read(name)
            assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
    with (E / (stem + '-manifest.json')).open('x') as out:
        json.dump(manifest, out, indent=2)
        out.write('\n')
    print(json.dumps({'archive': stem, 'members': len(content), 'bytes': manifest['zip_bytes'],
                      'sha256': manifest['zip_sha256']}))

archive('mvp024-index-maintenance-review-repair', members,
        'Historical b801 canonical PASS and independent R1 FAIL; unchanged-test lease RED/GREEN, related checks and normal repair commit. Not final successor gate/review or scale acceptance.')

members = {}
for pattern in ('mvp024-production-allocator-observe-r1*', 'mvp024-production-mmap-control-r1*',
                'mvp024-allocator-observation-r1*', 'mvp024-allocator-observer-r1*',
                'mvp024-pending-fts-maintenance-budget-r1.json'):
    for path in sorted(E.glob(pattern)):
        assert path.is_file() and not path.is_symlink()
        members['receipts/' + path.name] = path.read_bytes()
shared = ('input-manifest.json', 'pilot.toml', 'binding.json', 'oracle.json', 'acks.jsonl')
references = {}
for name in ('mvp024-production-allocator-observe-r1', 'mvp024-production-mmap-control-r1'):
    root = W / '.spike-work' / name
    assert not (root / 'data').exists()
    verified = json.loads((E / (name + '-verified.json')).read_text())
    for path in sorted(root.iterdir()):
        assert path.is_file() and not path.is_symlink()
        data = path.read_bytes()
        expected = verified['metadata'][path.name]
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
        if path.name in shared:
            assert data == (W / '.spike-work/mvp024-production-scale-pilot-r2' / path.name).read_bytes()
            references[name + '/' + path.name] = {'archive': 'scale-comparison.zip',
                                                'member': 'shared/' + path.name, **expected}
        else:
            members[name + '/' + path.name] = data
members['shared-input-references.json'] = (json.dumps(references, indent=2) + '\n').encode()
observer = W / '.spike-work/mvp024-allocator-observer-r1'
for path in sorted(observer.iterdir()):
    assert path.is_file() and not path.is_symlink()
    members['observer/' + path.name] = path.read_bytes()
archive('mvp024-index-maintenance-allocator-diagnostics', members,
        'Diagnostic malloc observation failed a disk-stat race and lost cgroup delegation due to inherited preload. Fixed mmap threshold alone still failed IPC at 6270/8322 and exceeded sampled 640 MiB RSS. Neither is acceptance; original IPC cause remains unclassified. Source fixed at b801 with b909 binary; referenced shared inputs are stored once in existing scale-comparison.zip.')
