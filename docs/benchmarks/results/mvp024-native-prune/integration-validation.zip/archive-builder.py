import pathlib,json,hashlib,zipfile,subprocess
E=pathlib.Path("/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/.git/akasha-evidence");W=pathlib.Path.cwd()
g=lambda *a:subprocess.check_output(['git',*a],text=True).strip()
assert g('rev-parse','HEAD')=='2512229320e7fab90cc2a587cf7643e71569eda1'
assert not g('status','--porcelain')
members={}
patterns=('mvp024-index-prune-canonical-r4*','mvp024-installed-timeout-diagnostic-r1*','incident-revocation-canonical-r1*','incident-revocation-canonical-r2*','incident-revocation-review-r1*','incident-revocation-ci-attempt1*','incident-revocation-ci-attempt2*','incident-revocation-ci-wait-r2-transport-failure.json','incident-revocation-ci-pr-r3.json','incident-revocation-ci-blocked-publication-r1.json','mvp024-maintenance-foundation-integration-r1*')
for pattern in patterns:
 found=sorted(E.glob(pattern));assert found,pattern
 for p in found:
  if p.suffix in ('.stdout','.stderr') or p.name.endswith('.final.txt'):continue
  assert p.is_file() and not p.is_symlink()
  members['receipts/'+p.name]=p.read_bytes()
for name in ['mvp024-index-prune-canonical-r5-failure-verified.json','mvp024-incident-roots-causal-classification-r1.json']:
 members['receipts/'+name]=(E/name).read_bytes()
identity={'integration_head':g('rev-parse','HEAD'),'integration_tree':g('rev-parse','HEAD^{tree}'),'foundation_head':'bcec374895bed1f26491524059cf6a121fc0cc85','maintenance_before':'51631472a175317695c4ec303435d4cacbc97705','scope':'Historical failures, two exact foundation gates, complete independent review and two hosted apt/DNS failures. Local forward integration only; merged candidate validation and all scale acceptance remain pending.','prior_evidence':'../incident-revocation/evidence.zip preserves original r5 failure and focused repair; review-repair.zip preserves earlier maintenance R1 FAIL and lease repair.'}
members['identity.json']=(json.dumps(identity,indent=2)+'\n').encode()
members['archive-builder.py']=pathlib.Path(__file__).read_bytes()
root=W/'docs/benchmarks/results/mvp024-native-prune'
z=root/'integration-validation.zip'
with zipfile.ZipFile(z,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as out:
 for name,data in sorted(members.items()):
  assert not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts
  i=zipfile.ZipInfo(name,(2026,11,11,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;out.writestr(i,data)
manifest={**identity,'zip_sha256':hashlib.sha256(z.read_bytes()).hexdigest(),'zip_bytes':z.stat().st_size,'members':{n:{'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()} for n,d in sorted(members.items())}}
with zipfile.ZipFile(z) as inp:
 assert len(inp.namelist())==len(set(inp.namelist()))==len(members)
 for name,value in manifest['members'].items():
  data=inp.read(name);assert len(data)==value['bytes'] and hashlib.sha256(data).hexdigest()==value['sha256']
with (root/'integration-validation-manifest.json').open('x') as out:json.dump(manifest,out,indent=2);out.write('\n')
print(json.dumps({'bytes':manifest['zip_bytes'],'members':len(members),'sha256':manifest['zip_sha256']}))
