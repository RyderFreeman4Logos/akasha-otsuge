import json, pathlib, runpy, subprocess, sys
script = pathlib.Path('scripts/check_daemon_command.py')
sys.argv = [str(script), 'target/release/akasha-otsuge', '--install']
try:
    runpy.run_path(str(script), run_name='__main__')
except subprocess.TimeoutExpired as error:
    print(json.dumps({'failure': 'TimeoutExpired', 'command': error.cmd, 'timeout_s': error.timeout}), flush=True)
    for name, value in [('captured_stdout', error.output), ('captured_stderr', error.stderr)]:
        if value is not None:
            print(name, flush=True)
            sys.stdout.buffer.write(value if isinstance(value, bytes) else value.encode())
            sys.stdout.buffer.flush()
    raise
