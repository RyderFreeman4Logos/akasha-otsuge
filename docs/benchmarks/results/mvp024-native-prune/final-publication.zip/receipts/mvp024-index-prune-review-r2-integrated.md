VERDICT: PASS
ACTIONABLE_COUNT: 0

Independent conventional native Codex R2 fallback review of the entire frozen `origin/main...HEAD` range: all 29 paths in `mvp024-index-prune-review-r2-integrated-scope.json`. No actionable regression or outstanding leaf-contract gap was found. This qualifies only the partial Issue #65 maintenance/fixture leaf, not full scale/resource acceptance, hosted CI, installation or publication. Hermes was not retried; no reviewer, relay or campaign was spawned.

HEAD_SHA: 2987eb1e744d2a2c55e642df3457b6156c8e2a88
TREE_SHA: f8396cd1e5db8acbaf0d223a89eb735828c67bed
BASE_SHA: 9f2ba152529a796383204a8a98dd89a5c6af6616
origin/main and merge-base: 9f2ba152529a796383204a8a98dd89a5c6af6616
Branch: feat/mvp-024-index-maintenance
W: /mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025
E: /home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/.git/akasha-evidence

Filesystem instructions and scope

Actual-filesystem checks of changed-file owners preceded source inspection. The completed instruction census records 144 AGENTS.md/CLAUDE.md paths, logical/resolved names and filesystem-confirmed absence; no applicable file was found, so no file line count applies. It includes /home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025, W, /ssd aliases, their ancestors through /, changed documentation owners, src/daemon/retrieval, src/retrieval, tests/support, the Codex fixture ancestry, and the original repository root. See E/mvp024-index-prune-review-r2-integrated-instructions.json. This is not Git-tree absence evidence. Full changed Rust source, the changed fixture, wiring, reachable native query/settlement operations, documentation changes and archive manifests were examined.

Ownership and maintenance

`src/daemon/retrieval.rs:154` serializes builders. `retrieval_index` acquires search_index at :64 and clones its Arc at :84. The prune branch at :224 attempts cleanup after 32 windows or completion; :225 uses try_lock, and :227 requires pointer identity plus exactly two strong owners. The cache guard remains in scope through the awaited prune at :236. Existing readers therefore defer cleanup, and new readers cannot clone the cache during it. Failed exclusion leaves the counter intact; a completed job can leave cleanup deferred until a later sync, whose completion branch retries even without new memory changes. Continuous readers can defer reclamation indefinitely.

Actual direct searches transfer the owner at `src/daemon/retrieval.rs:253`; consult memory_search obtains/transfers it at `src/daemon/consult_research.rs:188` and :192. `src/daemon/retrieval/search.rs:32` awaits lexical lookup, :111 obtains the vector handle, :118 awaits its search, and :406 explicitly drops the parent only after query processing. `src/retrieval.rs:497` and `src/retrieval/vector.rs:361` consume native streams through candidates before returning. No detached stream escapes these callers. Generation switching replaces the cached vector Arc, but an old query retains the parent and its selected handle. Pruning cannot overlap that reader.

`src/retrieval.rs:307` locks vector beneath the cache lock; no reachable vector-to-cache reverse acquisition was found. The synchronous authorization callback does not acquire admission. Existing readers cause deferral rather than a wait cycle. Rebuild separately refuses shared ownership at `src/daemon/retrieval.rs:123`; its existing retire_previous_tables operation remains distinct. Pruning visits only lexical plus the currently cached vector table at `src/retrieval.rs:308`, preserving other vector-generation tables and authoritative current/history storage.

R1 closure and error ordering

The preserved R1 FAIL and parent classification correctly identified a new destructive-operation contract gap despite the old canonical PASS. `src/daemon/retrieval.rs:93` now checks running state/current-instance ownership before authorize_job (:96), cancellation (:98), stopping (:100) and the original deadline (:102). This matches the existing finalization predicate at :267. Both callers were checked: rebuild's callback (:127), used by progress publication and table retirement, and prune's callback (:232). Pruning first checks live owner-scope permission (:233), then the shared predicate; each native table invokes it again at `src/retrieval.rs:309`. Lease errors precede the helper's permission/cancellation/deadline errors; the outer permission check can reject first. Errors propagate without authorizing native deletion. These are admission checks before each native operation, not a claim of mid-operation transactional revocation.

The maintained regression at `src/daemon/retrieval.rs:316` independently invalidates queued/current-owner and running/foreign-owner states, invokes actual retrieval_result at :368, compares complete version-ID sets at :398, and restores valid-owner pruning at :381/:402. Its archived RED returned Ok and changed [1,2,3,4] to [4]; the identical test region, including its leading newline, matches the preserved hash. Fresh execution passed. This closes the original ORIGIN: REGRESSION leaf-contract finding. It is a controlled snapshot fixture, not an observed scheduler takeover or data-loss race.

Pinned native semantics and indexes

Cargo's local LanceDB checkout is clean apart from .cargo-ok and matches b1b080b97c3edd2fd9f2aae8a3b71ff19487b1f8. Lance 13.0.0's crate checksum matches Cargo.lock; the inspected dataset, cleanup and merge_insert sources match that crate. In the pinned LanceDB checkout, `rust/lancedb/src/table/optimize.rs:229` forwards Prune options and :139 awaits cleanup_old_versions. In Lance, `src/dataset.rs:1505` converts zero age to now; `src/dataset/cleanup.rs:603` protects current/newer manifests, :513 rejects tagged obsolete versions before deletion, and :743 preserves recent unverified files. Thus older_than=0 does not delete the current version; delete_unverified=false is not an all-orphan-reclamation promise. Native errors become INDEX_IO.

`src/retrieval.rs:424` and `src/retrieval/vector.rs:294` create missing key/scope BTree indexes using the existing API; :452/:325 retain native index maintenance. Initialization remains conditional on existing sync/change paths, not an unconditional idle migration. `src/retrieval/batch.rs:49` deletes keys and :56 builds merge_insert updates/inserts; current-revision filtering and idempotent replay remain intact. Pinned merge_insert.rs:1293 selects equality-capable indexes and :1317 accounts for unindexed fragments. The regression checks correct rows at `tests/support/retrieval_maintenance.rs:237` and actual ScalarIndexQuery lookup plans on both tables at :247; it does not observe a merge execution plan. `src/retrieval/tests.rs:175` retains the original <=8 assertion; only its comment changed.

Incident fixture

The sole behavior change is conditional editor-release creation at `tests/support/daemon_incident.rs:431`. `tests/support/daemon_codex.rs:57` constructs the maintained protocol runner and records starts/PID. `tests/fixtures/codex/0.164.0/runner_host.py:280` signals readiness, :282 waits, and :312 constructs normal completion only afterward. Withholding release for roots_off excludes buffered normal success before restoration.

`src/daemon/models.rs:128` obtains live authorization failure; `src/daemon/consult_run.rs:242` retains that failure before :247 awaits cancellation. `src/daemon/editor_workflow.rs:257` propagates failure before checkpoint/apply; successful paths independently reauthorize at :287/:326. `src/daemon/consult.rs:421` persists the failed outcome, and `src/daemon/incident.rs:381` waits for terminal state before :424 copies the error. Immediate PATH_DENIED (:437), full unchanged-memory equality (:468), one start (:480) and replay assertions (:488) remain. No production authority, assertion or deadline was weakened. PID disappearance alone is not signal-level cancellation proof: the existing 15-second runner barrier can also cause abnormal exit. The later finished-state/error assertions establish the tested terminal contract.

Fresh checks

Each command ran exactly once under nonlogin /bin/bash, with full stdout/stderr and separate exits in E/mvp024-index-prune-review-r2-integrated-tests.log. Actual cargo/rustc paths were /home/obj/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/{cargo,rustc}; versions were 1.99.1 (5f94df478) and 1.99.1 (58cf8f9c3). Inherited sccache/TMPDIR were retained. Lexical CARGO_TARGET_DIR remained /ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/target, resolving under /mnt/ssd.

| Command | Exit | Actual result |
| --- | ---: | --- |
| cargo test --locked --offline --lib retrieval:: | 0 | 9 passed, 1 ignored, 103 filtered |
| cargo test --locked --offline --test daemon retrieval_tests:: | 0 | 26 passed, 155 filtered |
| cargo test --locked --offline --test daemon incident_tests:: | 0 | 9 passed, 1 ignored, 171 filtered |
| cargo test --locked --offline --test daemon editor_tests:: | 0 | 17 passed, 1 ignored, 163 filtered |
| cargo fmt --all --check | 0 | clean |
| cargo clippy --workspace --all-targets --locked --offline -- -D warnings | 0 | clean |

Total: 61 passes, three intentional ignores, no retries or extra product tests.
TEST_LOG_SHA256: c2235e74e29af9cafca02d38fcec9ffd31b88f3488d37be17819787570a5d5b7

Supplied gate and evidence limits

R6 was supplied, not independently executed. Admission records `just check`; verified/terminal receipts bind the exact HEAD/tree/base and all 29 source hashes. Its 72,539-byte raw log hashes to afacffcc7c584326ddf911449943523582b7079ac0869ddce22e2558431f7e97; 22 Rust summaries total 641 passes/39 ignores, with Python 35, Node 7 and installed lifecycle/UID/TCP checks. Terminal exit is zero. Verified-receipt SHA256: fb8c8d456e9aa17c51541000370e0c747cbfc225d126665e6f9c77979ade92fc.

All changed ZIP sizes/hashes and every decompressed member match manifests, with exact membership/no duplicates. Counts: native evidence 90, scale 119, repair 56, allocator 63, incident 19, integration 55, PR68 finalization 39, PR67 finalization 63. Ten allocator shared-input references match scale-comparison.zip. Archive receipts are E/mvp024-index-prune-review-r2-integrated-archives.json and -evidence-checks.json. No archived script executed. Original 179-line pruning tests and final key-test RED source match current bytes; key fixture compilation failures remain separate from behavioral RED.

The 1,024-record pilot verifies 1,042 current hashes/eight witnesses, 5,332,992 search bytes/77 files/one version. Both 8,192-record pilots remain failed at 3,140/3,380 of 8,322, RSS 691,466,240/689,385,472. Allocator observation failed transient census at 3,508, with all cgroups unavailable; peak estimated live 116,291,711 coexisted with arenas 505,516,032/free 420,943,745. Preload reproduces busctl exit121 separately; discarded original helper status prevents causal proof. Mmap-only control under original limits still failed IPC at 6,270, RSS679,796,736, five/127 over640MiB, kernel555,077,632 and zero sampled OOM. Original inherited allocator environment is unknown. Cleanup receipts preserve ownership/full hashes/removal of disposable stores. No completed latency/output comparison follows.

ORIGIN: PRE-EXISTING, nonblocking here: creation-only FTS update-budget gap remains documented for the next leaf, not repaired or proved as historical IPC cause. R4's discarded timeout stdout leaves last test/cause unknown; the unchanged 172-pass/9-ignore diagnostic in251.03s does not waive it. R5's isolated pass does not waive its early-regrant failure. Foundation bcec374's two gates and full independent review remain historical, separately verified evidence. Integration archive identity is 2512229, not documentation HEAD2987eb1. Both hosted attempts failed apt DNS before project checks; gzip/raw hashes agree. PR69 remains draft in archived receipts; no fresh remote readback/publication is claimed. PR67/68 local merge trees match reviewed trees; Mempal production repair is already in BASE, and its original busy occurrence remains unclassified.

Postflight confirms HEAD/tree/base/origin, clean porcelain, diff-check zero, absent index.lock and all 29 working bytes equal frozen blobs. Only named external outputs/receipts were written. Final report bytes are hashed externally, followed by source/index custody re-attestation.

Skipped: canonical rerun, scale workloads, native-child transcripts, secrets, archived execution, installation and publication. Remaining risks: indefinite reader deferral, unclassified historical failures, and incomplete full-scale/resource acceptance.
VERDICT: PASS
