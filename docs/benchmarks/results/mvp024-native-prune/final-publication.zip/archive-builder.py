import hashlib
import json
import pathlib
import subprocess
import zipfile

E = pathlib.Path(__file__).parent
W = pathlib.Path('/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025')
head = '2987eb1e744d2a2c55e642df3457b6156c8e2a88'
merge = '63acf39d2138bc582ee746b6eefede970fd3f8cc'
git = lambda *args: subprocess.check_output(['git', '-C', str(W), *args]).decode().strip()
tree = git('rev-parse', head + '^{tree}')
assert tree == git('rev-parse', merge + '^{tree}')
members = {}
for pattern in ('mvp024-index-prune-canonical-r6*', 'mvp024-index-prune-review-r2-integrated*',
                'mvp024-index-prune-review-launch-r2-integrated*', 'mvp024-index-maintenance-ci-*'):
    for path in sorted(E.glob(pattern)):
        if path.name.endswith(('.stdout', '.stderr', '.final.txt')):
            continue
        assert path.is_file() and not path.is_symlink()
        members['receipts/' + path.name] = path.read_bytes()
for name in ('mvp024-index-maintenance-merge-r1.json', 'mvp024-index-maintenance-pr-r1-readback.json',
             'mvp024-index-maintenance-push-r1.json', 'mvp024-index-maintenance-postmerge-status-r1.json'):
    members['receipts/' + name] = (E / name).read_bytes()
identity = {'head': head, 'merge': merge, 'tree': tree,
            'scope': 'Exact R6 gate, independent whole-range R2 review, successful hosted CI and merged PR70/69 readbacks. Full issue65 scale acceptance remains pending.'}
members['identity.json'] = (json.dumps(identity, indent=2) + '\n').encode()
members['archive-builder.py'] = pathlib.Path(__file__).read_bytes()
path = E / 'mvp024-maintenance-final-r1.zip'
with zipfile.ZipFile(path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
    for name, data in members.items():
        assert not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts
        info = zipfile.ZipInfo(name, (2026, 11, 16, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        out.writestr(info, data)
manifest = {**identity, 'zip_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'zip_bytes': path.stat().st_size, 'members': {
                name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                for name, data in members.items()}}
with zipfile.ZipFile(path) as saved:
    assert len(saved.namelist()) == len(set(saved.namelist())) == len(members)
    for name, expected in manifest['members'].items():
        data = saved.read(name)
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
with (E / 'mvp024-maintenance-final-r1-manifest.json').open('x') as out:
    json.dump(manifest, out, indent=2)
    out.write('\n')
print(json.dumps({'members': len(members), 'bytes': manifest['zip_bytes'], 'sha256': manifest['zip_sha256']}))
