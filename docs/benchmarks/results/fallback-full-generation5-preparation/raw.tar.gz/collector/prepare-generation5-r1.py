import datetime,fcntl,json,os,pathlib,shutil,subprocess,sys,time
repo=pathlib.Path.cwd();sys.path.insert(0,str(repo/'spikes/helix'))
from run_case import digest,process_identity,publish
storage=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023');base=storage/'fallback-full-generation5-r1';database=storage/'fallback-full-compressed-r1/database';frozen=repo/'.spike-work/partial-retirement-r2';source=json.loads((frozen/'source.json').read_text())
assert digest(frozen/'probe')==source['native_sha256']
for group in ['source_sha256','helpers_sha256']:
 for name,want in source[group].items():assert digest(repo/name)==want,name
publication=json.loads((repo/'.git/akasha-evidence/partial-retirement-publication.json').read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert publication['head']==publication['remote_head']==head and publication['exact_head_gate']=='passed' and publication['ci_conclusion']=='success'
assert json.loads((storage/'fallback-partial-retirement-green-r2/verified.json').read_text())['status']=='passed'
base.mkdir();(base/'OWNER').write_text('akasha-otsuge MVP-003 full generation5 preparation and partial candidate4 retirement\n')
plan=json.loads((storage/'fallback-full-generation4-r1/witness-plan.json').read_text());plan.update(binary=str(frozen/'probe'),binary_sha256=source['native_sha256'],query_comparison='candidate_set');assert len(plan['requests'])==66;publish(base/'witness-plan.json',plan)
publish(base/'admission.json',dict(controller=process_identity(os.getpid()),source=source,driver_sha256=digest(__file__),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=head,phases=['candidate4-before','66 before witnesses','retire incomplete4','candidate4-after','prune active3','66 after witnesses','begin5','backfill5'],competing_load='No other task-owned native benchmark or Cargo compilation; other user host activity uncontrolled'))
def inventory(name):
 components={}
 for parent,dirs,files in os.walk(database,followlinks=False):
  assert not any((pathlib.Path(parent)/d).is_symlink() for d in dirs)
  for filename in files:
   p=pathlib.Path(parent)/filename;assert not p.is_symlink();parts=p.relative_to(database).parts;key='/'.join(parts[:2]) if parts[0]=='derived' else parts[0];components[key]=components.get(key,0)+p.stat().st_blocks*512
 x=dict(allocated_bytes=components,free_bytes=shutil.disk_usage(database).free,note='inode allocation is not exclusive Btrfs extents; filesystem free includes concurrent host activity');publish(base/name,x);return x
def command_memory(phase,argv):
 unit='akasha-gen5-'+phase+'-r1';memory=base/(phase+'-memory.jsonl');command=['systemd-run','--user','--quiet','--wait','--pipe','--collect','--unit='+unit,'-p','MemoryMax=671088640','-p','MemorySwapMax=0','-p','LimitNOFILE=8192','-p','WorkingDirectory='+str(repo),'-p','Environment=MALLOC_MMAP_THRESHOLD_=131072','-p','Environment=AKASHA_SPIKE_PROFILE=low','-p','Environment=LANCE_CPU_THREADS=2',sys.executable,str(frozen/'measure.py'),str(memory),*argv];publish(base/(phase+'-command.json'),command)
 with (base/(phase+'.log')).open('x') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
 return memory,unit
def candidate_state(phase):
 request=base/(phase+'.request.json');publish(request,dict(op='status',generation=4))
 with (database/'.akasha-case-owner.lock').open('a') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB);memory,unit=command_memory(phase,[str(frozen/'probe'),str(database),'--generation',str(request)])
 rows=[json.loads(line) for line in memory.open()];assert rows[0]['limits']['memory.max']=='671088640' and rows[0]['limits']['memory.swap.max']=='0' and rows[0]['nofile_soft_hard']==[8192,8192];exes=[r for r in rows if r['event']=='executable'];assert len(exes)==1 and exes[0]['sha256']==source['native_sha256'];now=process_identity(exes[0]['pid']);assert now is None or now['start_ticks']!=exes[0]['start_ticks'];end=rows[-1];assert end['event']=='exit' and end['code']==end['native_code']==0 and end['scratch_cleanup']['removed'] and not pathlib.Path(end['scratch_cleanup']['path']).exists()
 samples=[r for r in rows if r['event']=='sample'];assert not any(int(r['memory_events'].get(k,0)) for r in samples for k in ['oom','oom_kill']);peak=max(r['engine_rss_bytes'] for r in samples);assert peak<=640*1024**2;assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip()=='inactive'
 replies=[json.loads(line) for line in (base/(phase+'.log')).read_text().splitlines() if line.startswith('{')];assert len(replies)==1;publish(base/(phase+'-verified.json'),dict(status='passed',reply=replies[0],rss_max_bytes=peak,exact_native_gone=True,unit_inactive=True,scratch_removed=True));return replies[0]
def witness(phase):
 memory,unit=command_memory('witness-'+phase,[sys.executable,str(repo/'.git/akasha-evidence/full-prune-witness.py'),str(base),phase]);subprocess.run([sys.executable,str(repo/'.git/akasha-evidence/collect-rebuild-recovery-step.py'),str(base/phase),str(memory),unit],check=True)
completed=[]
def operation(request):
 op=request['op'];publish(base/(op+'.request.json'),request)
 config=f'''[run]
id = "fallback-full-generation5-r1-{op.replace('_','-')}"
profile = "low"
seconds = 7200
[paths]
binary = "{frozen/'probe'}"
database = "{database}"
request = "{base/(op+'.request.json')}"
output = "{base/op}"
[disk]
start_bytes = 81212254720
reserve_bytes = 81212254720
[reliability]
max_attempts = 1
'''
 path=base/(op+'.toml');path.write_text(config);publish(base/'progress.json',dict(phase=op,completed=completed,controller=process_identity(os.getpid()),native_checkpoint=str(database/'generation-5-backfill.json')))
 with (base/(op+'.log')).open('x') as log:subprocess.run([sys.executable,str(frozen/'helix/run_generation.py'),str(path)],check=True,stdout=log,stderr=subprocess.STDOUT)
 subprocess.run([sys.executable,str(repo/'.git/akasha-evidence/verify-generation.py'),str(base/op)],check=True);reply=json.loads((base/op/'verified.json').read_text())['reply'];case=base/op;state=json.loads((case/'state.json').read_text());want=digest(case/'state.json')
 with (case/'completed-reuse.stdout').open('x') as stdout,(case/'completed-reuse.stderr').open('x') as stderr:subprocess.run([sys.executable,str(frozen/'helix/run_generation.py'),str(path),'--resume'],check=True,stdout=stdout,stderr=stderr)
 assert digest(case/'state.json')==want and json.loads((case/'completed-reuse.stdout').read_text())==state['result'];copy=case/'probe';assert copy.is_file() and not copy.is_symlink() and digest(copy)==source['native_sha256'];size=copy.stat().st_size;copy.unlink();publish(case/'copy-cleanup.json',dict(completed_reuse_verified=True,probe_removed=True,bytes=size,no_future_resume_claim_after_retirement=True));completed.append(op);return reply
candidate=candidate_state('candidate-before');assert candidate['generation']==4 and not candidate['ready'] and candidate['cursor']==candidate['documents']==11428831 and candidate['vector_rows']==candidate['vectors']==1000000 and candidate['index_deadline_ms']==1792836176755 and 'retirement' not in candidate
witness('before');before=inventory('disk-before.json');assert before['free_bytes']>=81212254720
until=int(time.time()*1000)+7200_000;reply=operation(dict(op='retire_generation',generation=4,deadline_ms=until));assert reply['retired'] and reply['generation']==4 and reply['completed']==reply['total']==2;assert not any(database.joinpath('derived').glob('g4_*.lance'))
after_candidate=candidate_state('candidate-after');assert after_candidate=={**candidate,'retirement':dict(deadline_ms=until,completed=2)}
reply=operation(dict(op='prune_versions',generation=3,deadline_ms=int(time.time()*1000)+7200_000));lifecycle=reply['lifecycle'];assert lifecycle['active']==3 and lifecycle['committed']==lifecycle['text']['watermark']==lifecycle['vector']['watermark']==309711
witness('after');after=inventory('disk-after-cleanup.json')
bundle={**candidate['bundle'],'schema':4};operation(dict(op='begin_corpus',generation=5,bundle=bundle,manifest='/tmp/akasha-otsuge-storage-20261022/full-corpus-v2.json'));reply=operation(dict(op='backfill',generation=5,waves=1000000));assert reply['cursor']==reply['documents']==11428831 and reply['vector_rows']==reply['vectors']==1000000 and not reply['ready'] and reply['index_deadline_ms'] is None
publish(base/'result.json',dict(status='prepared_not_built',generation=5,active=3,committed=309711,native_sha256=source['native_sha256'],witnesses_before=66,witnesses_after=66,witnesses_match_except_query_order=True,query_order_changes=json.loads((base/'after/result.json').read_text())['query_order_changes'],retired_generation4_allocated_bytes=sum(v for k,v in before['allocated_bytes'].items() if k.startswith('derived/g4_')),free_bytes_delta_after_cleanup=after['free_bytes']-before['free_bytes'],free_bytes=shutil.disk_usage(database).free,retired_candidate_original_deadline_preserved=True,operations=completed,disposable_copies_removed=True))
print(json.dumps(dict(status='prepared_not_built',generation=5,active=3,operations=completed)),flush=True)
