import datetime, json, pathlib, subprocess, sys
sys.path.insert(0, str(pathlib.Path('spikes/helix').resolve()))
from run_case import digest, process_identity, publish
root = pathlib.Path(sys.argv[1]).resolve()
state = json.loads((root / 'state.json').read_text())
assert state['phase'] == 'completed' and state['result']['status'] == 'passed'
for name, expected in state['result']['artifact_sha256'].items(): assert digest(root / name) == expected, name
attempt = state['attempts'][-1]
events = [json.loads(line) for line in pathlib.Path(attempt['log']).with_name('memory.jsonl').read_text().splitlines()]
native = [e for e in events if e['event'] == 'executable']
exits = [e for e in events if e['event'] == 'exit']
assert len(native) == len(exits) == 1 and native[0]['sha256'] == state['identity']['binary_sha256']
assert exits[0]['code'] == exits[0]['native_code'] == 0
for identity in [state['controller'], native[0]]:
    current = process_identity(identity['pid'])
    assert current is None or current['start_ticks'] != identity['start_ticks']
unit = subprocess.check_output(['systemctl', '--user', 'show', attempt['unit'], '-p', 'ActiveState', '--value'], text=True).strip()
assert unit == 'inactive'
assert events[0]['limits']['memory.max'] == '671088640' and events[0]['limits']['memory.swap.max'] == '0'
assert events[0]['nofile_soft_hard'] == [8192, 8192]
scratch = exits[0]['scratch_cleanup']
assert scratch['removed'] and not pathlib.Path(scratch['path']).exists()
samples = [e for e in events if e['event'] == 'sample']
assert samples and all(int(s['memory_events'].get('oom', 0)) == int(s['memory_events'].get('oom_kill', 0)) == 0 for s in samples)
rss = max(s['engine_rss_bytes'] for s in samples)
assert rss <= 640 * 1024**2
replies = [json.loads(line) for line in pathlib.Path(attempt['log']).read_text().splitlines() if line.startswith('{')]
assert len(replies) == 1
result = dict(status='passed', operation=state['result']['operation'], generation=state['result']['generation'],
    elapsed_s=state['result']['elapsed_s'], native_seconds=exits[0]['seconds'], rss_max_bytes=rss,
    cgroup_peak_bytes=max(s['cgroup_peak_bytes'] for s in samples), oom_events=0, native=native[0],
    unit=attempt['unit'], unit_state=unit, reply=replies[0], artifacts_verified=True,
    exact_processes_gone=True, scratch_removed=True, collector_sha256=digest(__file__),
    verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
publish(root / 'verified.json', result)
print(json.dumps({k:result[k] for k in ['status','operation','generation','elapsed_s','rss_max_bytes']}))
