import fcntl,hashlib,json,os,pathlib,sys,time
repo=pathlib.Path.cwd();sys.path[:0]=[str(repo/'spikes/helix'),str(repo/'spikes/fallback')]
from run_case import digest,process_identity,publish
from check_real_search import run_native

base=pathlib.Path(sys.argv[1]).resolve();phase=sys.argv[2];assert phase in {'before','after'}
plan=json.loads((base/'witness-plan.json').read_text());binary=pathlib.Path(plan['binary']);database=pathlib.Path(plan['database']);assert digest(binary)==plan['binary_sha256']
owner=(database/'.akasha-case-owner.lock').open('a');fcntl.flock(owner,fcntl.LOCK_EX|fcntl.LOCK_NB)
out=base/phase;out.mkdir();(out/'OWNER').write_text('akasha-otsuge MVP-003 read-only prune witnesses\n')
publish(out/'admission.json',dict(plan_sha256=digest(base/'witness-plan.json'),controller=process_identity(os.getpid()),driver_sha256=digest(__file__),helper_sha256=digest(repo/'spikes/fallback/check_real_search.py')))
started=time.monotonic();records=[];order_changes=[]
for i,step in enumerate(plan['requests']):
 request=out/f'{i:03d}.request.json';publish(request,step['request'])
 stdout,stderr=run_native([str(binary),str(database),'--'+step['channel'],str(request)],out,records)
 assert records[-1]['exit']==0 and not records[-1]['timed_out'],(i,stderr[-2000:])
 assert process_identity(records[-1]['child']['pid']) is None
 value=json.loads(stdout);op=step['request']['op']
 if op=='current':assert value['entry'] is not None and hashlib.sha256(value['entry']['body'].encode()).hexdigest()==step['expected_body_sha256']
 if op=='query_current':assert value['hits'] and all(x['partition']==f"p{step['request']['scope']}" for x in value['hits'])
 if op=='history':assert value['entries']
 if op=='get':assert value is not None and value['memory']==step['request']['memory']
 if phase=='after':
  before=json.loads((base/'before'/f'{i:03d}.stdout').read_text())
  if op=='query_current' and plan.get('query_comparison')=='candidate_set':
   if value!=before:order_changes.append(i)
   value={**value,'hits':sorted(value['hits'],key=lambda hit:json.dumps(hit,sort_keys=True))}
   before={**before,'hits':sorted(before['hits'],key=lambda hit:json.dumps(hit,sort_keys=True))}
  assert value==before,i
 elapsed=time.monotonic()-started
 publish(out/'progress.json',dict(completed=i+1,total=len(plan['requests']),elapsed_s=elapsed,rate_per_s=(i+1)/elapsed,eta_s=(len(plan['requests'])-i-1)*elapsed/(i+1),**process_identity(os.getpid())))
publish(out/'result.json',dict(status='passed',phase=phase,commands=len(records),seconds=time.monotonic()-started,artifact_sha256={p.name:digest(p) for p in out.iterdir() if p.is_file()},matches_before=phase=='after' and not order_changes,matches_before_ignoring_query_order=phase=='after',query_order_changes=order_changes))
print(json.dumps(dict(status='passed',phase=phase,commands=len(records),seconds=time.monotonic()-started)))
