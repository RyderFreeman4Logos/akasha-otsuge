import hashlib, json, pathlib, sys, tarfile

repo = pathlib.Path.cwd()
sys.path.insert(0, str(repo / 'spikes/helix'))
from run_case import digest, publish

root = pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023/fallback-full-generation5-r1')
result = json.loads((root / 'result.json').read_text())
assert result['status'] == 'prepared_not_built'
steps = {name: json.loads((root / name / 'verified.json').read_text()) for name in result['operations']}
for name, value in steps.items():
    cleanup = json.loads((root / name / 'copy-cleanup.json').read_text())
    assert value['status'] == 'passed' and value['exact_processes_gone'] and value['scratch_removed']
    assert value['unit_state'] == 'inactive' and value['oom_events'] == 0
    assert cleanup['completed_reuse_verified'] and cleanup['probe_removed'] and not (root / name / 'probe').exists()
backfill = steps['backfill']['reply']
assert backfill['cursor'] == backfill['documents'] == 11428831
assert backfill['vector_rows'] == backfill['vectors'] == 1000000
assert backfill['index_deadline_ms'] is None and not backfill['ready']
before=json.loads((root/'candidate-before-verified.json').read_text());after=json.loads((root/'candidate-after-verified.json').read_text());assert before['status']==after['status']=='passed'
assert not before['reply']['ready'] and before['reply']['index_deadline_ms']==1792836176755
assert after['reply']=={**before['reply'],'retirement':dict(deadline_ms=steps['retire_generation']['reply']['deadline_ms'],completed=2)}
files = {}
for prefix, tree in [('preparation', root), ('frozen-source', repo / '.spike-work/partial-retirement-r2')]:
    for path in tree.rglob('*'):
        if path.is_file() and path.name != 'probe' and '__pycache__' not in path.parts:
            assert not path.is_symlink()
            files[prefix + '/' + str(path.relative_to(tree))] = path
for name in ['prepare-generation5-r1.py', 'full-prune-witness.py', 'collect-rebuild-recovery-step.py', 'verify-generation.py', 'full-generation5-r1.log', 'archive-generation5-preparation-r1.py']:
    files['collector/' + name] = repo / '.git/akasha-evidence' / name
out = repo / 'docs/benchmarks/results/fallback-full-generation5-preparation'
out.mkdir()
archive = out / 'raw.tar.gz'
hashes = {name: digest(path) for name, path in sorted(files.items())}
with tarfile.open(archive, 'w:gz') as tf:
    for name, path in sorted(files.items()):
        tf.add(path, arcname=name, recursive=False)
with tarfile.open(archive, 'r:gz') as tf:
    assert len(tf.getnames()) == len(hashes) and set(tf.getnames()) == set(hashes)
    for member in tf.getmembers():
        assert hashlib.sha256(tf.extractfile(member).read()).hexdigest() == hashes[member.name]
publish(out / 'files.json', hashes)
summary = dict(result, source_commit='ddcf1136ea3d2a6b13e104065642d161c2e58a64', archive_files=len(files), archive_bytes=archive.stat().st_size, archive_sha256=digest(archive), steps={name: {k: value[k] for k in ['elapsed_s', 'rss_max_bytes', 'oom_events', 'artifacts_verified', 'exact_processes_gone', 'scratch_removed', 'unit_state']} for name, value in steps.items()}, candidate_state_checks=dict(before=before,after=after), comparisons='66 before and66 after witnesses; non-query responses exact; query candidate sets and all other fields exact; raw ranking order retained', disk_note='Inode allocation is not exclusive Btrfs allocation; filesystem free-space delta includes other host activity.', not_proven=['fresh uninterrupted full index build', 'full concurrent rebuild performance and resource acceptance', 'sole-backend selection'])
publish(out / 'summary.json', summary)
print(json.dumps({key: summary[key] for key in ['status', 'archive_files', 'archive_bytes', 'archive_sha256']}))
