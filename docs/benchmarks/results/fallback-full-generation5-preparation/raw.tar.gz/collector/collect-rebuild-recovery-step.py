import json,pathlib,subprocess,sys
repo=pathlib.Path.cwd();sys.path.insert(0,str(repo/'spikes/helix'))
from run_case import digest,process_identity,publish
root=pathlib.Path(sys.argv[1]);memory=pathlib.Path(sys.argv[2]);unit=sys.argv[3]
result=json.loads((root/'result.json').read_text());assert result['status']=='passed'
for name,want in result.get('artifacts',result.get('artifact_sha256')).items():assert digest(root/name)==want,name
records=json.loads((root/'commands.json').read_text());assert len(records)==result['commands']
for n,row in enumerate(records):
 assert not row['timed_out'] and row['phase']=='completed'
 assert digest(root/f'{n:03d}.stdout')==row['stdout_sha256']
 now=process_identity(row['child']['pid']);assert now is None or now['start_ticks']!=row['child']['start_ticks']
admission=json.loads((root/'admission.json').read_text());controller=admission['controller']
now=process_identity(controller['pid']);assert now is None or now['start_ticks']!=controller['start_ticks']
events=[json.loads(line) for line in memory.open()]
assert events[0]['limits']['memory.max']=='671088640' and events[0]['limits']['memory.swap.max']=='0' and events[0]['nofile_soft_hard']==[8192,8192]
end=events[-1];assert end['event']=='exit' and end['code']==end['native_code']==0
assert end['scratch_cleanup']['removed'] and not pathlib.Path(end['scratch_cleanup']['path']).exists()
samples=[e for e in events if e['event']=='sample'];assert samples
peak=max(e['engine_rss_bytes'] for e in samples);assert peak<=640*1024**2
assert not any(int(e['memory_events'].get(k,0)) for e in samples for k in ['oom','oom_kill'])
assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip()=='inactive'
verified=dict(status='passed',commands=len(records),seconds=result['seconds'],sampled_rss_max_bytes=peak,artifacts_verified=True,exact_processes_gone=True,scratch_removed=True,unit_inactive=True,memory_log_sha256=digest(memory),result_sha256=digest(root/'result.json'))
publish(root/'verified.json',verified);print(json.dumps(verified))
