"""Compact, source-derived protocol checks for the production corpus seeder."""
import hashlib,json,os,pathlib,re,select,time

def exchange(child,frame,deadline):
    pending=memoryview(frame)
    while pending:
        remaining=deadline-time.time()
        if remaining<=0 or not select.select([],[child.stdin],[],remaining)[1]:
            raise TimeoutError('seed input deadline')
        try:written=os.write(child.stdin.fileno(),pending)
        except BlockingIOError:continue
        if written<=0:raise RuntimeError('closed seed input')
        pending=pending[written:]
    received=bytearray()
    while not received.endswith(b'\n'):
        remaining=deadline-time.time()
        if remaining<=0 or not select.select([child.stdout],[],[],remaining)[0]:
            raise TimeoutError('seed acknowledgement deadline')
        try:part=os.read(child.stdout.fileno(),4097-len(received))
        except BlockingIOError:continue
        if not part:raise RuntimeError('seed exited before complete acknowledgement')
        received.extend(part)
        if len(received)>4096:raise ValueError('oversized acknowledgement')
    return bytes(received)

RUST_SPACE="\t\n\v\f\r \x85\xa0\u1680\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u2028\u2029\u202f\u205f\u3000"
def encode(value):
    return json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()
def digest(value):
    return hashlib.sha256(value).hexdigest()
def spans(body):
    data=body.encode();start=0
    if not body.strip(RUST_SPACE) or len(data)>65536:raise ValueError('invalid production body')
    while start<len(data):
        end=min(start+32768,len(data))
        while end<len(data) and data[end]&0xc0==0x80:end-=1
        if not data[start:end].decode().strip(RUST_SPACE):raise ValueError('empty production claim')
        yield start,end
        start=end
def project(record):
    row={key:record[key] for key in ('key','body','partition')}
    if not row['key'].strip(RUST_SPACE) or len(row['key'].encode())>256 or row['partition'] not in {f'p{i}' for i in range(8)}:
        raise ValueError('invalid production record identity')
    list(spans(row['body']))
    row['vector_cohort']='embedding' in record and len(row['body'].encode())<=4096
    return row
def source_id(binding,key):
    # Match the Rust Binding field order and serde tuple serialization exactly.
    bound=encode({'source_manifest_sha256':binding['source_manifest_sha256'],'observed_time_ms':binding['observed_time_ms']}).decode()
    return 'corpus/'+digest(encode([bound,key]))
def verify_ack(row,binding,raw):
    if len(raw)>4096 or not raw.endswith(b'\n'):raise ValueError('invalid acknowledgement frame')
    ack=json.loads(raw);body=row['body'].encode();source=source_id(binding,row['key'])
    expected={'key_sha256':digest(row['key'].encode()),'body_sha256':digest(body),'source_id':source,'utf8_bytes':len(body)}
    if set(ack)!=set(expected)|{'source_revision','memories'} or any(ack[k]!=v for k,v in expected.items()):
        raise ValueError('acknowledgement differs from source')
    def revision(v):return type(v) is int and 0<v<2**64
    if not revision(ack['source_revision']):raise ValueError('invalid source revision')
    parts=list(spans(row['body']));memories=ack['memories']
    if not isinstance(memories,list) or len(memories)!=len(parts):raise ValueError('incomplete claim coverage')
    previous=ack['source_revision'];oracle=hashlib.sha256()
    for item,(start,end) in zip(memories,parts):
        if not isinstance(item,list) or len(item)!=2 or item[0]!=f'{source}/{start}' or not revision(item[1]) or item[1]<=previous:
            raise ValueError('invalid memory identity or revision')
        previous=item[1]
        oracle.update(encode([item[0],item[1],digest(body[start:end]),start,end,row['partition'],row['vector_cohort']])+b'\n')
    return {'claims':len(parts),'source_revision':ack['source_revision'],'last_revision':previous,'oracle_sha256':oracle.hexdigest()}
def receipts(root,identity,total,unit_records=4096):
    paths=sorted((pathlib.Path(root)/'units').glob('*.json'));values=[];previous=identity;completed=0
    for number,path in enumerate(paths):
        if path.name!=f'{number:08d}.json':raise ValueError('unit journal gap or foreign filename')
        raw=path.read_bytes();value=json.loads(raw)
        if value['admission_sha256']!=identity or value['previous_sha256']!=previous or value['first']!=completed+1:
            raise ValueError('unit journal identity or chain changed')
        count=value['last']-value['first']+1
        if count<1 or count>unit_records or (count!=unit_records and value['last']!=total):
            raise ValueError('invalid completed unit bounds')
        if value['last']>total or value['records']!=count:raise ValueError('invalid completed unit count')
        for name in ('input_sha256','acks_sha256','oracle_sha256'):
            if not isinstance(value[name],str) or not re.fullmatch('[0-9a-f]{64}',value[name]):
                raise ValueError('invalid unit digest')
        previous=digest(raw);completed=value['last'];values.append(value)
    return values,previous,completed

def self_test():
    import subprocess,sys,tempfile
    for output,error in [(b'ack\n',None),(b'partial',RuntimeError),(b'x'*4097,ValueError)]:
        code='import os,sys;sys.stdin.buffer.readline();os.write(1,'+repr(output)+')'
        child=subprocess.Popen([sys.executable,'-c',code],stdin=subprocess.PIPE,stdout=subprocess.PIPE,bufsize=0)
        os.set_blocking(child.stdin.fileno(),False);os.set_blocking(child.stdout.fileno(),False)
        try:
            try:actual=exchange(child,b'input\n',time.time()+10)
            except Exception as caught:
                assert error is not None and isinstance(caught,error),caught
            else:assert error is None and actual==output
        finally:
            child.stdin.close();child.wait(timeout=10);child.stdout.close()
    binding={'source_manifest_sha256':'a'*64,'observed_time_ms':1793000000000}
    row=project(dict(key='fixture:你',body='a'*32767+'你',partition='p0'))
    sid=source_id(binding,row['key'])
    ack=dict(key_sha256=digest(row['key'].encode()),body_sha256=digest(row['body'].encode()),source_id=sid,
        source_revision=2,memories=[[sid+'/0',3],[sid+'/32767',4]],utf8_bytes=len(row['body'].encode()))
    assert verify_ack(row,binding,encode(ack)+b'\n')['claims']==2
    for changed in (dict(ack,source_id='wrong'),dict(ack,body_sha256='0'*64),dict(ack,memories=ack['memories'][:1]),
                    dict(ack,source_revision=True),dict(ack,memories=[[sid+'/0',3],[sid+'/32768',4]])):
        try:verify_ack(row,binding,encode(changed)+b'\n')
        except ValueError:pass
        else:raise AssertionError('changed acknowledgement accepted')
    for body in ('',' ','a'*65537,'a'*32768+' '*32768):
        try:project(dict(key='ok',body=body,partition='p1'))
        except ValueError:pass
        else:raise AssertionError('invalid record accepted')
    assert project(dict(key='ok',body='\x1c',partition='p1'))['body']=='\x1c'
    assert project(dict(key='ok',body='a'*4096,partition='p1',embedding=[1]))['vector_cohort']
    assert not project(dict(key='ok',body='a'*4097,partition='p1',embedding=[1]))['vector_cohort']
    with tempfile.TemporaryDirectory() as tmp:
        root=pathlib.Path(tmp);(root/'units').mkdir()
        value=dict(admission_sha256='a'*64,previous_sha256='a'*64,first=1,last=2,records=2,
            input_sha256='1'*64,acks_sha256='2'*64,oracle_sha256='3'*64)
        path=root/'units/00000000.json';path.write_bytes(encode(value)+b'\n')
        assert receipts(root,'a'*64,2)[2]==2
        value['previous_sha256']='b'*64;path.write_bytes(encode(value)+b'\n')
        try:receipts(root,'a'*64,2)
        except ValueError:pass
        else:raise AssertionError('foreign chain accepted')
        path.rename(root/'units/00000001.json')
        try:receipts(root,'a'*64,2)
        except ValueError:pass
        else:raise AssertionError('journal gap accepted')
    print('PASS: source-derived acknowledgement, UTF-8 coverage, cohort and compact journal checks')
if __name__=='__main__':
    import sys
    assert sys.argv[1:]==['--self-test']
    self_test()

