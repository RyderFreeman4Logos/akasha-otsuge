import datetime,fcntl,gzip,hashlib,json,os,pathlib,shutil,sys
sys.dont_write_bytecode=True
E=pathlib.Path(__file__).parent;W=pathlib.Path.cwd();sys.path[:0]=[str(W/"spikes/helix"),str(E)]
from run_case import process_identity
from mvp024_import_protocol_r1 import source_id,digest
r=(W/".spike-work/mvp024-claim-tail-replay-r1").resolve()
a=json.loads((r/"admission.json").read_text());s=pathlib.Path(a["socket_root"])
assert digest((E/"mvp024-claim-tail-replay-r1.py").read_bytes())==a["driver_sha256"]
terminal=json.loads((E/"mvp024-claim-tail-replay-r1.terminal.json").read_text())
assert terminal["exit_code"]==1 and terminal["log_sha256"]=="8241445463cc10adc458480f69befc6c9c3be790e47617d06cef1b224877fbf9"
log=(E/"mvp024-claim-tail-replay-r1.log").read_text()
assert 'line 138' in log and 'socket_root.iterdir()' in log and "AssertionError" in log
assert not (r/"failure.json").exists() and not (r/"result.json").exists()
ids=[json.loads(p.read_text()) for p in r.glob("*-process.json")];assert len(ids)==3
assert all(process_identity(p["pid"]) is None for p in ids)
assert not (r/"data").exists()
read=json.loads((r/"current-readback.json").read_text());oracle=json.loads((r/"oracle.json").read_text())["memories"]
assert read["full_content_and_spans_match"] and read["sources"]==13 and read["bytes"]==851968
assert len(read["claims"])==len(oracle)==39
byid={x["id"]:x for x in read["claims"]};assert len(byid)==39
d=(W/".spike-work/mvp024-empty-claim-diagnostic-r1").resolve();m=json.loads((d/"result.json").read_text())["matches"]
binding=json.loads((r/"binding.json").read_text())
assert digest((r/"input-manifest.json").read_bytes())==binding["source_manifest_sha256"]
expected={}
for key in m:
 raw=gzip.decompress((d/"bodies"/(key+".txt.gz")).read_bytes());assert digest(raw)==key and len(raw)==65536
 sid=source_id(binding,"fineweb:"+key)
 for lo,hi in ((0,32767),(32767,65534),(65534,65536)):
  expected[f"{sid}/{lo}"]=(key,lo,hi,digest(raw[lo:hi]))
assert set(expected)==set(byid)
for item in oracle:
 key,lo,hi,sha=expected[item["id"]]
 assert (item["source_hash"],item["start"],item["end"],item["claim_sha256"])==(key,lo,hi,sha)
 assert byid[item["id"]]["revision"]==item["revision"] and byid[item["id"]]["claim_sha256"]==sha
assert (r/"seed.acks").read_bytes()==(r/"replay.acks").read_bytes()
assert len((r/"seed.acks").read_bytes().splitlines())==13
for name in ("seed","replay"):
 t=json.loads((r/(name+"-terminal.json")).read_text());assert t["exit_code"]==0 and t["ack_sha256"]==digest((r/(name+".acks")).read_bytes())
commands=[json.loads(line) for line in (r/"commands.jsonl").read_text().splitlines()]
assert len([c for c in commands if c["argv"][:2]==["memory","show"] and c["exit_code"]==0])==39
assert commands[-1]["argv"]==["daemon","stop"] and commands[-1]["exit_code"]==0
assert s.resolve().parent==pathlib.Path(os.environ["TMPDIR"]).resolve() and not s.is_symlink()
assert (s/"OWNER").read_text()==str(r)+"\n" and {p.name for p in s.iterdir()}=={"OWNER","daemon.lock"}
snapshot={}
for p in s.iterdir():
 assert p.is_file() and not p.is_symlink() and p.stat().st_uid==os.getuid()
 snapshot[p.name]=dict(bytes=p.stat().st_size,sha256=digest(p.read_bytes()),allocated_bytes=p.stat().st_blocks*512)
with (s/"daemon.lock").open("rb") as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 shutil.rmtree(s)
assert not s.exists()
result=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status="FUNCTIONAL_PASS_CLEANUP_RECONCILED",original_run_exit_code=1,
 original_failure="Final cleanup allowlist omitted the daemon's daemon.lock. Original failure and driver are immutable; no functional rerun.",
 seed_records=13,current_claims=39,source_bytes=851968,exact_ack_replay=True,independent_body_span_hash_recheck=True,
 processes_absent=ids,daemon_zero_exit_basis="Original driver asserts all child return codes zero before deleting data and reaching the preserved cleanup traceback; stop command separately returned zero.",
 cleanup_data_absent=True,cleanup_socket_absent=True,socket_before=snapshot,
 driver_sha256=a["driver_sha256"],checker_sha256=digest(pathlib.Path(__file__).read_bytes()),head=a["build"]["head"],build=a["build"],
 limitations="No full corpus import, index, load or crash/recovery acceptance.")
(r/"cleanup-reconciled.json").write_text(json.dumps(result,indent=2)+"\n")
(E/"mvp024-claim-tail-replay-r1-verified.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({k:result[k] for k in ("status","original_run_exit_code","seed_records","current_claims","source_bytes","cleanup_data_absent","cleanup_socket_absent")}))
