import datetime,hashlib,json,pathlib,subprocess
E=pathlib.Path(__file__).parent;W=pathlib.Path.cwd()
commit=json.loads((E/"mvp024-claim-tail-commit-r1-result.json").read_text())
def git(*a):return subprocess.check_output(["git",*a],text=True).strip()
def sha(p):
 with pathlib.Path(p).open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()
assert git("rev-parse","HEAD")==commit["head"] and not git("status","--porcelain")
assert sha(W/"examples/corpus_seed.rs")=="a33d7ca1000fc790792b1b1258185d825b18a45fc5963fabf1afe68af0b3f03b"
subprocess.run(["cargo","test","--locked","--example","corpus_seed"],check=True)
subprocess.run(["cargo","build","--locked","--release","--bin","akasha-otsuge","--example","corpus_seed"],check=True)
assert git("rev-parse","HEAD")==commit["head"] and not git("status","--porcelain")
r=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=commit["head"],tree=git("rev-parse","HEAD^{tree}"),source_sha256=sha(W/"examples/corpus_seed.rs"),daemon_sha256=sha(W/"target/release/akasha-otsuge"),seeder_sha256=sha(W/"target/release/examples/corpus_seed"),driver_sha256=sha(__file__))
with (E/"mvp024-claim-tail-build-r1.json").open("x") as f:json.dump(r,f,indent=2);f.write("\n")
print(json.dumps(r))
