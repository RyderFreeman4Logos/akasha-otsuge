"""Replay the 13 exact rejected bodies through production seeding and daemon reads."""
import datetime,gzip,hashlib,json,os,pathlib,shutil,signal,subprocess,sys,tempfile,time
sys.dont_write_bytecode=True
W=pathlib.Path.cwd();E=pathlib.Path(__file__).parent
sys.path[:0]=[str(E),str(W/"spikes/data"),str(W/"spikes/helix")]
from download import publish
from run_case import process_identity
from mvp024_import_protocol_r1 import encode,digest,exchange,source_id,RUST_SPACE
def sha(p):
 with pathlib.Path(p).open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()
def git(*args):return subprocess.check_output(["git",*args],text=True).strip()
build=json.loads((E/"mvp024-claim-tail-build-r1.json").read_text())
assert git("rev-parse","HEAD")==build["head"] and not git("status","--porcelain")
binary=(W/"target/release/akasha-otsuge").resolve();seeder=(W/"target/release/examples/corpus_seed").resolve()
assert sha(binary)==build["daemon_sha256"] and sha(seeder)==build["seeder_sha256"]
assert sha(W/"examples/corpus_seed.rs")==build["source_sha256"]
diagnostic=(W/".spike-work/mvp024-empty-claim-diagnostic-r1").resolve()
known=json.loads((diagnostic/"result.json").read_text())["matches"];assert len(known)==13
root=(W/".spike-work/mvp024-claim-tail-replay-r1").resolve()
assert shutil.disk_usage(root.parent).free>30*1024**3
root.mkdir(mode=0o700);(root/"OWNER").write_text("akasha-otsuge:mvp024-claim-tail-replay-r1\n")
socket_root=pathlib.Path(tempfile.mkdtemp(prefix="a24t-",dir=os.environ["TMPDIR"]))
(socket_root/"OWNER").write_text(str(root)+"\n")
endpoint=socket_root/"service.sock";assert len(os.fsencode(endpoint))<108
config='[reliability]\nmax_attempts=1\nack_timeout_s=120\nunit_timeout_s=1800\ncommand_timeout_s=30\n[resources]\nmax_owned_data_bytes=67108864\n'
(root/"run.toml").write_text(config);epoch=digest(config.encode())
inputs={"diagnostic_result_sha256":sha(diagnostic/"result.json"),"records":sorted(known),
 "selection":"All 13 previously rejected exact FineWeb bodies, no byte changes; lexical cohort only"}
publish(root/"input-manifest.json",inputs)
binding={"source_manifest_sha256":sha(root/"input-manifest.json"),"observed_time_ms":1793000000000};publish(root/"binding.json",binding)
admission={"utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"build":build,"driver_sha256":sha(__file__),
 "protocol_sha256":sha(E/"mvp024_import_protocol_r1.py"),"process":process_identity(os.getpid()),"config_epoch":epoch,
 "diagnostic_admission_sha256":sha(diagnostic/"admission.json"),"socket_root":str(socket_root),
 "scope":"Exact 13-body Domain admission, idempotent replay and 39 daemon current reads; no indexing, full import, load or recovery acceptance."}
publish(root/"admission.json",admission)
commands=(root/"commands.jsonl").open("x");children=[];seed=daemon=None;failure=None;oracle=[];started=time.monotonic()
base=[str(binary),"--config",str(root/"daemon.toml"),"--socket",str(endpoint)]
def progress(phase,done,total):
 elapsed=time.monotonic()-started
 publish(root/"progress.json",dict(phase=phase,completed=done,total=total,elapsed_s=elapsed,rate_per_s=done/elapsed if done else None,eta_s=None,config_epoch=epoch))
def cli(*args,required=True):
 r=subprocess.run([*base,*map(str,args)],stdin=subprocess.DEVNULL,capture_output=True,timeout=30)
 commands.write(json.dumps(dict(argv=list(args),exit_code=r.returncode,stdout_sha256=digest(r.stdout),stderr_sha256=digest(r.stderr)))+"\n");commands.flush()
 if required:assert r.returncode==0,(args[:2],r.returncode,r.stderr.decode()[:1200])
 return json.loads(r.stdout)["data"] if r.returncode==0 else None
def rows():
 for body_hash,item in sorted(known.items()):
  p=diagnostic/"bodies"/(body_hash+".txt.gz");assert sha(p)==item["compressed_body_sha256"]
  raw=gzip.decompress(p.read_bytes());assert digest(raw)==body_hash and len(raw)==65536
  key="fineweb:"+body_hash;assert digest(key.encode())==item["original_identity"]["key_sha256"]
  assert [(x["start"],x["end"]) for x in item["candidate_spans"]]==[(0,32767),(32767,65534),(65534,65536)]
  yield dict(key=key,body=raw.decode(),partition="p"+str(hashlib.sha256(key.encode()).digest()[0]%8),vector_cohort=False)
def seed_pass(name,retain):
 global seed
 deadline=time.time()+1800
 with (root/(name+".stderr")).open("xb") as err,(root/(name+".acks")).open("xb") as output:
  seed=subprocess.Popen(["nohup",str(seeder),str(root/"data"),str(root/"binding.json")],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,start_new_session=True,bufsize=0)
  children.append(seed);publish(root/(name+"-process.json"),process_identity(seed.pid))
  os.set_blocking(seed.stdin.fileno(),False);os.set_blocking(seed.stdout.fileno(),False)
  try:
   for n,row in enumerate(rows(),1):
    raw=exchange(seed,encode(row)+b"\n",min(deadline,time.time()+120));ack=json.loads(raw)
    body=row["body"].encode();sid=source_id(binding,row["key"])
    assert ack["body_sha256"]==digest(body) and ack["key_sha256"]==digest(row["key"].encode()) and ack["source_id"]==sid
    assert ack["utf8_bytes"]==65536 and type(ack["source_revision"]) is int and ack["source_revision"]>0
    assert len(ack["memories"])==3
    previous=ack["source_revision"]
    for (mid,seq),(start,end) in zip(ack["memories"],[(0,32767),(32767,65534),(65534,65536)]):
     assert mid==f"{sid}/{start}" and type(seq) is int and seq>previous;previous=seq
     if retain:oracle.append(dict(id=mid,revision=seq,source_id=sid,source_revision=ack["source_revision"],source_hash=digest(body),start=start,end=end,claim_sha256=digest(body[start:end]),partition=row["partition"]))
    output.write(raw);output.flush();os.fsync(output.fileno());progress(name,n,13)
   seed.stdin.close();assert seed.wait(timeout=120)==0
   assert n==13
  finally:
   if not seed.stdin.closed:seed.stdin.close()
   if seed.poll() is None:seed.wait(timeout=120)
   seed.stdout.close()
  publish(root/(name+"-terminal.json"),dict(exit_code=seed.returncode,ack_sha256=sha(root/(name+".acks"))))
try:
 seed_pass("seed",True);seed_pass("replay",False)
 assert (root/"seed.acks").read_bytes()==(root/"replay.acks").read_bytes()
 assert len(oracle)==39
 publish(root/"oracle.json",{"memories":oracle,"exact_spans_basis":"Each diagnosed body has independently verified boundaries 0,32767,65534,65536; no production splitting function is reused."})
 (root/"daemon.toml").write_text("[paths]\ndata_dir="+json.dumps(str(root/"data"))+"\nsocket_path="+json.dumps(str(endpoint))+"\n")
 with (root/"daemon.log").open("xb") as log:
  daemon=subprocess.Popen(["nohup",*base,"daemon","run"],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 children.append(daemon);publish(root/"daemon-process.json",process_identity(daemon.pid))
 deadline=time.monotonic()+120
 while True:
  assert daemon.poll() is None,"daemon exited before readiness"
  if endpoint.exists():
   status=cli("daemon","status",required=False)
   if status:break
  assert time.monotonic()<deadline,"daemon readiness deadline"
  time.sleep(.1)
 publish(root/"daemon-initial-status.json",status)
 checked=[];joined={}
 for n,expected in enumerate(oracle,1):
  reply=cli("memory","show",expected["id"]);assert reply["data"]["state"]=="active"
  memory=reply["data"]["revision"]["memory"];assert memory["revision"]["commit_seq"]==expected["revision"]
  record=memory["record"];draft=record["draft"];assert record["authority"]=="delegated_approved" and record["approval"] is None
  raw=draft["claim"].encode();assert digest(raw)==expected["claim_sha256"] and raw.decode().strip(RUST_SPACE) and len(raw)<=32768
  assert draft["scope"]==dict(user=f"uid:{os.geteuid()}",project="corpus/"+expected["partition"],branch_or_version=None,session=None)
  assert draft["source_spans"]==[dict(event_id=expected["source_id"],revision=expected["source_revision"],content_sha256=expected["source_hash"],start=expected["start"],end=expected["end"])]
  joined.setdefault(expected["source_hash"],bytearray()).extend(raw)
  checked.append(dict(id=expected["id"],revision=expected["revision"],reply_sha256=digest(encode(reply)),claim_sha256=digest(raw)))
  progress("verify_current",n,39)
 assert len(joined)==13 and all(len(raw)==65536 and digest(raw)==key for key,raw in joined.items())
 assert sum(map(len,joined.values()))==851968
 publish(root/"current-readback.json",{"claims":checked,"sources":13,"bytes":851968,"full_content_and_spans_match":True})
 assert git("rev-parse","HEAD")==build["head"] and not git("status","--porcelain")
 assert sha(seeder)==build["seeder_sha256"] and sha(binary)==build["daemon_sha256"]
except BaseException as error:
 failure={"type":type(error).__name__,"message":str(error)};publish(root/"failure.json",failure);raise
finally:
 try:
  if seed and seed.poll() is None:
   if not seed.stdin.closed:seed.stdin.close()
   seed.wait(timeout=120)
  if daemon and daemon.poll() is None:
   cli("daemon","stop",required=False)
   try:daemon.wait(timeout=60)
   except subprocess.TimeoutExpired:daemon.send_signal(signal.SIGTERM);daemon.wait(timeout=30)
  assert all(p.poll() is not None and process_identity(p.pid) is None for p in children),"owned consumer still live"
  assert all(p.returncode==0 for p in children),"owned subprocess failed"
  assert (root/"OWNER").read_text()=="akasha-otsuge:mvp024-claim-tail-replay-r1\n"
  data=root/"data";snapshot={}
  if data.exists():
   assert not data.is_symlink() and data.resolve().parent==root
   for p in sorted(data.rglob("*")):
    assert not p.is_symlink()
    if p.is_file():snapshot[str(p.relative_to(root))]=dict(bytes=p.stat().st_size,allocated_bytes=p.stat().st_blocks*512,sha256=sha(p))
   allocated=sum(v["allocated_bytes"] for v in snapshot.values())
   publish(root/"cleanup-before.json",dict(files=snapshot,all_owned_consumers_terminal=True,allocated_bytes=allocated))
   assert allocated<=67108864
   shutil.rmtree(data);assert not data.exists()
  assert socket_root.resolve().parent==pathlib.Path(os.environ["TMPDIR"]).resolve() and (socket_root/"OWNER").read_text()==str(root)+"\n"
  assert {p.name for p in socket_root.iterdir()}<={"OWNER","service.sock","service.sock.lock"}
  shutil.rmtree(socket_root);assert not socket_root.exists()
  receipt=dict(status="PASS" if failure is None else "FAIL",failure=failure,seed_records=13 if failure is None else None,claims=39 if failure is None else None,source_bytes=851968 if failure is None else None,exact_replay=True if failure is None else None,cleanup_data_absent=not data.exists(),cleanup_socket_absent=not socket_root.exists(),cleanup_files=len(snapshot),cleanup_allocated_bytes=sum(v["allocated_bytes"] for v in snapshot.values()),elapsed_s=time.monotonic()-started,build=build,limits=admission["scope"])
  publish(root/"result.json",receipt);progress("complete" if failure is None else "failed",39 if failure is None else 0,39)
  print(json.dumps({k:v for k,v in receipt.items() if k!="build"}))
 except BaseException as error:
  publish(root/"finalization-failure.json",dict(type=type(error).__name__,message=str(error)));raise
 finally:commands.flush();os.fsync(commands.fileno());commands.close()
