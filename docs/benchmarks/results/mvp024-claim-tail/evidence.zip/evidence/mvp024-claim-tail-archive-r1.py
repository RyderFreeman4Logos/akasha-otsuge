import datetime,hashlib,json,pathlib,subprocess,zipfile
E=pathlib.Path(__file__).parent;W=pathlib.Path.cwd()
assert not json.loads((E/"wd-state.json").read_text())["active_work"]["primaries"]
v=json.loads((E/"mvp024-claim-tail-replay-r1-verified.json").read_text());assert v["status"]=="FUNCTIONAL_PASS_CLEANUP_RECONCILED"
assert not subprocess.check_output(["git","status","--porcelain"]).strip()
members={}
for p in sorted(E.iterdir()):
 if p.is_file() and p.name.startswith("mvp024-claim-tail") and not p.name.endswith((".supervisor.log",".zip")):
  members["evidence/"+p.name]=p.read_bytes()
root=(W/".spike-work/mvp024-claim-tail-replay-r1").resolve()
assert not (root/"data").exists()
for p in sorted(root.rglob("*")):
 if p.is_file():
  assert not p.is_symlink()
  members["replay/"+str(p.relative_to(root))]=p.read_bytes()
members["source/before/corpus_seed.rs"]=subprocess.check_output(["git","show","bf1576828c2797f28f702370857b8bbc523e515e:examples/corpus_seed.rs"])
members["source/after/corpus_seed.rs"]=(W/"examples/corpus_seed.rs").read_bytes()
members["support/mvp024_import_protocol_r1.py"]=(E/"mvp024_import_protocol_r1.py").read_bytes()
members["support/run_case.py"]=(W/"spikes/helix/run_case.py").read_bytes()
members["support/download.py"]=(W/"spikes/data/download.py").read_bytes()
assert hashlib.sha256(members["source/after/corpus_seed.rs"]).hexdigest()==v["build"]["source_sha256"]
p=E/"mvp024-claim-tail-evidence.zip";entries={}
with zipfile.ZipFile(p,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for n,b in sorted(members.items()):
  i=zipfile.ZipInfo(n,(2026,11,17,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,b)
  entries[n]=dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
with zipfile.ZipFile(p) as z:
 assert z.testzip() is None and set(z.namelist())==set(entries)
 for n,b in members.items():assert z.read(n)==b
r=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=v["head"],tree=v["build"]["tree"],archive_bytes=p.stat().st_size,archive_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),members=entries,scope="Exact unchanged RED/GREEN, five maintained seeder tests, committed-source release build, all 13 real bodies and 39 daemon readbacks, byte-identical replay, preserved finalization and environment failures, completed owned cleanup. No full corpus import/index/load/recovery proof.",original_full_scan_status="The original full production-shape scan remains failed. This successor validates every one of its 13 rejected bodies without filtering or byte changes.")
(E/"mvp024-claim-tail-evidence-manifest.json").write_text(json.dumps(r,indent=2)+"\n")
print(json.dumps({k:v for k,v in r.items() if k!="members"}|dict(members=len(entries))))
