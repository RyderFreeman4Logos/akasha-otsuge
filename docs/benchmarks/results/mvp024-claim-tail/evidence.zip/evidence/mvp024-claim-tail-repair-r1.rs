                if end < row.body.len()
                    && row.body[end..].trim().is_empty()
                    && let Some((last, _)) = row.body[..end]
                        .char_indices()
                        .rev()
                        .find(|(_, ch)| !ch.is_whitespace())
                    && last > start
                    && row.body.len() - last <= 32768
                    && !row.body[start..last].trim().is_empty()
                {
                    end = last;
                }

