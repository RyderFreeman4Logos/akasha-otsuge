import gzip, hashlib, json, pathlib, re, subprocess, zipfile
O = pathlib.Path(__file__).parent
A = O / 'archives'
def sha(b): return hashlib.sha256(b).hexdigest()
def read(p): return json.loads(p.read_bytes())
def git(*args): return subprocess.check_output(['git', *args])
D, E, P = [A / x for x in ('diagnostic', 'evidence', 'publication')]
results = {}
# Compare every scoped working file with its frozen object, not only the receipt.
pre = read(O / 'preflight.json')
for n, h in pre['source_sha256'].items():
    assert sha(git('show', 'HEAD:' + n)) == h == sha(pathlib.Path(n).read_bytes()), n
for n in ['src/domain/mod.rs','src/domain/review.rs','src/domain/schema.rs','src/storage/mod.rs','src/daemon.rs']:
    assert git('show','HEAD:'+n) == git('show','origin/main:'+n)
results['frozen_sources_match'] = 23
results['additional_source_sha256'] = {'src/domain/history.rs': sha(pathlib.Path('src/domain/history.rs').read_bytes())}
assert git('show','HEAD:src/domain/history.rs') == pathlib.Path('src/domain/history.rs').read_bytes()
# Nested original census: validate contents before comparing rejection identities.
zp = P/'evidence/mvp024-full-preparation-source-validation.zip'
m = read(P/'evidence/mvp024-full-preparation-source-validation-manifest.json')
assert sha(zp.read_bytes()) == m['archive_sha256'] and zp.stat().st_size == m['archive_bytes']
with zipfile.ZipFile(zp) as z:
    assert set(z.namelist()) == set(m['members'])
    for n,v in m['members'].items():
        raw=z.read(n);assert len(raw)==v['bytes'] and sha(raw)==v['sha256']
    shape=json.loads(z.read('run/production-shape.json'))
    results['original_census_shape']=shape
    results['original_census_failure']=json.loads(z.read('run/failure.json'))
    results['original_census_terminal']=json.loads(z.read('evidence/mvp024-full-preparation-source-r1.terminal.json'))
    assert 'run/result.json' not in z.namelist()
known=read(D/'result.json')['matches']
binding=read(E/'replay/binding.json')
assert binding['source_manifest_sha256']==sha((E/'replay/input-manifest.json').read_bytes())
acks=[json.loads(x) for x in (E/'replay/seed.acks').read_bytes().splitlines()]
assert (E/'replay/seed.acks').read_bytes()==(E/'replay/replay.acks').read_bytes()
assert len(known)==len(acks)==13
oracle=read(E/'replay/oracle.json')['memories'];current=read(E/'replay/current-readback.json')
assert len(oracle)==len(current['claims'])==39
byid={x['id']:x for x in oracle};reads={x['id']:x for x in current['claims']}
enc=lambda x:json.dumps(x,ensure_ascii=False,separators=(',',':')).encode()
body_rows=[]
for ack in acks:
    h=ack['body_sha256']; item=known[h]; raw=gzip.decompress((D/'bodies'/f'{h}.txt.gz').read_bytes())
    assert sha(raw)==h and len(raw)==65536
    assert len(raw)-len(raw.decode().rstrip().encode())==1
    assert item['original_identity']['body_sha256']==h
    assert item['original_identity'] in shape['first_rejections']
    assert [(s['start'],s['end']) for s in item['original_spans']]==[(0,32767),(32767,65535),(65535,65536)]
    assert [(s['start'],s['end']) for s in item['candidate_spans']]==[(0,32767),(32767,65534),(65534,65536)]
    key='fineweb:'+h
    sid='corpus/'+sha(enc([enc({'source_manifest_sha256':binding['source_manifest_sha256'],'observed_time_ms':binding['observed_time_ms']}).decode(),key]))
    assert ack['source_id']==sid and ack['key_sha256']==sha(key.encode())==item['original_identity']['key_sha256']
    assert ack['utf8_bytes']==65536 and len(ack['memories'])==3
    previous=ack['source_revision']; joined=b''
    for (mid,revision),(start,end) in zip(ack['memories'],[(0,32767),(32767,65534),(65534,65536)]):
        claim=raw[start:end]; assert claim.decode().strip() and len(claim)<=32768
        assert mid==f'{sid}/{start}' and revision>previous; previous=revision; joined+=claim
        x=byid[mid];assert (x['source_hash'],x['source_revision'],x['revision'],x['start'],x['end'],x['claim_sha256'])==(h,ack['source_revision'],revision,start,end,sha(claim))
        assert reads[mid]['revision']==revision and reads[mid]['claim_sha256']==sha(claim)
        assert x['partition']=='p'+str(hashlib.sha256(key.encode()).digest()[0]%8)
    assert joined==raw
    body_rows.append({'body_sha256':h,'bytes':len(raw),'source_id':sid})
results['body_checks']=body_rows;results['source_bytes']=sum(x['bytes'] for x in body_rows);results['claims_checked']=39
commands=[json.loads(x) for x in (E/'replay/commands.jsonl').read_text().splitlines()]
assert len([x for x in commands if x['argv'][:2]==['memory','show'] and x['exit_code']==0])==39
assert commands[-1]['argv']==['daemon','stop'] and commands[-1]['exit_code']==0
# Full raw terminal/log chains, including the failures.
chains=[]
for root in (D,E,P):
    for f in sorted(root.rglob('*.terminal.json')):
        d=read(f); log=f.with_name(f.name.replace('.terminal.json','.log'))
        if 'log_sha256' in d and log.exists():
            assert sha(log.read_bytes())==d['log_sha256'],str(log)
            chains.append({'path':str(f.relative_to(A)),'exit_code':d['exit_code'],'log_sha256':d['log_sha256']})
results['terminal_log_chains']=chains
r=read(E/'evidence/mvp024-claim-tail-red-green-r1.json')
before=(E/'source/before/corpus_seed.rs').read_bytes();after=(E/'source/after/corpus_seed.rs').read_bytes()
assert after==pathlib.Path('examples/corpus_seed.rs').read_bytes()
# The before snapshot is the unmodified source; regression is retained separately.
reg=(E/'evidence/mvp024-claim-tail-regression-r1.rs').read_bytes()
assert sha(after.split(b'#[cfg(test)]',1)[1])==r['unchanged_test_module_sha256']
assert reg.strip() in after and sha(after)==r['source_sha256']
assert before==git('show','origin/main:examples/corpus_seed.rs')
assert (D/'source/original-corpus_seed.rs').read_bytes()==before
assert read(E/'evidence/mvp024-claim-tail-red-r1.admission.json')['command']==read(E/'evidence/mvp024-claim-tail-green-r1.admission.json')['command']
results['red_green']=r
v=read(E/'evidence/mvp024-claim-tail-replay-r1-verified.json')
assert sha((E/'evidence/mvp024-claim-tail-replay-r1.py').read_bytes())==v['driver_sha256']
assert sha((E/'evidence/mvp024-claim-tail-replay-reconcile-r1.py').read_bytes())==v['checker_sha256']
results['reconciled_run']=v
# Prior publication binds complete report, four tests, merge tree, local and CI logs.
report=(P/'review/report.md').read_bytes();att=read(P/'review/attestation.json')
assert sha(report)==att['report_sha256'] and len(report)==att['report_bytes']
accepted=read(P/'evidence/mvp024-full-preparation-review-accepted-r1.json')
assert sha((P/'review/attestation.json').read_bytes())==accepted['attestation_sha256']
pr=read(P/'evidence/mvp024-full-preparation-pr74-merged-r1.json')
assert report.decode().strip() in pr['readback']['body']
for rev in ['d49e812bcb8bee8030175412d2eef7bfefbecffa','bf1576828c2797f28f702370857b8bbc523e515e']:
    assert git('rev-parse',rev+'^{tree}').decode().strip()=='d37d9be8012702194a7700710ef5d12428e9e02f'
ci=read(P/'evidence/mvp024-full-preparation-ci44009285018-verified.json')
rawci=gzip.decompress((P/'evidence/mvp024-full-preparation-ci44009285018.log.gz').read_bytes())
assert sha(rawci)==ci['raw_log_sha256'] and len(rawci)==ci['raw_log_bytes']
for label,raw in [('local',(P/'evidence/mvp024-full-preparation-canonical-r1.log').read_bytes()),('ci',rawci)]:
    txt=raw.decode(); blocks=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',txt)
    assert len(blocks)==22 and [sum(int(x[i]) for x in blocks) for i in range(3)]==[651,0,39]
    assert 'Ran 35 tests' in txt and '# pass 7' in txt and '"tcp_sockets": 0' in txt
    results['publication_'+label]={'sha256':sha(raw),'rust_passed':651,'rust_ignored':39,'python_passed':35,'node_passed':7}
pt=read(P/'review/python-tests.json');assert sha((P/'review/python-tests.log').read_bytes())==pt['log_sha256'] and pt['passed']==4
results['prior_report_sha256']=sha(report)
(O/'semantic-audit.json').write_text(json.dumps(results,indent=2)+'\n')
print('Verified 13 bodies, 39 claim hashes, original rejection identities, source snapshots, receipt/log chains and prior publication.')
