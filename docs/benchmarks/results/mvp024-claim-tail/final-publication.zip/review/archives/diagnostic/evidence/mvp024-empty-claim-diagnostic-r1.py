"""Locate only the 13 rejected public corpus bodies; test a byte-preserving boundary candidate."""
import collections,gzip,hashlib,json,os,pathlib,resource,subprocess,sys,time
sys.dont_write_bytecode=True
W=pathlib.Path.cwd();E=pathlib.Path(__file__).parent
sys.path[:0]=[str(W/'spikes/data'),str(E),str(W/'spikes/helix')]
from download import verify,publish
from prepare_corpus import chunks
from mvp024_import_protocol_r1 import RUST_SPACE
from run_case import process_identity
import pyarrow.parquet as pq

def sha(data):return hashlib.sha256(data).hexdigest()
def spans(body,adjust=False):
    data=body.encode();start=0
    while start<len(data):
        end=min(start+32768,len(data))
        while end<len(data) and data[end]&0xc0==0x80:end-=1
        if adjust and end<len(data) and not data[end:].decode().strip(RUST_SPACE):
            prefix=data[:end].decode().rstrip(RUST_SPACE)
            if prefix:
                pivot=len(prefix[:-1].encode())
                if start<pivot<end and len(data)-pivot<=32768:end=pivot
        yield dict(start=start,end=end,bytes=end-start,blank=not data[start:end].decode().strip(RUST_SPACE))
        start=end

def self_test():
    examples=['plain','a'*32768,'a'*65536,'a'*32767+'你'+'b'*32764+'\n\n']
    assert any(x['blank'] for x in spans(examples[-1]))
    for body in examples:
        data=body.encode();actual=list(spans(body,True))
        assert b''.join(data[x['start']:x['end']] for x in actual)==data
        assert all(0<x['bytes']<=32768 and not x['blank'] for x in actual)
    impossible='a'+' '*32768
    assert any(x['blank'] for x in spans(impossible,True))
    print('PASS: exact original UTF-8 coverage, bounded nonempty candidate and unchanged irreducible rejection')

def main():
    assert len(sys.argv)==1
    root=(W/'.spike-work/mvp024-empty-claim-diagnostic-r1').resolve();root.mkdir(mode=0o700)
    (root/'OWNER').write_text('akasha-otsuge:mvp024-empty-claim-diagnostic-r1\n')
    config='[reliability]\nmax_attempts=1\nunit_timeout_s=7200\n[resources]\nobserved_client_rss_ceiling_bytes=1073741824\n'
    with (root/'run.toml').open('x') as f:f.write(config);f.flush();os.fsync(f.fileno())
    epoch=sha(config.encode())
    head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
    assert head=='d49e812bcb8bee8030175412d2eef7bfefbecffa' and not subprocess.check_output(['git','status','--porcelain'])
    source=(W/'.spike-work/mvp024-full-preparation-source-r1').resolve()
    shape=json.loads((source/'production-shape.json').read_text())
    expected={x['body_sha256']:x for x in shape['first_rejections']}
    assert len(expected)==shape['counts']['rejected_records']==13
    log=E/'mvp024-full-preparation-source-r1.log'
    assert sha(log.read_bytes())=='ad5a4229dd9a717baed592a7d17783afc8effdc415db40f48c66e0748cbd7837'
    previous=0;groups=collections.defaultdict(dict)
    for line in log.read_text().splitlines():
        if not line.startswith('{'):continue
        row=json.loads(line)
        if 'prepared' not in row:continue
        for digest,item in expected.items():
            if previous<item['ordinal']<=row['documents']:
                assert row['prepared'].startswith('text-')
                groups[row['prepared']][digest]=item
        previous=row['documents']
    assert sum(map(len,groups.values()))==13
    inventory=json.loads((W/'spikes/data/sources.json').read_text())['sources'][1]
    inputs=[]
    for name in sorted(groups):
        index=int(name[5:10]);item=inventory['files'][index]
        inputs.append(dict(file=name,source=item,expected_matches=len(groups[name])))
    code={name:sha((E/name).read_bytes()) for name in ('mvp024-empty-claim-diagnostic-r1.py','mvp024_import_protocol_r1.py')}
    publish(root/'admission.json',dict(head=head,config_epoch=epoch,inputs=inputs,code_sha256=code,source_shape_sha256=sha((source/'production-shape.json').read_bytes()),
        process=process_identity(os.getpid()),license=inventory['license'],repository=inventory['repository'],revision=inventory['revision'],
        purpose='Read-only exact body/span diagnosis. Candidate splitting is diagnostic only, not a production source change.',
        limits=dict(max_raw_selected_bytes=13*65536,observed_client_rss_bytes=1073741824,attempts=1)))
    started=time.monotonic();found={};(root/'bodies').mkdir()
    publish(root/'state.json',dict(phase='locating',completed_units=[],matches={}))
    for unit,item in enumerate(inputs,1):
        path=(W/'.spike-work/corpus-full-v1'/item['file']).resolve(strict=True);verify(path,item['source'])
        targets=groups[item['file']];row_number=0;matched=set()
        for batch in pq.ParquetFile(path,pre_buffer=False).iter_batches(batch_size=64,columns=['text']):
            for row in batch.to_pylist():
                start=0
                for chunk_number,body in enumerate(chunks(row['text'])):
                    data=body.encode();digest=sha(data)
                    if digest in targets and digest not in matched:
                        expected_row=targets[digest]
                        assert len(data)==expected_row['bytes']==65536
                        assert sha(('fineweb:'+digest).encode())==expected_row['key_sha256']
                        original=list(spans(body));candidate=list(spans(body,True))
                        assert any(x['blank'] for x in original)
                        assert b''.join(data[x['start']:x['end']] for x in candidate)==data
                        assert all(0<x['bytes']<=32768 for x in candidate)
                        body_path=root/'bodies'/(digest+'.txt.gz');body_path.write_bytes(gzip.compress(data,mtime=0))
                        found[digest]=dict(original_identity=expected_row,file=item['file'],source_row=row_number,source_chunk=chunk_number,
                            chunk_utf8_start=start,original_row_sha256=sha(row['text'].encode()),source_bytes=len(data),
                            original_spans=original,candidate_spans=candidate,candidate_complete_nonempty=not any(x['blank'] for x in candidate),
                            compressed_body_sha256=sha(body_path.read_bytes()),compressed_bytes=body_path.stat().st_size)
                        matched.add(digest)
                    start+=len(data)
                row_number+=1
            elapsed=time.monotonic()-started
            if row_number%4096==0 or matched==set(targets):
                publish(root/'progress.json',dict(phase='locating_exact_rejected_bodies',completed=len(found),total=13,shards_completed=unit-1,
                    shard_total=len(inputs),active_shard=item['file'],raw_rows_in_shard=row_number,elapsed_s=elapsed,
                    rate_per_s=len(found)/elapsed,eta_s=None,process=process_identity(os.getpid())))
            assert resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024<=1073741824
            if matched==set(targets):break
        assert matched==set(targets),('missing exact rejected body',item['file'],set(targets)-matched)
        publish(root/'state.json',dict(phase='locating',completed_units=[x['file'] for x in inputs[:unit]],matches=found))
    assert set(found)==set(expected)
    result=dict(phase='complete',matches=found,original_blank_span_bytes=sum(x['bytes'] for v in found.values() for x in v['original_spans'] if x['blank']),
        raw_selected_bytes=sum(v['source_bytes'] for v in found.values()),compressed_bytes=sum(v['compressed_bytes'] for v in found.values()),
        all_candidate_spans_nonempty=all(v['candidate_complete_nonempty'] for v in found.values()),
        source_byte_coverage_unchanged=True,max_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,elapsed_s=time.monotonic()-started)
    assert sha((root/'run.toml').read_bytes())==epoch
    assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head and not subprocess.check_output(['git','status','--porcelain'])
    publish(root/'result.json',result);publish(root/'state.json',result)
    publish(root/'progress.json',dict(phase='complete',completed=13,total=13,elapsed_s=result['elapsed_s'],rate_per_s=13/result['elapsed_s'],eta_s=0,process=process_identity(os.getpid())))
    print(json.dumps({k:v for k,v in result.items() if k!='matches'}))
if __name__=='__main__':
    if sys.argv[1:]==['--self-test']:self_test()
    else:main()

