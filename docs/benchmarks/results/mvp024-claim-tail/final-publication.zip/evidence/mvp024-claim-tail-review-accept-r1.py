from pathlib import Path
import hashlib,json,subprocess,datetime
e=Path(__file__).parent;w=Path.cwd();r=e/"mvp024-claim-tail-review-r1"
a=json.loads((r/"attestation.json").read_text());s=json.loads((e/"mvp024-claim-tail-parent-scope-r1.json").read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(["git",*args],text=True).strip()
report=(r/"report.md").read_text();assert report.splitlines()[0]==report.splitlines()[-1]=="VERDICT: PASS"
assert a["verdict"]=="PASS" and a["actionable_count"]==0 and a["clean"] and a["porcelain"]==""
assert sha(r/"report.md")==a["report_sha256"] and (r/"report.md").stat().st_size==a["report_bytes"]==11864
for k in ("head","tree","base","origin_main","branch","patch_sha256","patch_bytes"):assert a[k]==s[k]
assert git("rev-parse","HEAD")==a["head"] and git("rev-parse","HEAD^{tree}")==a["tree"] and not git("status","--porcelain")
assert git("rev-parse","origin/main")==a["base"] and git("branch","--show-current")==a["branch"]
patch=subprocess.check_output(["git","diff","--binary","--full-index","origin/main...HEAD"]);assert hashlib.sha256(patch).hexdigest()==a["patch_sha256"]
for name,digest in a["source_sha256"].items():
 assert sha(w/name)==digest
 assert hashlib.sha256(subprocess.check_output(["git","show","HEAD:"+name])).hexdigest()==digest
for name,digest in s["source_sha256"].items():assert a["source_sha256"][name]==digest
for name,info in a["artifacts"].items():
 p=r/name;assert p.resolve().is_relative_to(r.resolve()) and p.is_file() and not p.is_symlink()
 assert sha(p)==info["sha256"] and p.stat().st_size==info["bytes"],name
for name,digest in a["protected_input_hashes"].items():
 p=Path(name);p=p if p.is_absolute() else e/p
 assert p.resolve().parent==e.resolve()
 assert sha(p)==(digest["sha256"] if isinstance(digest,dict) else digest)
t=a["fresh_tests"];assert t["exit_code"]==0 and t["passed"]==5 and len(t["executed_tests"])==5
assert sha(r/"fresh-tests.log")==t["log_sha256"] and "5 passed; 0 failed; 0 ignored;" in (r/"fresh-tests.log").read_text()
assert sha(t["argv"][0])==t["binary_sha256_before"]==t["binary_sha256_after"]==a["postflight_binary_sha256"]
assert a["archive_member_count"]==166
for key,lines in {"examples/corpus_seed.rs":[142,184],"src/domain/mod.rs":[194,261,330,444,464,552,667,690],"src/domain/history.rs":[300],"src/storage/mod.rs":[386],"src/daemon.rs":[324]}.items():
 source=(w/key).read_text().splitlines()
 print(key,json.dumps({line:source[line-1:min(line+2,len(source))] for line in lines}))
accepted=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status="PASS",head=a["head"],tree=a["tree"],base=a["base"],branch=a["branch"],actionable_findings=0,report_sha256=a["report_sha256"],report_bytes=a["report_bytes"],attestation_sha256=sha(r/"attestation.json"),artifacts_verified=len(a["artifacts"]),source_hashes_verified=len(a["source_sha256"]),protected_inputs_verified=len(a["protected_input_hashes"]),archive_members_verified=166,fresh_rust_tests=5,fresh_tests_log_sha256=t["log_sha256"],preserved_review_aggregation_failures=3,preserved_parent_aggregation_failures=1,patch_sha256=a["patch_sha256"],scope="Reviewed claim-tail repair and bounded exact-body evidence; no full-scale acceptance.")
with (e/"mvp024-claim-tail-review-accepted-r1.json").open("x") as f:json.dump(accepted,f,indent=2);f.write("\n")
print(json.dumps(accepted))
