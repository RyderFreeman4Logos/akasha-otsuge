import datetime,gzip,hashlib,json,pathlib,re
E=pathlib.Path(__file__).parent
stem="mvp024-claim-tail-ci44016475601";b=(E/(stem+".log")).read_bytes();text=b.decode()
meta=json.loads((E/(stem+"-metadata.json")).read_text());run=json.loads((E/"mvp024-claim-tail-ci-r1.json").read_text())
scope=json.loads((E/"mvp024-claim-tail-parent-scope-r1.json").read_text())
assert run["id"]==44016475601 and run["head_sha"]==scope["head"] and run["run_attempt"]==1 and run["conclusion"]=="success"
checkout=meta["checkout"];assert checkout["tree"]==scope["tree"] and checkout["parents"]==[scope["base"],scope["head"]]
assert checkout["sha"] in text
rows=[tuple(map(int,x)) for x in re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;",text)]
assert len(rows)==22 and sum(x[0] for x in rows)==652 and sum(x[1] for x in rows)==0 and sum(x[2] for x in rows)==39
assert "Ran 35 tests" in text and "# pass 7" in text and "test result: FAILED" not in text
installed=next(json.loads(line[line.index('{"installed"'):]) for line in text.splitlines() if '{"installed"' in line)
assert installed["installed"] and all(installed[k]=="passed" for k in ("lifecycle","private_uid_denial","peer_uid_denial")) and installed["tcp_sockets"]==0
jobs=meta["jobs"]["jobs"];assert jobs and all(j["conclusion"]=="success" for j in jobs)
assert all(any(s["name"]=="Check" and s["conclusion"]=="success" for s in j["steps"]) for j in jobs)
z=gzip.compress(b,mtime=0);(E/(stem+".log.gz")).write_bytes(z)
result=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status="PASS",head=scope["head"],tree=scope["tree"],checkout=checkout,run=run,jobs=meta["jobs"],rust_passed=652,rust_ignored=39,rust_blocks=22,python_passed=35,node_passed=7,installed=installed,raw_log_bytes=len(b),raw_log_sha256=hashlib.sha256(b).hexdigest(),gzip_bytes=len(z),gzip_sha256=hashlib.sha256(z).hexdigest(),actual_checkout_tree_equals_reviewed=True)
with (E/(stem+"-verified.json")).open("x") as f:json.dump(result,f,indent=2);f.write("\n")
print(json.dumps({k:result[k] for k in ("status","head","tree","rust_passed","raw_log_sha256","gzip_sha256","installed")}))
