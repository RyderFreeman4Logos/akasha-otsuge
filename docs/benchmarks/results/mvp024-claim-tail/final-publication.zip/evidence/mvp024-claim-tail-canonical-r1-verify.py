import datetime,hashlib,json,pathlib,re,subprocess
E=pathlib.Path(__file__).parent
stem='mvp024-claim-tail-canonical-r1'
load=lambda n:json.loads((E/n).read_text())
scope=load('mvp024-claim-tail-parent-scope-r1.json');ad=load(stem+'.admission.json');end=load(stem+'.terminal.json')
assert (E/(stem+'.collected.json')).exists()
git=lambda *a:subprocess.check_output(['git',*a],text=True).strip()
assert end['exit_code']==0 and ad['command']==['just','check']
assert ad['head']==end['head']==scope['head']==git('rev-parse','HEAD') and ad['tree']==scope['tree']==git('rev-parse','HEAD^{tree}')
assert not git('status','--porcelain') and ad['dirty_diff_sha256']==hashlib.sha256(b'').hexdigest() and not ad['untracked']
assert scope['base']==git('merge-base','origin/main','HEAD') and scope['origin_main']==git('rev-parse','origin/main')
for p,sha in scope['source_sha256'].items():assert hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()==sha,p
b=(E/(stem+'.log')).read_bytes();assert hashlib.sha256(b).hexdigest()==end['log_sha256'];text=b.decode()
rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
assert len(rows)==22 and all(int(r[1])==0 for r in rows)
passed=sum(int(r[0]) for r in rows);ignored=sum(int(r[2]) for r in rows)
assert (passed,ignored)==(652,39),(passed,ignored)
assert re.search(r'Ran 35 tests in [\d.]+s\s+OK',text) and re.search(r'# pass 7\s+# fail 0',text)
installed=[json.loads(line) for line in text.splitlines() if line.startswith('{"installed":')]
assert len(installed)==1;installed=installed[0]
assert installed['installed'] and all(installed[k]=='passed' for k in ('lifecycle','private_uid_denial','peer_uid_denial')) and installed['tcp_sockets']==0
assert hashlib.sha256(pathlib.Path('target/release/akasha-otsuge').read_bytes()).hexdigest()==installed['binary_sha256']

assert 'test result: FAILED' not in text and 'akasha-otsuge 0.1.0-dev' in text
result=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='PASS',head=scope['head'],tree=scope['tree'],base=scope['base'],
 exit_code=end['exit_code'],seconds=end['seconds'],log_sha256=end['log_sha256'],rust_passed=passed,rust_ignored=ignored,rust_result_blocks=len(rows),
 python_passed=35,node_passed=7,clippy_fmt='PASS',capture_example='PASS',installed=installed,clean_before_after=True,scoped_source_hashes=scope['source_sha256'],
 limits='Exact final claim-tail candidate canonical gate; 13-body verification used separately pinned release artifacts. Its cleanup failure remains preserved. No full-scale acceptance.')
matches=re.findall(r'Running unittests examples/corpus_seed\.rs \(([^)]+)\)',text)
assert len(matches)==1,matches
binary=pathlib.Path(matches[0]);assert binary.is_file()
result['review_test_binary']=dict(path=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),source_sha256=scope['source_sha256']['examples/corpus_seed.rs'],basis='Exact clean canonical log names this test artifact; five maintained seeder tests execute in this gate.')
with (E/(stem+'-verified.json')).open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k!='scoped_source_hashes'}))

