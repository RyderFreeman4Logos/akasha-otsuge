import hashlib,json,pathlib,zipfile,datetime
E=pathlib.Path(__file__).parent;W=pathlib.Path.cwd()
already=set()
for name in ("manifest.json","diagnostic-manifest.json"):
 p=W/"docs/benchmarks/results/mvp024-claim-tail"/name
 old=json.loads(p.read_text())
 already.update(n.removeprefix("evidence/") for n in old["members"] if n.startswith("evidence/"))
state=json.loads((E/"wd-state.json").read_text());assert all(not p["name"].startswith("mvp024-claim-tail") for p in state["active_work"]["primaries"])
members={}
for p in sorted(E.iterdir()):
 if p.is_file() and p.name.startswith("mvp024-claim-tail") and p.name not in already:
  if p.name.endswith((".stdout",".stderr",".final.txt",".supervisor.log")):continue
  if p.name in ("mvp024-claim-tail-final-publication.zip","mvp024-claim-tail-final-publication-manifest.json"):continue
  if p.name=="mvp024-claim-tail-ci44016475601.log":continue
  members["evidence/"+p.name]=p
R=E/"mvp024-claim-tail-review-r1"
a=json.loads((R/"attestation.json").read_text())
for name,v in sorted(a["artifacts"].items()):
 p=R/name;assert p.is_file() and not p.is_symlink()
 assert p.stat().st_size==v["bytes"] and hashlib.sha256(p.read_bytes()).hexdigest()==v["sha256"]
 members["review/"+name]=p
members["review/attestation.json"]=R/"attestation.json"
members["runtime/mvp020-review-runtime-r2.json"]=E/"mvp020-review-runtime-r2.json"
archive=E/"mvp024-claim-tail-final-publication.zip";entries={}
with zipfile.ZipFile(archive,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(members.items()):
  raw=p.read_bytes();i=zipfile.ZipInfo(name,(2026,11,17,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,raw)
  entries[name]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(entries)
 for name,v in entries.items():assert hashlib.sha256(z.read(name)).hexdigest()==v["sha256"]
receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),reviewed_head="73a0911d07f50c4cd17a2c234a9f6444f62de4ee",merge="a177d6e23568b627ec9eef593d88289bc8634041",tree="89de21fb856fe342430bc0f7a9a54464bf64f477",archive_bytes=archive.stat().st_size,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=entries,scope="Final PR75 exact gate, independent review, CI, push, PR readback, merge and tracker reconciliation; original 13-body evidence remains in evidence.zip and diagnostic.zip.",publication="Complete immutable PASS report is in PR75 description. Original full scan, cleanup and review/parent aggregation failures remain preserved. All 13 repaired bodies pass bounded functional checks; no full production import/index acceptance.",staged_outside_frozen_worktree=True)
with (E/"mvp024-claim-tail-final-publication-manifest.json").open("x") as f:json.dump(receipt,f,indent=2);f.write("\n")
print(json.dumps({k:v for k,v in receipt.items() if k!="members"}|dict(members=len(entries))))
