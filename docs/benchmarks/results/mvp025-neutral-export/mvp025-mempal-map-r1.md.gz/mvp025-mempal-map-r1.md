**建议首版导入器只支持经结构校验的 `(schema=21, fork_ext=28)` 快照。** 仅导出 `drawers` 或搜索结果会丢失持久数据；应分别保存内容、关系、历史凭据及停用的运行状态。

以下 `P` **精确代表** `4593a5c5e6a9ea1140256cd42fa5838511a24e14`；引用格式为 `P:path:行范围`。这是冻结源码探索报告，不是代码审查或运行验证。

**读取边界。** 已跟随符号链接完整读完：

- `mempal/AGENTS.md` → `/home/obj/project/github/t4nature/s/llm/coding/rules/AGENTS.md`，195 行。
- `mempal/CLAUDE.md` → `/home/obj/project/github/RyderFreeman4Logos/drafts/mempal/CLAUDE.md`，249 行。

采用父任务已核实的 `src/`、`src/core/` 无嵌套指令结论。源码仅通过冻结 Git 对象读取；未读取修改后的工作区源码，未打开数据库、运行 mempal、构建、测试或调用网络。

**1．必须保留的内容与关系**

| 表／主键 | 导入映射与不可静默丢弃的字段 | 冻结来源 |
|---|---|---|
| `drawers`／`id TEXT` | 当前存储文本 `content`；`wing, room, source_file, source_type, confidence, added_at, chunk_index`。`source_file` 是出处标识，不是原文件字节副本。 | `P:src/core/db.rs:224–249` |
| `drawers` 扩展 | `memory_kind, domain, field, anchor_kind, anchor_id, parent_anchor_id, provenance, statement, tier, status`；四组 JSON 引用 `supporting_refs, counterexample_refs, teaching_refs, verification_refs`；`scope_constraints, trigger_hints, content_hash`。 | `P:src/core/db.rs:6594–6662` |
| `drawers` 范围与生命周期 | `project_id, source_root, normalize_version, deleted_at, valid_from, valid_until, merge_count, updated_at, compacted_into, supersedes, is_pinned, pin_order`。保留失效、删除及被替代记录，不能全部恢复成活动记忆。 | `P:src/core/db_fork_ext.rs:534–546,628–630`; `P:src/core/db.rs:6552–6554,6816–6817,6931–6937,6155–6199`; `P:src/core/db_fork_ext.rs:300–302` |
| `drawers` 排序／归属状态 | `importance, last_accessed_at, access_count, accumulated_boost, effective_importance, stale_penalty_applied, consolidation_priority, last_sleep_at`；另有 `admission_owner, creation_operation_id`。前者包含不可凭文本重建的使用历史，后者只作来源元数据。 | `P:src/core/db.rs:6584–6585,6219–6230,7095–7097`; `P:src/core/db_fork_ext.rs:767–784`; `P:src/core/db_fork_ext_v28.rs:3–5` |
| `triples`／`id TEXT` | `subject, predicate, object, valid_from, valid_to, confidence, source_drawer`，以及 nullable `project_id`。实体是文本，不应自行创造实体 ID；`source_drawer` 指向 drawer。 | `P:src/core/db.rs:240–249`; `P:src/core/db_fork_ext.rs:534–536` |
| `taxonomy`／`(wing,room)` | `display_name, keywords`；`room` 默认空串。保留空串与 NULL 的区别，不把用户路由关键词当可随意丢弃的索引。 | `P:src/core/db.rs:251–257` |
| `tunnels`／`id TEXT` | 左右 `wing/room`、`label, created_at, created_by, deleted_at`。这是显式范围链接，不是 drawer 外键，也没有该 DDL 所定义的 project 字段。 | `P:src/core/db.rs:6794–6814` |
| `knowledge_cards`／`id TEXT` | `statement, content, tier, status, domain, field`；完整 anchor 层级、`scope_constraints, trigger_hints, created_at, updated_at`；`auto_generated, crystallization_score, source_drawer_ids`。卡片不能与同名 drawer 合并。 | `P:src/core/db.rs:6830–6846,6246–6277` |
| `knowledge_evidence_links`／`id TEXT` | `card_id → knowledge_cards.id`、`evidence_drawer_id → drawers.id`、`role, note, created_at`；唯一组合 `(card_id,evidence_drawer_id,role)`。角色有 supporting、verification、counterexample、teaching。 | `P:src/core/db.rs:6848–6858` |
| `conversation_turns`／`id TEXT` | 实际保存的会话文本 `content`；`session_id, tool, turn_index, role, timestamp_epoch, token_count, project_path, git_branch, is_csa_delegated, provenance`。唯一组合 `(session_id,tool,turn_index)`。 | `P:src/core/db_fork_ext.rs:30–55` |
| `conversation_turns` Hermes 元数据 | `hermes_profile, session_title, session_source, message_id, tool_name, tool_call_id, previous_message_id, next_message_id`。Hermes 条件唯一键为 `(hermes_profile,session_id,message_id)`；保留 profile 与前后消息链接。 | `P:src/core/db_fork_ext.rs:106–120,699–708` |
| `patterns`／`pattern_id` | `signature BLOB, exemplar_ids, exemplar_count, session_ids, session_count, topic_tags, model_id, status, first_seen_at, updated_at, project_id`。即使模式由算法生成，也须保留原记录及引用。 | `P:src/core/db_fork_ext.rs:224–241` |
| `skills`／`skill_id` | `name, trigger_description, pattern_id, exemplar_ids, adoption_count, rejection_count, status, promoted_at, updated_at, project_id`。这些状态和反馈计数不能从文本重建。 | `P:src/core/db_fork_ext.rs:191–207` |
| `foresights`／`drawer_id` | drawer 外键；`statement, reason, trigger_condition, due_at, valid_from, valid_until, resolved_at, resolution_note, created_at, updated_at`。导入后不自动调度。 | `P:src/core/db.rs:7052–7071` |
| `design_insights`／`id` | `source, scope, target_artifact, evidence_ref, summary, rule_text, priority, status, created_at, resolved_at, resolved_by, resolution_note, redaction_count, project_id`。这是保存的设计内容与处理结果。 | `P:src/core/db.rs:7023–7049` |

**不要只复用 `Drawer` DTO 做导出。** 它不包含全部持久列，例如 project/source root、删除时间、merge 状态及 operation 归属。应按受支持表结构读取原始列。参见 `P:src/core/types.rs:555–600` 与上述迁移。

`content_hash` 是 **BLAKE3(content bytes)**；drawer ID 则可能使用截短 SHA-256 加范围信息。ID 不是内容完整性摘要，导入时必须保留原 ID，并另算完整摘要。见 `P:src/core/db.rs:95–97`; `P:src/core/utils.rs:18–65`。

**2．实际保留的历史、审计与 recall 凭据**

| 表／主键 | 保存了什么；不能推断什么 |
|---|---|
| `knowledge_events`／`id` | `card_id,event_type,from_status,to_status,reason,actor,metadata,created_at`；数据库触发器禁止 UPDATE/DELETE。它记录生命周期事件，DDL **不要求保存每版完整卡片文本**。`P:src/core/db.rs:6860–6901` |
| `runtime_adoption_events`／`id` | `track,signal,feature,query,context_hash,card_id,evaluator_id,research_report_id,note,metadata,created_at`。可保存使用／接受／拒绝等记录，但不等于完整检索结果、完整 context 或已证实的人类确认。`P:src/core/db.rs:6904–6929` |
| `consolidation_log`／`id` | 时间、wing/room/project、cluster size、strategy、target drawer、source drawer ID 列表、`dry_run`。是压缩关系凭据，不是被压缩文本的独立版本库。`P:src/core/db.rs:7099–7122` |
| `sleep_log`／`id`；`sleep_resolution_log`／`id` | 前者保存阶段、计数、dry-run；后者保存 drawer／triple／原 source drawer 引用、双方 confidence、action、dry-run。`P:src/core/db.rs:7134–7173` |
| `failure_events`／`event_id` | drawer、wing/room/project、topic signature、failure type、detected time。保存检测结果，不代表保存了完整失败过程。`P:src/core/db_fork_ext.rs:209–222` |
| `gating_audit`／`id` | candidate hash、drawer、decision、tier、label/reason/score、`explain_json`、保留期限、时间、project、LLM verdict/score、可选 `content_preview`。preview 不是完整原文。`P:src/core/db_fork_ext.rs:279–298,327–329,544–546,843–855` |
| `novelty_audit`／`id` | candidate hash、decision、near drawer、cosine、created time、project；没有完整候选正文列。`P:src/core/db_fork_ext.rs:304–316,544–546` |
| `pending_message_completions`／`message_id` | kind、创建/claim/完成时间、processing ms、result drawer、op state、拒绝原因、failure detail、`result_json`、nullable `source_hash`。这是完成回执，不能重新执行。`P:src/core/db_fork_ext.rs:333–347,68–79`; `P:src/core/db_fork_ext_v27.rs:3–5` |

关键限制：

- novelty merge 原地替换 `drawers.content/content_hash/updated_at` 并递增 `merge_count`；没有在该路径保存旧全文。不能制造修订链。`P:src/core/db.rs:1155–1195`。
- supersede 保留旧 drawer，并设置 status、deleted_at、valid_until；原因另追加到 DB 同目录的 `audit.jsonl`。**单 DB 导入无法取得该文件内的原因。** `P:src/core/db.rs:3604–3645`。
- gating 与 embedding failure audit 有七天保留机制，源码提供清理操作；缺少事件不证明事件从未发生。`P:src/core/db.rs:60,896–908`; `P:src/core/db_fork_ext.rs:801–813`。
- `source_type='user_explicit'`、`provenance='human'`、accepted signal、promoted status 都应保留为**源系统声明**。它们本身不足以证明某个具体用户审阅了具体版本；源码还包含来源／confidence 回填。`P:src/core/db.rs:6965–6992`。

**3．派生数据与禁止重新激活的状态**

| 类别 | 处理建议及证据 |
|---|---|
| FTS、普通 SQL indexes、FTS shadow tables | 可由保留文本重建，不作为内容来源。`drawers_fts` 是 external-content FTS5；当前迁移会重建它。`P:src/core/db.rs:6557–6566,7012–7021` |
| `drawer_vectors` | 可选、惰性创建的 vec0 表；`id,embedding FLOAT[动态维度],project_id`，当前距离 cosine、index version `v2`。允许“没有向量”的合法库；导入时不要调用模型补齐。`P:src/core/db.rs:49–51,236–238`; `P:src/core/db_fork_ext.rs:1043–1056` |
| `conversation_turn_vectors` | `(turn_id,chunk_index)` 主键、vector BLOB；后加 `embedder_fingerprint,dim,index_version`。保留来源对应关系；重新生成需明确模型契约，不能声称可重建出相同字节。`P:src/core/db_fork_ext.rs:46–51,633–642` |
| `fork_ext_meta`／`key` | 版本标记、向量身份元数据、计数器、维护进度等混合 KV。按键分类保存，未知键列入清单，不能整体当配置执行。向量键形如 `reindex:{drawer_id}:{field}`。`P:src/core/db_fork_ext.rs:19–26,570–591`; `P:src/core/db.rs:1563–1584,7307–7309` |
| `pending_messages`／`id` | kind、source hash、**payload**、claim token、claim/heartbeat 时间、retry/backoff/next-attempt、status、错误、failure class，以及结果字段。payload 可能含尚未进入 drawers 的唯一内容，不能静默丢弃；只能保存为停用的未完成输入。`P:src/core/db_fork_ext.rs:243–266,68–79,711–760` |
| `reindex_progress`／`source_path` | chunk checkpoint、embedder、开始/更新时间、status；停用保存，不恢复任务。`P:src/core/db_fork_ext.rs:268–277` |
| `leases`、`runtime_writer_leases`、`runtime_writer_lease_generations` | 文件资源 holder、runtime owner/PID/boot/session、expiry/heartbeat、mode、metadata、generation。仅审计保留，不转成有效锁或授权。`P:src/core/db.rs:7001–7009,7074–7093`; `P:src/core/db_fork_ext_v26.rs:15–29` |
| `operation_telemetry`／`id`；`embed_failure_log`／`id` | 操作时间、耗时、来源、错误、行数/I/O/锁/重试统计与 metadata；embedding 错误、endpoint、次数、耗时及保留期限。不会重建内容历史。`P:src/core/db_fork_ext.rs:131–162,174–189` |
| 可选 `historical_rejudge_work_items` | `(run_id,drawer_rowid)` 主键，保存 drawer ID、快照 hash/元数据、LLM stage、处理结果；不是正文版本表，不恢复执行。`P:src/main.rs:3086,21121–21165` |

另有独立 `rejudge-backup-*.sqlite`，其 `user_version=2`，表为 `rejudge_backup_metadata/rejudge_backup_items`，后者保存 `item_json/content_sha256`。**它不是 schema21 的 palace DB**；首版应拒绝误识别。见 `P:src/main.rs:22122–22149`。

**4．版本、只读与损坏处理契约**

已验证：

- upstream 标记来自 `PRAGMA user_version`，当前 **21**；fork 标记来自 `fork_ext_meta['fork_ext_version']`，当前 **28**。正常打开路径先检查两轴，更高版本均报错。`P:src/core/db.rs:49,6447–6460`; `P:src/core/db_fork_ext.rs:26,362–389`; `P:src/core/db_open.rs:5–14,317–318`。
- 缺 fork meta 表或版本键，原程序返回 **0**；非数值字符串报转换错误。原程序接受较低版本不代表首版 importer 应支持它们。建议缺标记、旧版、未来版、结构不匹配均明确拒绝，另行扩展支持矩阵。
- `open_read_only` 使用 SQLite READ_ONLY；`open_query_only` 实际以 READ_WRITE 打开，再设 query_only。二者都跳过迁移。`P:src/core/db_open.rs:175–200,302–334`。
- **`open_read_only` 仍申请 admission，创建 holder lease 并保存 admission state。** 因此不适用于要求零源端写入的 importer。`P:src/core/db_open.rs:252–263`; `P:src/core/db_admission.rs:451–484`。
- 标准打开会注册 sqlite-vec；依赖声明为 sqlite-vec `0.1.9`、rusqlite `0.37` bundled。`P:src/core/db_open.rs:296`; `P:src/core/db.rs:7285–7300`; `P:Cargo.toml:67–72`。
- 可选 JSON 缺值与损坏不是同一情况：NULL list 可读成空列表，损坏 JSON 会报错；未知 enum、非法 anchor/domain 组合也会报错。taxonomy decoder 还会过滤非字符串元素。导入器应保留原字段及诊断，避免这种有损解码。`P:src/core/db.rs:7569–7599,7677–7715,7764–7778`。

**快照/WAL 建议属于待验证的 importer 要求，不是已发现的 mempal 快照保证：** 本轮未找到可据此承诺一致导出的公共 snapshot 接口。只接受已独立制备、停止变化且有来源清单的一致快照；不能在写入期间仅复制 `.db`、遗漏 WAL，或用 `immutable=1` 掩盖变化。读取应使用独立 SQLite READ_ONLY 连接和一个显式读事务，不调用 mempal bootstrap、migration、checkpoint 或 admission。向量缺失、扩展缺失与内容表损坏必须分别报告。

**5．真实隔离样本的最小路径——仅建议，未执行**

建议后续编写一个**固定 P 的公共库 API fixture builder**，仅向指定 SSD 隔离目录写新库：

1. `Database::open(new_path)` 让真实迁移创建 21/28；通过 `Drawer::new_bootstrap_evidence` 和 `insert_drawer_with_project_validity` 写三个固定文本 drawer：A 项目两个、B 项目一个。
2. 用公共 API 写一个 taxonomy entry、一个引用 A1 的 triple、一个 knowledge card 和一条 supporting evidence link；soft-delete A2。
3. 关闭全部 builder 连接，再独立只读验收。预计上述业务表计数分别为 drawers=3、deleted=1、triples=1、cards=1、links=1、taxonomy=1。其他表及元数据另列实际计数，不能预设全空。
4. 使用独立读取器检查版本、完整性、外键及引用目标；按主键排序计算带 NULL/类型标记的逐行摘要和表摘要，并保存成品文件 SHA-256、固定文本预期摘要、两项目分布及全部关系。
5. 第二层样本再覆盖 conversation、supersedes、compaction、receipts、malformed JSON、未知版本和向量扩展失败；不以手写简化 DDL 冒充真实支持样本。

公共入口证据：`P:src/lib.rs:17`; `P:src/core/mod.rs:8,59–60`; `P:src/core/db_open.rs:165–168`; `P:src/core/types.rs:602–652`; `P:src/core/db.rs:589–617,1282,3025–3072,3365–3403,3549–3555,4214–4231`。CLI ingest 具有 pipeline 行为，本轮没有核实无模型且完全隔离的调用契约，因此不推荐直接拿它生成该样本。

**建议 importer 验收不变量：** 原始 ID 和文本字节保持；不跨 project/profile 合并；NULL、空串、空列表可区分；所有表都有“导入／停用保存／明确排除”计数；引用缺失有诊断；deleted/superseded/compacted 不复活；审计不升级为用户事实；未完成 payload 不丢失；任何失败不发布半成品，重复导入可识别同一来源快照。

**本轮明确未知：** 实际库的表存在性、行数、完整性与历史覆盖；会话采集是否完整；原文件是否另有副本；外部 `audit.jsonl`、spool、配置及备份的实际保留情况；无 sqlite-vec 时普通内容读取的具体兼容边界。下一步最窄缺口是上述真实 fixture 与独立快照验收，无需扩大源码探索。

**读取文件及 SHA-256。** 下列均为 P 的完整 blob 哈希；阅读采用上述目标范围，未整文件倾倒 `db.rs`。

```text
src/core/db.rs                e0d74766aeeeff40efe4faf8371f0b19485f99573e7ef8f2c9273101852fe8a8
src/core/db_fork_ext.rs       93b7f9e801161d96d585002cb66dd61ff2b51903ec0264a91ea1c2a2ef3cf578
src/core/db_fork_ext_v26.rs   429f1d2e6acc59294b9f6328f43f44773688c3f848df9f5bb3b2238734aec8c3
src/core/db_fork_ext_v27.rs   14b40d836d36bb583807f73c30ee6840c304e0310348132e10618cb5985e0d82
src/core/db_fork_ext_v28.rs   9e2b686899e4db25b6cf3620f4e5d624692279a9c4e0b63ef29566c861691382
src/core/db_open.rs           a86e5373a28fa4d7ac7e7587059ee9f46bab792da4cf9690c804414fbb9d8cee
src/core/db_connection.rs     edff04e39ae906f3e06b5b3117a922202dc71b3c747a42bea09e789b7eece670
src/core/db_admission.rs      491548882381cb78360c9209d7baa05d4261c6e8e8dcda2d5b4791678dcadcad
src/core/types.rs             c467720f585bba908ac3fd5ba32aad359601932a0619b794a608ab3f09a4bce0
src/core/utils.rs             dae409b469a0b09cc3e30e3a9519578e6523ec0462b90a5601ede5d18aab9188
src/core/mod.rs               f111af66918523b5adefeb99c3214bb8cd4a264e552bfedcbfea47d4c25b04c5
src/lib.rs                    9656d3e431b779d472f9612e2c62551d6cd4150a4662a7915422e5c166576171
src/main.rs                   ca5f7103624d877b53c08e77d577f3cba636efcb50330e0fc9661517cda03e58
Cargo.toml                    a5f9c35139aab1416c19bf2f9a5e7bc90ceae5d1de80e15a87643067b73a172c
```

未创建文件、Git artifacts、relay 或子 agent；所有命令已结束，未改动源码、数据、配置或 memory。  
未执行样本或运行验证；主要风险是误把当前文本与审计凭据当作完整原始资料或修订历史。

