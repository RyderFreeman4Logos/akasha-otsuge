import hashlib
import json
import pathlib
import subprocess
import zipfile

E = pathlib.Path(__file__).parent
M = E.parent.parent
head = 'e7cef25276e0737d781b5cfac69504c70c15818d'
merge = '9f2ba152529a796383204a8a98dd89a5c6af6616'
git = lambda *args: subprocess.check_output(['git', '-C', str(M), *args])
assert git('rev-parse', head + '^{tree}') == git('rev-parse', merge + '^{tree}')
names = []
for stem in ('canonical-r1', 'review-launch-r1', 'push-r1'):
    for suffix in ('.admission.json', '.launch.json', '.terminal.json', '.collected.json', '.log'):
        names.append('mvp024-mempal-lock-' + stem + suffix)
names += ['mvp024-mempal-lock-' + name for name in (
    'canonical-r1-preflight.json', 'canonical-r1-verified.json',
    'review-r1.md', 'review-r1-tests.log', 'review-r1-scope.json',
    'review-r1-postflight.json', 'review-r1-final.json', 'review-r1-verified.json',
    'review-r1-parent-citations.json', 'review-r1.exit.json', 'review-r1.final.txt',
    'review-r1-public-body.md', 'review-r1-transport-cleanup-admission.json',
    'review-r1-transport-cleanup.json', 'remote-r1.json', 'publication-r1.json',
    'publication-final.json', 'ci-r1.json', 'ci-r1.log.gz', 'merge-r1.json',
)]
names += ['mvp024-production-main-ci-cache-r1.json']
members = {'receipts/' + name: (E / name).read_bytes() for name in names}
assert hashlib.sha256(members['receipts/mvp024-mempal-lock-review-r1.md']).hexdigest() == 'c8ad662d0858e30bb890988ec0be9c72fb5fce898a13cd0b0f7583f6128b136a'
source = 'src/storage/mempal/writer.rs'
members['source/e7cef25/' + source] = git('show', head + ':' + source)
members['archive-builder.py'] = pathlib.Path(__file__).read_bytes()
pins = {source: hashlib.sha256(members['source/e7cef25/' + source]).hexdigest()}
identity = {'reviewed_head': head, 'merge': merge,
            'tree': git('rev-parse', head + '^{tree}').decode().strip(),
            'source_sha256': pins,
            'scope': 'Final gate, independent review, full public report readback, CI and merge supplement. Earlier RED/GREEN and failures remain in evidence.zip.'}
members['identity.json'] = (json.dumps(identity, indent=2) + '\n').encode()
archive = E / 'mvp024-mempal-lock-finalization.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as target:
    for name, data in members.items():
        assert not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts
        info = zipfile.ZipInfo(name, (2026, 11, 11, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        target.writestr(info, data)
manifest = {**identity, 'zip_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
            'zip_bytes': archive.stat().st_size,
            'members': {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                        for name, data in members.items()}}
with zipfile.ZipFile(archive) as target:
    assert len(target.namelist()) == len(set(target.namelist())) == len(members)
    for name, expected in manifest['members'].items():
        data = target.read(name)
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
with (E / 'mvp024-mempal-lock-finalization-manifest.json').open('x') as target:
    json.dump(manifest, target, indent=2)
    target.write('\n')
print(json.dumps({'archive': str(archive), 'members': len(members),
                  'bytes': manifest['zip_bytes'], 'sha256': manifest['zip_sha256']}))
