VERDICT: PASS
ACTIONABLE_COUNT: 0

Independent Codex conventional read-only fallback using native-code-review criteria; this is not a Hermes verdict. Zero actionable regressions or leaf contract gaps found in the complete origin/main...HEAD range.

HEAD: e7cef25276e0737d781b5cfac69504c70c15818d
TREE: e377ab28ae4c516518ff09ac1ac6f2fdc9a53d48
BASE / merge-base: e5746acbaffbd6189fca51f9248249fb6d1f6585
origin/main: b71b18d9b959c4b2214405da812570ff1d39d772
Branch: fix/mempal-output-lock-release
Implementation parent: 1ebec1478cf6b896b349827ad131cc630d67d7b5 (tree b00609f52e7db4d9b58fed351472537d90fe6f34), directly parented by BASE. HEAD adds documentation/evidence only.

Scope and filesystem instructions

W=/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025
E=/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/.git/akasha-evidence

The five changed paths exactly match mvp024-mempal-lock-review-r1-scope.json: writer.rs, docs/plan/todo.md, and the evidence README/ZIP/manifest. All current bytes match frozen HEAD and the scope's SHA-256 values. The complete 710-line writer, constructors, ownership and publication paths, full/incremental callers and relevant sinks/tests were read.

Before source, filesystem checks found no AGENTS.md or CLAUDE.md at W, its ancestors, E, its ancestors, or in the src/docs/tests instruction search. Explicit applicable ancestor checks were repeated at postflight: 54 logical instruction paths, all absent (including no dangling symlink); zero instruction lines available. W/AGENTS.md and W/CLAUDE.md resolve to their identical absolute W paths and are absent; the same holds for W/src, W/src/storage, W/src/storage/mempal, W/src/storage/mempal/incremental, W/docs, W/docs/plan, W/docs/benchmarks, W/docs/benchmarks/results and W/docs/benchmarks/results/mempal-output-lock instruction pairs. Full absolute logical/resolved paths, existence and line counts are recorded in E/mvp024-mempal-lock-review-r1-postflight.json. No Git-tree absence was substituted for filesystem checks.

Ownership review

- src/storage/mempal/writer.rs:77 and :79 unlock the pinned conversion-file and directory descriptors. Neither operation reopens a pathname. File replacement or directory renaming therefore cannot redirect cleanup to a replacement owner.
- writer.rs:108 opens a fresh directory description; :127 acquires it before Output exists (:129). Failed directory admission closes only that attempt's description. writer.rs:179 independently opens the conversion file; :203 stores a try_clone of that same description before :139 locks the returned handle. A failed conversion-file attempt can invoke unlock on its own unlocked description, never another writer's independently opened description. The directory remains owned through conversion-file cleanup, then releases last.
- writer.rs:198 checks an existing pinned member without replacing its map entry. The later directory scan cannot replace the original lock owner with a separately opened description. Publication inserts only conversion.json or manifest.json on these paths (:385, :524), not the lock member.
- Retained descriptor copies share the owner's open file description. Explicit unlock removes its lock even while copies remain open; their later close cannot unlock a successor's distinct description. This is the same best-effort destructor policy as src/storage/layout.rs:41. Unlock errors remain intentionally ignored in Drop; this is not a new fallible shutdown API or a claim about process-abort cleanup.
- All fallible steps before directory acquisition own no lock. After acquisition, Output is constructed without an intervening fallible operation. Errors from lock-file opening/validation, lock attempt, directory scan, identity parsing, sink opening or output validation unwind Output. Partial sink construction drops later-created sink locals before the earlier output local (writer.rs:353, :394, :395, :396). For a complete Writer, declaration order drops commits/blobs (:18, :19) before output (:30), regardless of initializer order.
- finish consumes self at writer.rs:505, flushes pending changes (:506), consumes and finishes sinks (:514, :515), then syncs or publishes metadata (:523, :524). Sink::finish flushes and syncs at src/storage/archive.rs:118 and :119. Error exits retain cleanup ordering; ordinary drop likewise drops buffered sinks before unlocking. Publication still writes/syncs an anonymous file and links without replacement (writer.rs:282, :283, :284), then syncs the directory (:302).
- Full migration constructs at src/storage/mempal.rs:97 and consumes at :175; intermediate errors unwind the same writer. Incremental migration constructs through Writer::open at src/storage/mempal/incremental.rs:567; conversion borrows it, clears projection (:594), closes storage (:595), cleans scratch (:598), and finishes (:601). All error returns drop the writer. CLI dispatch at src/main.rs:698 and :699 reaches these same callers. No format, active-owner exclusion or source-identity policy changes.

Regression and evidence custody

The maintained test clones the actual owner's directory or pinned file separately (writer.rs:563, :565), requires active-owner exclusion (:568), drops that writer (:573), and constructs the successor (:574) before dropping the retained descriptor (:579). Its final assertion (:581) checks both iterations. This exercises the kernel lock owner, not a separately reopened surrogate. The busy attempt fails before Output construction and cannot manufacture early owner release.

Verified manifest.json SHA-256 634235b39c82d6e29e4bb4a17ccfd9fda85ced017d15b3d7f8f9206f680918ff, ZIP SHA-256 5530e6528bd72334f95c6809db2135bbeebfcaf876f65ba35a887e1163e46014, 77,272 bytes, exactly 50 unique members. Decompressed every member and checked its length/hash; all six source snapshots and five separate pruning-context sources equal their pinned Git blobs. Terminal log hashes and the historical failed-range diff hash also match.

Full retained RED source SHA-256: 042c8dc062845e34c776e2b059a099ead158089d6fb31dfe080cab390ea6122e. It equals BASE writer plus only the new test; GREEN differs from RED by precisely the ten production lines. Identical 1,747-byte test region SHA-256: 7178767e6e430e1d4088bce2928fe07e1403fe85df3aabd31e94dbb78b141039. The oracle's baseline-production hash uses the prefix before the first #[cfg(test)], not the test-module boundary; that serialization matches. An initial reviewer hash-boundary assumption failed and was corrected using full-source comparison, without rerunning tests or changing supplied evidence (recorded in postflight).

Archived RED compiled and failed both retained-descriptor cases with MEMPAL_CONVERSION_BUSY (exit 101); archived GREEN passed five library tests/one ignored helper. Public migration regression passed 17; its recorded set-e launcher includes Clippy, fmt and diff-check, with terminal exit 0. These are supplied precommit working-tree receipts at BASE, not exact-committed-HEAD executions; the source/commit receipt binds the resulting implementation to 1ebec14. Fresh checks below independently cover HEAD.

Fresh checks (each requested command executed once)

Pinned absolute cargo/rustc from /home/obj/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin were resolved and version-checked immediately before each command in non-login /bin/bash. RUSTC was explicitly pinned; existing sccache retained. Rustc 1.99.1 commit 58cf8f9c35b355199727627d07ae34a4e2846d67; cargo 1.99.1 (5f94df478). CARGO_TARGET_DIR and checkout target symlink both retain lexical /ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/target (/ssd resolves to /mnt/ssd). TMPDIR=/mnt/ssd/mirror-rootfs/home/obj/tmp/a15-cache-s0s9a8n9.

| Command | Exit | Actual result |
| --- | --- | --- |
| cargo test --locked --offline --lib storage::mempal:: | 0 | 5 passed, 1 intentional child-helper ignore, 106 filtered |
| cargo test --locked --offline --test archive mempal:: | 0 | 17 passed, 0 ignored, 11 filtered |
| cargo test --locked --offline --lib storage::layout::tests::admission_release_does_not_wait_for_inherited_descriptor_copies -- --exact | 0 | 1 passed, 0 ignored, 111 filtered |
| cargo clippy --workspace --all-targets --locked --offline -- -D warnings | 0 | clean |

Aggregate runner exit 0; 23 selected Rust passes. No zero-selected binary credited. Complete stdout/stderr and command exits: E/mvp024-mempal-lock-review-r1-tests.log.
TEST_LOG_SHA256: 1156df59c3b0233e58c9a518564c61fb1008540c6d9e8a9330cf4050ca7205bf

Immutable supplied canonical gate

E/mvp024-mempal-lock-canonical-r1-verified.json SHA-256: 9b635de89c65107334d0ce6c992081876747b47fca01810d305ca5657787ca47.
Its full 71,664-byte raw log E/mvp024-mempal-lock-canonical-r1.log SHA-256: 95b0f9a53a3c367ea35838387995dec15c4b2393d9a2bd92ffcfab4562fe51ac.
Re-attested matching HEAD/tree/base/branch/source/clean state; raw log digest and 22 Rust summary blocks total 634 passes/39 ignores, plus 35 Python and 7 Node passes and supplied installed-smoke success. Recorded just check exit 0. Accepted only as supplied immutable exact-HEAD evidence, not independently run by this reviewer. No canonical gate repetition or installation occurred.

Historical attribution and limits

The separate 2e320a4ad458744347bd516209159c28f16b5472 pruning gate remains failed: 99 passes / 1 failure / 11 ignores; manifest.json.tmp expected UNSAFE_MEMPAL_SNAPSHOT but got MEMPAL_CONVERSION_BUSY. The unchanged exact selector passed alone. All nine responsible Mempal/layout source files match BASE, but no failing OS lock/holder was recorded: original occurrence remains UNCLASSIFIED. The new RED proves an existing lifetime defect, not the historical suite cause. Pruning-context files are custody only; no pruning acceptance or integration verdict is issued.

Pre-existing concerns are separate: the unknown historical failure remains open; no additional actionable pre-existing defect was established in this leaf. README and TODO preserve these boundaries and #65's scale/coverage/load acceptance. No waiver, issue closure, publication or live-runtime qualification is implied.

Postflight before report: exact HEAD/tree/base/origin, all five source hashes, clean worktree/index and absent index.lock verified; receipt E/mvp024-mempal-lock-review-r1-postflight.json. Product custody will be re-attested after this write and final report bytes hashed externally.

Skipped: no full canonical rerun, Daybreak/new adversarial experiments, archived pilot execution, corpus reads, secrets/native-child transcripts, new reviewer, tool installation or unrelated daemon-lock repair.
Risk/limits: best-effort Drop cannot report unlock failure; retained-copy proof covers ordinary owner release, not forced process death with independently surviving copies. Historical causality and #65 acceptance remain open.
VERDICT: PASS
