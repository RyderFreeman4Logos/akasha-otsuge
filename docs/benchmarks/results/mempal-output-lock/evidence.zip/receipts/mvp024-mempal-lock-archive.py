"""Retain the lock repair and the distinct unclassified canonical occurrence."""
import hashlib
import json
import pathlib
import subprocess
import zipfile

w = pathlib.Path.cwd()
e = pathlib.Path(__file__).parent
destination = w / 'docs/benchmarks/results/mempal-output-lock'
destination.mkdir(parents=True, exist_ok=False)
members = {}

def add(name, data):
    assert name not in members and not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts
    members[name] = data

for path in sorted(e.iterdir()):
    if path.is_file() and path.name.startswith((
        'mvp024-mempal-lock-', 'mvp024-index-prune-canonical-r1',
        'mvp024-index-prune-canonical-failure-r1', 'mvp024-prune-mempal-classify-r1',
    )):
        add('receipts/' + path.name, path.read_bytes())
pins = ['e5746acbaffbd6189fca51f9248249fb6d1f6585', '1ebec1478cf6b896b349827ad131cc630d67d7b5']
for pin in pins:
    for name in ['src/storage/mempal/writer.rs', 'src/storage/mempal/tests.rs', 'src/storage/layout.rs']:
        add(f'source/{pin}/{name}', subprocess.check_output(['git', 'show', f'{pin}:{name}']))
failed_head = '2e320a4ad458744347bd516209159c28f16b5472'
for name in ['src/retrieval.rs', 'src/retrieval/vector.rs', 'src/daemon/retrieval.rs',
             'tests/support/daemon_retrieval.rs', 'tests/support/retrieval_maintenance.rs']:
    add(f'failed-pruning-context/{failed_head}/{name}', subprocess.check_output(['git', 'show', f'{failed_head}:{name}']))
notes = {
    'scope': 'One production file: explicitly release Mempal output directory/file locks at the end of their owner lifetime. Buffered sinks still drop first.',
    'original_failure': 'Pruning candidate 2e320a4 canonical gate failed in the unchanged moved-snapshot test: MEMPAL_CONVERSION_BUSY, expected UNSAFE_MEMPAL_SNAPSHOT. Exact same test passed alone. The original failing lock and holder were not recorded; cause remains UNCLASSIFIED.',
    'separate_red_green': 'A new ordinary real-kernel regression retains a duplicate of each open file description independently. Both cases failed successor admission before the fix and pass unchanged after explicit unlock. Active-owner exclusion remains asserted.',
    'custody': 'RED had only the new test over e5746ac. The full RED source and frozen test-region hash are retained. The fix is committed as 1ebec14 on a separate branch; unmerged pruning commits remain intact on feat/mvp-024-index-maintenance.',
    'verification': 'Five library Mempal tests and 17 public full/incremental archive tests passed, one intentional library child helper ignored; Clippy/fmt passed. Final canonical checks, independent review and publication are separate steps.',
    'limits': 'This does not identify the historical suite failure, rerun the real snapshot acceptance, change data formats, waive #65 scale criteria, or add a Daybreak/adversarial campaign.',
}
add('scope-and-custody.json', (json.dumps(notes, indent=2) + '\n').encode())
target = destination / 'evidence.zip'
with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(members.items()):
        info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
manifest = {'schema_version': 1, 'source_pins': pins, 'failed_pruning_head': failed_head,
            'zip_sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'zip_bytes': target.stat().st_size,
            'members': {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in sorted(members.items())}}
(destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None and sorted(archive.namelist()) == sorted(members)
    for name, item in manifest['members'].items():
        data = archive.read(name)
        assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
print(json.dumps({'files': len(members), 'zip_bytes': manifest['zip_bytes'], 'zip_sha256': manifest['zip_sha256']}))
