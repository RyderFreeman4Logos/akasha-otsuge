VERDICT: FAIL

ACTIONABLE_COUNT: 0
PRODUCT_CODE_DISPOSITION: PASS
RECEIPT_PRESERVATION_DISPOSITION: FAIL

This is one independent conventional native Codex fallback review, authorized after Hermes failed. It is not Hermes, CSA, or Claude-native evidence. No introduced actionable product finding was identified in origin/main...HEAD. The overall FAIL is solely a reviewer-caused evidence-custody failure described below; it must not be presented as a product regression or as an unqualified promotion PASS.

Evidence-custody incident

Before source inspection, I independently enumerated logical/resolved ancestors and changed owner directories, but wrote that census using write_text to E/mvp024-vector-coverage-review-r1-scope.json. That pathname already held the parent's scope receipt. I replaced its original bytes without retaining them. The brief describes that original as 126 candidates with no files; I cannot independently attest its original inventory or hash now and have not reconstructed it. My replacement contains 210 candidates with no files, including the SSD aliases and original checkout. A later lstat check also found no dangling instruction symlinks. No applicable AGENTS.md or CLAUDE.md was found, so there was no discovered instruction file requiring an EOF read.

The parent canonical verifier references the original scope schema, so that script cannot be replayed unchanged against my replacement. The canonical R2 admission, terminal, collected receipt, full log and verified result remain intact. I independently checked their exact identities, log hash, counters, installed binary hash and all 18 source hashes; those checks do not restore the overwritten receipt. Separate reviewer admission, instructions and postflight receipts retain the new observations. E/mvp024-vector-coverage-review-r1-receipt-incident.json explicitly records the loss. This report withholds an overall PASS because the requested evidence preservation was not fully satisfied. Recovery of the original requires an actually retained copy, not fabrication of its former contents. No source repair or gate repetition is indicated by this incident.

A separate first archive-verifier invocation failed with KeyError 'archive': the native manifest uses zip_bytes/zip_sha256 rather than the vector manifest's archive/bytes/sha256 keys. The corrected read-only verification checked both actual schemas and all members. This was reviewer probe setup failure, not product RED; it is recorded in the archive receipt.

Frozen scope and attribution

Checkout: /mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025
Branch: feat/mvp-024-vector-coverage
HEAD: e3ce456c3ba42bfafdaf78cd36825a462e3283fe
Tree: 2529fe1d86f3879b3ee8f96f2c2661647f873df5
origin/main and independently resolved merge-base: 96e2b5f07f1dea0289f82d88bc89b43c754d4fc1

The worktree was clean at admission, after every focused command and before report writing. All 18 working-tree files match their frozen Git blobs and the intact canonical verified receipt. Index/HEAD lock paths are absent. Canonical range diff command: git diff --binary --full-index origin/main...HEAD; 1,781,091 bytes; SHA-256 6bbd7cb3d58bc8435b1bb09093920c1ef6bcfc4a3b09a3fff89b17b7be715213.

Commit 88211b7caf987224d7ae2833938f385e3a644a05 archives the preceding already-merged native-startup leaf in five documentation/evidence paths. It does not implement vector filtering. Commit e3ce456 implements the optional vector selection and its tests/docs in 14 paths; docs/plan/todo.md overlaps, giving 18 paths overall. Native-startup pilot/review/CI evidence remains attributed to b83cf3d and merge 96e2b5f, never to this vector feature.

All touched source, tests and Markdown were read in full, including the complete TODO. Both manifests were read and all archive members verified in memory without extraction. Reachability inspection covered the shared Scope contract, Domain active/prepare/permission, config resolve/archive/checkpoint/restore, durable configuration storage, job admission and pinned vector generation, Consult memory_search, index status, lexical/vector index ownership, native batch updates, completion publication, provider identity, daemon fixture and relevant existing lifecycle/grant tests. Native child transcripts were not inspected.

The native-code-review skill and its scope/attribution, foundations, Rust/isolation, config/restore, receipt-integrity, boundaries/verdict, failure-classification, finalization and applicable supporting routes were read. Their line counts and hashes are in the reviewer instructions receipt. The explicit user restrictions take precedence over generic delegation, worktree, target and smoke suggestions. Ponytail full scope discipline was applied. There was no recursive delegation, Hermes/CSA dispatch, new relay, dependency installation, server change, model inference, cache cleanup, alternate target, new worktree, issue/PR write or Git mutation.

1. Configuration and compatibility

src/config/schema.rs:189 uses default plus skip_serializing_if=Option::is_none. The absent field therefore adds no serialized config key. src/config/mod.rs:81 restores through validation and recomputes the existing config/retrieval digests; src/config/mod.rs:394 computes the retrieval fingerprint from retrieval/models/access. The only diagnostic-name change is the safe fixed field name at src/config/mod.rs:286. src/config/manager.rs:31 checks absence in the archived checkpoint and exact restored digest/checkpoint equality.

src/config/schema.rs:588 requires an embedding profile, 1–64 entries and scope.contains(scope) for every entry. Existing model-reference validation at src/config/schema.rs:670 verifies the referenced profile has embedding kind. Scope::contains at src/domain/mod.rs:46 validates both operands, preserves user equality and each ceiling constraint. Scope validation at src/domain/mod.rs:33 rejects empty/oversized components and branch-without-project. embeds_scope at src/config/schema.rs:198 uses any selected ceiling. This reuses the existing contract without expanding read authority.

tests/config.rs:305 exercises omitted serialization/roundtrip, a two-entry list, fingerprint change, empty list, invalid user/branch, oversized component, 65 entries and missing embedding profile. The new field is opt-in; old JSON/checkpoints remain readable with unchanged default bytes. This is backward reading, not a supported downgrade of a newly scoped configuration or status to an older binary: the old deny_unknown_fields schemas do not know embedding_scopes.

2. Generation binding, filtering and durable progress

src/retrieval/vector.rs:33 retains SHA256(JSON(("claim-4096-byte-mean-cosine-v1", model_identity))) for None. Only an explicit list adds the versioned embedding-scopes-v1 hash layer at :39; the existing nondefault lexical-generation layer follows. Provider identity at src/provider.rs:227 includes kind, endpoint, model and dimension. The list is serialized in order: reorderings or duplicates can produce separate generations even if their selected set is equivalent; no normalization or set-equivalence promise is made.

VectorStatus omits None at src/retrieval/vector.rs:13, publishes an explicit list at :59 and rejects persisted generation/model/dimension/selection/watermark mismatch at :64. The same list thus determines both generation identity and status validation.

At src/retrieval/vector.rs:177, live authorization precedes Domain::active. Selection at :182 uses the actual active memory's scope. Only an otherwise indexed completion becomes scope_excluded (:189); superseded remains superseded and continues without destructive action. Required active memories alone reach the embedding path (:197). Inactive/excluded non-superseded rows retain the existing native removal path (:301). Domain::prepare at src/domain/mod.rs:585 refuses scope changes with SCOPE_CHANGE_REQUIRES_NEW_MEMORY; an in-place move is not a supported scenario and is not assumed here.

NativeBatch coalesces rows/removals by stable hash key (src/retrieval/batch.rs:27, :43). Completion entries are still appended for each sequence, including metadata-only not_required entries (src/retrieval.rs:535). Physical flush precedes atomic completion/progress publication (src/retrieval/vector.rs:311, :350; src/retrieval.rs:556). Failed embeddings retain the old prefix and error trace. Existing provider-queue authorization and progress publication authorization remain in place. Lexical sync at src/retrieval.rs:348 has no selector and continues indexing all active memories.

Activation at src/retrieval/vector.rs:443 still requires both prefixes to reach the fixed admitted target and publishes the active pointer through checked storage. The selector does not change leases, read grants, transaction bounds or target handling.

3. Search generation, privacy and disclosure

The job admission path src/daemon/jobs.rs:1194 obtains query_vector_snapshot and persists its config generation. src/daemon/retrieval.rs:37 resolves the active generation's archived config while a different requested generation is pending and verifies its generation identity. Execution restores the admitted config at :141. Consult's reachable memory-search caller also passes the selected generation (src/daemon/consult_research.rs:189).

src/daemon/retrieval/search.rs:45 selects that pinned vector configuration. The new check at :59 uses its selection; the same vector_config supplies profile/provider dispatch at :72 and the vector index at :118. Exclusion produces vector_scope_excluded before any query embedding call, while retaining lexical ranking. A config-only selector change cannot make a query excluded by the old active selection reach the new provider. Changing model and selection does not split their ownership: they are fields of the same durable snapshot.

Requested-scope permission is checked at search.rs:24. Candidate reads still enforce current authority, exact revision, requested scope and validity at :152. Exact-scope lexical/vector filters are unchanged. Applicable ancestor rules remain governed by their existing separate permission path. Global index metadata is omitted without owner-wide permission at :302; publication rechecks that permission at :417 and binds the required receipt scope at :432. The added selection list is not exposed as global diagnostics to a narrow reader. Standalone index status retains owner-wide admission (src/daemon.rs:295).

4. Actual tests and their limits

tests/support/retrieval_coverage.rs:18 exercises any-of selection with an unmatched first ceiling and matching second ceiling, 3 lexical rows versus 2 vectors, no excluded-memory embedding request, an excluded-scope keyword hit and no query embedding call. The test checks actual recorded HTTP requests, not merely config values.

The test at :103 verifies the exact old all-claim generation formula and legacy VectorStatus roundtrip, shrinks to alpha, changes to beta, queries using the old alpha selection before activation, proves beta remains excluded despite the new config, activates beta, restores None and the original generation, then restarts the daemon and reads that restored generation. The restart assertion follows restoration of None; it is not separately a crash/restart-while-scoped-build test. Scoped persistence is also traced through the shared checkpoint/restore path above.

The test at :202 indexes an all-excluded corpus with zero provider calls, retains lexical hits, executes a selected-but-empty native vector-table query and checks every sequence up to the vector watermark has a completion. Its three memory completion outcomes are scope_excluded. Existing held-provider and queued-search lifecycle tests (tests/support/retrieval_lifecycle.rs:4, :9), failed-build prefix test (:265), retirement/correction test (:291), live-grant shrink (tests/support/retrieval_regressions.rs:249), and archived diagnostic permission test (:309) all ran in the requested daemon selector. The explicit-list test covers preactivation selection; held-provider model switching is complementary existing coverage, not a newly combined simultaneous selector/model/restart fixture.

The HTTP fixture at tests/support/model_endpoint.rs:132 constructs tiny synthetic vectors from text markers. These are real daemon/HTTP/native-index tests with synthetic embeddings, not real model inference, retrieval-quality measurement, precomputed-corpus identity proof or scale acceptance.

5. Archived evidence

Vector archive: docs/benchmarks/results/mvp024-vector-coverage/evidence.zip has exactly 35 unique members, 28,577 bytes, SHA-256 fdbd4afd1796e1411fddfcf77636739c99b7c114614196fa39d432518f47e7c4. Every member name, byte length and SHA-256 matches manifest.json; there are no extra/missing/duplicate members.

The archived behavioral RED is a working-tree implementation stage based on 88211b7 after the new config was accepted, before filtering. Its config test passed; its daemon assertion at retrieval_coverage.rs:33 failed with 3 vectors versus 2 expected while lexical rows stayed 3. The identical saved test digest dd2f3a16a8fb3f70e07330abcadb983f6a35c7ffc383f75e114377ea9ad2ab41 is bound by both RED and GREEN source receipts and independently matches the archived test bytes. GREEN executed one daemon and one config test successfully. This does not claim the earlier release accepted the formerly unsupported config key (README.md:7).

Expanded-fixture focused R1 failed E0603 by calling crate-private storage::hash; R2 failed E0277 because the SHA-256 array lacks LowerHex. Both failed before tests and remain separate from the behavioral RED. R3 recorded 67 Rust passes/one intentional ignore plus lint/format checks. The archive's pending-canonical/review labels describe that earlier checkpoint, not the later exact-head R2 or this review (README.md:20, :27).

Native final publication: docs/benchmarks/results/mvp024-native-memory/final-publication.zip has exactly 115 unique members, 1,320,577 bytes, SHA-256 67b42d20d5cf365ded1095cb6edef75913ab77316f4d2fe419edd1687a269a97. All manifest members verify. All five shared references and the referenced scale-comparison.zip hash verify without corpus extraction/copy.

The archive binds b83cf3d1022d28961fda2ebe20b42a24c797060c / tree e82093f968b0133db7ba1d84064bdc9adb0dca88 and merge 96e2b5f. Its canonical/final-pilot release is 0a5436f0dc22a2858f3f083be56be55a278b78f31315d76888ebd309c5425fc1; the earlier pilot daemon is 93c7abb6f2e1fbf2d90d631e66768e65c56bf4e82b8c1ba3111108d481d41082. The different build commands do not classify the hash difference or prove reproducible builds. Seeder f009f18a372add120f4c8994bb80844d6301f9eba8b2f3af8afca747c365ff3c remains attributed to source 92031ea46c6dcb33e4810954aba00b91c5d3357d.

The retained final bounded pilot records 8,192 sources / 35,875,218 unique UTF-8 bytes / 8,322 current-claim checks / eight witnesses, 212.303666 seconds indexing, 198 complete samples, RSS max 418,988,032 bytes and sampled nearest-rank P99 413,306,880, zero sampled OOM kills. Cleanup records 543 files / 127,373,312 allocated bytes and removal only of the recorded stopped data/socket roots after process/cgroup/consumer checks. These are historical receipts; I did not rerun the corpus or rehash deleted stores. No continuous-peak or immediate Btrfs reclamation claim follows.

The preserved native review reports zero actionable findings and 64 fresh Rust passes but its release smoke exited 1 at an unavailable alternate-UID prerequisite. The lower-level historical launcher cause remains unavailable. The parent helper diagnosis/same-artifact smoke passed separately. Archived CI43963794901 attempt 1 passed; decompressed raw-log hash and 643 Rust passes/39 ignores were independently reconciled, with its separately identified installed binary. These are archived observations, not fresh remote readbacks. README.md:171–190 preserves this distinction and the normalization correction's original raw bytes. No historical report was rewritten by this review.

6. Exact gate admission and fresh checks

R2 was supplied frozen evidence, not an independently rerun canonical gate. I read its admission, terminal, collected and verified receipts, inspected the verifier and scripts/check.sh, and read the complete 889-line log. SHA-256 e97c7f94f8ddb40610e1d37599dd342efeea6a5c6440abd2f1b9ef799ff59cfd matches both terminal and verified receipt. It exited 0 in 604.813588 seconds on this exact clean head/tree. Its 22 Rust result blocks sum to 650 passes and 39 intentional ignores, with Python 35 and Node 7. Installed serial daemon acceptance contributes 176 passes/9 ignores in 252.49 seconds; installed lifecycle, private UID denial, peer UID denial and zero TCP sockets passed. The release file currently hashes to the recorded 4c29824abf0e2466fae4e0c32e2f1a37d5635bd5621244f6ff1ab2fec4f8ac1e. These supplied installed checks remain required evidence; no fresh alternate-UID smoke was requested or run.

Canonical R1 remains exit 101, with the Codex binary reporting 14 passes, one failure and two ignores. tests/support/codex_caller.rs:177 unwrapped HistoryGap in caller::native_model_tool_definitions_preserve_fences_without_exposing_harness_text. The exact isolated diagnostic ran that one test successfully in 0.11 seconds. Its nine owner/dependency hashes were independently compared across base, HEAD and working tree and match. This is unchanged source with an unclassified historical runtime cause, not proof of a pre-existing causal defect and not a waiver. The already-authorized one unchanged canonical retry subsequently passed as R2. I ran no further full gate or diagnostic retry.

Initial login-shell PATH passed through mise and emitted unrelated read-only cache warnings while reporting Rust 1.99.1. All actual focused commands used the canonical admission PATH explicitly: /home/obj/.hermes/node/bin:/home/obj/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin:/home/obj/.cargo/bin:/usr/local/bin:/usr/bin:/bin. Cargo 1.99.1, rustc 1.99.1, Node v22.23.3 and sccache 0.19.0 resolved paths/hashes are retained in admission.json. RUSTUP_TOOLCHAIN=1.99.1; inherited CARGO_HOME/RUSTUP_HOME were not reassigned. RUSTC_WRAPPER and SCCACHE_SERVER_UDS match canonical admission. AKASHA_ACCEPTANCE_BINARY is absent, so fresh daemon tests select Cargo's built executable, not an installed override.

CARGO_TARGET_DIR and the lexical target symlink stayed exactly /ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/target. TMPDIR stayed /mnt/ssd/mirror-rootfs/home/obj/tmp/a15-cache-s0s9a8n9. The explicit shared-target permission was honored. The existing daemon fixture supplies private HOME/config/data/socket roots (tests/daemon.rs:200, :231); its HTTP fixture binds loopback ephemeral ports. No real inference service was called.

Each requested command executed once, with stdout/stderr, command and exit retained in mvp024-vector-coverage-review-r1-tests.log:

| Command | Exit | Selected result |
| --- | ---: | --- |
| cargo test --locked --test daemon retrieval_tests:: -- --test-threads=1 | 0 | 29 passed, 0 ignored, 156 filtered |
| cargo test --locked --test config | 0 | 26 passed, 0 ignored, 0 filtered |
| cargo test --locked --lib retrieval:: -- --test-threads=1 | 0 | 9 passed, 1 intentional crash-child ignore, 103 filtered |
| cargo test --locked --lib config:: | 0 | 3 passed, 0 ignored, 110 filtered |
| cargo clippy --workspace --all-targets --locked -- -D warnings | 0 | clean |
| cargo fmt --all -- --check | 0 | clean |
| git diff --check | 0 | clean |

Total fresh Rust: 67 passed, zero failed, one intentional ignore. The retrieval:: filter also selects the existing daemon::jobs::retrieval lease test; the count is taken from actual output. No check failure or retry occurred. TEST_LOG_SHA256: f11c19cbd1aa8dd037395a290662a302d4e7c5e3798fbca13c1898f407c9e9e7.

7. Remaining acceptance and custody

#65 must remain open. Million-vector cohort/supplement identity and cardinality, all declared eligible 50 GB lexical bytes, 100 independent clients, required steady load, overload and recovery/crash acceptance remain unaccepted (docs/plan/todo.md:1174, :1283, :1286, :1292). The functional selector and synthetic fixture do not admit the 37-row supplement or satisfy those requirements. md2audio/方脸说 is canceled. Claude authentication and mp SSH remain blocked; no substitution is Claude-native evidence. Daybreak/red-team work remains deferred. No issues or PRs were modified and this review does not publish the leaf.

The source review is complete with zero actionable introduced findings. R1's runtime failure remains unclassified; archive compile/setup failures and native UID prerequisite failure retain their separate attribution. The report's overall FAIL is the reviewer receipt-preservation failure, not invented code attribution. Independent fresh checks and exact source hashes remain valid with that limitation explicitly attached.

Receipts alongside this report: mvp024-vector-coverage-review-r1-admission.json; -instructions.json; -archives.json; -tests.log; -test-exits.json; -receipt-incident.json; -postflight.json; and the final post-write attestation/hash in -final.json. The current -scope.json is the reviewer replacement, not the original parent receipt. All 18 reviewed file hashes follow:

| Path | SHA-256 |
| --- | --- |
| docs/benchmarks/production-scale.md | 1d9af9528b66edbc06c3939975a04d4ac33d1fe8823fad9f769d7b01d96ce10a |
| docs/benchmarks/results/mvp024-native-memory/README.md | 01d4f9981e97be00a70a001b185dd276f7cb4da454b18c035dc359cd3ddaf449 |
| docs/benchmarks/results/mvp024-native-memory/final-publication-manifest.json | e9bb46b9b19f60e47a8e07a73500be35d1f4464bd34046bd63fc912785d3019f |
| docs/benchmarks/results/mvp024-native-memory/final-publication.zip | 67b42d20d5cf365ded1095cb6edef75913ab77316f4d2fe419edd1687a269a97 |
| docs/benchmarks/results/mvp024-vector-coverage/README.md | ab51f138b81aabb7d42c33f5e311ff8ba4086cb27e65a5730d30775a7c4ad86b |
| docs/benchmarks/results/mvp024-vector-coverage/evidence.zip | fdbd4afd1796e1411fddfcf77636739c99b7c114614196fa39d432518f47e7c4 |
| docs/benchmarks/results/mvp024-vector-coverage/manifest.json | 1d8fe424a9186a3e4d3e3adc8f4219f50c0d60017dd5303b09dbbabc97029c93 |
| docs/configuration.md | 573639491d9663395216cd3bc0500dc9f63dfc166828059c9206b13ef6c3e58b |
| docs/plan/todo.md | 141ef266e8947d4c148a35af0b1a2ed2d78e5987c7d9fe5466ca8f0638ea147e |
| docs/retrieval.md | 75655c0a8512a607fbf8c24d681035ec2240bb890166e3893116c49735c69da4 |
| src/config/manager.rs | 477ffbd7130a6882af37f69c72de519e733d5f05107a7ccaceaf9eae72b2cedf |
| src/config/mod.rs | 1d57c23b516a4a371fc5f2217e229bd2108b7dacbb4fc61d8f8ce0835c663219 |
| src/config/schema.rs | 1640586cd71bf991e9abd88d8205bb38a769141dd3680f064aef6a8aeeaa0397 |
| src/daemon/retrieval/search.rs | 205c355ae9bf2644766cfa71f9bed2d2c8e334cf03b01535ce80e19a161c4c7e |
| src/retrieval/vector.rs | 128d70818d427c5f637dafe808531dd8f481c443b5e1b580eeb4192bfa1b9ddd |
| tests/config.rs | cd7b899111cbcd5ce9e772ab390e1cf4d3ef67032087f5f8979f983db8fbcec0 |
| tests/support/daemon_retrieval.rs | 593451512e2250b945991dc935e5054ce755144ad8532c7a8ac74b2bde11df9b |
| tests/support/retrieval_coverage.rs | 153a029b1711ae03fab2ca5e89f12448952e530dbd9f0df7719317f448fbced3 |

Skipped: full-gate/corpus reruns, fresh alternate-UID smoke, real inference, remote publication and deferred work. Risks: original parent scope-receipt bytes were lost by this reviewer; full-scale/recovery acceptance and historical failure causality remain unresolved.

VERDICT: FAIL
