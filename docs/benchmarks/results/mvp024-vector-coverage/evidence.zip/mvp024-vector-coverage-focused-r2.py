import datetime,hashlib,json,pathlib,subprocess
E=pathlib.Path(__file__).parent;W=pathlib.Path.cwd();name='mvp024-vector-coverage-focused-r2'
subprocess.run(['cargo','fmt','--all'],check=True)
paths=['src/config/schema.rs','src/config/mod.rs','src/config/manager.rs','src/retrieval/vector.rs','src/daemon/retrieval/search.rs','tests/config.rs','tests/support/daemon_retrieval.rs','tests/support/retrieval_coverage.rs','docs/configuration.md','docs/retrieval.md']
sources={p:hashlib.sha256((W/p).read_bytes()).hexdigest() for p in paths}
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'sources':sources,'commands':[]}
commands=[['cargo','test','--locked','--test','daemon','retrieval_tests::','--','--test-threads=1'],['cargo','test','--locked','--test','config'],['cargo','test','--locked','--lib','retrieval::','--','--test-threads=1'],['cargo','test','--locked','--lib','config::'],['cargo','clippy','--locked','--all-targets','--','-D','warnings'],['cargo','fmt','--all','--','--check'],['git','diff','--check']]
rc=0
for command in commands:
 print('COMMAND '+json.dumps(command),flush=True)
 r=subprocess.run(command,stdin=subprocess.DEVNULL)
 receipt['commands'].append({'argv':command,'exit_code':r.returncode})
 rc=r.returncode
 if rc:break
assert sources=={p:hashlib.sha256((W/p).read_bytes()).hexdigest() for p in paths}
with (E/(name+'-results.json')).open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
raise SystemExit(rc)
