import datetime,hashlib,json,pathlib,subprocess
E=pathlib.Path(__file__).parent;W=pathlib.Path.cwd();name='mvp024-vector-coverage-green-r1'
red=json.loads((E/'mvp024-vector-coverage-red-r1-results.json').read_text())
test='tests/support/retrieval_coverage.rs'
assert hashlib.sha256((W/test).read_bytes()).hexdigest()==red['sources'][test]
subprocess.run(['cargo','fmt','--all'],check=True)
assert (W/test).read_bytes()==(E/'mvp024-vector-coverage-red-r1-test.rs').read_bytes()
paths=['src/config/schema.rs','src/config/mod.rs','src/retrieval/vector.rs','src/daemon/retrieval/search.rs','tests/config.rs','tests/support/daemon_retrieval.rs',test]
sources={p:hashlib.sha256((W/p).read_bytes()).hexdigest() for p in paths}
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'sources':sources,'unchanged_red_test':True,'commands':[]}
commands=[['cargo','test','--locked','--test','daemon','retrieval_tests::coverage::vector_scope_selection_preserves_lexical_coverage_and_skips_provider_calls','--','--exact'],['cargo','test','--locked','--test','config','embedding_scope_selection_is_optional_bounded_and_validated','--','--exact']]
rc=0
for command in commands:
 print('COMMAND '+json.dumps(command),flush=True)
 r=subprocess.run(command,stdin=subprocess.DEVNULL)
 receipt['commands'].append({'argv':command,'exit_code':r.returncode})
 rc=r.returncode
 if rc:break
assert sources=={p:hashlib.sha256((W/p).read_bytes()).hexdigest() for p in paths}
with (E/(name+'-results.json')).open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
raise SystemExit(rc)
