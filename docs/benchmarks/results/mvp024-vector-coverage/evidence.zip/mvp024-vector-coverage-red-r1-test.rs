use super::*;

fn settings(endpoint: &str, projects: Option<&[&str]>) -> String {
    let selection = projects.map_or_else(String::new, |projects| {
        let scopes = projects
            .iter()
            .map(|project| format!("{{user={:?},project={project:?}}}", scope(project).user))
            .collect::<Vec<_>>()
            .join(",");
        format!("embedding_scopes=[{scopes}]\n")
    });
    format!(
        "[retrieval]\nembedding='embed'\n{selection}[models.embed]\nkind='embedding'\nendpoint={endpoint:?}\nmodel='vectors-2'\ndimension=2\nlocal=true\ntimeout='2s'"
    )
}

#[test]
fn vector_scope_selection_preserves_lexical_coverage_and_skips_provider_calls() {
    let endpoint = super::super::model_tests::Endpoint::retrieval();
    let mut daemon = Daemon::new();
    seed(&daemon);
    daemon.configure(&settings(&endpoint.address, Some(&["unused", "alpha"])));
    daemon.start();
    daemon.cli(&[
        "index",
        "sync",
        "--idempotency-key",
        "selected-vector-build",
    ]);
    let built = finished(&daemon, "selected-vector-build");
    assert_eq!(built["state"], "succeeded", "{built}");
    assert_eq!(built["result"]["indexed_rows"], 3, "{built}");
    assert_eq!(built["result"]["vector"]["indexed_rows"], 2, "{built}");
    assert_eq!(
        built["result"]["vector"]["embedding_scopes"],
        json!([scope("unused"), scope("alpha")])
    );
    assert!(
        endpoint
            .requests
            .lock()
            .unwrap()
            .iter()
            .all(|(_, body)| { body["input"][0] != "离线私有检索 private search" }),
        "excluded memory reached the embedding provider"
    );
    let before = endpoint.requests.lock().unwrap().len();
    let scope_file = daemon.root.join("scope.json");
    std::fs::write(&scope_file, serde_json::to_vec(&scope("beta")).unwrap()).unwrap();
    daemon.cli(&[
        "search",
        "private",
        "--scope",
        scope_file.to_str().unwrap(),
        "--idempotency-key",
        "excluded-vector-search",
    ]);
    let job = finished(&daemon, "excluded-vector-search");
    assert_eq!(job["state"], "succeeded", "{job}");
    let output: Value = serde_json::from_str(job["result"]["output"].as_str().unwrap()).unwrap();
    assert_eq!(output["mode"], "keyword", "{output}");
    assert_eq!(
        output["items"][0]["memory"]["revision"]["key"]["id"],
        "private"
    );
    assert!(
        output["coverage"]["gaps"]
            .as_array()
            .unwrap()
            .iter()
            .any(|gap| gap == "vector_scope_excluded"),
        "{output}"
    );
    assert_eq!(endpoint.requests.lock().unwrap().len(), before);
    daemon.cli(&["daemon", "stop"]);
    daemon.wait();
}
