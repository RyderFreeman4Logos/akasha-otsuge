import datetime,hashlib,json,pathlib,subprocess,sys
E=pathlib.Path(__file__).parent;W=pathlib.Path.cwd();name='mvp024-vector-coverage-red-r1'
paths=['src/config/schema.rs','src/config/mod.rs','tests/config.rs','tests/support/daemon_retrieval.rs','tests/support/retrieval_coverage.rs']
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='88211b7caf987224d7ae2833938f385e3a644a05'
r=subprocess.run(['cargo','fmt','--all'])
assert r.returncode==0
sources={p:hashlib.sha256((W/p).read_bytes()).hexdigest() for p in paths}
(E/(name+'-test.rs')).open('xb').write((W/paths[-1]).read_bytes())
(E/(name+'-preimplementation.patch')).open('xb').write(subprocess.check_output(['git','diff','--binary','--full-index']))
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':'88211b7caf987224d7ae2833938f385e3a644a05','sources':sources,'classification':'New optional configuration contract is accepted and validated; production selection/generation/search wiring intentionally absent for behavioral RED. Not a claim that the old product accepted this formerly unsupported option.','commands':[]}
commands=[['cargo','test','--locked','--test','config','embedding_scope_selection_is_optional_bounded_and_validated','--','--exact'],['cargo','test','--locked','--test','daemon','retrieval_tests::coverage::vector_scope_selection_preserves_lexical_coverage_and_skips_provider_calls','--','--exact']]
rc=0
for command in commands:
 print('COMMAND '+json.dumps(command),flush=True)
 r=subprocess.run(command,stdin=subprocess.DEVNULL)
 receipt['commands'].append({'argv':command,'exit_code':r.returncode})
 rc=r.returncode
 if rc!=0:break
assert sources=={p:hashlib.sha256((W/p).read_bytes()).hexdigest() for p in paths}
with (E/(name+'-results.json')).open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
raise SystemExit(rc)
