VERDICT: FAIL

Independent native-code-review of the complete frozen MVP-025 offline neutral-import leaf found **one actionable introduced regression**: replay can report success without completing a previously failed publication-directory sync. The required focused tests pass. The defect still blocks this leaf under the requested zero-actionable-findings rule.

Saved report: [mvp025-neutral-import-review-r1.md](/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/.git/akasha-evidence/mvp025-neutral-import-review-r1.md). SHA-256: `588a84146a56876190c28b91546690ba9dabda9b6bf3e5518be05758b752d830`.

**Scope and custody**

Repository: `/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025`; logical and resolved paths match. Branch: `feat/mvp-025-neutral-import`.

- Base, `origin/main`, and merge base: `3b6bf74d57b275e154195571700d64406832c2d3`.
- HEAD: `a61acd9089c9d16d96f3f863e583c3f2ca5846bc`.
- Tree: `ba055fdacb47f3e31ddf16146677c98bcea02587`.
- Reviewed range: `origin/main...HEAD`, both commits: `415f50c1f727ec06b2f03c633ca235be531d1626` (export-closure archive/docs) and `a61acd9089c9d16d96f3f863e583c3f2ca5846bc` (offline import).
- Coverage: all 73 changed paths: eight Rust implementation/test files, two product/planning documents, 16 export-final evidence files, and 47 import evidence files. Evidence members were checked against both manifests; JSON receipts, decompressed log results and report classifications were inspected.

This review covers validated OFFLINE import and storage-history restoration. It does not approve issue #25 completion, active imported runtime use, fresh runtime initialization, real mempal migration, incremental different-archive merging, or full domain-level acceptance. Their absence is not classified as a regression.

Source and Git state were read-only. No agents, worktrees, commits, publication, provider calls, broad gates, ambient configuration changes, environment overrides, source databases or native-child transcripts were used. Writes were limited to the requested external report/log, normal focused-test outputs and exact disposable fixtures. Parent-owned WD was untouched.

**Filesystem instruction inspection**

Before source reads, actual filesystem checks inspected both `AGENTS.md` and `CLAUDE.md` at every checkout ancestor, following existing paths rather than inferring absence from Git. Both names were absent at:

`/`, `/mnt`, `/mnt/ssd`, `/mnt/ssd/mirror-rootfs`, `/mnt/ssd/mirror-rootfs/home`, `/mnt/ssd/mirror-rootfs/home/obj`, `/mnt/ssd/mirror-rootfs/home/obj/project`, `/mnt/ssd/mirror-rootfs/home/obj/project/github`, `/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos`, and the repository root.

Both names were also absent in each applicable nested directory: `src`, `src/storage`, `tests`, `tests/support`, `docs`, `docs/plan`, `docs/benchmarks`, `docs/benchmarks/results`, `docs/benchmarks/results/mvp025-neutral-import`, and `docs/benchmarks/results/mvp025-neutral-export-final`. There were no applicable instruction files to resolve or count; these are verified filesystem absences, not zero-line files.

A symlink-following checkout search found instructions only below unused `.spike-work/helix-db` and `.spike-work/lancedb-v040`; no source below those trees was inspected. Pinned native API reads instead used `/home/obj/.cargo/git/checkouts/surrealkv-e974f5998ebcb4c5/4338a79`; both instruction names were verified absent through its actual ancestors, `src`, and `src/ring`. Both names were also absent through the external evidence directory’s ancestors before report creation.

The lexical `target` link remains `/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/target`; its resolved directory is under `/mnt/ssd/mirror-rootfs`. The `.spike-work` link likewise retains its original `/ssd/...` target.

**Blocking finding F1 — MODERATE, REGRESSION**

Location: [src/storage/import.rs:248](/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025/src/storage/import.rs:248), covering lines 248–269, particularly the `if !existing` guard and parent sync at line 265. Related promise: `docs/neutral-archive.md:122–123`.

Trigger: the no-replacement rename succeeds, but the subsequent `layout::sync_dir(&data)` fails, or execution stops between rename and parent sync. `authority` is then visible. The next identical import takes the existing-destination branch, validates its contents and closes the native store, but skips the entire publication block, including the outstanding parent sync. It returns `Ok(manifest)` and the CLI exits zero.

This is a false successful reconciliation of a failed durability step. Native close syncs the native database directory structure, not the application data directory that owns the `authority` rename. Visibility and content integrity therefore do not establish the publication durability promised by a successful retry. This does not allege observed power-loss data loss.

A bounded public-CLI probe reproduced the defect using the exact canonical release executable:

`/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/target/release/akasha-otsuge`

SHA-256: `4aeb0e8ea262e2cac1d025e104238268ded4f4024b2dc08f24e730d15691aa93`.

The probe generated a private SSD archive with 64 small memory revisions, request-key order differing from chronological order, and a UTF-8/NUL key. Data totaled 32,037 JSONL bytes and 1,207 blob bytes. After native staging appeared, it changed only the disposable destination data directory to mode `0300`: traversal and rename remained possible, but opening that parent for directory sync failed with permission denial.

Observed results for `BINARY --config FIXTURE/config.toml archive import FIXTURE/archive`:

1. First invocation: exit **1**, empty stdout, structured stderr code **`STORAGE_IO`**. `authority` existed and `.archive-import` did not.
2. Independent `os.open(data, O_RDONLY | O_DIRECTORY)`: **PermissionError**; the parent remained unopenable for sync.
3. Identical replay with permissions unchanged: exit **0**, a success manifest on stdout, empty stderr.

The Python probe supervisor exited **0**, confirming all assertions. Its exact child terminated; directory permissions were restored and the entire exact fixture was removed. Complete observations are appended to the focused log. No source edits, injected libraries or environment changes were used.

Required correction: successful completed-import replay must establish the publication parent sync as well, and propagate its failure. Preserve original archive identities and later local writes. Add a focused regression for failed post-rename sync followed by replay; do not treat successful content revalidation as completion of that filesystem step.

This behavior is introduced by the new import function. The base has no import/replay path. No other actionable introduced finding was identified.

**Implementation trace and remaining assessment**

- **CLI:** `src/main.rs` routes only the exact three-argument archive form into offline storage. It resolves the explicit config and selected profile through the existing resolver, rejects `--socket`, preserves the existing non-UTF-8 argument policy, maps storage error codes into structured stderr, and propagates stdout-write failure. It does not fall through into daemon operation.
- **Input boundary:** `regular_file` uses `NOFOLLOW|NONBLOCK` and verifies a regular file. Source/data canonical paths are checked for overlap. The manifest is bounded to 64 KiB; versions, exact two data-file names, lengths and lowercase SHA-256 syntax are checked. Archive structs and nested receipt/reference/key types reject unknown fields. JSONL reads are bounded to 1 MiB including LF; batches have at most 64 changes, 128 KiB per blob and 1 MiB total content. EOF, trailing bytes, offsets and complete file hashes are checked.
- **Identity and history:** request validation, sorted canonical request hashing, exact receipt references and content hashes bind the revisions. Strict request ordering rejects duplicate request IDs; sequence range/count checks plus occupied outbox refusal reject duplicate or missing sequences. Head reconstruction checks exact predecessor equality and rejects Evidence rewrites. UTF-8 and NUL content are retained without normalization; the additional probe also exercised NUL in record identity.
- **Native API:** the pinned SurrealKV revision is `4338a790c8edc56ef5ea1e46157427af4815be3c`. Its `Transaction::set_at` preserves explicit timestamps, and `get_at` selects versions at or before the requested timestamp. Staging request-key order followed by chronological `set_at(head, seq+1)` reconstruction agrees with `Storage::at(..., at+1)`. The focused roundtrip checks all four kinds and points 0–3, original receipts/clocks, reopen, a later sequence-4 write and replay without replacing that write. No original application commits are renumbered or added for import.
- **Transactions and cancellation:** staged receipt/revisions/outbox/clock share one immediate transaction; each chronological head batch advances application sequence atomically. Resume compares saved receipt, outbox, clock and revision bytes before reuse. The pinned native pipeline settles accepted commits independently of a dropped waiter and drains admission on close. Cancellation before publication leaves an unpublished stage or the published destination for later reconciliation; no separate cancellation fault run was added.
- **Ownership and publication:** the importer lock checks regular-file type, UID, link count and `0600`, and takes an exclusive lock. Native locking separately excludes concurrent storage owners. Recognized stages require matching manifest-bound identity and current-UID `0700`; missing/incomplete identities and foreign stages are refused. Invalid-archive cleanup is limited to a recognized unpublished stage after successful native close. Other errors retain it. Publication closes native storage, checks/writes format metadata, syncs the stage, and uses `RENAME_NOREPLACE`; a concurrent destination cannot be replaced. F1 concerns the subsequent retry path.
- **Runtime isolation:** `src/daemon.rs:656–660` checks import metadata immediately after storage open and before configuration recovery, grants, jobs, incidents or notifications. A provider client and private listener may be constructed before refusal, but service dispatch/scheduling is never entered. Two focused startup attempts return `IMPORTED_RUNTIME_DISABLED`, remove the owned socket, and leave application sequence unchanged. No credentials, tasks or imported capabilities are automatically activated.
- **Stricter receipt deserialization:** audited storage receipt lookup/idempotency/export/outbox callers and embedded `RevisionRef` consumers in capture, domain history/recall/review/outcome, configuration/model-result archives and retrieval. Supported in-tree producers serialize the same existing fields; no supported producer writing now-rejected extensions was found. No introduced supported-format compatibility defect is asserted. Arbitrary record content remains opaque original bytes during import.

**Commands and fresh results**

The following requested commands ran **once each, sequentially**, with no retries:

| Command | Exit | Selected result |
|---|---:|---|
| `cargo test --locked --test archive --test cli --test storage` | 0 | 8 archive + 5 CLI + 17 storage passed; zero failures |
| `cargo test --locked --lib storage::crash_tests::killed_archive_import_resumes_staging_heads_and_publication_without_duplicates -- --exact --nocapture` | 0 | 1 passed, 73 filtered out; four actual SIGKILL phases |

The four phases reported `import-staged`, `import-head`, `import-before-publish` and `import-published`, each with signal 9, recovered sequence 3 and zero duplicate commits. The publication checkpoint is after successful parent sync; it does not cover F1’s failure boundary.

Complete combined stdout/stderr, numeric exit statuses and the additional probe are retained in [mvp025-neutral-import-review-r1-tests.log](/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/.git/akasha-evidence/mvp025-neutral-import-review-r1-tests.log).

Log: **7,095 bytes**, SHA-256 **`2ec3f16fd8979c55265bdda81b9f5bd2761de6613d15effa04d5f23918a66bb6`**.

Cargo resolved through the inherited mise shim to `/home/obj/.cargo/bin/cargo`. `RUSTUP_TOOLCHAIN=1.99.1`, `CARGO_TARGET_DIR`, `RUSTC_WRAPPER`, `TMPDIR` and `SCCACHE_SERVER_UDS` were preserved; no Cargo concurrency override was introduced. Mise emitted read-only cache-write warnings, retained in the log; both test commands still exited zero. No concurrent Cargo or broad check was launched.

Identity/status/range checks used `git rev-parse`, `git merge-base`, `git log`, `git diff --stat/--name-only` and `git status --porcelain=v1 --untracked-files=all`. An exact comparison confirmed Cargo manifests/lockfile, `justfile`, `scripts/check.sh`, storage layout and historical-read implementation unchanged from the base.

**Canonical and archived evidence**

The canonical recipe is `just check` → `bash scripts/check.sh`. It was inspected, **not rerun**. The supplied verified receipt matches the frozen base/HEAD/tree and clean admission, exit **0**, **448.062881s**. Recounting its log yields **21 Rust result rows, 550 passes, 0 failures, 32 ignored**, including installed repeats; daemon runs each have 157 passes and 7 ignored. Installed lifecycle/private-UID/peer-UID/zero-TCP results remain supporting evidence, not acceptance of F1.

Canonical identities independently recomputed:

| Artifact | SHA-256 |
|---|---|
| verified receipt | `d153d2eefa7c83757a1d06a8e64895c81a49cd737eace5e85bd85c92902c56c3` |
| admission | `9734f2d7c411524d66034066d82c474b1b64e428d9e5fb5419ac9132bfeb1d8f` |
| terminal | `a18d5cefbba461963d2fa853ac8d4e6299815f8e1f05cafadeeea307b02ff0a7` |
| collected | `822a13c8d25023146ae7f5e9d014271fa190a83512391e3e9e9a2279b1d0ac0e` |
| complete log, 62,583 bytes | `4931154ddbfa30a73602a9a4efca6476c4298b0035a0e8af39dc0c66904d6b43` |

Import manifest SHA-256 **`e2af219cc0434e2ec8e4597f33f47519e33b284e4cfc24000241c4bb8a7308ce`** verifies all **46 members / 73,868 bytes** and **10 final source hashes**. All ten historical focused terminal-log hashes also match the decompressed logs and collected receipts.

Historical classifications remain separate:

| Run | Exit | Preserved meaning |
|---|---:|---|
| Initial RED | 101 | Tests compiled; import command absent |
| GREEN R1 | 101 | Compilation failure: unused import and SHA formatting; not behavioral RED |
| GREEN R2 | 0 | Six archive tests |
| Boundaries RED | 101 | Rejected-stage cleanup and imported-daemon activation failures |
| GREEN R3 | 0 | Seven archive tests after those repairs |
| GREEN R4 | 0 | 30 integration tests + four-phase SIGKILL test + Clippy |
| Stage-ownership RED | 101 | Unowned stage adopted |
| GREEN R5 | 0 | 31 tests + Clippy |
| Stage-permissions RED | 101 | Public resumed-stage permissions accepted |
| Final GREEN R6 | 0 | 31 tests + Clippy, **49.657983s** |

The final foreign-stage fixture explicitly sets `0700` and asserts `IMPORT_CONFLICT`, preventing a permissions denial from masking missing stage identity. Earlier admission receipts bind their own dirty development patches at `415f50c`, not the final committed candidate.

Export-final manifest SHA-256 **`946f2cde9bf36ac18a725861659cda39f271f7c3580e8174db5d3d36ae0d3474`** verifies all **15 members / 70,708 bytes**. Its seven source hashes were checked with `git show 7ad2aab5721a2f840865da8a77d9bb367b6d9909:PATH`, not against the changed checkout. It preserves PR #57 export closure without closing #25. Historical main CI **42760179799** binds `3b6bf74`; it is not a gate for this candidate.

The runtime explorer report’s decompressed hash and five Git blobs were verified at frozen `415f50c1f727ec06b2f03c633ca235be531d1626`. It remains a recommendation, not implemented fresh-runtime initialization or real migration proof. No foreign mempal discovery was repeated.

**Pre-existing observations and actual gaps**

Native open/recovery may change physical database files; existing CLI/config error and argument policies, native locking and cache behavior predate this range. No separate pre-existing actionable defect is asserted. Historical FAILs, unknown source provenance/approval facts, prior acceptance gaps and unresolved causality are not relabeled by these passing checks.

Power-loss and ENOSPC recovery were not tested. The new probe proves a publication-sync error and false-success replay, not actual crash data loss. Hash validation establishes integrity, not source authentication. Incomplete initial ownership markers remain deliberately refused; unknown staging contents must not be adopted.

Fresh local authority, normal imported daemon use, actual supported mempal samples, incremental different-archive merging and full domain-level acceptance remain future leaves. This review neither broadens into those tasks nor treats their absence as a finding.

**Final attestation**

HEAD remains `a61acd9089c9d16d96f3f863e583c3f2ca5846bc`; tree remains `ba055fdacb47f3e31ddf16146677c98bcea02587`; `origin/main` and merge base remain `3b6bf74d57b275e154195571700d64406832c2d3`. Tracked and untracked worktree status is clean. No review-owned child or disposable probe fixture remains.

Skipped canonical reruns, broad gates, live/source databases, providers and future-leaf acceptance, as requested.  
Residual risk: F1 permits success without completing publication durability; this frozen leaf requires repair and a new review before approval.

VERDICT: FAIL