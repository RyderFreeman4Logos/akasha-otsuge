# Scoped review: one Lance Session per authority

PASS for this ownership repair and its diagnostic gates. Implementing-agent
self-review only; no independent review or full-scale acceptance claim.

Inspected every connect caller: baseline backfill/build/query, delta apply,
prune/retire/activate, current candidates, workload derived oracle and tests.
One Arc<Session> is constructed by Authority::open (and its unit fixture), and
every connection clones that Arc. Authorities do not share a process-global
Session. Existing cache/spill capacities, buffer sizes, worker counts, index
parameters, original deadlines and dependency pins are unchanged. The Session
spill store creates its scratch storage lazily in the pinned implementation.

The former native regression fails at the actual dataset-session identity
assertion, after successful native table/index execution. The repaired test
passes and checks fresh row counts and indexed candidates after another
connection appends, for both text and vector families. It retains the existing
scope-bitmap plan assertions. This protects ownership and version freshness;
it is not a measurement of aggregate RSS or proof of the full OOM's cause.

Validation:12 release units, release all-targets Clippy and release build pass.
The179-command lifecycle fixture passes12 SIGKILL barriers and two competing
owner refusals. The160s/100-client corpus-concurrent fixture passes4,528 requests,
all original thresholds/oracles and ten tamper controls. Process/unit/scratch
and disposable fixture cleanup are verified against frozen native68e74e4.

The full preparation's before reads retain the same candidate membership,
revisions and all non-query fields as the previous binary. One BM25 response
exchanges two adjacent candidates. No stable rank order is promised by the
candidate_set_only interface; raw order is retained and no causal explanation
is claimed. Full concurrent RSS/throughput and the final backend decision stay open.
