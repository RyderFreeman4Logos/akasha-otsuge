import json,pathlib,subprocess,sys
repo=pathlib.Path.cwd();sys.path.insert(0,str(repo/'spikes/helix'))
from run_case import digest,process_identity,publish
storage=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023');frozen=repo/'.spike-work/shared-session-r1';sha=json.loads((frozen/'source.json').read_text())['native_sha256'];assert digest(frozen/'probe')==sha
def gone(identity):
 now=process_identity(identity['pid']);assert now is None or now['start_ticks']!=identity['start_ticks']
def memory(path,unit,native=False):
 es=[json.loads(line) for line in path.open()];assert es[0]['limits']['memory.max']=='671088640' and es[0]['limits']['memory.swap.max']=='0' and es[0]['nofile_soft_hard']==[8192,8192]
 executions=[e for e in es if e['event']=='executable'];assert len(executions)==1;gone(executions[0])
 if native:assert executions[0]['sha256']==sha
 end=es[-1];assert end['event']=='exit' and end['code']==end['native_code']==0
 assert end['scratch_cleanup']['removed'] and not pathlib.Path(end['scratch_cleanup']['path']).exists()
 samples=[e for e in es if e['event']=='sample'];assert not any(int(e['memory_events'].get(k,0)) for e in samples for k in ['oom','oom_kill'])
 assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip()=='inactive'
 peak=max(e['engine_rss_bytes'] for e in samples);assert peak<=640*1024**2;return peak
life=storage/'fallback-shared-session-lifecycle-r1';result=json.loads((life/'result.json').read_text());assert result['status']=='passed' and result['checks']==179 and result['temporary_root_removed']
for name,want in result['artifact_sha256'].items():assert digest(life/name)==want,name
for record in result['records']:
 assert record['command'][0]==str(frozen/'probe');gone(record['child'])
assert sum(r['kill'] is not None for r in result['records'])==12 and len(result['contenders'])==2
peak=memory(repo/'.git/akasha-evidence/shared-session-lifecycle-r1-memory.jsonl','akasha-shared-session-lifecycle-r1')
publish(life/'verified.json',dict(status='passed',commands=179,sigkill_barriers=12,contenders=2,seconds=result['seconds'],rss_max_bytes=peak,artifacts_verified=True,exact_processes_gone=True,fixture_removed=True,scratch_removed=True,unit_inactive=True,native_sha256=sha))
root=storage/'fallback-shared-session-concurrent-r1'
with (root/'case-verification.log').open('x') as log:subprocess.run([sys.executable,str(repo/'.git/akasha-evidence/verify-full-case.py'),str(root/'case'),sha],stdout=log,stderr=subprocess.STDOUT,check=True)
case=json.loads((root/'case/verified.json').read_text());assert case['status']=='passed' and not case['failures']
admission=json.loads((root/'admission.json').read_text());assert admission['binary_sha256']==sha;gone(admission['controller'])
for command in json.loads((root/'commands.json').read_text()):
 assert command['exit']==0
 unit=next(x.split('=',1)[1] for x in command['command'] if x.startswith('--unit='));memory(root/(command['name']+'-memory.jsonl'),unit,True)
assert not pathlib.Path(admission['temporary_root']).exists()
result=json.loads((root/'result.json').read_text());assert result['status']=='passed_diagnostic_only' and len(result['rebuild_controls'])==10
report=dict(status='passed',native_sha256=sha,seconds=result['seconds'],case_seconds=case['seconds'],requests=case['content_oracle']['requests'],rss_p99_bytes=case['rss_p99_bytes'],rss_max_bytes=case['rss_max_bytes'],rebuild=result['case']['rebuild'],operations=case['operations'],controls=10,artifacts_verified=True,exact_processes_gone=True,units_inactive=True,fixture_removed=True,scratch_removed=True)
publish(root/'verified.json',report)
print(json.dumps(dict(lifecycle_commands=179,sigkill_barriers=12,concurrent_status=report['status'],requests=report['requests'],rss_p99_bytes=report['rss_p99_bytes'],rss_max_bytes=report['rss_max_bytes'],seconds=report['case_seconds'])))
