import hashlib,json,pathlib,sys,tarfile
repo=pathlib.Path.cwd();sys.path.insert(0,str(repo/'spikes/helix'))
from run_case import digest,publish
storage=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023');frozen=repo/'.spike-work/shared-session-r1';source=json.loads((frozen/'source.json').read_text())
assert digest(frozen/'probe')==source['native_sha256']
files={}
def add(prefix,root):
 for p in root.rglob('*'):
  if p.is_file() and p.name!='probe' and '__pycache__' not in p.parts:
   assert not p.is_symlink();files[prefix+'/'+str(p.relative_to(root))]=p
for kind in ['lifecycle','concurrent']:
 root=storage/f'fallback-shared-session-{kind}-r1';assert json.loads((root/'verified.json').read_text())['status']=='passed';add(kind,root)
add('frozen',frozen)
for group in ['source_sha256','helpers_sha256']:
 for name,want in source[group].items():assert digest(repo/name)==want,name;files['candidate-source/'+name]=repo/name
for p in (repo/'.git/akasha-evidence').glob('shared-session-*'):
 if p.is_file():files['collector/'+p.name]=p
for name in ['collect-shared-session-native-r1.py','archive-shared-session-r1.py','verify-full-case.py']:
 files['collector/'+name]=repo/'.git/akasha-evidence'/name
out=repo/'docs/benchmarks/results/fallback-shared-session';out.mkdir();archive=out/'raw.tar.gz';hashes={n:digest(p) for n,p in sorted(files.items())}
with tarfile.open(archive,'w:gz') as tf:
 for name,p in sorted(files.items()):tf.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tf:
 assert set(tf.getnames())==set(hashes)
 for m in tf.getmembers():assert hashlib.sha256(tf.extractfile(m).read()).hexdigest()==hashes[m.name],m.name
publish(out/'files.json',hashes)
life=json.loads((storage/'fallback-shared-session-lifecycle-r1/verified.json').read_text());concurrent=json.loads((storage/'fallback-shared-session-concurrent-r1/verified.json').read_text())
summary=dict(status='passed_diagnostic_only',source_parent=source['parent'],native_sha256=source['native_sha256'],archive_files=len(files),archive_bytes=archive.stat().st_size,archive_sha256=digest(archive),behavioral_red='actual two native dataset sessions have distinct identity under old connection ownership',release_units=12,release_all_targets_clippy='passed',lifecycle=life,concurrent=concurrent,review='implementing-agent self-review only',capacities_unchanged=dict(index_cache_bytes=16*1024**2,metadata_cache_bytes=8*1024**2,spill_cap_bytes=64*1024**2),not_proven=['full concurrent build memory/performance','exclusive causal attribution of prior OOM','sole backend decision'])
publish(out/'summary.json',summary);print(json.dumps({k:summary[k] for k in ['status','native_sha256','archive_files','archive_bytes','archive_sha256']}))
