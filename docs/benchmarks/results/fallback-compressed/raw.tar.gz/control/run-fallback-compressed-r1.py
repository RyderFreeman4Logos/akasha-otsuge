import datetime, hashlib, json, os, pathlib, shutil, subprocess, sys, time, uuid
repo=pathlib.Path.cwd(); evidence=repo/'.git/akasha-evidence'
sys.path.insert(0,str(repo/'spikes/helix'))
from run_case import publish, process_identity, digest
binary=repo/'.spike-work/fallback-compressed-r1/probe'
binary.parent.mkdir(mode=0o700)
shutil.copy2(repo/'target/storage-spike/release/akasha-fallback-probe',binary)
old=json.loads((evidence/'vlog-campaign-r1-admission.json').read_text())
commands=[]
unit='akasha-compressed-low-'+uuid.uuid4().hex
for name,command in old['commands']:
 name=name.replace('vlog-','compressed-')
 command=[s.replace('fallback-vlog-r1/probe','fallback-compressed-r1/probe')
     .replace('fallback-vlog-','fallback-compressed-')
     .replace('fallback-stream-vlog-r1','fallback-stream-compressed-r1')
     .replace('vlog-low-reopen-r1','compressed-low-reopen-r1') for s in command]
 command=[('--unit='+unit) if s.startswith('--unit=') else s for s in command]
 commands.append((name,command))
publish(evidence/'compressed-campaign-r1-admission.json',dict(
 binary_sha256=digest(binary),commands=commands,controller=process_identity(os.getpid()),
 started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),low_unit=unit,
 source_sha256={str(p):digest(p) for p in (repo/'spikes/fallback').rglob('*') if p.is_file() and (p.suffix in ('.rs','.py','.toml','.lock'))}))
started=time.monotonic();results=[]
for name,command in commands:
 publish(evidence/'compressed-campaign-r1-progress.json',dict(phase=name,completed=len(results),total=len(commands),elapsed_s=time.monotonic()-started,results=results))
 began=time.monotonic()
 with (evidence/(name+'.log')).open('xb') as output:
  run=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT,
      env=dict(os.environ,LANCE_CPU_THREADS='2',AKASHA_SPIKE_PROFILE='low'),timeout=7200)
 result=dict(name=name,exit=run.returncode,seconds=time.monotonic()-began);results.append(result)
 print(json.dumps(result),flush=True)
 if run.returncode:raise SystemExit(run.returncode)
publish(evidence/'compressed-campaign-r1-result.json',dict(status='passed',binary_sha256=digest(binary),results=results,low_unit=unit))
publish(evidence/'compressed-campaign-r1-progress.json',dict(phase='completed',completed=len(results),total=len(commands),elapsed_s=time.monotonic()-started,results=results))
