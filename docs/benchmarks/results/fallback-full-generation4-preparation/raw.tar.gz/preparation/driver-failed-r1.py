import datetime,hashlib,json,os,pathlib,shutil,subprocess,sys,time
repo=pathlib.Path.cwd();sys.path.insert(0,str(repo/'spikes/helix'))
from run_case import digest,process_identity,publish
storage=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023')
base=storage/'fallback-full-generation4-r1';database=storage/'fallback-full-compressed-r1/database';frozen=repo/'.spike-work/shared-session-r1'
source=json.loads((frozen/'source.json').read_text());assert digest(frozen/'probe')==source['native_sha256']
for group in ['source_sha256','helpers_sha256']:
 for name,want in source[group].items():assert digest(repo/name)==want,name
assert json.loads((storage/'fallback-shared-session-concurrent-r1/result.json').read_text())['status']=='passed_diagnostic_only'
base.mkdir();(base/'OWNER').write_text('akasha-otsuge MVP-003 full generation4 preparation\n')
prior=storage/'fallback-full-rebuild-r1/witness-after';result=json.loads((prior/'result.json').read_text());assert result['status']=='passed'
records=json.loads((prior/'commands.json').read_text());requests=[];originals=[]
for i,record in enumerate(records):
 path=prior/f'{i:03d}.request.json';assert digest(path)==result['artifacts'][path.name]
 request=json.loads(path.read_text())
 if record['exit'] or request.get('generation')==2:continue
 reply_path=prior/f'{i:03d}.stdout';assert digest(reply_path)==result['artifacts'][reply_path.name]
 step=dict(channel='authority' if '--authority' in record['command'] else 'generation',request=request)
 if request['op']=='current':step['expected_body_sha256']=hashlib.sha256(json.loads(reply_path.read_text())['entry']['body'].encode()).hexdigest()
 requests.append(step);originals.append(reply_path)
assert len(requests)==66
publish(base/'witness-plan.json',dict(binary=str(frozen/'probe'),binary_sha256=source['native_sha256'],database=str(database),requests=requests))
publish(base/'admission.json',dict(controller=process_identity(os.getpid()),source=source,driver_sha256=digest(__file__),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),phases=['before witnesses','retire inactive2','prune active3','after witnesses','begin4','backfill4'],competing_load='parent receipt/code publication only; no other native benchmark or Cargo compilation'))
def inventory(name):
 components={}
 for parent,dirs,files in os.walk(database,followlinks=False):
  assert not any((pathlib.Path(parent)/d).is_symlink() for d in dirs)
  for filename in files:
   path=pathlib.Path(parent)/filename;assert not path.is_symlink();s=path.stat();parts=path.relative_to(database).parts
   key='/'.join(parts[:2]) if parts[0]=='derived' else parts[0]
   components[key]=components.get(key,0)+s.st_blocks*512
 value=dict(allocated_bytes=components,free_bytes=shutil.disk_usage(database).free,note='inode allocation is not exclusive Btrfs allocation; filesystem free includes concurrent host activity');publish(base/name,value);return value
def witness(phase):
 unit='akasha-gen4-witness-'+phase+'-r1';memory=base/(phase+'-memory.jsonl')
 command=['systemd-run','--user','--quiet','--wait','--pipe','--collect','--unit='+unit,'-p','MemoryMax=671088640','-p','MemorySwapMax=0','-p','LimitNOFILE=8192','-p','WorkingDirectory='+str(repo),'-p','Environment=MALLOC_MMAP_THRESHOLD_=131072',sys.executable,str(frozen/'measure.py'),str(memory),sys.executable,str(repo/'.git/akasha-evidence/full-prune-witness.py'),str(base),phase]
 publish(base/(phase+'-command.json'),command)
 with (base/(phase+'.log')).open('x') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
 subprocess.run([sys.executable,str(repo/'.git/akasha-evidence/collect-rebuild-recovery-step.py'),str(base/phase),str(memory),unit],check=True)
 if phase=='before':
  for i,original in enumerate(originals):assert json.loads((base/phase/f'{i:03d}.stdout').read_text())==json.loads(original.read_text()),i
completed=[]
def operation(request):
 op=request['op'];publish(base/(op+'.request.json'),request)
 config=f'''[run]
id = "fallback-full-generation4-r1-{op.replace('_','-')}"
profile = "low"
seconds = 7200
[paths]
binary = "{frozen/'probe'}"
database = "{database}"
request = "{base/(op+'.request.json')}"
output = "{base/op}"
[disk]
start_bytes = 81212254720
reserve_bytes = 81212254720
[reliability]
max_attempts = 1
'''
 path=base/(op+'.toml');path.write_text(config)
 publish(base/'progress.json',dict(phase=op,completed=completed,controller=process_identity(os.getpid()),native_checkpoint=str(database/'generation-4-backfill.json')))
 with (base/(op+'.log')).open('x') as log:subprocess.run([sys.executable,str(frozen/'helix/run_generation.py'),str(path)],check=True,stdout=log,stderr=subprocess.STDOUT)
 subprocess.run([sys.executable,str(repo/'.git/akasha-evidence/verify-generation.py'),str(base/op)],check=True)
 completed.append(op);return json.loads((base/op/'verified.json').read_text())['reply']
witness('before');before=inventory('disk-before.json')
assert before['free_bytes']>=81212254720
reply=operation(dict(op='retire_generation',generation=2,deadline_ms=int(time.time()*1000)+7200_000));assert reply['retired'] and reply['generation']==2 and reply['completed']==reply['total']==4
assert not any(database.joinpath('derived').glob('g2_*.lance'))
reply=operation(dict(op='prune_versions',generation=3,deadline_ms=int(time.time()*1000)+7200_000));lifecycle=reply['lifecycle'];assert lifecycle['active']==3 and lifecycle['committed']==lifecycle['text']['watermark']==lifecycle['vector']['watermark']==269826
witness('after');after=inventory('disk-after-cleanup.json')
bundle=json.loads((prior/'000.stdout').read_text())['bundle'];bundle['schema']=3
operation(dict(op='begin_corpus',generation=4,bundle=bundle,manifest='/tmp/akasha-otsuge-storage-20261022/full-corpus-v2.json'))
reply=operation(dict(op='backfill',generation=4,waves=1000000));assert reply['cursor']==reply['documents']==11428831 and reply['vector_rows']==reply['vectors']==1000000 and not reply['ready'] and reply['index_deadline_ms'] is None
for op in completed:
 case=base/op;state=json.loads((case/'state.json').read_text());want=digest(case/'state.json')
 with (case/'completed-reuse.stdout').open('x') as stdout,(case/'completed-reuse.stderr').open('x') as stderr:subprocess.run([sys.executable,str(frozen/'helix/run_generation.py'),str(base/(op+'.toml')),'--resume'],check=True,stdout=stdout,stderr=stderr)
 assert digest(case/'state.json')==want and json.loads((case/'completed-reuse.stdout').read_text())==state['result']
 copy=case/'probe';assert copy.is_file() and not copy.is_symlink() and digest(copy)==source['native_sha256'];size=copy.stat().st_size;copy.unlink()
 publish(case/'copy-cleanup.json',dict(completed_reuse_verified=True,probe_removed=True,bytes=size,no_future_resume_claim_after_retirement=True))
publish(base/'result.json',dict(status='prepared_not_built',generation=4,active=3,committed=269826,native_sha256=source['native_sha256'],witnesses_before=66,witnesses_after=66,exact_witnesses_match=True,retired_generation2_allocated_bytes=sum(v for k,v in before['allocated_bytes'].items() if k.startswith('derived/g2_')),free_bytes_delta_after_cleanup=after['free_bytes']-before['free_bytes'],free_bytes=shutil.disk_usage(database).free,operations=completed,disposable_copies_removed=True))
print(json.dumps(dict(status='prepared_not_built',generation=4,active=3,operations=completed)),flush=True)
