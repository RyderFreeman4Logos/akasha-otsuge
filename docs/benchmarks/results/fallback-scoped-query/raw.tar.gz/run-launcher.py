import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time
import uuid

repo = Path('/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge')
base = Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023')
root = base / 'fallback-full-scoped-query-r1'
database = base / 'fallback-full-compressed-r1/database'
frozen = repo / '.spike-work/full-query-scoped-r1'
binary = repo / '.spike-work/cold-workload-r1/probe'
fixture = repo / '.spike-work/ann-oracle-full-v1/queries.json'
digest = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert digest(binary) == '9b09f83c8a225eb608600b2a3f7d6106c7ab2d1c8726956aee97cfea5cbb36d1'
assert all(digest(frozen / p) == h for p,h in json.loads((frozen / 'source.json').read_text()).items())
prior = json.loads((database / '.akasha-generation-owner.json').read_text())
state = json.loads((Path(prior['output']) / 'state.json').read_text())
assert state['phase'] == 'completed' and state['result']['status'] == 'passed'
assert state['result']['operation'] == 'build' and state['result']['generation'] == 2
root.mkdir(mode=0o700)
(root / 'OWNER').write_text('akasha-otsuge MVP-003 scoped full exact query run\n')
unit = 'akasha-full-scoped-query-' + uuid.uuid4().hex
command = ['systemd-run', '--user', '--quiet', '--wait', '--pipe', '--collect', '--unit='+unit,
    '-p','MemoryHigh=536870912','-p','MemoryMax=671088640','-p','MemorySwapMax=0',
    '-p','LimitNOFILE=8192','-p','RuntimeMaxSec=14400',
    '-p','Environment=AKASHA_SPIKE_PROFILE=low','-p','Environment=LANCE_CPU_THREADS=2',
    '-p','Environment=LANCE_DEFAULT_IO_BUFFER_SIZE=16777216',
    '-p','Environment=LANCE_SHUFFLE_BATCH_BYTES=16777216',
    '-p','Environment=LANCE_SHUFFLE_MAX_PRELOADED_OFFSETS_BYTES=0',
    sys.executable,str(frozen/'measure.py'),str(root/'memory.jsonl'),
    sys.executable,str(frozen/'fallback/check_real_search.py'),str(binary),str(database),
    str(fixture),str(root/'queries'),'--generation','2']
admission = dict(command=command, unit=unit, binary_sha256=digest(binary),
    launcher_sha256=digest(__file__), fixture_sha256=digest(fixture), frozen_source=json.loads((frozen/'source.json').read_text()),
    started_unix_s=time.time(), kernel=platform.release(), platform=platform.platform(),
    affinity=sorted(os.sched_getaffinity(0)), free_bytes=shutil.disk_usage(database).free,
    prior_index_result=state['result'], group_includes_python_query_driver=True)
(root/'launch.json').write_text(json.dumps(admission,indent=2)+'\n')
with (root/'driver.log').open('x') as log:
    result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
(root/'terminal.json').write_text(json.dumps(dict(exit=result.returncode,finished_unix_s=time.time(),unit=unit))+'\n')
raise SystemExit(result.returncode)
