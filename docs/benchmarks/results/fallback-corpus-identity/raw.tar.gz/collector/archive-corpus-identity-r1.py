import hashlib,json,pathlib,sys,tarfile
repo=pathlib.Path.cwd();sys.path.insert(0,str(repo/'spikes/helix'))
from run_case import digest,process_identity,publish
storage=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023');frozen=repo/'.spike-work/corpus-identity-r1';source=json.loads((frozen/'source.json').read_text());validation=json.loads((repo/'.git/akasha-evidence/corpus-identity-validation.json').read_text());assert source['native_sha256']==validation['native_sha256']==digest(frozen/'probe')
files={}
def add(prefix,root):
 for p in root.rglob('*'):
  if p.is_file() and p.name!='probe' and '__pycache__' not in p.parts:
   assert not p.is_symlink();files[prefix+'/'+str(p.relative_to(root))]=p
for phase in ['red-r2','lifecycle-r1','import-r1','search-r1','concurrent-r1']:add(phase,storage/('fallback-corpus-identity-'+phase))
add('frozen-r1',frozen)
for group in ['source_sha256','helpers_sha256']:
 for name,want in source[group].items():assert digest(repo/name)==want,name
for n in [1,2]:
 events=[json.loads(x) for x in (repo/f'.git/akasha-evidence/corpus-identity-red-r{n}-memory.jsonl').open()]
 for e in events:
  if e['event']=='executable':
   now=process_identity(e['pid']);assert now is None or now['start_ticks']!=e['start_ticks']
 assert events[-1]['code']==1 and events[-1]['scratch_cleanup']['removed'] and not pathlib.Path(events[-1]['scratch_cleanup']['path']).exists()
for p in (repo/'.git/akasha-evidence').iterdir():
 if p.is_file() and 'corpus-identity' in p.name:files['collector/'+p.name]=p
out=repo/'docs/benchmarks/results/fallback-corpus-identity';out.mkdir();archive=out/'raw.tar.gz';hashes={n:digest(p) for n,p in sorted(files.items())}
with tarfile.open(archive,'w:gz') as tf:
 for name,p in sorted(files.items()):tf.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tf:
 assert set(tf.getnames())==set(hashes)
 for m in tf.getmembers():assert hashlib.sha256(tf.extractfile(m).read()).hexdigest()==hashes[m.name],m.name
publish(out/'files.json',hashes)
summary=dict(status='passed_native_fixtures',source_parent=source['parent'],native_sha256=source['native_sha256'],archive_files=len(files),archive_bytes=archive.stat().st_size,archive_sha256=digest(archive),validation=validation,regression='Exact original-manifest model/fingerprint/dimension/chunker binding at generation creation and shared reads; legacy binding preserves original state/deadlines; rejected requests await database close',oracle_custody=json.loads((repo/'.git/akasha-evidence/corpus-identity-oracle-custody-final.json').read_text()),review='independent frozen-source re-review pending',not_proven=['full imported-database metadata binding','optional legacy text-layout binary fixture','full concurrent resource acceptance','sole backend decision'])
publish(out/'summary.json',summary);print(json.dumps({k:summary[k] for k in ['status','native_sha256','archive_files','archive_bytes','archive_sha256']}))
