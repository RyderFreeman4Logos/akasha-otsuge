# Candidate source identity review repair

Frozen review: ddcf1136ea3d2a6b13e104065642d161c2e58a64, issue #3 / PR #31.
Finding R1: baseline backfill copies imported embeddings but Begin accepts a
different model/fingerprint/chunker. Delta output validation then trusts that
unbound generation label. Workload and lifecycle replay inherit the same label.

Scope: one source-identity boundary, not another backend or model service.
Inventory: load::run/read_state; search::Begin/read_state; work_pin/work_query;
checked_output; check_lifecycle/check_search and native unit fixtures. Existing
Helix corpus coverage already derives the pinned publisher model fingerprint.

Required regression: correct imported identity admits a fresh generation;
different model/fingerprint/dimension/chunker cannot create another generation;
failure leaves no usable generation; old generation stays readable. Bind the
test bytes through RED/GREEN. Preserve synthetic fixture provenance as synthetic.

Proposed minimum: retain verified import manifest metadata, compare the bundle
against that same source identity at generation admission/read boundaries, and
use the existing hash-checked Begin manifest to bind legacy import metadata.
No original record/vector rewrite, no deadline reset, no 50GB reimport. Resolve
the exact representation after the independent frozen review is complete.

Execution order: collect running generation5 preparation; preserve its exact
native identity and successful/failed outcome. Run a bounded behavioral RED on
the old native, repair and gate the source, re-review, then freeze the corrected
native for the next full case. Do not start full r3 on a known incomplete source
review or repeat unrelated historical full runs.
