import json,pathlib,subprocess,sys
repo=pathlib.Path.cwd();sys.path.insert(0,str(repo/'spikes/helix'))
from run_case import digest,process_identity,publish
storage=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023');frozen=repo/'.spike-work/corpus-identity-r1';source=json.loads((frozen/'source.json').read_text());sha=source['native_sha256'];assert digest(frozen/'probe')==sha
for group in ['source_sha256','helpers_sha256']:
 for name,want in source[group].items():assert digest(repo/name)==want,name
def gone(identity):
 now=process_identity(identity['pid']);assert now is None or now['start_ticks']!=identity['start_ticks'],identity
def memory(path,unit,native=False):
 es=[json.loads(line) for line in path.open()];assert es[0]['limits']['memory.max']=='671088640' and es[0]['limits']['memory.swap.max']=='0' and es[0]['nofile_soft_hard']==[8192,8192]
 executions=[e for e in es if e['event']=='executable'];assert len(executions)==1;gone(executions[0])
 if native:assert executions[0]['sha256']==sha
 end=es[-1];assert end['event']=='exit' and end['code']==end['native_code']==0
 assert end['scratch_cleanup']['removed'] and not pathlib.Path(end['scratch_cleanup']['path']).exists()
 samples=[e for e in es if e['event']=='sample'];assert not any(int(e['memory_events'].get(k,0)) for e in samples for k in ['oom','oom_kill'])
 assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip()=='inactive'
 peak=max(e['engine_rss_bytes'] for e in samples);assert peak<=640*1024**2;return peak
reports={}
for kind,count,kills in [('lifecycle',231,19),('import',21,1),('search',85,5)]:
 root=storage/f'fallback-corpus-identity-{kind}-r1';result=json.loads((root/'result.json').read_text());admission=json.loads((root/'admission.json').read_text())
 assert result['status']=='passed' and result['checks']==len(result['records'])==count
 assert admission['binary_sha256']==sha and not pathlib.Path(admission['temporary_root']).exists();gone(admission['controller'])
 for name,want in result['artifact_sha256'].items():assert digest(root/name)==want,name
 for record in result['records']:
  assert record['command'][0]==str(frozen/'probe');gone(record['child'])
 assert sum(bool(r.get('kill') or r.get('killed_after')) for r in result['records'])==kills
 if kind=='lifecycle':assert len(result['contenders'])==2
 peak=memory(repo/f'.git/akasha-evidence/corpus-identity-{kind}-r1-memory.jsonl',f'akasha-corpus-identity-{kind}-r1')
 report=dict(status='passed',commands=count,sigkill_barriers=kills,seconds=result['seconds'],rss_max_bytes=peak,artifacts_verified=True,exact_processes_gone=True,fixture_removed=True,scratch_removed=True,unit_inactive=True,native_sha256=sha)
 if kind=='lifecycle':report['contenders']=2
 if kind=='search':assert admission['legacy_binary_sha256'] is None;report['legacy_binary_fixture_run']=False
 publish(root/'verified.json',report);reports[kind]=report
root=storage/'fallback-corpus-identity-concurrent-r1'
with (root/'case-verification.log').open('x') as log:subprocess.run([sys.executable,str(repo/'.git/akasha-evidence/verify-full-case.py'),str(root/'case'),sha],stdout=log,stderr=subprocess.STDOUT,check=True)
case=json.loads((root/'case/verified.json').read_text());assert case['status']=='passed' and not case['failures']
admission=json.loads((root/'admission.json').read_text());assert admission['binary_sha256']==sha;gone(admission['controller'])
for command in json.loads((root/'commands.json').read_text()):
 assert command['exit']==0
 unit=next(x.split('=',1)[1] for x in command['command'] if x.startswith('--unit='));memory(root/(command['name']+'-memory.jsonl'),unit,True)
assert not pathlib.Path(admission['temporary_root']).exists()
result=json.loads((root/'result.json').read_text());assert result['status']=='passed_diagnostic_only' and len(result['rebuild_controls'])==10
report=dict(status='passed',native_sha256=sha,seconds=result['seconds'],case_seconds=case['seconds'],requests=case['content_oracle']['requests'],rss_p99_bytes=case['rss_p99_bytes'],rss_max_bytes=case['rss_max_bytes'],rebuild=result['case']['rebuild'],operations=case['operations'],controls=10,artifacts_verified=True,exact_processes_gone=True,units_inactive=True,fixture_removed=True,scratch_removed=True)
publish(root/'verified.json',report);reports['concurrent']=report
gone(json.loads((repo/'.git/akasha-evidence/corpus-identity-validation-admission-r1.json').read_text())['controller'])
publish(repo/'.git/akasha-evidence/corpus-identity-validation.json',dict(status='passed_native_fixtures',native_sha256=sha,source_parent=source['parent'],unit_tests=13,clippy='passed_release_all_targets',reports=reports))
print(json.dumps(reports))
