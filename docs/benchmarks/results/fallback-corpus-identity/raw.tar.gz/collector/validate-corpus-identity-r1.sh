#!/usr/bin/env bash
set -euo pipefail
export PATH=/home/obj/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin:/usr/local/bin:/usr/bin:/bin
export RUSTUP_TOOLCHAIN=1.99.1 CARGO_TARGET_DIR=/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/target/storage-spike CARGO_BUILD_JOBS=2 LANCE_CPU_THREADS=2 MALLOC_MMAP_THRESHOLD_=131072
cargo test --release --locked --offline --manifest-path spikes/fallback/Cargo.toml > .git/akasha-evidence/corpus-identity-unit-r1.log 2>&1
cargo clippy --release --all-targets --locked --offline --manifest-path spikes/fallback/Cargo.toml -- -D warnings > .git/akasha-evidence/corpus-identity-clippy-r1.log 2>&1
cargo build --release --locked --offline --manifest-path spikes/fallback/Cargo.toml > .git/akasha-evidence/corpus-identity-build-r1.log 2>&1
python3 .git/akasha-evidence/freeze-corpus-identity-r1.py
bash .git/akasha-evidence/corpus-identity-native-r1.sh
