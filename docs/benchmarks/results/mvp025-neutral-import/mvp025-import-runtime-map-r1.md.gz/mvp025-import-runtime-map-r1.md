Preserve the archive’s original authority records and history, but place a durable **runtime import boundary** between those records and consumers that execute or authorize actions. Apply that boundary at consumers; do not hide imported heads in `Storage::current`, rewrite provenance, or renumber original commits.

This is a source-grounded recommendation, not a verified implementation.

**Evidence basis.** Below, `P` means frozen commit `415f50c1f727ec06b2f03c633ca235be531d1626`; every `P:path:line` citation refers to that object. Tree: `1b12bcb2f87a6e0468998bf2be68f06c3c2f6762`. Actual logical/resolved repository paths matched. No `AGENTS.md` or `CLAUDE.md` was found in the checked ancestors, owned-directory ancestors, or symlink-followed `src` tree. Source reads used `git show`/`git grep` at P. Final tracked status was clean; HEAD was P on `feat/mvp-025-neutral-import`.

**Verified activation and authorization inventory**

`RecordKind` has exactly `Evidence`, `Memory`, `State`, and `Job` (`P:src/storage/mod.rs:28`). Physical keys are `head/{kind}/{length-hex}/{id}` and `revision/{kind}/{length-hex}/{id}/{seq:020}` (`P:src/storage/mod.rs:216`).

| Kind and exact ID prefix/key | Consumer and consequence |
|---|---|
| **State** `daemon/config`; `daemon/config-generation/{generation:020}`; **Evidence** `daemon-config-blob/{digest}` | Startup `configuration::open` restores the saved manager, including active configuration and pending state, before reconciling startup input. Generation checkpoints also supply job and retrieval configurations. This is automatic restoration, not merely archival configuration display. `P:src/daemon/configuration.rs:23,110,117,188`; `P:src/config/manager.rs:177`; `P:src/daemon/jobs.rs:1223`. |
| **Job** `daemon-job/{hash(id)}`; **State** `daemon/active-jobs` | `recover` reads every active job; interrupted work can become queued. Scheduler claims queued jobs and dispatches model, retrieval, consult, extraction, grill, or capture workflows. Deadlines and authorization can reject execution, but are not an import quarantine. `P:src/daemon/jobs.rs:641,728,1216,1264,1309,1508`. |
| **State** `daemon/incidents`, `incident/{id}`; **Evidence** `incident-event/{id}/{event}` | `advance_incidents` automatically processes pending incidents, reconciles existing editor jobs, or submits an editor job using saved configuration. Incident authorization checks current triggers, state and expiry. `P:src/daemon/incident.rs:13,30,71,298`. |
| **State** `notification/cursor`, `notification/item/{64-hex-id}` | Scheduler projects **historical outbox revisions** of State `review/…` and `incident/…`, then scans notification heads. Current grants and notifier routes control delivery. Existing attempts can be recovered; missing deliveries can be claimed. Clearing pending jobs alone cannot prevent this. `P:src/daemon/notifier.rs:90,106,139,276,294`; `P:src/daemon/jobs.rs:1518`. |
| Notification delivery above | Stdio delivery invokes a configured subprocess for capability discovery and delivery, optionally loading credentials from an environment variable. This is automatic external activity once scheduler eligibility succeeds. `P:src/daemon/notifier/stdio.rs:565,585,605,663`. |
| **Evidence** `invocation/{hash(id)}` | `Invocation::load_verified` reads the stored capability/binding, checks principal and capture anchor, and returns an invocation usable to construct read/capture contexts. Used by explicit host calls, consult/editor authorization, and outcome/history-related consumers. Not itself a startup scanner. `P:src/adapter/binding.rs:122,192,200,263,274`; `P:src/daemon/consult.rs:207`; `P:src/daemon/outcome.rs:18`. |
| **Evidence** `claude-registration/{hash(token)}`, `claude-child/{hash(serialized source)}`, `codex-registration/{hash(token)}`, `pi-registration/{hash(token)}`, `pi-session-registration/{hash(serialized source)}` | Explicit host requests resolve stored registrations; registrations contain capability, source, scope and machine paths. Pi registration can reuse an existing session-to-token mapping. These are bearer/identity authorization inputs, although no startup scan was found. `P:src/daemon/claude.rs:13,28,68,189`; `P:src/daemon/codex.rs:13,21,106`; `P:src/daemon/pi.rs:13,21,81`. Hermes constructs registration from explicit event inputs rather than a corresponding persisted registration key in this census: `P:src/daemon/hermes.rs:70`. |
| **State** `read-grant/{hash(principal)}` | `Domain::permission` consults the **current** grant, including for historical reads. Startup creates a local grant only when the key is absent. An imported same-UID grant therefore suppresses fresh initialization. Explicit setters can replace/revoke grants. `P:src/domain/history.rs:141,158,190,209,228`. |
| **State** `search/lexical-v1`, `search/vector/{generation}`, `search/vector-active`, `search/vector-active/{hash(lexical generation)}`, `search/completion/{generation}/{seq:020}` | Persisted cache progress and generation selection. Vector fallback can restore a prior configuration generation. Missing native lexical tables with a nonzero imported watermark produce `INDEX_MISSING`; imported metadata is not a rebuilt index. No unconditional startup index build was found: execution goes through retrieval jobs. `P:src/retrieval.rs:37,134,214,241,522`; `P:src/retrieval/vector.rs:18,404`; `P:src/daemon/retrieval.rs:26,37,58`. |

Immediate restart order matters: storage opens → configuration restores → startup-file reconciliation → `ensure_local_reader` → job recovery → scheduler starts. Scheduler processes notifications and incidents before claiming active jobs. The file watcher also reloads local configuration automatically (`P:src/daemon.rs:655,693,712,740,756`).

**State that must remain readable**

Keep original heads, all revisions and previous links, commit sequence, commit receipts, outbox entries, and clocks. Storage enforces expected-head equality and immutable Evidence; historical reads use versioned heads at `at + 1` (`P:src/storage/mod.rs:389,420,435,484`; `P:src/storage/history.rs:135`). A filtered generic `current()` would make callers submit incorrect `expected_revision: None` and could invite attempted Evidence replacement.

Preserve these as original authority or historical evidence:

- **Memory** IDs are the memory ID itself; **Evidence** `source/{hash(event)}`; **State** `adoption/{hash(memory)}` and `scope/{hash(serialized scope)}/{hash(memory)}`. Adoption resolution checks the memory revision, lifecycle, scope and previous-adoption link; scoped historical enumeration needs membership heads. These State records are essential, not disposable indexes (`P:src/domain/mod.rs:297`; `P:src/domain/history.rs:130,250,345`).
- **Evidence** `capture-event/`, `capture-intent/`, `capture-blob/`, `capture-delta/`; **State** `capture-checkpoint/`, `capture-message/`. Preserve captured source history and references. Checkpoints alone do not activate capture in the startup path examined (`P:src/capture/mod.rs:34,71,184,247,405`).
- **State** `recall/`, **Evidence** `recall-body/`, **State** `review/`, `review-decision/`, `memory-patch/`; **Evidence** `outcome/`, `model-blob/`, invocation and registration records. Preserve receipt bodies, decisions and supporting evidence even when their runtime authority is disabled (`P:src/domain/recall.rs:88`; `P:src/domain/review.rs:101`; `P:src/domain/patch.rs:34`; `P:src/daemon/outcome.rs:7`; `P:src/daemon/models.rs:36`).

Recall replay additionally requires matching principal, binding and run ID, current permission, original selected revisions and source spans. Preserving bytes does not automatically grant a new local identity replay access (`P:src/domain/recall.rs:247,397`).

Search tables/progress/completions are derived and rebuildable. Notification items are derived projections **with delivery history**: retain that evidence, but do not reuse it as delivery authority. Queue/config/grant heads are historical operational authority whose imported values must become inactive, not disappear.

Unknown IDs within the four kinds should remain archival and receive no runtime eligibility. Unsupported kinds or schemas should fail validation. This census does not establish semantics for arbitrary extension prefixes.

**Smallest recommended integration**

Use one durable boundary containing the original archive’s final sequence **B**, an import identity, and the classification/version needed to interpret it. Persist it before publication and load it before configuration restoration or scheduler recovery. Corrupt import metadata must fail closed. Keep ordinary non-imported stores’ behavior unchanged.

The boundary is a runtime eligibility rule, not a global historical-read filter:

1. **Queues:** treat imported active-job and pending-incident lists as effectively empty, while retaining their actual head revisions for subsequent CAS writes. New local admissions write normal lists against those real heads. Do not resume an imported job merely because its mutable head later changes.
2. **Notifications:** start projection after B and exclude imported notification sources from delivery/recovery. Check source eligibility, not merely the notification head’s latest sequence: acknowledging or otherwise updating an old item must not accidentally rearm it. A later explicit, authorized review/incident action needs a defined policy for producing a new local notification.
3. **Configuration:** ignore imported checkpoints for active restoration. Initialize from fresh local startup configuration, using a generation that cannot collide with imported generation keys. Keep imported generation checkpoints accessible as historical evidence, but exclude them from active retrieval fallback and execution plans.
4. **Grants:** imported grants do not satisfy `permission`. `ensure_local_reader` must append a fresh local grant against the real existing head when that head is imported. Use a fresh import-specific request ID; the existing deterministic `local-reader/…` receipt may already exist.
5. **Bindings:** imported registration tokens and invocation records remain inspectable but cannot authorize fresh host operations, execution or capture. Fresh bindings require new local validation and identity. Preserve historical receipt inspection separately from active invocation use.
6. **Indexes:** select a fresh local lexical generation with zero progress, following `begin_rebuild`’s existing generation pattern. Its derived vector generation/active key must also be fresh. Do not run embedding or rebuilding during import; later explicit retrieval work uses local configuration.

The exact production caller set requiring integration or review is:

| Area | Files/callers |
|---|---|
| Boundary ownership | Existing storage open/import publication seam; add boundary read/validation without changing generic `current`, `revision`, `at` or receipt semantics. |
| Startup/config | `src/daemon.rs::run`; `src/daemon/configuration.rs::{open,load,save}`; generation allocation in `src/config/manager.rs`. |
| Scheduling | `src/daemon/jobs.rs::{active,recover,claim,submit_job}`; `src/daemon/incident.rs::{pending_incidents,advance_incidents,authorize_incident_execution}`. |
| Notifications | `src/daemon/notifier.rs::{project_notifications,advance_notifications}`; final dispatch eligibility in `src/daemon/notifier/stdio.rs`. |
| Access | `src/domain/history.rs::{permission,ensure_local_reader,change_local_reader,set_read_grant}`. |
| Host/binding use | Registration lookups and identity reuse in `src/daemon/{claude,codex,pi}.rs`; `src/adapter/binding.rs::{bind,load,load_verified}` and reuse paths in `src/adapter/{claude,codex,hermes,pi}/caller.rs`. |
| Mixed historical/action consumers | `src/daemon/consult.rs::{submit_consult,consult_invocation,job_read_context}`, `src/daemon/editor_workflow.rs`, `src/daemon/outcome.rs::outcome_binding`. Avoid blanket rejection that breaks diagnostic/history routes. |
| Derived retrieval state | `src/retrieval.rs::{status,begin_rebuild}`, `src/retrieval/vector.rs::{status,active_vector,activate_vector}`, `src/daemon/retrieval.rs::{retrieval_snapshot,query_vector_snapshot}`. |

A migration commit can empty mutable queues and select a fresh index generation using normal CAS semantics. **It cannot alone neutralize immutable invocation/registration Evidence.** Likewise, config saving can require blob commits, so a claim of “one bootstrap commit” needs qualification. Atomic publication of the unpublished directory is the useful completion boundary.

Concrete unresolved tradeoffs:

- Existing invocation IDs and Pi/Claude identity mappings can collide with fresh registration. Immutable Evidence must remain immutable: reject reuse or use a genuinely fresh local identity; do not silently remint the same key.
- Imported-job submission currently returns the existing job on matching fingerprint (`P:src/daemon/jobs.rs:913`). Minimal explicit resumption is a **new local job ID and freshly authorized plan**, referencing the archived job. In-place imported checkpoint resumption is additional work.
- Current history/receipt APIs retain identity and permission checks, and some daemon inspection paths also require machine paths. Cross-UID/path-independent owner inspection is not established by this recommendation.
- “Latest revision > B” alone is insufficient for every object. Incidental writes must not launder an imported capability or delivery attempt into local authority.

Preserve original memory authority exactly. `HumanConfirmed` requires matching human approval; delegated and candidate records have distinct rules (`P:src/domain/mod.rs:407`). An owner executing import supplies no missing human statement or approval. Neutral self-archives should not enter a mempal-source ingress path.

**Smallest causal acceptance matrix — parent-owned**

| Scenario | Required observation |
|---|---|
| Empty-store roundtrip, before startup | Original revisions, heads, clocks, receipts, outbox and source references match; only explicit import metadata/bootstrap records are additional. |
| Adversarial runtime payload + immediate restart, twice | Queued/checkpointed jobs, pending incidents, old tokens, grants, notification attempts and archived configs cause zero foreign subprocess, provider, network or notification calls. Test with otherwise permissive local routes to expose missing guards. |
| Historical preservation | Current/adopted memory, scoped state, before/after adoption history, original ranges and recall replay remain consistent at original sequences. Fresh current authorization is required; identity-mismatch refusal remains intact. |
| Fresh local startup | Local config and reader are created despite imported same-key heads and receipt IDs; foreign pending config is inactive; restart retains local generations/grants. |
| Fresh work after restart | New job, host registration/binding, explicit retrieval rebuild and notification source work normally; writes use actual previous revisions and fresh IDs/generations. |
| Explicit resumption | Archived work remains inert until a fresh authorized local admission; its successor survives restart without rearming unrelated imported work. |
| Failure boundary | Invalid/missing required import metadata, unsupported prefixes and interrupted publication never yield a partially activated store. |

Selected Git blob hashes: daemon `d8d9ce7dc38e7b29507ca139236ec1f515d24e28`; jobs `7a7994746cca69021252d9f69928995d605061a9`; notifier `735b8bc12ae4ce88ba34ce76135f7e5b920f089d`; binding `8f0ae189a6ddc58261900ce21cd7822a4b2280c4`; history `4f58bc89b195dcd179ef8c9a1f4ec3e25d82c497`.

Skipped parser/writer discovery, builds, tests and live data. All commands terminated; no files, probes, agents or background processes were created.
Residual risk: the boundary’s identity/replay split and generation-collision handling require parent implementation and causal tests before publication.