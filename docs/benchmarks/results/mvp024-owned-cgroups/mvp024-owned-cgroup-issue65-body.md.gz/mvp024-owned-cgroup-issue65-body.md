> Supersedes closed #24

## Closure correction

MVP-024 is **not accepted**. #24 was marked completed at 2026-11-11T07:31:41Z, immediately after [PR #64](https://github.com/RyderFreeman4Logos/akasha-otsuge/pull/64) merged. PR64 delivered software memory admission/reservations, not the full scale/recovery acceptance. Its description contained a negated closing-keyword reference; future partial PRs must use only `Refs` links and must not place closing keywords next to this Issue number. This closure does not count as completed acceptance.

Merged evidence remains valid only for its scope: [PR #56](https://github.com/RyderFreeman4Logos/akasha-otsuge/pull/56) observability, [PR #63](https://github.com/RyderFreeman4Logos/akasha-otsuge/pull/63) controlled storage reopen, and [PR #64](https://github.com/RyderFreeman4Logos/akasha-otsuge/pull/64) measured admission/native reservations. All original seven implementation dependencies are complete. The functional owned-cgroup leaf is now merged in [PR #66](https://github.com/RyderFreeman4Logos/akasha-otsuge/pull/66): reviewed head `84428714a378bc849895c8f3ff4af6ed6af6e1c9`, merge `9253a8b799421db3893e0e67dd2cfb55ca8c4b79`, identical tree `6e1e6d2f84c9ac99c9e1e45e181f39dad1b91849`. The exact canonical gate passed 626 Rust executions (39 intentional opt-in ignores), Python 34 and Node 7; two separately enabled real-kernel normal lifecycle tests passed. [Complete independent review](https://github.com/RyderFreeman4Logos/akasha-otsuge/pull/66#issuecomment-6791715702) passed with zero actionable findings and 44 fresh tests. [CI42989102629](https://github.com/RyderFreeman4Logos/akasha-otsuge/actions/runs/42989102629) succeeded. Historical editor/diagnostic IPC failures remain unclassified; the separate normal-child-exit regression is not claimed as their explanation. Full production scale/recovery acceptance remains pending.

## Remaining acceptance, unchanged

- [x] Finish actual owned cgroup limits, kernel peak/accounting, all managed helpers, truthful degraded status, ordinary lifecycle and high-to-low convergence; complete canonical checks, independent conventional review and publication.
- [ ] Verify the retained licensed source manifest and stream at least 50,000,000,000 unique real UTF-8 bytes through the production path, full lexical coverage, at least 1,000,000 real nonzero/nonidentical vectors, and 100,000 changes. Do not duplicate the raw corpus or substitute earlier spike receipts.
- [ ] Execute unchanged 512/640, 1024/1280 and 2048/2048 MiB memory profiles and service-total accounting. Run at least 100 clients for 1,800 seconds per required low/high profile, preserving the original workload rates, latency/RSS/no-OOM thresholds, backlog and burst-recovery bounds in the source specification.
- [ ] Preserve accepted-event/history/scope/retraction oracles, concurrent index/rebuild and ordinary recovery/deadline evidence. Daybreak and new red-team/adversarial campaigns remain owner-deferred; no such result is implied by normal functional regressions.
- [ ] Publish immutable source/binary/corpus identities, checkpointed commands, actual resource/disk metrics, all failed attempts and final consistency results. Update downstream #26/#27/#28 tracking. Partial implementation must not automatically resolve this Issue.

The complete original specification and its thresholds below remain authoritative; no acceptance criterion is removed by this bookkeeping repair.

---

> 从规格 v0.1 逐页导入；下方的“规格草案”是来源快照状态。当前工作状态以本 GitHub Issue 为准，尚未验收。

# MVP-024｜50 GB、100 客户端、内存预算与故障恢复压力验收

Source: [Notion](https://app.notion.com/p/40117b41f58c813ea375fb1009199a8e?pvs=204) · Specification v0.1 · Captured 2026-10-22

**计划ID：** `MVP-024`。**当前状态：** 规格草案，GitHub Issue待后续开发Agent创建；未实施、未验收。

Issue清单与依赖映射：[11｜MVP Issue 清单、顺序与需求覆盖](https://app.notion.com/p/40117b41f58c815d9678e25102eae698)

**拟用GitHub标题：** `[MVP-024] 50 GB、100 客户端、内存预算与故障恢复压力验收`

## Issue 正文

**覆盖需求：**REQ-16、REQ-18、REQ-19、REQ-20、REQ-21、REQ-23。

**目标：**证明系统在要求的数据规模和并发下有界运行，而非只在小型 fixtures 上成立。

**范围：**构建可追溯、实际落盘、可解析且内容有多样性的 50 GB 语料压力档，并实际建立所需索引；明确原始与索引各自体积。100 个并发客户端进行读写混合，后台同时导入/索引/历史读取/修订；控制 daemon+storage/index 的 512 MiB 默认目标与最高 2 GiB 配置预算；外部 workers 单列且总进程组一并报告。

**非目标：**不以稀疏占位文件、空向量、极端重复文本或仅 cache hit 冒充真实压力；不把 backpressure/SSD spool 当绝对防 OOM 保证；100 GB 和 256 MiB 不属于必须通过档。

**依赖：**MVP-004、MVP-008、MVP-010、MVP-016、MVP-017、MVP-020、MVP-023。

**验收测试：**正式 50 GB/100 客户端档无 OOM、无已确认接收事件丢失、无 scope 串线、无撤回内容复活；报告冷热 p50/p95/p99、吞吐、队列/字节水位、RSS/实际限制口径、外部进程和磁盘。测试磁盘满、超大消息、断连、kill/restart、索引落后和 provider 停机；过载有明确降级/拒绝且可恢复。达不到默认目标必须修复或取得明确范围变更，不能隐藏到报告脚注。

**完成证据/产物：**数据 manifest/hash/来源许可、真实磁盘与索引统计、压测命令/机器规格、原始监控和一致性检查、故障注入报告；可附非阻塞的 100 GB 扩展结果。

## 相关规格

- [08｜内存预算、SSD、并发、恢复与规模验收](https://app.notion.com/p/40117b41f58c81f68da4d7bcb89553e4)
- [05｜存储选型 ADR、版本、回执与索引一致性](https://app.notion.com/p/40117b41f58c81d6a0b3ea46b1ac4c10)
- [09｜验收矩阵、质量门槛与 MVP 完成标准](https://app.notion.com/p/40117b41f58c8129bf52e98ae1bf7016)

## 执行与结案记录

后续开发Agent创建真实Issue后记录URL。关闭前在GitHub Issue中补齐：实现commit/PR、实际测试命令、系统/宿主/模型版本、验收结果与产物链接、仍存在的限制。不得把本页“待执行”直接改为完成而没有证据。

所有Issue遵循统一执行手册：[10｜开发 Agent 执行手册](https://app.notion.com/p/40117b41f58c814ba2c8c2cbef66219c)

## 实施追踪

- [不可变规格快照](https://github.com/RyderFreeman4Logos/akasha-otsuge/blob/b1f4459/docs/spec/issues/MVP-024.md)
- [最终验收矩阵](https://github.com/RyderFreeman4Logos/akasha-otsuge/blob/b1f4459/docs/spec/09.md)
- CLI 名称：`akasha-otsuge`（替换来源中的 `mem` 占位名）。
- 实现、测试与验收证据：待执行。

## Original implementation dependencies (completed)

- [MVP-004 / #4](https://github.com/RyderFreeman4Logos/akasha-otsuge/issues/4)
- [MVP-008 / #8](https://github.com/RyderFreeman4Logos/akasha-otsuge/issues/8)
- [MVP-010 / #10](https://github.com/RyderFreeman4Logos/akasha-otsuge/issues/10)
- [MVP-016 / #16](https://github.com/RyderFreeman4Logos/akasha-otsuge/issues/16)
- [MVP-017 / #17](https://github.com/RyderFreeman4Logos/akasha-otsuge/issues/17)
- [MVP-020 / #20](https://github.com/RyderFreeman4Logos/akasha-otsuge/issues/20)
- [MVP-023 / #23](https://github.com/RyderFreeman4Logos/akasha-otsuge/issues/23)
