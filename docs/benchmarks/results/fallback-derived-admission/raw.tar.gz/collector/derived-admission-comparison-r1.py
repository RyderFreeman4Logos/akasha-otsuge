import datetime,json,os,pathlib,subprocess,time
repo=pathlib.Path.cwd();storage=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023');evidence=repo/'.git/akasha-evidence';helper=repo/'.spike-work/derived-admission-r1/helix/check_generation_workload.py';fixture=repo/'.spike-work/derived-admission-r1/eight-real.jsonl'
rows=[]
for label,binary,output in [('baseline',repo/'.spike-work/shared-session-r1/probe',storage/'fallback-derived-admission-baseline-r1'),('candidate',repo/'.spike-work/derived-admission-r1/probe',storage/'fallback-derived-admission-concurrent-r2')]:
 environment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),load_average=os.getloadavg(),pressure={name:pathlib.Path('/proc/pressure',name).read_text() for name in ['cpu','io','memory']},note='Other host workloads are not controlled; this is a bounded same-harness pair after a failed latency gate, not a causal proof by itself')
 (evidence/f'derived-admission-pair-{label}-environment.json').write_text(json.dumps(environment,indent=2)+'\n')
 started=time.monotonic()
 with (evidence/f'derived-admission-pair-{label}-r1.log').open('x') as log:
  result=subprocess.run(['python3',str(helper),str(binary),str(fixture),str(output),'fallback','--rebuild'],stdout=log,stderr=subprocess.STDOUT)
 rows.append(dict(label=label,exit=result.returncode,seconds=time.monotonic()-started,output=str(output)))
 (evidence/'derived-admission-pair-progress.json').write_text(json.dumps(dict(completed=len(rows),total=2,rows=rows),indent=2)+'\n')
 print(json.dumps(rows[-1]),flush=True)
raise SystemExit(int(any(row['exit'] for row in rows)))
