import fcntl,json,os,pathlib,subprocess,sys,time
repo=pathlib.Path.cwd();sys.path[:0]=[str(repo/'spikes'),str(repo/'spikes/helix')]
from run_case import digest,process_identity,publish
from cold_cache import prepare
root=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023/fallback-ann-malloc-r1')
phase=sys.argv[1];assert phase in ['before','after']
plan=json.loads((root/'plan.json').read_text());database=pathlib.Path(plan['database']);binary=pathlib.Path(plan['binary'])
assert digest(binary)==plan['binary_sha256'] and digest(root/'requests.json')==plan['requests_sha256']
assert os.environ['LANCE_IVF_GLOBAL_TOPK_CHUNK_BYTES']==str(plan['chunk_bytes'][phase])
lock=(database/'.akasha-case-owner.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
out=root/phase;out.mkdir();(out/'OWNER').write_text('akasha-otsuge MVP-003 read-only long-lived native query diagnostic\n')
publish(out/'admission.json',dict(plan_sha256=digest(root/'plan.json'),driver_sha256=digest(__file__),controller=process_identity(os.getpid()),chunk_bytes=plan['chunk_bytes'][phase]))
if phase=='before':
    controls=[]
    for name,raw,error in [('empty','[]','expected sixteen fixed queries'),('large',' '*(1024*1024+1),'replay input exceeds limit')]:
        invalid=out/(name+'.json');invalid.write_text(raw)
        result=subprocess.run([str(binary),str(database),'--query-replay',str(invalid)],capture_output=True,text=True,timeout=10)
        assert result.returncode==1 and error in result.stderr and not result.stdout
        controls.append(dict(case=name,exit=result.returncode,stderr=result.stderr,source_sha256=digest(invalid)))
    publish(out/'negative-controls.json',controls)
prepare(database,out,lock)
started=time.monotonic()
with (out/'stdout.jsonl').open('x') as stdout,(out/'stderr.log').open('x') as stderr:
    child=subprocess.Popen([str(binary),str(database),'--query-replay',str(root/'requests.json')],stdout=stdout,stderr=stderr,env={**os.environ,'LD_PRELOAD':plan['allocator_observer'],'AKASHA_MALLOC_REPORT':str(out/'malloc-report.xml')})
    identity=process_identity(child.pid);publish(out/'child.json',identity)
    try:
        code=child.wait(timeout=300)
        assert code==0,code
    finally:
        if child.poll() is None:child.kill();child.wait(timeout=10)
now=process_identity(identity['pid']);assert now is None or now['start_ticks']!=identity['start_ticks']
rows=[json.loads(line) for line in (out/'stdout.jsonl').open()]
assert len(rows)==65 and [r['ordinal'] for r in rows[:-1]]==list(range(64))
assert rows[-1]['status']=='passed_readonly_diagnostic' and rows[-1]['committed']==plan['committed']
changes=[]
if phase=='after':
    before=[json.loads(line) for line in (root/'before/stdout.jsonl').open()]
    for i,(old,new) in enumerate(zip(before[:-1],rows[:-1],strict=True)):
        if old['reply']!=new['reply']:changes.append(i)
        old,new=old['reply'],new['reply']
        old={**old,'hits':sorted(old['hits'],key=lambda h:json.dumps(h,sort_keys=True))}
        new={**new,'hits':sorted(new['hits'],key=lambda h:json.dumps(h,sort_keys=True))}
        assert old==new,i
publish(out/'result.json',dict(status='passed_readonly_diagnostic',queries=64,seconds=time.monotonic()-started,committed=plan['committed'],order_only_changes=changes,artifacts={p.name:digest(p) for p in out.iterdir() if p.is_file()}))
print(json.dumps(dict(status='passed_readonly_diagnostic',phase=phase,queries=64,seconds=time.monotonic()-started,order_only_changes=changes)))
