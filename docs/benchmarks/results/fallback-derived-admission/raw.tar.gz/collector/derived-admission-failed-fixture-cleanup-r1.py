import fcntl,json,os,pathlib,shutil,subprocess,sys
repo=pathlib.Path.cwd();sys.path.insert(0,str(repo/'spikes/helix'))
from run_case import digest,process_identity,publish
out=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023/fallback-derived-admission-concurrent-r1');admission=json.loads((out/'admission.json').read_text());root=pathlib.Path(admission['temporary_root']);state=json.loads((out/'case/state.json').read_text());verified=json.loads((out/'case/verified.json').read_text())
assert verified['status']=='failed' and verified['failures']==['write P95 exceeded'] and verified['artifacts_verified'] and verified['exact_processes_gone']
assert root.parent==pathlib.Path('/tmp') and root.name.startswith('akasha-generation-workload-') and not root.is_symlink()
assert (root/'OWNER').read_text()=='akasha-otsuge MVP-003 owned corpus import and database\n'
identities=[admission['controller'],state['controller']];units=[state['unit']]
for command in json.loads((out/'commands.json').read_text()):
 assert command['exit']==0
 units.append(next(x.split('=',1)[1] for x in command['command'] if x.startswith('--unit=')))
for path in [*out.glob('*-memory.jsonl'),out/'case/memory.jsonl']:
 rows=[json.loads(line) for line in path.open()];identities += [r for r in rows if r['event']=='executable'];assert rows[-1]['event']=='exit';assert rows[-1]['code']==(1 if path.parent.name=='case' else 0)
for old in identities:
 now=process_identity(old['pid']);assert now is None or now['start_ticks']!=old['start_ticks']
for unit in units:assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip() in {'inactive','failed'}
owner=(root/'database/.akasha-case-owner.lock').open('a');fcntl.flock(owner,fcntl.LOCK_EX|fcntl.LOCK_NB)
files=list(root.rglob('*'));assert all(not p.is_symlink() and p.stat().st_uid==os.getuid() for p in [root,*files]);allocated=sum(p.stat().st_blocks*512 for p in files if p.is_file());free=shutil.disk_usage(root).free
report=dict(path=str(root),owner_sha256=digest(root/'OWNER'),allocated_file_bytes=allocated,exact_recorded_processes_gone=True,units_inactive=True,case_owner_lock_acquired=True,authority_fixture_only=True,measured_case_preserved=str(out/'case'))
publish(out/'fixture-cleanup-admission.json',report);shutil.rmtree(root);assert not root.exists();owner.close()
report.update(removed=True,filesystem_free_delta=shutil.disk_usage('/tmp').free-free,note='File allocation and free-space delta are distinct; concurrent host activity is not controlled');publish(out/'fixture-cleanup.json',report);print(json.dumps(report))
