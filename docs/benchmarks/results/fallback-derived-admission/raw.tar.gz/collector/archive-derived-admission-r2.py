import hashlib,json,pathlib,re,sys,tarfile
repo=pathlib.Path.cwd();sys.path.insert(0,str(repo/'spikes/helix'))
from run_case import digest,publish
storage=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023');frozen=repo/'.spike-work/derived-admission-r1';source=json.loads((frozen/'source.json').read_text())
assert digest(frozen/'probe')==source['native_sha256']
files={}
def add(prefix,root):
 for p in root.rglob('*'):
  if p.is_file() and p.name not in {'probe','observe.so'} and '__pycache__' not in p.parts:
   assert not p.is_symlink();files[prefix+'/'+str(p.relative_to(root))]=p
for kind in ['lifecycle','concurrent']:
 root=storage/(f'fallback-derived-admission-{kind}-r1' if kind=='lifecycle' else 'fallback-derived-admission-concurrent-r2');assert json.loads((root/'verified.json').read_text())['status']=='passed';add(kind,root)
add('candidate-frozen',frozen)
add('initial-failed-concurrent',storage/'fallback-derived-admission-concurrent-r1')
add('baseline-pair',storage/'fallback-derived-admission-baseline-r1')
for group in ['source_sha256','helpers_sha256']:
 for name,want in source[group].items():assert digest(repo/name)==want,name
controls={}
for name in ['fallback-ann-chunk-pair-r1','fallback-ann-chunk-replay-r1','fallback-ann-malloc-r1','fallback-rebuild-memory-observe-r1']:
 root=storage/name;add('bounded-controls/'+name,root)
 summary=root/('comparison.json' if 'chunk' in name else 'observation.json');controls[name]=json.loads(summary.read_text())
for name in ['query-replay-r1','rebuild-memory-observe-r1','malloc-observe-r1']:add('diagnostic-frozen/'+name,repo/'.spike-work'/name)
prefixes=('derived-admission-','ann-chunk-pair-r1','ann-replay-r1','ann-malloc-r1','query-replay-','rebuild-memory-observe-')
names=['archive-derived-admission-r1.py','archive-derived-admission-r2.py','freeze-derived-admission-r1.py','validate-derived-admission-r1.sh','collect-derived-admission-native-r1.py','collect-derived-admission-native-r2.py','verify-full-case.py','collect-rebuild-r2-step.py','ann-chunk-pair-r1.py','shared-session-upstream-source-audit.json']
for p in (repo/'.git/akasha-evidence').iterdir():
 if p.is_file() and (p.name.startswith(prefixes) or p.name in names):files['collector/'+p.name]=p
red=json.loads((repo/'.git/akasha-evidence/derived-admission-red-source.json').read_text());s=(repo/'spikes/fallback/src/search/changes.rs').read_bytes();start=s.index(b'    #[tokio::test',s.index(b'async fn delta_queries_share_session'))
assert hashlib.sha256(s[start:]).hexdigest()==red['test_sha256']
assert 'baseline build bypassed the shared index admission' in (repo/'.git/akasha-evidence/derived-admission-red-r2.log').read_text()
assert '1 passed; 0 failed' in (repo/'.git/akasha-evidence/derived-admission-green-r1.log').read_text()
assert '12 passed; 0 failed' in (repo/'.git/akasha-evidence/derived-admission-unit-r1.log').read_text()
out=repo/'docs/benchmarks/results/fallback-derived-admission';out.mkdir();archive=out/'raw.tar.gz';hashes={n:digest(p) for n,p in sorted(files.items())}
with tarfile.open(archive,'w:gz') as tf:
 for name,p in sorted(files.items()):tf.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tf:
 assert set(tf.getnames())==set(hashes)
 for m in tf.getmembers():assert hashlib.sha256(tf.extractfile(m).read()).hexdigest()==hashes[m.name],m.name
publish(out/'files.json',hashes)
summary=dict(status='passed_diagnostic_only',source_parent=source['parent'],native_sha256=source['native_sha256'],archive_files=len(files),archive_bytes=archive.stat().st_size,archive_sha256=digest(archive),behavioral_red='baseline generation2 completes while real delta application holds derived admission',red_oracle_sha256=red['test_sha256'],initial_harness_failure='short exact selector collected zero tests; retained r1, corrected fully qualified selector r2 without changing test',release_units=12,release_all_targets_clippy='passed',lifecycle=json.loads((storage/'fallback-derived-admission-lifecycle-r1/verified.json').read_text()),concurrent=json.loads((storage/'fallback-derived-admission-concurrent-r2/verified.json').read_text()),bounded_controls=controls,initial_concurrent_failure=json.loads((storage/'fallback-derived-admission-concurrent-r1/case/verified.json').read_text()),baseline_pair=json.loads((storage/'fallback-derived-admission-baseline-r1/case/verified.json').read_text()),review='implementing-agent self-review only',fix='reuse derived lock for baseline build; persist one deadline before waiting; release authority writer before wait; refresh generation state on admission',unchanged=['native cache/spill/FTS/IVF settings','default64MiB ANN scoring chunk','fixed allocator mmap threshold','original deadlines','resource/performance thresholds','dependency pins'],not_proven=['full concurrent build memory/performance','exclusive causal attribution of prior OOM','sole backend decision'])
publish(out/'summary.json',summary);print(json.dumps({k:summary[k] for k in ['status','native_sha256','archive_files','archive_bytes','archive_sha256']}))
