#!/usr/bin/env bash
set -euo pipefail
cd /home/obj/project/github/RyderFreeman4Logos/akasha-otsuge
export MALLOC_MMAP_THRESHOLD_=131072 LANCE_CPU_THREADS=2 LANCE_FTS_NUM_SHARDS=1 LANCE_FTS_PARTITION_SIZE=32 LANCE_DEFAULT_IO_BUFFER_SIZE=16777216
session_frozen="$PWD/.spike-work/derived-admission-r1"
session_storage=/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023
systemd-run --user --quiet --wait --pipe --collect --unit=akasha-derived-admission-lifecycle-r1 -p MemoryMax=671088640 -p MemorySwapMax=0 -p LimitNOFILE=8192 -p WorkingDirectory="$PWD" -p Environment=MALLOC_MMAP_THRESHOLD_=131072 -p Environment=LANCE_CPU_THREADS=2 -p Environment=LANCE_FTS_NUM_SHARDS=1 -p Environment=LANCE_FTS_PARTITION_SIZE=32 -p Environment=LANCE_DEFAULT_IO_BUFFER_SIZE=16777216 python3 "$session_frozen/measure.py" .git/akasha-evidence/derived-admission-lifecycle-r1-memory.jsonl python3 "$session_frozen/fallback/check_lifecycle.py" "$session_frozen/probe" "$session_frozen/eight-real.jsonl" "$session_storage/fallback-derived-admission-lifecycle-r1" > .git/akasha-evidence/derived-admission-lifecycle-r1.log 2>&1
python3 "$session_frozen/helix/check_generation_workload.py" "$session_frozen/probe" "$session_frozen/eight-real.jsonl" "$session_storage/fallback-derived-admission-concurrent-r1" fallback --rebuild > .git/akasha-evidence/derived-admission-concurrent-r1.log 2>&1
