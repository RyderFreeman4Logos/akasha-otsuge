# Implementing-agent self-review — derived build admission

Verdict: PASS for the bounded source change; full resource acceptance pending.
This is self-review, not independent review or Issue completion.

Parent: e4de7fdc8051b474bd090c0de9ef9ba6620633db.
Scope: search::build_generation and the existing native concurrency regression.
Callers: public generation Build and workload_backend::work_rebuild.

- Both paths now share the existing derived mutex used by delta apply, advance
  and activation, matching spec08 default one builder.
- The short authority writer scope serializes first deadline persistence and
  releases before derived admission; it cannot invert activation's derived/writer
  order. Baseline build does not retain the writer while doing native work.
- Waiting for derived admission is inside the original persisted deadline.
  State is read again after admission, preventing a queued invocation from
  overwriting a preceding builder's ready result. Expired unbuilt generations
  remain expired. Ready generations retain coverage verification without rebuild.
- Existing native test holds real delta application at its barrier. Parent
  completes generation2 despite that ownership; candidate expires without any
  generation2 index, ordinary second commit succeeds, and generation3 builds after
  release. Original authority-filter assertion is retained.
- Test bytes are bound by derived-admission-red-source.json; the initial selector
  collected zero tests and is excluded. Corrected exact selector collects one
  behavioral RED, then the same assertion bytes pass.
- No dependencies, cache capacities, query chunk setting, thresholds or schema
  change. The production-database authority is not mutated by this regression.
- Earlier bounded query controls do not establish full concurrent memory success.
  Delta indexing pauses during baseline build; persisted outbox and existing
  index_lag/current-authority filtering preserve the specified visibility boundary.

Native units, Clippy, lifecycle and concurrent receipts are finalized separately;
canonical root gate and publication bind the eventual commit, not this draft.
