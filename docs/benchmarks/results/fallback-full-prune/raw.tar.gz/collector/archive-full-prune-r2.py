import datetime, hashlib, json, pathlib, shutil, subprocess, sys, tarfile

repo = pathlib.Path.cwd()
sys.path.insert(0, str(repo / 'spikes/helix'))
from run_case import digest, publish

storage = pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023')
base = storage / 'fallback-full-prune-r2'
prune = json.loads((base / 'prune/verified.json').read_text())
assert prune['status'] == 'passed' and prune['artifacts_verified']
for phase in ['before', 'after']:
    result = json.loads((base / phase / 'result.json').read_text())
    assert result['status'] == 'passed' and result['commands'] == 42
    for name, expected in result['artifact_sha256'].items():
        assert digest(base / phase / name) == expected, name
assert json.loads((base / 'after/verified.json').read_text())['matches_before']
reuse = json.loads((base / 'completed-reuse.json').read_text())
assert reuse['status'] == 'passed' and reuse['state_unchanged'] and not reuse['native_execution']
state = json.loads((base / 'prune/state.json').read_text())
for name, expected in state['result']['artifact_sha256'].items():
    assert digest(base / 'prune' / name) == expected, name
copy = base / 'prune/probe'
assert digest(copy) == state['identity']['binary_sha256']
assert prune['processes_gone'] and prune['unit_state'] == 'inactive'
for proc in pathlib.Path('/proc').iterdir():
    if not proc.name.isdigit():
        continue
    try:
        assert (proc / 'exe').resolve(strict=True) != copy.resolve(), proc.name
    except (OSError, RuntimeError):
        pass
size = copy.stat().st_size
copy.unlink()
assert not copy.exists()
publish(base / 'controller-copy-retired.json', dict(
    removed=str(copy), bytes=size, binary_sha256=state['identity']['binary_sha256'],
    free_bytes=shutil.disk_usage(base).free,
    note='Completed reuse was verified before removing this disposable copy. This controller is retired; later --resume is not claimed. Frozen source binary remains available.'))

files = {}
for prefix, path in [('failed-witness-r1', storage / 'fallback-full-prune-r1'), ('full-r2', base)]:
    for p in path.rglob('*'):
        if p.is_file():
            assert p.name != 'probe'
            files[prefix + '/' + str(p.relative_to(path))] = p
frozen = repo / '.spike-work/prune-versions-r1'
source = json.loads((frozen / 'source.json').read_text())
for p in frozen.rglob('*'):
    if p.is_file() and p.name != 'probe' and '__pycache__' not in p.parts:
        files['frozen/' + str(p.relative_to(frozen))] = p
for name, expected in source['source_sha256'].items():
    assert digest(repo / name) == expected, name
    assert hashlib.sha256(subprocess.check_output(['git', 'show', 'a62f40d:' + name])).hexdigest() == expected
    files['candidate-source/' + name] = repo / name
for name in ['full-prune-witness.py', 'archive-full-prune-r2.py', 'full-prune-r2.log',
             'full-prune-before-r1.log', 'full-prune-before-r2.log', 'full-prune-after-r2.log',
             'full-disk-before-prune-r1.json', 'full-disk-after-prune-r2.json']:
    files['collector/' + name] = repo / '.git/akasha-evidence' / name
out = repo / 'docs/benchmarks/results/fallback-full-prune'
out.mkdir()
hashes = {name: digest(p) for name, p in sorted(files.items())}
archive = out / 'raw.tar.gz'
with tarfile.open(archive, 'w:gz') as tf:
    for name, p in sorted(files.items()):
        tf.add(p, arcname=name, recursive=False)
with tarfile.open(archive, 'r:gz') as tf:
    assert set(tf.getnames()) == set(hashes)
    for member in tf.getmembers():
        assert hashlib.sha256(tf.extractfile(member).read()).hexdigest() == hashes[member.name]
publish(out / 'files.json', hashes)
before = json.loads((repo / '.git/akasha-evidence/full-disk-before-prune-r1.json').read_text())
after = json.loads((repo / '.git/akasha-evidence/full-disk-after-prune-r2.json').read_text())
summary = dict(status='passed_offline_full_active_generation_prune', source_head='a62f40d43bc28c952c7ab7b51e8f84ebdcc5d6c4',
    binary_sha256=state['identity']['binary_sha256'], archive_files=len(files), archive_bytes=archive.stat().st_size,
    archive_sha256=digest(archive), artifacts_verified=True, seconds=prune['elapsed_s'],
    rss_max_bytes=prune['rss_max_bytes'], cgroup_peak_bytes=prune['cgroup_peak_bytes'], oom_events=0,
    memory_max_bytes=671088640, memory_swap_max_bytes=0, tables=prune['reply']['tables'],
    native_removed_bytes=prune['removed_bytes'], obsolete_versions_removed=prune['removed_versions'],
    witnesses_before=42, witnesses_after=42, exact_json_matches=True, lifecycle=prune['reply']['lifecycle'],
    completed_controller_reuse='unchanged state and no native execution; disposable controller binary then retired',
    failed_first_witness='NOFILE limit omitted; first read failed EMFILE before any prune; retained separately',
    disk=dict(before=before, after=after), exact_processes_gone=True, scratch_removed=True,
    not_proven=['online cleanup', 'inactive generation retirement', 'full concurrent rebuild peak disk bound'])
publish(out / 'summary.json', summary)
print({k: summary[k] for k in ['archive_files', 'archive_bytes', 'archive_sha256', 'seconds', 'native_removed_bytes']})
