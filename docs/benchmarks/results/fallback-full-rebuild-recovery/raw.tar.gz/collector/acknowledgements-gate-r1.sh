#!/usr/bin/env bash
set -euo pipefail
export PATH=/home/obj/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin:"$PATH"
export RUSTUP_TOOLCHAIN=1.99.1
export CARGO_TARGET_DIR=/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/target/storage-spike
export CARGO_BUILD_JOBS=2
cargo test --manifest-path spikes/fallback/Cargo.toml --locked --release > .git/akasha-evidence/acknowledgements-unit-r1.log 2>&1
cargo clippy --manifest-path spikes/fallback/Cargo.toml --locked --release --all-targets -- -D warnings > .git/akasha-evidence/acknowledgements-clippy-r1.log 2>&1
cargo build --manifest-path spikes/fallback/Cargo.toml --locked --release > .git/akasha-evidence/acknowledgements-build-r1.log 2>&1
python3 -m py_compile spikes/fallback/check_authority.py
