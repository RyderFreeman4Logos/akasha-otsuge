# Scoped source review: recorded acknowledgement reconciliation

PASS for the bounded diagnostic verifier and its tested acceptance paths.
This is the implementing agent's self-review, not an independent review and not
an overall storage acceptance verdict. The concurrent full rebuild remains failed.

Reviewed the Request dispatch, 1 MiB input limit, 1..=256 receipt limit, one
read-only transaction, durable receipt equality, immutable outbox/revision identity,
body/scope/active oracle, reconstructed original Change hash, and fixed read point.
The implementation never applies a change. Unknown requests, malformed fields,
altered content and altered stored request hashes fail closed. Cross-batch
uniqueness and complete log coverage belong to the bounded full-run caller.

The frozen candidate passes 12 release unit tests, release all-targets Clippy,
and 77 native authority commands with three real SIGKILL barriers. The old
binary's unsupported-operation refusal is explicitly not behavioral RED.
The new regression covers two historical revisions, rescope/retraction, all
eleven changed fields, unknown requests, empty/oversize batches and stored-hash
corruption. The native fixture separately reopens four acknowledged revisions.

All 9,286 successful logged workload acknowledgements and 50 seed acknowledgements
match durable receipts, content and original request hashes. Ten additional
committed sequences have no persisted request outcomes; their outcomes stay
unknown. Restoration uses the exact eight expected current revisions and checks
unchanged prior history, original source keys/bodies/scopes and exact new commits.

Recovery validation uses the original workload binary and deadlines. Generation
catch-up cannot infer an embedding: eight historical vector restorations require
explicit outputs. Their prior hashed source documents/vectors and current heads
are checked before replay into generation3. No embedding model is called and no
authority history is deleted. Raw failed attempts are retained, including harness
field mismatches and the missing-vector-input failure; no rerun relabels them.

The native concurrent OOM, build-only recovery, sampled disk bound and later
activation witnesses are separate claims. Sharing a Lance Session is a planned
memory-ownership change; it is absent from this patch. Fresh full concurrent
resource/performance acceptance and the sole backend decision remain open.
