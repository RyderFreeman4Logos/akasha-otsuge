import fcntl,hashlib,json,os,pathlib,sys,time
repo=pathlib.Path.cwd();sys.path[:0]=[str(repo/'spikes/helix'),str(repo/'spikes/fallback')]
from run_case import digest,process_identity,publish
from check_real_search import run_native


def correction_versions(case):
    sources=json.loads((case/'corrections.json').read_text())
    selected={s['memory']:{} for s in sources};last={s['memory']:None for s in sources}
    for line in (case/'runtime/requests.jsonl').open():
        row=json.loads(line)
        if row['operation']=='correction' and row['status']=='success':
            entry=row['receipt']['oracle'];memory=entry['memory']
            assert memory in selected
            stage=(row['ordinal']-1)%4
            selected[memory].setdefault(stage,row)
            last[memory]=row
    assert all(set(rows)=={0,1,2,3} for rows in selected.values())
    assert all(row is not None for row in last.values())
    return sources,selected,last


def main():
    case=pathlib.Path(sys.argv[1]).resolve();output=pathlib.Path(sys.argv[2]).resolve();phase=sys.argv[3]
    assert phase in {'before','after'}
    state=json.loads((case/'state.json').read_text());assert state['phase'] in {'completed','abandoned'}
    config=state['identity']['config'];active=config['run']['generation'];candidate=config['run']['rebuild_generation']
    binary=pathlib.Path(config['paths']['binary']);database=pathlib.Path(config['paths']['database'])
    assert digest(binary)==state['identity']['binary_sha256']
    owner=(database/'.akasha-case-owner.lock').open('a');fcntl.flock(owner,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert digest(case/'corrections.json')==state['identity']['corrections_sha256']
    sources,versions,last=correction_versions(case);run=config['run']['id']
    if state['phase']=='completed':
        assert state['result']['status']=='passed'
        assert all((row['ordinal']-1)%4==3 for row in last.values())
        committed=state['result']['engine']['snapshot']['derived']['committed']
        heads={memory:dict(seq=row['receipt']['commit_seq'],request_id=f"{run}:{row['client']}:{row['ordinal']}") for memory,row in last.items()}
    else:
        restored_path=case.parent/'restoration';restored=json.loads((restored_path/'result.json').read_text())
        assert restored['status']=='passed_guarded_original_restoration' and restored['active']==active
        for name,want in restored['artifacts'].items():assert digest(restored_path/name)==want
        committed=restored['committed'];heads={row['memory']:dict(seq=row['to_seq'],request_id=row['request_id']) for row in restored['sources']}
        assert set(heads)==set(last) and len(heads)==8
    output.mkdir();(output/'OWNER').write_text('akasha-otsuge MVP-003 full rebuild generation witnesses\n')
    publish(output/'admission.json',dict(controller=process_identity(os.getpid()),case_state_sha256=digest(case/'state.json'),driver_sha256=digest(__file__),binary_sha256=digest(binary),phase=phase,active_before=active,candidate=candidate,committed=committed))
    records=[];started=time.monotonic();expected_commands=78 if phase=='before' else 79
    def call(channel,request,error=None):
        path=output/f'{len(records):03d}.request.json';publish(path,request)
        stdout,stderr=run_native([str(binary),str(database),'--'+channel,str(path)],output,records)
        assert not records[-1]['timed_out']
        assert records[-1]['exit']==(1 if error else 0),(len(records)-1,stderr[-1500:])
        current=process_identity(records[-1]['child']['pid']);assert current is None or current['start_ticks']!=records[-1]['child']['start_ticks']
        elapsed=time.monotonic()-started;publish(output/'progress.json',dict(completed=len(records),total=expected_commands,elapsed_s=elapsed,rate_per_s=len(records)/elapsed,eta_s=(expected_commands-len(records))*elapsed/len(records),**process_identity(os.getpid())))
        if error:assert error.encode() in stderr;return None
        return json.loads(stdout)
    def g(op,generation=candidate,**kw):return call('generation',dict(op=op,generation=generation,**kw))
    candidate_state=g('status');assert candidate_state['ready'] and candidate_state['cursor']==candidate_state['documents']==11428831 and candidate_state['vector_rows']==candidate_state['vectors']==1_000_000
    lifecycle={n:g('lifecycle_status',n) for n in [active,candidate]}
    for n,value in lifecycle.items():
        assert value['active']==(active if phase=='before' else candidate) and value['committed']==committed
        expected=0 if phase=='before' and n==candidate else committed
        assert value['text']['watermark']==value['vector']['watermark']==expected
        assert value['text']['pending'] is value['vector']['pending'] is None
    bundle=candidate_state['bundle'];fixture=json.loads(pathlib.Path(config['paths']['fixture']).read_text())
    for source in sources:
        memory=source['memory'];head=heads[memory];request_id=head['request_id']
        for generation in [active,candidate]:
            receipt=g('indexed_receipt',generation,request_id=request_id)
            assert receipt['commit_seq']==head['seq'] and receipt['generation']==generation
            assert receipt['stage']==('committed' if phase=='before' and generation==candidate else 'indexed')
            expected=0 if phase=='before' and generation==candidate else committed
            assert receipt['watermarks']==dict(text=expected,vector=expected)
            if phase=='after' and generation==candidate:assert receipt['reasons']==dict(text='applied',vector='not_required')
        for version in versions[memory].values():
            expected=version['receipt']['oracle'];entry=call('authority',dict(op='get',memory=memory,at=expected['seq']))
            assert entry is not None and entry['memory']==memory and entry['seq']==expected['seq'] and entry['scope']==expected['scope'] and entry['active']==expected['active']
            assert hashlib.sha256(entry['body'].encode()).hexdigest()==expected['body_sha256']
        current=call('authority',dict(op='current',principal=run,memory=memory));entry=current['entry']
        assert current['at']==committed and entry['seq']==head['seq'] and entry['body']==source['body'] and entry['scope']==source['scope'] and entry['active'] and entry['source_key']==source['key']
    query=fixture['queries'][sources[0]['query_index']]
    if phase=='before':
        call('generation',dict(op='query_current',generation=candidate,bundle=bundle,principal=run,scope=0,term=query['term']),error='query generation unavailable')
        call('generation',dict(op='activate',generation=candidate),error='candidate generation has incomplete coverage')
    query_generation=active if phase=='before' else candidate
    query_bundle=g('status',active)['bundle'] if phase=='before' else bundle
    for source in sources:
            q=fixture['queries'][source['query_index']]
            reply=g('query_current',query_generation,bundle=query_bundle,principal=run,scope=source['scope'],term=q['term'],min_commit_seq=committed)
            expected=heads[source['memory']]['seq']
            assert any(h['memory']==source['memory'] and h['seq']==expected and h['partition']==f"p{source['scope']}" for h in reply['hits'])
            assert reply['read_seq']==reply['validated_at_seq']==committed
    vectors=pathlib.Path(config['paths']['fixture']).parent/fixture['vector_file']['name'];assert digest(vectors)==fixture['vector_file']['sha256']
    import struct
    with vectors.open('rb') as stream:
            for scope in range(8):
                q=next(q for q in fixture['queries'] if q['partition']==f'p{scope}' and q.get('vector_offset') is not None)
                stream.seek(q['vector_offset']);vector=list(struct.unpack('<1536f',stream.read(1536*4)))
                reply=g('query_current',query_generation,bundle=query_bundle,principal=run,scope=scope,vector=vector,min_commit_seq=committed)
                assert any(h['memory']==q['memory'] and h['seq']==0 for h in reply['hits'])
                assert all(h['partition']==f'p{scope}' for h in reply['hits']) and reply['validated_at_seq']==committed
    if phase=='after':
        for changed in [dict(schema=bundle['schema']+1),dict(model='foreign'),dict(model_fingerprint='0'*64),dict(dimension=1)]:
            call('generation',dict(op='query_current',generation=candidate,bundle={**bundle,**changed},principal=run,scope=0,term=query['term']),error='query bundle mismatch')
    assert len(records)==expected_commands
    publish(output/'result.json',dict(status='passed',phase=phase,commands=len(records),active_generation=active if phase=='before' else candidate,committed=committed,seconds=time.monotonic()-started,source_versions=32,current_sources=8,indexed_receipts=16,artifacts={p.name:digest(p) for p in output.iterdir() if p.is_file()}))
    print(json.dumps(dict(status='passed',phase=phase,commands=len(records),seconds=time.monotonic()-started)))


if __name__=='__main__':main()
