import fcntl,json,os,pathlib,sys,time
repo=pathlib.Path.cwd();sys.path[:0]=[str(repo/'spikes/helix'),str(repo/'spikes/fallback')]
from run_case import digest,process_identity,publish
from check_real_search import run_native
root=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023/fallback-full-rebuild-r1')
for phase in ['witness-before-r3','drain-3-r2','vector-replay']:
 assert json.loads((root/phase/'verified.json').read_text())['status']=='passed'
state=json.loads((root/'low/state.json').read_text());config=state['identity']['config'];binary=pathlib.Path(config['paths']['binary']);database=pathlib.Path(config['paths']['database'])
assert digest(binary)==state['identity']['binary_sha256']
lock=(database/'.akasha-case-owner.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
output=root/'activation';output.mkdir();(output/'OWNER').write_text('akasha-otsuge MVP-003 recovered generation3 activation\n')
publish(output/'admission.json',dict(controller=process_identity(os.getpid()),native_sha256=digest(binary),driver_sha256=digest(__file__)))
records=[];started=time.monotonic()
def call(op,generation):
 request=output/f'{len(records):03d}.request.json';publish(request,dict(op=op,generation=generation))
 stdout,stderr=run_native([str(binary),str(database),'--generation',str(request)],output,records)
 assert records[-1]['exit']==0 and not records[-1]['timed_out'],stderr[-1000:]
 return json.loads(stdout)
for generation in [2,3]:
 before=call('lifecycle_status',generation);assert before['active']==2 and before['committed']==before['text']['watermark']==before['vector']['watermark']==269826
 assert before['text']['pending'] is before['vector']['pending'] is None
activated=call('activate',3);assert activated['active']==3
for generation in [2,3]:
 after=call('lifecycle_status',generation);assert after['active']==3 and after['committed']==after['text']['watermark']==after['vector']['watermark']==269826
publish(output/'result.json',dict(status='passed',active=3,committed=269826,commands=len(records),seconds=time.monotonic()-started,artifacts={p.name:digest(p) for p in output.iterdir() if p.is_file()}))
print(json.dumps(dict(status='passed',active=3,committed=269826,commands=len(records))),flush=True)
