import fcntl,hashlib,json,pathlib,sys,time
repo=pathlib.Path.cwd();sys.path[:0]=[str(repo/'spikes/helix'),str(repo/'spikes/fallback')]
from run_case import digest,process_identity,publish
from check_real_search import run_native
storage=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023');root=storage/'fallback-full-rebuild-r1';case=root/'low'
verified=json.loads((root/'acknowledgements/result.json').read_text());assert verified['status']=='passed_all_recorded_acknowledgements' and verified['total_verified']==9336
for name,want in verified['artifacts'].items():assert digest(root/'acknowledgements'/name)==want
state=json.loads((case/'state.json').read_text());assert state['phase']=='abandoned'
assert digest(case/'corrections.json')==state['identity']['corrections_sha256']
assert digest(case/'runtime/requests.jsonl')==json.loads((root/'acknowledgements/admission.json').read_text())['requests_sha256']
config=state['identity']['config'];binary=pathlib.Path(config['paths']['binary']);database=pathlib.Path(config['paths']['database'])
assert digest(binary)==state['identity']['binary_sha256']
lock=(database/'.akasha-case-owner.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
sources=json.loads((case/'corrections.json').read_text());before=json.loads((root/'reconcile/result.json').read_text());point=before['committed']
assert point==verified['commit_seq'] and len(sources)==len(before['heads'])==8
output=root/'restoration';output.mkdir();(output/'OWNER').write_text('akasha-otsuge MVP-003 guarded source restoration after failed workload\n')
publish(output/'admission.json',dict(controller=process_identity(__import__('os').getpid()),native_sha256=digest(binary),driver_sha256=digest(__file__),sources_sha256=digest(case/'corrections.json'),verification_sha256=digest(root/'acknowledgements/result.json'),reconciliation_sha256=digest(root/'reconcile/result.json'),initial_commit_seq=point))
records=[];started=time.monotonic();restored=[]
def call(channel,request):
    path=output/f'{len(records):03d}.request.json';publish(path,request)
    stdout,stderr=run_native([str(binary),str(database),'--'+channel,str(path)],output,records)
    assert records[-1]['exit']==0 and not records[-1]['timed_out'],stderr[-1000:]
    current=process_identity(records[-1]['child']['pid']);assert current is None or current['start_ticks']!=records[-1]['child']['start_ticks']
    elapsed=time.monotonic()-started;publish(output/'progress.json',dict(completed=len(records),total=36,elapsed_s=elapsed,rate_per_s=len(records)/elapsed,eta_s=(36-len(records))*elapsed/len(records)))
    return json.loads(stdout)
assert call('authority',dict(op='status'))['commit_seq']==point
for source,prior in zip(sources,before['heads'],strict=True):
    memory=source['memory'];assert memory==prior['memory']
    old=call('authority',dict(op='get',memory=memory,at=point))
    assert old['seq']==prior['seq'] and old['scope']==prior['scope'] and old['active']==prior['active'] and hashlib.sha256(old['body'].encode()).hexdigest()==prior['body_sha256']
    change=dict(request_id=f'full-rebuild-r1-restore:{memory}',memory=memory,expected=old['seq'],scope=source['scope'],active=True,body=source['body'],text_only=True)
    receipt=call('authority',dict(op='apply',change=change));assert receipt['stage']=='committed' and receipt['commit_seq']==point+len(restored)+1
    historical=call('authority',dict(op='get',memory=memory,at=point));assert historical==old
    current=call('authority',dict(op='get',memory=memory,at=receipt['commit_seq']))
    assert current['body']==source['body'] and current['scope']==source['scope'] and current['active'] and current['text_only'] and current['source_key']==source['key'] and current['previous']==old['seq'] and current['seq']==receipt['commit_seq']
    restored.append(dict(memory=memory,from_seq=old['seq'],to_seq=current['seq'],body_sha256=hashlib.sha256(current['body'].encode()).hexdigest(),request_id=change['request_id']))
assert call('authority',dict(op='status'))['commit_seq']==point+8
lifecycle={g:call('generation',dict(op='lifecycle_status',generation=g)) for g in [2,3]}
assert all(value['active']==2 and value['committed']==point+8 for value in lifecycle.values())
assert len(records)==36
publish(output/'result.json',dict(status='passed_guarded_original_restoration',sources=restored,committed=point+8,active=2,lifecycle=lifecycle,commands=len(records),seconds=time.monotonic()-started,artifacts={p.name:digest(p) for p in output.iterdir() if p.is_file()}))
print(json.dumps(dict(status='passed_guarded_original_restoration',sources=8,committed=point+8,commands=len(records))),flush=True)
