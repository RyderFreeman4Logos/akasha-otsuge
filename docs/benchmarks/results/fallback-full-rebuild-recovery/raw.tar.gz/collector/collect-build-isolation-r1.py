import datetime,json,math,pathlib,subprocess,sys
sys.path.insert(0,str(pathlib.Path('spikes/helix').resolve()))
from run_case import digest,process_identity,publish
root=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023/fallback-full-build-isolation-r1');case=root/'build'
admission=json.loads((root/'admission.json').read_text());state=json.loads((case/'state.json').read_text())
assert state['phase'] in {'completed','interrupted'}
assert state['identity']['binary_sha256']==admission['native_sha256']
for name,want in state['result']['artifact_sha256'].items():assert digest(case/name)==want
attempt=state['attempts'][-1];log=pathlib.Path(attempt['log']);memory=log.with_name('memory.jsonl')
events=[json.loads(line) for line in memory.open() if line.endswith('\n')]
native=[e for e in events if e['event']=='executable'];terminal=[e for e in events if e['event']=='exit'];samples=[e for e in events if e['event']=='sample']
assert len(native)==1 and len(terminal)<=1 and samples
assert native[0]['sha256']==admission['native_sha256']
for identity in [state['controller'],native[0]]:
    current=process_identity(identity['pid']);assert current is None or current['start_ticks']!=identity['start_ticks']
unit_state=subprocess.check_output(['systemctl','--user','show',attempt['unit'],'-p','ActiveState','--value'],text=True).strip();assert unit_state=='inactive'
assert events[0]['limits']['memory.max']=='671088640' and events[0]['limits']['memory.swap.max']=='0' and events[0]['nofile_soft_hard']==[8192,8192]
deadlines=[];replies=[];oom_kill=False
for line in log.open():
    if line.startswith('ORIGINAL_OPERATION_DEADLINE_MS:'):deadlines.append(int(line.split(':',1)[1]))
    if line.startswith('{'):replies.append(json.loads(line))
    if 'oom-kill' in line:oom_kill=True
assert deadlines and set(deadlines)=={admission['unchanged_original_index_deadline_ms']}
rss=sorted(s['engine_rss_bytes'] for s in samples);peak=rss[-1];p99=rss[math.ceil(len(rss)*.99)-1]
clean_exit=len(terminal)==1 and terminal[0]['code']==terminal[0]['native_code']==0
oom_events={k:max(int(s['memory_events'].get(k,0)) for s in samples) for k in ['oom','oom_kill']}
no_oom=not oom_kill and not any(oom_events.values())
scratch=terminal[0].get('scratch_cleanup') if terminal else None
scratch_removed=bool(scratch and scratch['removed'] and not pathlib.Path(scratch['path']).exists())
coverage=len(replies)==1 and replies[0].get('ready') is True and replies[0]['cursor']==replies[0]['documents']==11428831 and replies[0]['vector_rows']==replies[0]['vectors']==1000000
passed=state['result']['exit']==0 and clean_exit and no_oom and peak<=640*1024**2 and p99<=512*1024**2 and coverage and scratch_removed
result=dict(status='passed_direct_low_recovery_only' if passed else 'failed_direct_low_recovery',native_operation=state['result'],native_sha256=admission['native_sha256'],original_deadline_ms=deadlines[0],native_terminal=terminal[0] if terminal else None,full_index_coverage=coverage,reply=replies[0] if len(replies)==1 else None,rss_p99_bytes=p99,rss_max_bytes=peak,samples=len(samples),sampled_seconds=samples[-1]['seconds'],cgroup_peak_bytes=max(s['cgroup_peak_bytes'] for s in samples),oom_kill=oom_kill,sampled_oom_events=oom_events,exact_processes_gone=True,unit_inactive=True,unit=attempt['unit'],scratch_cleanup=scratch,scratch_removed=scratch_removed,collector_sha256=digest(__file__),verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),not_proven=['fresh uninterrupted build','concurrent build/query acceptance','all recorded acknowledgements retained','causal isolation of a specific allocation'],artifacts=state['result']['artifact_sha256'])
publish(root/'result.json',result)
print(json.dumps({k:result[k] for k in ['status','full_index_coverage','rss_p99_bytes','rss_max_bytes','sampled_seconds','oom_kill','original_deadline_ms']}))
raise SystemExit(0 if passed else 1)
