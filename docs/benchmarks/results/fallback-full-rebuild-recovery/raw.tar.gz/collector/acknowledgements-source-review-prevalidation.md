# Acknowledgement verifier preliminary source review

Implementing-agent source review only; no independent review or gate PASS.

Scope: bounded readonly authority request, its77-command native fixture, one
release unit, and failed-run verification/restoration drivers. The old binary's
unsupported-operation control is admission evidence, not a behavioral RED.

Reviewed paths: Request dispatch ->1MiB input bound ->1..=256 receipts ->one
readonly transaction ->durable receipt equality ->job_entry revision identity
and historical content ->reconstructed Change/idempotency hash ->fixed commit
point. Each body is bounded by the existing512KiB record decoder. No write path
is entered by the verifier. Global duplicate IDs and complete batch coverage
are checked by the full-run caller, not asserted by a single batch.

The native fixture reopens between operations and checks four historical
revisions,11 altered fields, unknown requests and empty/oversize batches. The
unit additionally corrupts the durable request hash, restores it, and checks the
same commit point. All of these new native checks remain UNEXECUTED until the
ongoing frozen build-only measurement terminates.

Full-run collection binds the abandoned case, complete request log, baseline
manifest, expected commit point and unique request/sequence identities. Guarded
restoration requires every recorded acknowledgement and checks prior history,
current source key/body/scope, active generation and the exact eight new commits.
Missing buffered request outcomes remain unknown rather than inferred failed.

Pending: compile/tests/Clippy,77-command native fixture,9336 full acknowledgements,
actual guarded restoration and drain, source freeze, full review and publication.
