import hashlib,json,pathlib,sys,tarfile
repo=pathlib.Path.cwd();sys.path.insert(0,str(repo/'spikes/helix'))
from run_case import digest,publish
storage=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023')
root=storage/'fallback-full-rebuild-r1';isolation=storage/'fallback-full-build-isolation-r1'
failed=json.loads((root/'low/state.json').read_text());assert failed['phase']=='abandoned'
recovery=json.loads((isolation/'result.json').read_text());assert recovery['status']=='passed_direct_low_recovery_only'
steps={name:json.loads((root/name/'verified.json').read_text()) for name in ['acknowledgements','restoration','witness-before-r3','vector-replay','drain-3-r2','activation','witness-after']}
assert all(s['status']=='passed' for s in steps.values())
native=json.loads((storage/'fallback-acknowledgements-native-r1/verified.json').read_text());assert native['status']=='passed'
files={}
def add_tree(prefix,path):
 for p in path.rglob('*'):
  if p.is_file() and p.name!='probe' and '__pycache__' not in p.parts:
   assert not p.is_symlink();files[prefix+'/'+str(p.relative_to(path))]=p
for prefix,path in [('full-failed',root),('build-only-recovery',isolation),('authority-native',storage/'fallback-acknowledgements-native-r1'),('old-native-admission',repo/'.git/akasha-evidence/acknowledgements-red-r1'),('frozen-old',repo/'.spike-work/corpus-corrections-r2'),('frozen-ack',repo/'.spike-work/acknowledgements-r1')]:add_tree(prefix,path)
source=json.loads((repo/'.spike-work/acknowledgements-r1/source.json').read_text())
assert digest(repo/'.spike-work/acknowledgements-r1/probe')==source['native_sha256']
for group in ['source_sha256','helpers_sha256']:
 for name,want in source[group].items():
  assert digest(repo/name)==want,name;files['candidate-source/'+name]=repo/name
collector=repo/'.git/akasha-evidence'
for pattern in ['acknowledgements-*.log','acknowledgements-*.sh','acknowledgements-*.json','acknowledgements-*.md','full-rebuild-*.log','full-rebuild-*.jsonl','full-rebuild-*.json','full-rebuild-*.py','full-build-isolation-r1.log','disk-observer-accounting-r2.json','measure-rebuild-disk.py','reconcile-full-rebuild-r1.py','verify-full-rebuild-acknowledgements.py','restore-full-rebuild-sources.py','drain-failed-rebuild-generation.py','replay-generation3-restored-vectors.py','activate-recovered-generation3.py','collect-rebuild-recovery-step.py','collect-build-isolation-r1.py','archive-full-rebuild-recovery-r1.py']:
 for p in collector.glob(pattern):
  if p.is_file():files['collector/'+p.name]=p
out=repo/'docs/benchmarks/results/fallback-full-rebuild-recovery';out.mkdir();archive=out/'raw.tar.gz'
hashes={n:digest(p) for n,p in sorted(files.items())}
with tarfile.open(archive,'w:gz') as tf:
 for name,p in sorted(files.items()):tf.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tf:
 assert set(tf.getnames())==set(hashes)
 for m in tf.getmembers():assert hashlib.sha256(tf.extractfile(m).read()).hexdigest()==hashes[m.name],m.name
publish(out/'files.json',hashes)
summary=dict(status='recovery_and_acknowledgements_passed_concurrent_acceptance_failed',source_parent=source['parent'],workload_native_sha256=failed['identity']['binary_sha256'],acknowledgement_native_sha256=source['native_sha256'],archive_files=len(files),archive_bytes=archive.stat().st_size,archive_sha256=digest(archive),artifacts_verified=True,
 concurrent_failure=dict(cause='systemd oom-kill',seconds=403.420,rss_max_bytes=686899200,complete_logged_requests=10942,logged_successful_acknowledgements=9286,observer_terminal_missing=True),
 direct_low_recovery={k:recovery[k] for k in ['status','full_index_coverage','rss_p99_bytes','rss_max_bytes','sampled_seconds','original_deadline_ms','oom_kill']},steps=steps,
 acknowledgement_count=9336,unknown_unlogged_committed_sequences=list(range(269809,269819)),restored_sources=8,active_generation=3,committed_and_both_watermarks=269826,
 disk_failure_samples=dict(total_inode_allocation_max_bytes=118985441280,filesystem_free_min_bytes=401853628416,category_cap_violation=False,completed_rebuild_peak=False,observer_note='Original ru_maxrss included pre-exec lifetime highwater; VmRSS observer self-check retained, no retrospective runtime RSS claim'),
 release_units=12,native_authority_commands=77,real_sigkill_barriers=3,release_all_targets_clippy='passed',review='implementing-agent self-review only',
 harness_failures_retained=['drain collector compared catch_up target/done extras to lifecycle status','witness current used read_seq instead of at','witness hits expected absent source key; source key now checked on authority entry','generation3 catch_up requires explicit vector outputs for eight restored vectorized sources; frozen original outputs replayed separately'],
 not_proven=['fresh uninterrupted full low build','full concurrent workload/rebuild latency throughput and memory acceptance','complete concurrent rebuild disk peak','controlled full build SIGKILL','sole backend decision'])
publish(out/'summary.json',summary);print(json.dumps({k:summary[k] for k in ['status','archive_files','archive_bytes','archive_sha256']}))
