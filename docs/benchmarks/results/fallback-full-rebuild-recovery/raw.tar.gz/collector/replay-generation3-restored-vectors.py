import fcntl,hashlib,json,os,pathlib,sys,time
repo=pathlib.Path.cwd();sys.path[:0]=[str(repo/'spikes/helix'),str(repo/'spikes/fallback')]
from run_case import digest,process_identity,publish
from check_real_search import run_native
storage=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023');root=storage/'fallback-full-rebuild-r1';prior=storage/'fallback-full-corpus-lifecycle-r1/case'
state=json.loads((root/'low/state.json').read_text());config=state['identity']['config'];binary=pathlib.Path(config['paths']['binary']);database=pathlib.Path(config['paths']['database'])
assert digest(binary)==state['identity']['binary_sha256']
old=json.loads((prior/'state.json').read_text());assert old['phase']=='completed' and old['result']['status']=='passed'
lock=(database/'.akasha-case-owner.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
output=root/'vector-replay';output.mkdir();(output/'OWNER').write_text('akasha-otsuge MVP-003 explicit original-vector replay into recovered generation3\n')
publish(output/'admission.json',dict(controller=process_identity(os.getpid()),native_sha256=digest(binary),driver_sha256=digest(__file__),historical_case_sha256=digest(prior/'state.json')))
records=[];started=time.monotonic();sources=[]
def call(channel,request):
 path=output/f'{len(records):03d}.request.json';publish(path,request)
 stdout,stderr=run_native([str(binary),str(database),'--'+channel,str(path)],output,records)
 assert records[-1]['exit']==0 and not records[-1]['timed_out'],stderr[-1000:]
 publish(output/'progress.json',dict(completed=len(records),total=26,elapsed_s=time.monotonic()-started))
 return json.loads(stdout)
before=call('generation',dict(op='lifecycle_status',generation=3));assert before['committed']==269826 and before['active']==2 and before['vector']['pending'] is None
for row in old['result']['cases']:
 if row['mode']!='ann':continue
 tag=f"p{row['scope']}-ann";names=[tag+'-restore-vector.request.json',tag+'-restore.request.json',tag+'-source.reply.json']
 for name in names:
  assert digest(prior/name)==old['result']['artifact_sha256'][name]
  (output/name).write_bytes((prior/name).read_bytes())
 request,change,source=[json.loads((prior/name).read_text()) for name in names]
 seq=row['commits'][-1];assert request['seq']==seq and request['family']=='vector' and request['generation']==2
 current=call('authority',dict(op='get',memory=row['memory'],at=269826))
 assert current['seq']==seq and current['body']==source['body'] and current['scope']==row['scope'] and current['active'] and not current['text_only'] and current['source_key']==source['key']
 assert request['vector']['values']==source['embedding'] and request['vector']['body_sha256']==hashlib.sha256(source['body'].encode()).hexdigest()
 call('generation',{**request,'generation':3})
 receipt=call('generation',dict(op='indexed_receipt',generation=3,request_id=change['change']['request_id']))
 assert receipt['stage']=='indexed' and receipt['commit_seq']==seq and receipt['reasons']==dict(text='applied',vector='applied')
 sources.append(dict(memory=row['memory'],scope=row['scope'],seq=seq,body_sha256=request['vector']['body_sha256'],vector_request_sha256=digest(prior/names[0])))
after=call('generation',dict(op='lifecycle_status',generation=3));assert after['committed']==269826 and after['active']==2 and after['vector']['pending'] is None
assert len(records)==26 and len(sources)==8
publish(output/'result.json',dict(status='passed',commands=len(records),seconds=time.monotonic()-started,sources=sources,before=before,after=after,artifacts={p.name:digest(p) for p in output.iterdir() if p.is_file()}))
print(json.dumps(dict(status='passed',sources=8,commands=len(records))),flush=True)
