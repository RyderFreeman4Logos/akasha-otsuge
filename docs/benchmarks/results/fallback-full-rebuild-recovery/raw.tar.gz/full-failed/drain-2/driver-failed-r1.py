import fcntl,json,os,pathlib,sys,time
repo=pathlib.Path.cwd();sys.path[:0]=[str(repo/'spikes/helix'),str(repo/'spikes/fallback')]
from run_case import digest,process_identity,publish
from check_real_search import run_native
generation=int(sys.argv[1]);assert generation in {2,3}
storage=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023');root=storage/'fallback-full-rebuild-r1';case=root/'low'
state=json.loads((case/'state.json').read_text());config=state['identity']['config'];binary=pathlib.Path(config['paths']['binary']);database=pathlib.Path(config['paths']['database'])
assert digest(binary)==state['identity']['binary_sha256']
assert json.loads((root/'restoration/verified.json').read_text())['status']=='passed'
expected=json.loads((root/'restoration/result.json').read_text())['committed'];assert expected==269826
lock=(database/'.akasha-case-owner.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
output=root/f'drain-{generation}';output.mkdir();(output/'OWNER').write_text('akasha-otsuge MVP-003 bounded drain after failed full rebuild\n')
publish(output/'admission.json',dict(generation=generation,expected_committed=expected,controller=process_identity(os.getpid()),native_sha256=digest(binary),driver_sha256=digest(__file__),deadline_seconds=300,case_state_sha256=digest(case/'state.json')))
records=[];started=time.monotonic()
def call(op,**fields):
    remaining=300-(time.monotonic()-started);assert remaining>0
    request=output/f'{len(records):03d}.request.json';publish(request,dict(op=op,generation=generation,**fields))
    stdout,stderr=run_native([str(binary),str(database),'--generation',str(request)],output,records,timeout=remaining)
    assert records[-1]['exit']==0 and not records[-1]['timed_out'],stderr[-1000:]
    value=json.loads(stdout);assert value['committed']==expected and value['active']==2
    completed=min(value['text']['watermark'],value['vector']['watermark']);elapsed=time.monotonic()-started
    publish(output/'progress.json',dict(completed=completed,total=expected,elapsed_s=elapsed,remaining=expected-completed))
    return value
before=call('lifecycle_status');value=before
for _ in range(4):
    if min(value['text']['watermark'],value['vector']['watermark'])==expected:break
    value=call('catch_up',waves=1000000)
assert value['text']['watermark']==value['vector']['watermark']==expected
assert value['text']['pending'] is value['vector']['pending'] is None
after=call('lifecycle_status');assert after==value and time.monotonic()-started<=300
for record in records:
    current=process_identity(record['child']['pid']);assert current is None or current['start_ticks']!=record['child']['start_ticks']
publish(output/'result.json',dict(status='passed',generation=generation,seconds=time.monotonic()-started,before=before,after=after,commands=len(records),artifacts={p.name:digest(p) for p in output.iterdir() if p.is_file()}))
print(json.dumps(dict(status='passed',generation=generation,committed=expected,commands=len(records),seconds=time.monotonic()-started)),flush=True)
