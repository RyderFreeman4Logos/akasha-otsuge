import json, os, pathlib, resource, shutil, signal, stat, subprocess, sys, time

repo=pathlib.Path.cwd()
sys.path.insert(0,str(repo/'spikes/helix'))
from run_case import digest,process_identity,publish

def snapshot(database, output, active, candidate):
    started=time.monotonic()
    result={k:dict(files=0,allocated_bytes=0,logical_bytes=0) for k in ['authority','active','candidate','scratch','other']}
    vanished=0
    roots=[(database,None)]+[(p,'scratch') for p in output.glob('native-scratch-*')]
    for root,forced in roots:
        if root.is_symlink(): raise ValueError('symlink in measured owned storage')
        for parent,dirs,files in os.walk(root,followlinks=False):
            for name in dirs:
                if (pathlib.Path(parent)/name).is_symlink(): raise ValueError('symlink in measured owned storage')
            for name in files:
                path=pathlib.Path(parent)/name
                try: value=path.lstat()
                except FileNotFoundError:
                    vanished+=1
                    continue
                if stat.S_ISLNK(value.st_mode): raise ValueError('symlink in measured owned storage')
                if not stat.S_ISREG(value.st_mode): continue
                parts=path.relative_to(root).parts
                group=forced or ('authority' if parts[0]=='authority' else
                    'active' if len(parts)>1 and parts[0]=='derived' and parts[1].startswith(f'g{active}_') else
                    'candidate' if len(parts)>1 and parts[0]=='derived' and parts[1].startswith(f'g{candidate}_') else 'other')
                result[group]['files']+=1
                result[group]['allocated_bytes']+=value.st_blocks*512
                result[group]['logical_bytes']+=value.st_size
    return dict(categories=result,free_bytes=shutil.disk_usage(database).free,vanished_entries=vanished,
        scan_seconds=time.monotonic()-started,observer_peak_rss_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
        measured_unix_s=time.time())

def violations(sample,plan):
    return [k for k,limit in plan['allocated_byte_limits'].items() if sample['categories'][k]['allocated_bytes']>limit]+(
        ['headroom'] if sample['free_bytes']<plan['headroom_bytes'] else [])

def terminate_native(output,identity):
    state=json.loads((output/'state.json').read_text())
    if state['controller']['pid']!=identity['pid'] or state['controller']['start_ticks']!=identity['start_ticks']:
        raise ValueError('case controller identity changed; refusing unrelated cancellation')
    events=[json.loads(line) for line in (output/'memory.jsonl').read_text().splitlines(keepends=True) if line.endswith('\n')]
    native=[e for e in events if e['event']=='executable']
    if len(native)!=1: raise ValueError('missing exact native cancellation identity')
    engine=native[0]
    if engine['sha256']!=state['identity']['binary_sha256'] or not engine['cgroup'].endswith('/'+state['unit']+'.service'):
        raise ValueError('native cancellation identity differs from admission')
    try: handle=os.pidfd_open(engine['pid'])
    except ProcessLookupError: return dict(already_exited=True,native=engine)
    try:
        current=process_identity(engine['pid'])
        if current is None: return dict(already_exited=True,native=engine)
        if current['start_ticks']!=engine['start_ticks']: raise ValueError('native PID was reused')
        group=pathlib.Path(f"/proc/{engine['pid']}/cgroup").read_text().strip().split('::',1)[1]
        if '/sys/fs/cgroup'+group!=engine['cgroup']: raise ValueError('native cgroup changed')
        signal.pidfd_send_signal(handle,signal.SIGTERM)
    finally: os.close(handle)
    return dict(signal='SIGTERM',native=engine,note='only the exact admitted native PID; observer retains cleanup and terminal receipt ownership')

def main():
    plan_path=pathlib.Path(sys.argv[1]).resolve(strict=True)
    plan=json.loads(plan_path.read_text());database=pathlib.Path(plan['database']).resolve(strict=True)
    output=pathlib.Path(plan['run_output']).resolve();evidence=pathlib.Path(plan['evidence_output']).resolve()
    assert plan['sample_interval_seconds']==10 and plan['headroom_bytes']>=30*1024**3
    assert set(plan['allocated_byte_limits'])=={'authority','active','candidate','scratch','other'}
    assert all(type(v) is int and v>0 for v in plan['allocated_byte_limits'].values())
    assert type(plan['active_generation']) is int and type(plan['candidate_generation']) is int
    assert 0<plan['active_generation']!=plan['candidate_generation']>0
    assert (database/'OWNER').read_text()=='akasha-otsuge MVP-003 fallback database\n'
    assert not output.exists()
    evidence.mkdir()
    initial=snapshot(database,output,plan['active_generation'],plan['candidate_generation'])
    assert not violations(initial,plan)
    remaining=sum(max(0,limit-initial['categories'][k]['allocated_bytes']) for k,limit in plan['allocated_byte_limits'].items())
    assert initial['free_bytes']>=remaining+plan['headroom_bytes']
    publish(evidence/'admission.json',dict(plan=plan,plan_sha256=digest(plan_path),driver_sha256=digest(__file__),
        controller_sha256=digest(plan['command'][1]),config_sha256=digest(plan['command'][2]),initial=initial,
        remaining_allocated_budget_bytes=remaining,observer=process_identity(os.getpid()),
        limits_note='sampled inode allocation caps with10s checks; not an instantaneous quota or exclusive Btrfs extent accounting'))
    failure=None;cancellation=None;samples=[]
    with (evidence/'controller.log').open('x') as log,(evidence/'samples.jsonl').open('x') as stream:
        child=subprocess.Popen(plan['command'],stdout=log,stderr=subprocess.STDOUT)
        identity=process_identity(child.pid)
        publish(evidence/'controller.json',identity)
        try:
            while True:
                sample=snapshot(database,output,plan['active_generation'],plan['candidate_generation'])
                samples.append(sample)
                stream.write(json.dumps(sample)+'\n');stream.flush();os.fsync(stream.fileno())
                publish(evidence/'progress.json',sample)
                breached=violations(sample,plan)
                if breached:
                    failure='storage budget exceeded: '+','.join(breached)
                    if child.poll() is None: cancellation=terminate_native(output,identity)
                    break
                try:
                    child.wait(timeout=plan['sample_interval_seconds'])
                    break
                except subprocess.TimeoutExpired: pass
        except BaseException as error:
            failure=str(error) or type(error).__name__
            if child.poll() is None: cancellation=terminate_native(output,identity)
        finally:
            child.wait(timeout=180)
        final=snapshot(database,output,plan['active_generation'],plan['candidate_generation'])
        samples.append(final);stream.write(json.dumps(final)+'\n');stream.flush();os.fsync(stream.fileno())
    peaks={k:max(s['categories'][k]['allocated_bytes'] for s in samples) for k in plan['allocated_byte_limits']}
    result=dict(status='passed_sampled_storage_bound' if child.returncode==0 and failure is None and not violations(final,plan) else 'failed',
        child_exit=child.returncode,failure=failure,cancellation=cancellation,samples=len(samples),sampled_peaks=peaks,
        sampled_total_peak_bytes=max(sum(v['allocated_bytes'] for v in s['categories'].values()) for s in samples),
        free_bytes_min=min(s['free_bytes'] for s in samples),observer_peak_rss_bytes=max(s['observer_peak_rss_bytes'] for s in samples),
        scan_seconds_total=sum(s['scan_seconds'] for s in samples),final=final,
        observer_note='separate metadata-only harness; no engine data is cached here; scans are not atomic',
        bound_note='observed allocation bound at10s checks, not instantaneous filesystem quota; native free-space guard remains active')
    publish(evidence/'result.json',result)
    print(json.dumps({k:result[k] for k in ['status','child_exit','sampled_peaks','sampled_total_peak_bytes','free_bytes_min']}))
    return 0 if result['status']=='passed_sampled_storage_bound' else 1

if __name__=='__main__': raise SystemExit(main())
