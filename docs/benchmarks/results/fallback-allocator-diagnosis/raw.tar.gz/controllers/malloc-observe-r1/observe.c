#define _POSIX_C_SOURCE 200809L
#include <fcntl.h>
#include <malloc.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

static FILE *report;
static pthread_t worker;
static atomic_int stopped;

static void sample(void) {
    struct timespec now;
    clock_gettime(CLOCK_MONOTONIC, &now);
    struct mallinfo2 info = mallinfo2();
    fprintf(report, "BEGIN %ld.%09ld arena=%zu used=%zu free=%zu mmap=%zu\n",
            now.tv_sec, now.tv_nsec, info.arena, info.uordblks, info.fordblks, info.hblkhd);
    if (malloc_info(0, report) != 0) _exit(122);
    fputs("END\n", report);
    if (fflush(report) || fsync(fileno(report))) _exit(123);
}

static void *observe(void *unused) {
    (void)unused;
    while (!atomic_load(&stopped)) {
        sample();
        struct timespec delay = {.tv_sec = 1};
        nanosleep(&delay, NULL);
    }
    return NULL;
}

__attribute__((constructor)) static void start(void) {
    const char *path = getenv("AKASHA_MALLOC_REPORT");
    if (!path) return;
    int fd = open(path, O_WRONLY | O_CREAT | O_EXCL | O_NOFOLLOW, 0600);
    if (fd < 0 || !(report = fdopen(fd, "w"))) _exit(121);
    if (pthread_create(&worker, NULL, observe, NULL)) _exit(124);
}

__attribute__((destructor)) static void finish(void) {
    if (!report) return;
    atomic_store(&stopped, 1);
    pthread_join(worker, NULL);
    sample();
    fclose(report);
}
