import hashlib
import importlib
import json
import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
from run_case import digest, process_identity, publish
def run(name, args, killed=False, refused=False):
    unit = 'akasha-corpus-life-'+uuid.uuid4().hex
    command = ['systemd-run', '--user', '--quiet', '--wait', '--pipe', '--collect', '--unit='+unit,
        '-p', 'MemoryMax=671088640', '-p', 'MemorySwapMax=0', '-p', 'LimitNOFILE=8192', '-p', 'RuntimeMaxSec=1200',
        '-p', 'Environment=AKASHA_SPIKE_PROFILE=low', '-p', 'Environment=MALLOC_MMAP_THRESHOLD_=131072',
        '-p', 'Environment=LANCE_FTS_NUM_SHARDS=1', '-p', 'Environment=LANCE_FTS_PARTITION_SIZE=32',
        '-p', 'Environment=LANCE_CPU_THREADS=2', '-p', 'Environment=LANCE_DEFAULT_IO_BUFFER_SIZE=16777216',
        '-p', 'Environment=LANCE_SHUFFLE_BATCH_BYTES=16777216', '-p', 'Environment=LANCE_SHUFFLE_MAX_PRELOADED_OFFSETS_BYTES=0',
        '-p', 'Environment=AKASHA_SPIKE_DISK_RESERVE_BYTES=36212254720', sys.executable, str(frozen/'measure.py'),
        str(output/(name+'-memory.jsonl')), *map(str,args)]
    record = dict(name=name, unit=unit, command=command, phase='admitted')
    records.append(record)
    publish(output/'commands.json', records)
    publish(output/'progress.json', dict(phase=name, completed=len(records)-1, total=10, elapsed_s=time.monotonic()-started))
    with (output/(name+'.log')).open('x') as log:
        child = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, timeout=1230)
    record.update(phase='completed', exit=child.returncode)
    publish(output/'commands.json', records)
    events = [json.loads(line) for line in (output/(name+'-memory.jsonl')).read_text().splitlines()]
    exits = [r for r in events if r['event']=='exit']
    assert len(exits)==1 and exits[0]['scratch_cleanup']['removed']
    if killed:
        assert child.returncode != 0 and exits[0]['native_code']==-9, (name, child.returncode, exits)
    elif refused:
        assert child.returncode != 0, name
    else:
        assert child.returncode==0, (name, (output/(name+'.log')).read_text()[-3000:])
    assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip() in {'inactive','failed'}
    for row in events:
        if row['event']=='executable':
            now=process_identity(row['pid']);assert now is None or now['start_ticks']!=row['start_ticks']
    return events

repo=pathlib.Path.cwd()
sys.path.insert(0,str(repo/'spikes/helix'))
from run_case import digest,process_identity,publish
storage=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023')
output=storage/'fallback-corpus-lifecycle-fixture-r1'
frozen=repo/'.spike-work/corpus-lifecycle-r1'
binary=repo/'.spike-work/incremental-text-r1/probe'
admission=json.loads((output/'admission.json').read_text())
assert digest(binary)==admission['binary_sha256']
temporary=pathlib.Path(admission['temporary_root']);database=temporary/'database'
records=json.loads((output/'commands.json').read_text());started=time.monotonic()
case_output=output/'case';args=[binary,database,frozen/'queries.json',case_output,'--generation','1']
state=json.loads((case_output/'state.json').read_text());assert state['phase']=='completed';result=state['result']
assert len(result['cases'])==16 and [seq for c in result['cases'] for seq in c['commits']]==list(range(1,65)) and result['final']['committed']==64
assert json.loads((case_output/'p0-bm25-correct.reply.json').read_text())==json.loads((case_output/'cut.json').read_text())['receipt']

before={p.name:digest(p) for p in case_output.iterdir() if p.is_file()}
run('completed-reuse',[sys.executable,frozen/'fallback/check_corpus_lifecycle.py',*args,'--resume'])
assert before=={p.name:digest(p) for p in case_output.iterdir() if p.is_file()}
fixture=frozen/'queries.json';original=fixture.read_bytes()
try:
    fixture.write_bytes(original+b'\n')
    run('changed-fixture',[sys.executable,frozen/'fallback/check_corpus_lifecycle.py',*args,'--resume'],refused=True)
    assert 'immutable identity changed' in (output/'changed-fixture.log').read_text()
finally:fixture.write_bytes(original)
reply=case_output/'p0-bm25-correct-current.reply.json';original=reply.read_bytes()
try:
    reply.write_bytes(original+b'\n')
    run('changed-reply',[sys.executable,frozen/'fallback/check_corpus_lifecycle.py',*args,'--resume'],refused=True)
finally:reply.write_bytes(original)
assert before=={p.name:digest(p) for p in case_output.iterdir() if p.is_file()}
sys.path.insert(0,str(frozen/'fallback'));module=importlib.import_module('check_corpus_lifecycle')
entry=json.loads(reply.read_text())['entry'];change=json.loads((case_output/'p0-bm25-correct.request.json').read_text())['change']
expected=(entry['memory'],entry['seq'],change['scope'],change['body'],change['text_only'],entry['source_key'])
module.check_entry(entry,*expected);negative=[]
for key,value in dict(memory=0,seq=0,scope=7,active=False,body='forged',text_only=False,source_key='forged').items():
    try:module.check_entry({**entry,key:value},*expected)
    except AssertionError:negative.append(key)
    else:raise AssertionError(('forged current receipt accepted',key))
for record in json.loads((case_output/'commands.json').read_text()):
    now=process_identity(record['child']['pid']);assert now is None or now['start_ticks']!=record['child']['start_ticks']
for name,value in result['artifact_sha256'].items():assert digest(case_output/name)==value,name
assert (temporary/'OWNER').read_text()=='akasha-otsuge MVP-003 owned corpus import and database\n'
shutil.rmtree(temporary)
publish(output/'result.json',dict(status='passed_diagnostic_only',cases=16,commits=64,commands=len(records),
    native_commands=result['native_commands'],negative_controls=negative,crash_resume='durable native commit before reply-cache publication; no duplicate revision',
    completed_reuse_no_effects=True,changed_fixture_refused=True,changed_reply_refused=True,fixture_removed=not temporary.exists(),
    binary_sha256=digest(binary),continuation_seconds=time.monotonic()-started,native_case_seconds=result['seconds'],not_proven=['full corpus','simultaneous query/build scheduling'],
    artifact_sha256={str(p.relative_to(output)):digest(p) for p in output.rglob('*') if p.is_file()}))
print(json.dumps(dict(status='passed',cases=16,commits=64,seconds=time.monotonic()-started)))
