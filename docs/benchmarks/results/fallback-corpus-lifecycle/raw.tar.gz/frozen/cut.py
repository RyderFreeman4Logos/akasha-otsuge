import sys,os,signal,json,pathlib
sys.path.insert(0,str(pathlib.Path(__file__).parent/'fallback'))
import check_corpus_lifecycle as case
original=case.run_native
def cut_after_commit(*args,**kwargs):
    stdout,stderr=original(*args,**kwargs)
    command=args[0]
    if command[-1].endswith('p0-bm25-correct.request.json'):
        receipt=json.loads(stdout)
        assert receipt['commit_seq']==1
        case.publish(pathlib.Path(sys.argv[4])/'cut.json',dict(phase='native_committed_before_reply_cache',receipt=receipt,controller=case.process_identity(os.getpid())))
        os.kill(os.getpid(),signal.SIGKILL)
    return stdout,stderr
case.run_native=cut_after_commit
case.main()
