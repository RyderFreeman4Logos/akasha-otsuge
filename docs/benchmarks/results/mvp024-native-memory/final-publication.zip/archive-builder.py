import hashlib
import json
import pathlib
import subprocess
import zipfile

E = pathlib.Path(__file__).parent
W = pathlib.Path('/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025')
head = 'b83cf3d1022d28961fda2ebe20b42a24c797060c'
tree = subprocess.check_output(['git', '-C', str(W), 'rev-parse', head + '^{tree}'], text=True).strip()
members, references = {}, {}
shared_archive = W / 'docs/benchmarks/results/mvp024-native-prune/scale-comparison.zip'
shared_manifest = json.loads(shared_archive.with_name('scale-comparison-manifest.json').read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
assert sha(shared_archive.read_bytes()) == shared_manifest['zip_sha256']
shared = ('input-manifest.json', 'pilot.toml', 'binding.json', 'oracle.json', 'acks.jsonl')
names = ('mvp024-production-final-binary-r1',)
for name in names:
    root = W / '.spike-work' / name
    assert not (root / 'data').exists()
    verified = json.loads((E / (name + '-verified.json')).read_text())
    assert verified['head'] == head
    cleanup = json.loads((E / (name + '-cleanup.json')).read_text())
    assert cleanup['removed'] and all(not pathlib.Path(p).exists() for p in cleanup['roots'])
    for path in sorted(root.iterdir()):
        assert path.is_file() and not path.is_symlink()
        data = path.read_bytes()
        expected = verified['metadata'][path.name]
        assert len(data) == expected['bytes'] and sha(data) == expected['sha256']
        if path.name in shared:
            member = 'shared/' + path.name
            assert expected == shared_manifest['members'][member]
            with zipfile.ZipFile(shared_archive) as prior:
                assert data == prior.read(member)
            references[name + '/' + path.name] = {
                'archive': '../mvp024-native-prune/scale-comparison.zip',
                'archive_sha256': shared_manifest['zip_sha256'], 'member': member, **expected}
        else:
            members[name + '/' + path.name] = data
    for path in sorted(E.glob(name + '*')):
        assert path.is_file() and not path.is_symlink()
        members['receipts/' + path.name] = path.read_bytes()
patterns = [
    'mvp024-native-canonical-r2*',
    'mvp024-native-canonical-verify-r1.py',
    'mvp024-native-review-r1-final*',
    'mvp024-native-review-r1-reviewer*',
    'mvp024-native-review-launch-r1-final*',
    'mvp024-native-review-uid-*',
    'mvp024-native-push-r1*',
    'mvp024-native-ci-r1*',
    'mvp024-native-ci-watch-r1*',
    'mvp024-native-merge-r1.json',
    'mvp024-native-publication-readback-r1.json',
    'mvp024-native-postmerge-readback-r1.json',
    'mvp024-native-final-pilot-issue65-readback-r1-normalized.json',
    'mvp024-native-receipt-normalization-r1.json',
]
for pattern in patterns:
    selected = sorted(E.glob(pattern))
    assert selected, pattern
    for item in selected:
        if item.suffix in ('.stdout', '.stderr', '.tmp'):
            continue
        assert item.is_file() and not item.is_symlink()
        members['receipts/' + item.name] = item.read_bytes()
members['raw/mvp024-native-final-pilot-issue65-readback-r1.json.txt'] = (E / 'mvp024-native-final-pilot-issue65-readback-r1.json').read_bytes()
members['review-input/final-brief.md'] = (W / '.review/mvp024-native-review-r1-final-brief.md').read_bytes()
for name, data in members.items():
    if name.endswith('.json'):
        json.loads(data)
    elif name.endswith('.jsonl'):
        for line in data.splitlines():
            json.loads(line)
identity = {'head': head, 'tree': tree, 'cases': list(names),
            'scope': 'Final canonical/install release artifact bounded pilot, canonical R2, unchanged independent review with preserved UID-prerequisite failure, separate parent UID diagnosis/smoke, successful CI and exact PR71 publication/merge. Full issue65 acceptance remains pending.',
            'cleanup': 'All exact disposable databases and sockets removed after process/consumer checks; source shards and shared oracles are not duplicated.', 'merge': '96e2b5f07f1dea0289f82d88bc89b43c754d4fc1', 'report_sha256': '181bbed29ca37a8c8e2394b0ec12b830dbc93f0d5feceb1dc2a72f4ace832a01', 'format_note': 'One parent issue readback contained a trailing literal backslash-n. Its original bytes are retained as raw text beside a separately normalized identical JSON value and correction receipt. Native child transcripts are excluded.'}
members['identity.json'] = (json.dumps(identity, indent=2) + '\n').encode()
members['shared-input-references.json'] = (json.dumps(references, indent=2) + '\n').encode()
members['archive-builder.py'] = pathlib.Path(__file__).read_bytes()
path = E / 'mvp024-native-final-r1.zip'
with zipfile.ZipFile(path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
    for name, data in members.items():
        assert not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts
        info = zipfile.ZipInfo(name, (2026, 11, 16, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        out.writestr(info, data)
manifest = {**identity, 'zip_sha256': sha(path.read_bytes()), 'zip_bytes': path.stat().st_size,
            'members': {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in members.items()}}
with zipfile.ZipFile(path) as saved:
    assert len(saved.namelist()) == len(set(saved.namelist())) == len(members)
    for name, expected in manifest['members'].items():
        data = saved.read(name)
        assert len(data) == expected['bytes'] and sha(data) == expected['sha256']
with (E / 'mvp024-native-final-r1-manifest.json').open('x') as out:
    json.dump(manifest, out, indent=2)
    out.write('\n')
print(json.dumps({'members': len(members), 'references': len(references), 'bytes': manifest['zip_bytes'], 'sha256': manifest['zip_sha256']}))
