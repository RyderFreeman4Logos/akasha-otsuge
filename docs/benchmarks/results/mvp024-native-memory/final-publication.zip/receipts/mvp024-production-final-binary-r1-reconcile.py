import pathlib,json,hashlib,datetime,os,stat,shutil
E=pathlib.Path("/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/.git/akasha-evidence");root=pathlib.Path('.spike-work/mvp024-production-final-binary-r1').resolve(strict=True)
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
state=json.loads((root/'state.json').read_text());ad=json.loads((root/'admission.json').read_text());terminal=json.loads((E/'mvp024-production-final-binary-r1.terminal.json').read_text())
assert terminal['exit_code']==0 and state['phase']=='complete' and state['completed_units']==['seed','index','verify'] and state['processes_terminal']=={'daemon':0,'seed':0}
assert sha(E/'mvp024-production-final-binary-r1.log')==terminal['log_sha256']
assert (state['seed_records'],state['memories'],state['unique_utf8_bytes'])==(8192,8322,35875218)
baseline=root.parent/'mvp024-production-scale-pilot-r2'
for name in ['pilot.toml','input-manifest.json','binding.json','oracle.json','acks.jsonl']:assert (root/name).read_bytes()==(baseline/name).read_bytes(),name
rows=[json.loads(x) for x in (root/'metrics.jsonl').read_text().splitlines()];assert rows
rss=[];missing=[]
for n,row in enumerate(rows):
 c=row['resources']['cgroup'];assert c['available'] and c['complete'] and c['enforced'] and c['effective']=={'daemon_memory_target_mib':512,'daemon_peak_limit_mib':640,'service_total_budget_mib':2048}
 m=row['resources']['measurement'];group=m.get('daemon_group')
 if group is None:
  assert not m['complete'] and m['error']=='RESOURCE_MEASUREMENT_UNAVAILABLE';missing.append({'index':n,'elapsed_s':row['elapsed_s'],'error':m['error']});continue
 rss.append(group['rss_bytes'])
assert len(rss)==len(rows) and not missing and max(rss)<512*1024**2
import subprocess
assert ad['head']==subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='b83cf3d1022d28961fda2ebe20b42a24c797060c'
assert not subprocess.check_output(['git','status','--porcelain'])
assert sha(pathlib.Path('target/release/akasha-otsuge'))==ad['daemon_sha256']
build=json.loads((E/'mvp024-production-final-binary-r1-build.json').read_text())
gate=json.loads((E/'mvp024-native-canonical-r2-verified.json').read_text())
assert ad['head']==build['head']==gate['head']
assert ad['daemon_sha256']==build['daemon_sha256']==gate['installed']['binary_sha256']
assert ad['seeder_source_pin']==build['seeder_source_pin']=='92031ea46c6dcb33e4810954aba00b91c5d3357d'
assert ad['seeder_sha256']==build['seeder_sha256']==sha(pathlib.Path('target/release/examples/corpus_seed'))
assert ad['driver_sha256']==build['driver_sha256']==sha(E/'mvp024-production-final-binary-r1.py')

assert ad['native_startup']['external_daemon_overrides']=={} and all(x is None for x in ad['native_startup']['inherited_environment'].values())
start=json.loads((root/'daemon-process.json').read_text());effective=json.loads((root/'fts-environment.json').read_text())['process']
assert all(start[k]==effective[k] for k in ['pid','start_ticks'])
result=json.loads((root/'result.json').read_text());oracle=json.loads((root/'oracle.json').read_text())
assert result['status']=='pilot_pass_not_scale_acceptance' and result['all_current_claim_hashes_verified']==8322
assert len(result['read_seconds'])==8322 and all(x>0 for x in result['read_seconds'])
commands=[json.loads(x) for x in (root/'commands.jsonl').read_text().splitlines()]
reads=[x for x in commands if x['argv'][:2]==['memory','show']]
assert len(reads)==8322 and all(x['exit_code']==0 for x in reads)
assert [x['argv'][2] for x in reads]==[x['id'] for x in oracle['memories']]
assert len(result['lexical_partition_witnesses'])==8
for witness in result['lexical_partition_witnesses']:
 partition=witness['partition'];expected=oracle['witnesses'][partition];assert witness['expected']==expected
 job=json.loads((root/('pilot-search-'+partition+'-terminal.json')).read_text());assert job['state']=='succeeded' and job['error'] is None
 items=[x['memory'] for x in json.loads(job['result']['output'])['items']]
 assert any(x['revision']['key']['id']==expected['id'] and x['revision']['commit_seq']==expected['revision'] for x in items)
 assert all(x['record']['draft']['scope']['project']=='corpus/'+partition for x in items)
index=json.loads((root/'pilot-index-terminal.json').read_text());assert index['state']=='succeeded' and index['result']['indexed_rows']==8322 and index['result']['lexical_watermark']==index['retrieval_target_seq']==16520
assert json.loads((root/'fts-environment.json').read_text())['selected_environment']=={'LANCE_FTS_NUM_SHARDS':'1','LANCE_FTS_PARTITION_SIZE':'32','MALLOC_ARENA_MAX':'2'}
import math
verification={'memory_read_success_receipts':len(reads),'memory_ids_equal_frozen_oracle':True,'driver_claim_hash_revision_authority_assertions_passed':8322,'scoped_search_outputs_independently_rechecked':8,'index_watermark':16520,'sampled_rss_p99_nearest_rank_bytes':sorted(rss)[math.ceil(len(rss)*.99)-1]}
identities=[json.loads((root/n).read_text()) for n in ['seed-process.json','daemon-process.json']]+[ad['process'],json.loads((E/'mvp024-production-final-binary-r1.launch.json').read_text())['process']]
for ident in identities:
 p=pathlib.Path('/proc')/str(ident['pid'])/'stat'
 if p.exists():assert p.read_text().rsplit(')',1)[1].split()[19]!=str(ident['start_ticks']),ident
initial=json.loads((root/'initial-status.json').read_text());cgroup=pathlib.Path(initial['resources']['cgroup']['path']);assert not cgroup.exists(),cgroup
data=root/'data';socket=pathlib.Path(ad['socket_root']);tmp=pathlib.Path('/mnt/ssd/mirror-rootfs/home/obj/tmp/a15-cache-s0s9a8n9')
assert data.resolve()==data and data.is_dir() and socket.parent==tmp and socket.name.startswith('a24p-') and len(socket.name)==13 and socket.is_dir() and not socket.is_symlink()
files={}
for p in sorted(data.rglob('*')):
 assert not p.is_symlink(),p
 if p.is_file():
  s=p.stat();assert s.st_uid==os.getuid() and stat.S_ISREG(s.st_mode)
  files[str(p.relative_to(data))]={'bytes':s.st_size,'allocated_bytes':s.st_blocks*512,'sha256':sha(p)}
metadata={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in root.iterdir() if p.is_file()}
verified={'utc':now(),'classification':'EXACT_FINAL_BINARY_BOUNDED_PILOT_PASS_NOT_SCALE_ACCEPTANCE','head':ad['head'],'daemon_sha256':ad['daemon_sha256'],'seeder_sha256':ad['seeder_sha256'],'progress':json.loads((root/'progress.json').read_text()),'state':state,'metadata':metadata,'sample_count':len(rows),'valid_rss_samples':len(rss),'output_verification':verification,'unavailable_measurements':missing,'max_sampled_rss_bytes':max(rss),'rss_over512_count':sum(x>512*1024**2 for x in rss),'rss_over640_count':sum(x>640*1024**2 for x in rss),'max_sampled_kernel_bytes':max(x['resources']['cgroup']['daemon_group']['peak_bytes'] for x in rows),'max_sampled_oom_kills':max(x['resources']['cgroup']['daemon_group']['oom_kills'] for x in rows),'last_memory_breakdown':rows[-1]['diagnostic_memory_breakdown'],'native_files':files,'native_allocated_bytes':sum(x['allocated_bytes'] for x in files.values()),'owned_process_identities_absent':identities,'cgroup_absent':str(cgroup),'aggregation_notes':f'All {len(rows)} observations complete; no unavailable RSS sample. Nearest-rank sample P99 retained, not a continuous maximum.','limits':'Exact canonical/install-gate release binary, bounded 8192-source pilot only; no full corpus, ANN, concurrent load or full scale acceptance. Historical IPC cause remains unclassified; single observations do not establish a causal performance interval.'}
receipt=E/'mvp024-production-final-binary-r1-verified.json'
with receipt.open('x') as f:json.dump(verified,f,indent=2);f.write('\n')
old=json.loads((E/'mvp024-production-mmap-control-r1-cleanup-admission.json').read_text())
known={(x['pid'],str(x['start_ticks']),x['comm']) for x in old['excluded_unrelated_services']}
references=[];excluded=[];unknown=[];inspected=0
roots=[data,socket]
def matches(value):
 return any(value==str(r) or value.startswith(str(r)+'/') for r in roots)
for p in pathlib.Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  if p.stat().st_uid!=os.getuid():continue
  s=(p/'stat').read_text().rsplit(')',1)[1].split();comm=(p/'comm').read_text().strip();identity=(int(p.name),s[19],comm)
  if s[0]=='Z':continue
  inspected+=1
  links=[p/'cwd',p/'exe',*list((p/'fd').iterdir())]
  for link in links:
   try:
    value=os.readlink(link)
    if matches(value):references.append({'pid':int(p.name),'kind':link.name,'path':value})
   except FileNotFoundError:pass
 except FileNotFoundError:pass
 except PermissionError:
  if identity in known:excluded.append({'pid':identity[0],'start_ticks':identity[1],'comm':identity[2],'reason':'Exact previously classified unrelated nondumpable service identity; no new exclusion inferred'})
  else:unknown.append({'pid':int(p.name)})
assert not references and not unknown,{'references':references,'unknown':unknown}
for rel,expected in files.items():
 p=data/rel;assert p.stat().st_size==expected['bytes'] and sha(p)==expected['sha256']
admit={'utc':now(),'roots':[str(x) for x in roots],'verified_receipt_sha256':sha(receipt),'owned_processes_and_cgroup_absent':True,'native_files_reverified':len(files),'native_allocated_bytes':verified['native_allocated_bytes'],'own_uid_processes_inspected':inspected,'accessible_references':references,'excluded_unrelated_services':excluded,'free_before_bytes':shutil.disk_usage('/mnt/ssd').free,'scope':'Only exact completed final-binary pilot disposable native data and owned socket directory; preserve every metadata/source/corpus/cache file.'}
with (E/'mvp024-production-final-binary-r1-cleanup-admission.json').open('x') as f:json.dump(admit,f,indent=2);f.write('\n')
for p in roots:shutil.rmtree(p)
assert all(not p.exists() for p in roots)
done={**admit,'utc':now(),'removed':True,'free_after_bytes':shutil.disk_usage('/mnt/ssd').free,'free_delta_is_not_exact_reclaim_on_btrfs':True}
with (E/'mvp024-production-final-binary-r1-cleanup.json').open('x') as f:json.dump(done,f,indent=2);f.write('\n')
print(json.dumps({'classification':verified['classification'],'progress':verified['progress']['completed'],'total':8322,'valid_rss_samples':len(rss),'unavailable_measurements':missing,'max_rss':max(rss),'over512':verified['rss_over512_count'],'over640':verified['rss_over640_count'],'kernel_peak':verified['max_sampled_kernel_bytes'],'sampled_oom':verified['max_sampled_oom_kills'],'native_files':len(files),'native_allocated_bytes':verified['native_allocated_bytes'],'cleanup':True,'excluded_known_services':len(excluded)}))
