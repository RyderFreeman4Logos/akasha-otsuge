import ast,datetime,hashlib,importlib.util,json,os,pathlib,shutil,subprocess,sys,time
E=pathlib.Path(__file__).parent
W=pathlib.Path.cwd()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='b83cf3d1022d28961fda2ebe20b42a24c797060c'
assert not subprocess.check_output(['git','status','--porcelain'])
path=W/'scripts/check_daemon_command.py'
before=subprocess.check_output(['git','show','63acf39d2138bc582ee746b6eefede970fd3f8cc:scripts/check_daemon_command.py'],text=True)
after=path.read_text()
def definitions(text):
 return {node.name:ast.dump(node,include_attributes=False) for node in ast.parse(text).body if isinstance(node,ast.FunctionDef) and node.name in ['command','another_uid']}
assert definitions(before)==definitions(after)
spec=importlib.util.spec_from_file_location('owned_cli_smoke',path)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
status={k:v.strip() for line in pathlib.Path('/proc/self/status').read_text().splitlines() if ':' in line for k,v in [line.split(':',1)] if k in ['Uid','Gid','NoNewPrivs','Seccomp','Seccomp_filters']}
choices=[]
if shutil.which('unshare') and shutil.which('setpriv'):
 choices.append(['unshare','--map-auto','--map-root-user','setpriv','--reuid=1','--regid=1','--clear-groups','--bounding-set=-all'])
if os.geteuid()==0:
 choices.append(['setpriv','--reuid=65534','--regid=65534','--clear-groups','--bounding-set=-all'])
elif shutil.which('sudo'):
 choices.append(['sudo','-n','-u','nobody','--'])
results=[]
for prefix in choices:
 r=module.command([*prefix,sys.executable,'-c','import os; print(os.geteuid())'])
 results.append({'prefix':prefix,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
available=any(r['exit_code']==0 and r['stdout'].strip().isdigit() and int(r['stdout'])!=os.geteuid() for r in results)
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'unchanged_helper_ast':True,'parent_status':status,'parent_uid_map':pathlib.Path('/proc/self/uid_map').read_text(),'attempts':results,'parent_alternate_uid_available':available,'limits':'This is the parent managed environment, not a reconstruction of the terminated reviewer environment. Original reviewer smoke remains exit1; its precise lower-level launcher failure was not captured and remains unavailable.'}
with (E/'mvp024-native-review-uid-prerequisite-r1.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
assert available,'Parent UID prerequisite also unavailable; do not run smoke'
binary=W/'target/release/akasha-otsuge'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(binary)=='0a5436f0dc22a2858f3f083be56be55a278b78f31315d76888ebd309c5425fc1'
cmd=[sys.executable,str(path),str(binary)]
start=time.monotonic();r=subprocess.run(cmd,stdin=subprocess.DEVNULL,capture_output=True,text=True)
print(r.stdout,end='');print(r.stderr,end='',file=sys.stderr)
receipt.update(smoke_command=cmd,smoke_exit=r.returncode,smoke_seconds=time.monotonic()-start,smoke_stdout=r.stdout,smoke_stderr=r.stderr,binary_sha256=digest(binary))
assert not subprocess.check_output(['git','status','--porcelain'])
with (E/'mvp024-native-review-uid-smoke-r1-result.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
raise SystemExit(r.returncode)
