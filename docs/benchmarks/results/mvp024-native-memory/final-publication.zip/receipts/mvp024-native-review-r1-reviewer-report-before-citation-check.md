VERDICT: PASS
ACTIONABLE_COUNT: 0

Independent conventional native Codex fallback review of the entire origin/main...HEAD range. This is the first dispatched independent review of this startup leaf, not a Claude-native or CSA verdict. No actionable REGRESSION was found. PASS is a source-review disposition under the requested zero-actionable rule; it does not mean every fresh command passed. The fresh release smoke exited 1 at its unavailable alternate-UID prerequisite, as detailed below. Its failure is preserved without retry or waiver. The supplied exact-candidate canonical gate independently provides the completed installed lifecycle/UID acceptance.

Frozen scope and custody

W: /mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025
E: /home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/.git/akasha-evidence
Branch: fix/mvp-024-native-memory
HEAD: b83cf3d1022d28961fda2ebe20b42a24c797060c
TREE: e82093f968b0133db7ba1d84064bdc9adb0dca88
origin/main and merge-base: 63acf39d2138bc582ee746b6eefede970fd3f8cc
Canonical full-index binary range diff SHA-256: 19441fcd1659e9fe9b3f6110949b05bc593632d3e66d22be595068243d4c9583

All three commits and all 19 changed paths in the immutable final-scope JSON were reviewed. Commit 92031ea adds the startup implementation, tests and evidence; 6435c3e changes only five documentation/evidence paths; b83cf3d changes the two fixture publication sites and their evidence/docs. Direct Git comparison confirms src, Cargo manifests/lock, examples, startup regression and release smoke still equal 92031ea. No thresholds, existing assertions or product deadlines were relaxed.

The E brief describes the earlier 6435c3e candidate and was read as historical input. The final scope, launcher and .review/mvp024-native-review-r1-final-brief.md agree with the current user instructions and govern this report. Their hashes are retained in reviewer-postflight.json. Parent inputs and earlier receipts were not overwritten.

Before source reading, real-filesystem inspection checked 46 logical AGENTS.md/CLAUDE.md candidates through every supplied-checkout ancestor and changed-path owner, resolving each path. None exists, including no dangling instruction symlink; therefore no applicable instruction file required an EOF read or line count. The later supplemental alias/original-root/caller-directory census checked 122 candidates, also all absent. Both complete path/result lists are retained in reviewer-instructions.json and reviewer-instructions-aliases.json; these are filesystem observations, not Git absence inference. Native-code-review SKILL.md and its scope/attribution, foundations, lifecycle, Rust/isolation, boundaries/verdict, receipt-integrity, failure-classification and immutable-report/finalization routes were read. Ponytail scope discipline was retained. No recursive review, Hermes/CSA call, model call, relay, transcript inspection, new worktree/target, dependency install or source edit occurred.

Startup execution and lifecycle

At src/main.rs:118 the parser retains the original Vec<OsString>. Global config/socket paths remain OS strings; command-token UTF-8 validation remains unchanged. The operation match admits only daemon run/start to this final daemon route after other offline/adapter branches return. Configuration is read and resolved at :690 onward, and mismatched explicit sockets fail at :847 before re-execution. Therefore malformed arguments/configuration still fail through the existing error path rather than being bypassed.

src/main.rs:856 handles daemon start and returns. Only daemon run reaches native_environment at :863. var_os compares each of the three exact values, and Command::new(current_exe()).args(&args).envs(native_environment).exec() at :874 replaces the process with the same executable and original argument vector. exec retains PID and process-group identity; there is no spawned intermediary. The three values are established in the new image, so the next pass does not loop. Command inherits unrelated environment; it does not call env_clear or mutate global environment in the current process. Failure to resolve/exec the executable propagates as an ordinary error. Help/version and the early __native-runner dispatch at :954 remain outside this route.

The call to daemon::run remains after this boundary at src/main.rs:881. src/daemon.rs:663 then creates the private data directory, acquires the listener, opens resource accounting and calls open_service; Storage::open is at :687. Thus neither storage nor index initialization precedes the exec. The current-thread Tokio runtime and config parsing do precede it, but their allocations are replaced with the process image. There is no unsafe set_var/pre_exec addition.

Detached ownership remains coherent: src/daemon.rs:630 converts only the final start argument to run; :632 launches nohup with the same executable and argument vector, preserved log FDs and its own process group; :649 requires the status PID to equal child.id(). Existing child-exit and startup-timeout branches remain. serve at :764 retains signal handling, normal stop/drain and controlled reopen; close_recording at :169 drains owners, releases the cached index and closes storage. A budget reopen calls open_service, not main, so it retains the process's startup defaults and original PID/socket. Native runners continue through their existing early entrypoint; descendants can inherit the documented environment. No independent native-runner route was retargeted.

Pinned FTS semantics and limits

src/retrieval.rs:433 creates FTS with explicit creation-time memory_limit_mb((budget/16).clamp(1,32)) and one worker. :452 subsequently uses OptimizeAction::Index(Default::default()). The pinned LanceDB b1b080b97c3edd2fd9f2aae8a3b71ff19487b1f8 table/optimize.rs:244 forwards this to optimize_indices; :110 invokes the dataset update. Lance-index 13.0.0 tokenizer.rs:207 and :219 skip serialization of memory_limit_mb and num_workers. Loading stored tokenizer parameters therefore cannot retain those creation-only values. inverted/index/inverted_index.rs:966 updates through to_builder, whose :83/:113 path copies the loaded params into the existing-index builder. builder.rs:51/:58 lazily reads the two environment variables, and :83/:91 resolves workers and per-worker bytes. The new settings reach the actual default update path, including reopened indexes, before these lazy values can initialize. The cached lance-index crate checksum matches Cargo.lock (21b5e0ccd1b4bffdccbb3b5c989e62eb545587d84b0785da50eda5a4d87d0a5d); all three inspected dependency files match that archive.

MALLOC_ARENA_MAX=2 addresses the observed glibc retention under the recorded environment, not all allocators or all memory. docs/memory-resources.md:16–31 accurately states one worker/32 MiB, retained settings on reload, inheritance, explicit glibc tunable precedence and custom-allocator limitations. The fixed 32 MiB update buffer also applies below the required 512 MiB target; those compatible lower targets have no validated operating-envelope claim. Buffer size, allocator arenas, kernel charged bytes and total RSS are distinct. No universal RSS cap or continuous-peak guarantee follows from this leaf.

Regression and PID publication evidence

The new public regression at tests/support/daemon_resources.rs:5 executes three inherited-environment cases: absent, larger values, and already-correct values. It starts the real CLI through Daemon::command/start_command (tests/daemon.rs:231/:262), checks status PID against the spawned Child, checks all three procfs environment entries plus GLIBC_TUNABLES, and performs normal stop/wait. The fixture uses private unique temporary roots and its own unavailable session bus. The old code compiled and failed the MALLOC_ARENA_MAX assertion: regression.zip's native-startup-red-r1.log records one selected failure. Comparing its complete saved test source with the current file shows only line layout and one trailing array comma. The separate focused-r1 failure is the formatter comparator rejecting that comma before tests, not a product RED. The later archive records 1+26+5 passing Rust tests and debug detached smoke, distinct from installed release acceptance.

scripts/check_daemon_command.py:101 now supplies larger inherited values and :112 verifies the three corrected values. All prior checks remain: exact argv census and executable/PID/start identity (:109), 0600/0700 modes (:117), no owned TCP sockets (:126), actual alternate kernel UID and private/peer denial (:130 onward), normal stop/socket removal/unavailable status (:180 onward), and exact-owned cleanup (:193 onward). No assertion or deadline was removed.

The original 6435c3e full canonical gate is still FAIL: exit 101, 172 daemon passes, one failure, nine ignores. The raw failure is ParseIntError { kind: Empty } at tests/support/daemon_codex.rs:1347, before acquiring the corresponding process handle. It does not identify a PID filename or cancellation mode. The one isolated pass is diagnostic only and did not waive this gate; the failed full gate was the reason for repair before canonical r2.

Both the producer and consumer are byte-identical on merge-base and 6435c3e. The archived source-derived probes execute each actual producer statement sequence with observation between file-open and write: both old sites expose an empty ready file, and both repaired sites hide readiness until complete PID bytes exist. This demonstrates the publication window, not the exact historical scheduling trigger. The first tiny /tmp probe and the paired canonical-SSD RED/GREEN roots are recorded removed. No probe was rerun here.

At tests/fixtures/codex/0.164.0/runner_host.py:44–45 and :189–190, write_text closes child.pid.tmp before replace publishes child.pid in the same directory. tests/support/daemon_codex.rs:58 injects a completed runner.pid write before protocol startup. In delegate_cancel, runner_host.py:185 writes parent.pid before requesting the child; the child then writes runner.pid before its own publication. The two sites are alternative fixture scenarios, and unique Daemon roots avoid competing publishers. The consumer still waits on child.pid at daemon_codex.rs:1332, then reads all required PID files and obtains pidfds. Its 10-second readiness/settlement and three-second disappearance bounds, terminal state/error/run-trace assertions, runner-work cleanup and no-replay assertions through :1435 are unchanged. The earlier repaired 32-pass receipt and this review's fresh 32 consult passes remain separate evidence.

Archive and measurement audit

All five ZIP byte sizes/digests, exact member sets (no duplicates), decompressed member lengths/SHA-256 values and JSON/JSONL parsing passed. Shared references were resolved against the actual scale-comparison archive and checked at both archive and member level. No binary/corpus dump or archived driver execution was used.

| Archive | Members | Shared references |
| --- | ---: | ---: |
| native-memory/controls.zip | 126 | 15 |
| native-memory/regression.zip | 35 | 0 |
| native-memory/production-default.zip | 50 | 5 |
| native-prune/final-publication.zip | 41 | 0 |
| native-memory/pid-publication.zip | 31 | 0 |

The 20 references preserve identical policy, manifest, binding, acknowledgements and oracle bytes. They describe 8,192 sources, 35,875,218 unique UTF-8 bytes and 8,322 expected claims. Controllers' actual assertions were inspected: source/key hashes and UTF-8 coverage during seeding, current active state/revision/claim hash/delegated authority/no approval/project scope, and expected ID/revision plus scope for every lexical witness. Complete cases have exactly 8,322 successful memory-show commands in oracle order, eight independently rechecked search outputs and index watermark 16,520. Command logs retain output hashes, not every full current-memory response body; driver assertions and successful terminal execution establish those current-claim checks. The eight full search terminal outputs can be independently rechecked. This is not a complete native-index-body oracle, vector coverage or fresh replay of the deleted stores.

Raw resource rows were independently aggregated, preserving unknowns. Every row retained effective original 512/640/2048 MiB cgroups and their actual high/max readbacks.

| Run | Rows / valid RSS | RSS max bytes | Nearest-rank P99 bytes | Result |
| --- | ---: | ---: | ---: | --- |
| FTS1/32 only | 94 / 93 | 692056064 | not acceptance | failed at 3622/8322 |
| FTS1/32 + arena2 | 197 / 197 | 406609920 | 405094400 | bounded complete |
| FTS1/1 + arena2 | 753 / 753 | 282107904 | 277876736 | bounded complete |
| 92031ea production defaults | 197 / 197 | 414588928 | 411643904 | bounded complete |
| b83cf3d final binary | 198 / 198 | 418988032 | 413306880 | bounded complete |

FTS-only row 50 remains RESOURCE_MEASUREMENT_UNAVAILABLE, not zero; 46 valid rows exceed 640 MiB. The two initial null-assuming aggregations remain setup failures. That run reached no complete current/partition verification. Its inherited arena setting was not recorded, so the subsequent arena result is not a strict causal allocator pair. The controls use the same recorded daemon 3ca6fe59 and seeder f009f18a. The successful controls' index times are 203.635 and 795.438 seconds; sequential single observations without cache eviction/repetition do not establish a causal performance interval.

The successful native-default controller contains explicit assertions against inherited preload/allocator/FTS overrides, supplies no external daemon overrides, and reads back exact product values after startup with matching PID/start ticks. The earlier release artifact is 93c7abb6f2e1fbf2d90d631e66768e65c56bf4e82b8c1ba3111108d481d41082 at 92031ea. Its build command includes --bin and --example and differs from the canonical command. The exact artifact-difference cause remains unclassified; there is no reproducible-build claim.

The additional final-binary build/verified/cleanup-admission/cleanup and dotted admission/terminal/collected receipts were located by their actual names and checked. Their daemon is the exact canonical/install binary 0a5436f0dc22a2858f3f083be56be55a278b78f31315d76888ebd309c5425fc1 at b83cf3d/e82093f. Seeder f009f18a372add120f4c8994bb80844d6301f9eba8b2f3af8afca747c365ff3c remains built at 92031ea; relevant production sources equal HEAD. It was not relabelled as rebuilt here. All 39 retained metadata hashes, terminal log hash, driver/build/admission identities and five shared input files match. The same assertions and eight search witnesses pass; final 198 complete samples have zero sampled OOM kills, RSS maximum 418988032, P99 413306880 and kernel charged peak 537362432 bytes. No sampled zero covers unobserved intervals.

Cleanup receipts bind full native-file inventories, process PID/start identities, absent owned cgroups and scoped consumer checks before removal. Independent sums agree: controls 110526464/127340544/140582912 allocated bytes; earlier production 127356928; final binary 127373312 across 543 files. Exact declared data/socket roots are now absent. Historical inventories cannot be rehashed from deleted stores; their archived integrity and pre-removal receipts are the evidence. Known excluded nondumpable unrelated services remain explicitly listed; no universal process-visibility claim or immediate Btrfs space-reclamation inference is made.

The complete prior maintenance R1 FAIL and integrated R2 PASS reports were read, not replaced. The final-publication archive preserves 641/39, Python35/Node7, 61 fresh review passes/three ignores, hosted CI43942780707 and PR70/69 readbacks. Decompressed CI log SHA-256 matches b53b28ea468a60a6183ac091a0023956414857ba313060251efe2ddc6a510e6d; local objects confirm 2987eb1 and merge 63acf39 have the same tree. These are archived publication observations, not fresh remote readbacks. The former missing lease check was repaired on the base; it is not reintroduced. Earlier resource/IPC, installed timeout, incident fixture and apt/DNS failures retain their original dispositions and unknown causality.

Canonical prerequisite and fresh checks

Supplied canonical r2 PASS was complete before this review. Admission, terminal, verified receipt and entire log were examined; identity, clean source and all 19 scoped hashes match. Log SHA-256 is 25c2d7ebbf8ffd0ca948fa4b95c86b9bdc532e78433483386b9e5b6bef24f53f. Its 22 Rust summary blocks total 643 passes/39 intentional ignores; Python35 and Node7 pass. The installed serial daemon block is 173 passes/nine ignores (242.42 seconds), followed by installed lifecycle, private/peer UID and zero-TCP acceptance on the exact final artifact. This was supplied evidence, not a gate rerun or a substitute for source review.

Executable provenance was checked before tests. Initial PATH commands passed through mise and reported Rust1.99.1; unrelated mise cache-write warnings were not test failures. Test invocations put the existing /home/obj/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin first, with cargo/rustc and clippy/fmt binary hashes retained. Existing RUSTUP_HOME, CARGO_HOME, sccache wrapper/socket and canonical TMPDIR were preserved. CARGO_TARGET_DIR and readlink target stayed lexically /ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/target. No global configuration changed.

Each command below ran once. Full combined output and exact exits are in E/mvp024-native-review-r1-final-tests.log.

| Command | Exit | Fresh result |
| --- | ---: | --- |
| cargo test --locked --test daemon resource_tests::native_startup_limits_preserve_pid_and_unrelated_environment -- --exact | 0 | 1 passed, 181 filtered |
| cargo test --locked --test daemon retrieval_tests:: | 0 | 26 passed, 156 filtered |
| cargo test --locked --test cli | 0 | 5 passed |
| python3 scripts/check_daemon_command.py target/release/akasha-otsuge | 1 | alternate UID fixture unavailable at :72, called from :130 |
| cargo clippy --workspace --all-targets --locked -- -D warnings | 0 | clean |
| cargo fmt --all -- --check | 0 | clean |
| git diff --check | 0 | clean |
| cargo test --locked --test daemon codex_tests::consult_ | 0 | 32 passed, 150 filtered |

Total fresh Rust: 64 passed, zero failed, zero ignored. TEST_LOG_SHA256: b4c836f2841113df6e0c4660d65213bff18be8cbe229523b6535d947774bda9f.

ORIGIN: PRE-EXISTING execution prerequisite, non-actionable: the fresh release smoke could not obtain an alternate UID in the managed reviewer environment. another_uid and this assertion are unchanged from base. The traceback establishes that detached start, corrected environment, exact process identity/argv, private modes and no-TCP assertions were reached successfully before :130. Fresh UID denial and the later normal-stop assertions were NOT executed; the finally cleanup ran instead. No smoke retry, selector substitution, permission change or test weakening occurred. The remaining independent checks then ran normally. Supplied canonical installed acceptance supplies those completed checks, but this local smoke remains exit 1, not GREEN. The exact underlying alternate-UID launcher failure was not separately diagnosed.

Remaining acceptance and final custody

ORIGIN: OUT-OF-SCOPE for this partial leaf: full 50 GB corpus and million-vector identity/coverage (including the 37 oversized documents), both required load profiles, 100 clients, full native-index-body oracle, recovery/crash/resource acceptance and final release qualification. docs/plan/todo.md:1203 onward preserves that work; :9 requires partial Refs #65 rather than a closure reference. Claude-native authentication and Daybreak/new red-team work remain deferred; canceled unrelated repositories were not resumed. This review neither publishes nor closes any issue. Historical pending-gate/review sentences in committed evidence are stage snapshots, not a claim that the supplied successor gate is missing.

Postflight before report creation confirmed exact HEAD/tree/base/origin/branch, clean porcelain, no index.lock, unchanged lexical target and release hash, and every scoped working file equal to both its immutable hash and HEAD blob. No newly created akasha-daemon-/akasha-installed- temporary root remains. Structured receipts alongside this report are mvp024-native-review-r1-reviewer-{preflight,instructions,instructions-aliases,gate-provenance,archives,pilot-audit,test-exits,test-exits-remaining,postflight}.json; the immutable parent final-scope JSON supplies the path inventory. Final report bytes are hashed externally and repository custody is checked once more after writing.

Skipped: canonical/benchmark reruns, new adversarial campaigns, installation, publication and unrelated work. Limits: fresh UID smoke unavailable, finite sampling, allocator overrides and full-scale/recovery acceptance remain open.
VERDICT: PASS
