import datetime,hashlib,json,pathlib,subprocess
E=pathlib.Path(__file__).parent;W=pathlib.Path.cwd()
git=lambda *a:subprocess.check_output(['git',*a],text=True).strip()
head=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}');branch=git('branch','--show-current')
assert head=='b83cf3d1022d28961fda2ebe20b42a24c797060c' and branch=='fix/mvp-024-native-memory'
assert not git('status','--porcelain')
base='63acf39d2138bc582ee746b6eefede970fd3f8cc'
assert git('merge-base','origin/main','HEAD')==git('rev-parse','origin/main')==base
gate=json.loads((E/'mvp024-native-canonical-r2-verified.json').read_text())
review=json.loads((E/'mvp024-native-review-r1-final-verified.json').read_text())
uid=json.loads((E/'mvp024-native-review-uid-smoke-r1-result.json').read_text())
assert gate['head']==review['head']==uid['head']==head
assert gate['status']=='PASS' and review['actionable_count']==0 and uid['smoke_exit']==0
assert hashlib.sha256((E/'mvp024-native-review-r1-final.md').read_bytes()).hexdigest()==review['report_sha256']
hooks_path=subprocess.run(['git','config','--get','core.hooksPath'],capture_output=True,text=True)
assert hooks_path.returncode==1 and not hooks_path.stdout
hooks=pathlib.Path(git('rev-parse','--git-path','hooks')).resolve()
active=[p.name for p in hooks.iterdir() if p.is_file() and not p.name.endswith('.sample') and p.stat().st_mode&0o111] if hooks.exists() else []
assert active==[],active
before=git('ls-remote','origin','refs/heads/main','refs/heads/'+branch)
refs={line.split()[1]:line.split()[0] for line in before.splitlines()}
assert refs.get('refs/heads/main')==base
assert refs.get('refs/heads/'+branch) in [None,head]
r=subprocess.run(['git','push','-u','origin',branch],text=True,capture_output=True)
receipt={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'tree':tree,'base':base,'branch':branch,'normal_push_no_hook_bypass':True,'active_hooks':active,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'remote_before':refs}
if r.returncode==0:
 after=git('ls-remote','origin','refs/heads/main','refs/heads/'+branch)
 refs_after={line.split()[1]:line.split()[0] for line in after.splitlines()}
 receipt['remote_after']=refs_after
 assert refs_after['refs/heads/'+branch]==head
 assert refs_after['refs/heads/main']==base
assert git('rev-parse','HEAD')==head and not git('status','--porcelain')
with (E/'mvp024-native-push-r1.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({k:receipt[k] for k in ['head','tree','branch','exit_code','normal_push_no_hook_bypass']}))
raise SystemExit(r.returncode)
