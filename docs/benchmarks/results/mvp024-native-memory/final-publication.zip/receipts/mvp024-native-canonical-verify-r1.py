import datetime
import hashlib
import json
import os
import pathlib
import re
import subprocess
import sys

E = pathlib.Path(__file__).parent
W = pathlib.Path.cwd()
name, expected_head = sys.argv[1:]
git = lambda *args: subprocess.check_output(['git', *args], text=True).strip()
sha = lambda data: hashlib.sha256(data).hexdigest()
admission = json.loads((E / (name + '.admission.json')).read_text())
terminal = json.loads((E / (name + '.terminal.json')).read_text())
log = (E / (name + '.log')).read_bytes()
assert terminal['exit_code'] == 0 and terminal['head'] == admission['head'] == expected_head
assert admission['command'] == ['just', 'check'] and admission['dirty_diff_sha256'] == sha(b'')
assert admission['untracked'] == [] and not git('status', '--porcelain')
assert git('rev-parse', 'HEAD') == expected_head and git('rev-parse', 'HEAD^{tree}') == admission['tree']
assert sha(log) == terminal['log_sha256']
text = log.decode()
summaries = re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;.*finished in ([\d.]+)s$', text, re.M)
passed = sum(int(row[0]) for row in summaries)
ignored = sum(int(row[2]) for row in summaries)
assert (passed, ignored, len(summaries)) == (643, 39, 22), (passed, ignored, summaries)
assert all(int(row[1]) == 0 for row in summaries)
assert re.search(r'Ran 35 tests in ', text) and re.search(r'^# pass 7$', text, re.M)
assert 'error:' not in text and 'test result: FAILED' not in text
installed = [json.loads(line) for line in text.splitlines() if line.startswith('{') and '"installed": true' in line]
assert len(installed) == 1
installed = installed[0]
assert all(installed[k] == 'passed' for k in ['lifecycle', 'private_uid_denial', 'peer_uid_denial'])
assert installed['tcp_sockets'] == 0 and installed['binary_sha256'] == sha((W / 'target/release/akasha-otsuge').read_bytes())
assert tuple(map(int, summaries[-1][:3])) == (173, 0, 9)
base = git('merge-base', 'origin/main', 'HEAD')
assert base == '63acf39d2138bc582ee746b6eefede970fd3f8cc'
paths = git('diff', '--name-only', 'origin/main...HEAD').splitlines()
source = {}
for name_in_tree in paths:
    data = (W / name_in_tree).read_bytes()
    assert data == subprocess.check_output(['git', 'show', expected_head + ':' + name_in_tree])
    source[name_in_tree] = sha(data)
live = []
for p in pathlib.Path('/proc').iterdir():
    if not p.name.isdigit():
        continue
    try:
        if p.stat().st_uid != os.getuid() or (p / 'comm').read_text().strip() not in {'cargo', 'rustc', 'clippy-driver', 'just'}:
            continue
        fields = (p / 'stat').read_text().rsplit(')', 1)[1].split()
        if fields[0] != 'Z' and pathlib.Path(os.readlink(p / 'cwd')).resolve() == W.resolve():
            live.append({'pid': int(p.name), 'start_ticks': fields[19]})
    except FileNotFoundError:
        continue
assert not live, live
receipt = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'PASS',
           'head': expected_head, 'tree': admission['tree'], 'base': base, 'exit_code': 0,
           'seconds': terminal['seconds'], 'log_sha256': terminal['log_sha256'],
           'rust_passed': passed, 'rust_ignored': ignored, 'rust_result_blocks': len(summaries),
           'python_passed': 35, 'node_passed': 7, 'clippy_fmt': 'PASS', 'capture_example': 'PASS',
           'installed': installed, 'installed_serial_test_s': float(summaries[-1][3]),
           'clean_before_after': True, 'scoped_source_hashes': source,
           'terminal_census': {'live_core_processes': live, 'basis': 'Exact checkout own-UID compiler/gate census; not all helper completeness'},
           'limits': 'Exact candidate gate only. Full issue65 corpus/load/recovery acceptance remains pending.'}
with (E / (name + '-verified.json')).open('x') as out:
    json.dump(receipt, out, indent=2)
    out.write('\n')
print(json.dumps({k: v for k, v in receipt.items() if k != 'scoped_source_hashes'}))
