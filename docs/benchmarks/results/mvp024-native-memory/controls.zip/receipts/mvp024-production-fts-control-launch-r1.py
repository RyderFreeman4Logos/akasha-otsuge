import pathlib,sys,subprocess,json,hashlib
W=pathlib.Path.cwd();E=pathlib.Path(__file__).parent
sys.path.insert(0,str(W/'spikes/helix'))
from run_case import publish,digest
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='2987eb1e744d2a2c55e642df3457b6156c8e2a88'
assert not subprocess.check_output(['git','status','--porcelain'])
gate=json.loads((E/'mvp024-index-prune-canonical-r6-verified.json').read_text())
review=json.loads((E/'mvp024-index-prune-review-r2-integrated-verified.json').read_text())
assert gate['head']==review['head']==head and gate['status']==review['status']=='PASS'
assert not (W/'.spike-work/mvp024-production-fts-control-r1').exists()
driver=E/'mvp024-production-fts-control-r1.py'
assert digest(driver)=='cb692526bee1811b216c4ed4b1f1c561c55294538e50771d1e99639c6ca17e2a'
binary=W/'target/release/akasha-otsuge'
assert digest(binary)==gate['installed']['binary_sha256']
print('Building the production corpus seeder at the frozen integrated source',flush=True)
subprocess.run(['cargo','build','--release','--locked','--offline','--example','corpus_seed'],check=True)
assert not subprocess.check_output(['git','status','--porcelain'])
receipt={'head':head,'tree':gate['tree'],'daemon_sha256':digest(binary),'seeder_sha256':digest(W/'target/release/examples/corpus_seed'),'seeder_source_sha256':digest(W/'examples/corpus_seed.rs'),'driver_sha256':digest(driver),'compile_command':['cargo','build','--release','--locked','--offline','--example','corpus_seed'],'purpose':'Bounded original-resource FTS1/32 control; no full scale or paired same-binary improvement claim'}
publish(E/'mvp024-production-fts-control-r1-build.json',receipt)
print(json.dumps(receipt),flush=True)
raise SystemExit(subprocess.run([str(W/'.spike-work/data-env/bin/python'),str(driver)]).returncode)
