import pathlib,json,hashlib,datetime,os,stat,shutil
E=pathlib.Path("/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/.git/akasha-evidence");root=pathlib.Path('.spike-work/mvp024-production-fts-control-r1').resolve(strict=True)
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
state=json.loads((root/'state.json').read_text());ad=json.loads((root/'admission.json').read_text());terminal=json.loads((E/'mvp024-production-fts-control-launch-r1.terminal.json').read_text())
assert terminal['exit_code']==1 and state['phase']=='failed' and state['completed_units']==['seed'] and state['processes_terminal']=={'daemon':0,'seed':0}
assert sha(E/'mvp024-production-fts-control-launch-r1.log')==terminal['log_sha256']
assert (state['seed_records'],state['memories'],state['unique_utf8_bytes'])==(8192,8322,35875218)
baseline=root.parent/'mvp024-production-scale-pilot-r2'
for name in ['pilot.toml','input-manifest.json','binding.json','oracle.json','acks.jsonl']:assert (root/name).read_bytes()==(baseline/name).read_bytes(),name
rows=[json.loads(x) for x in (root/'metrics.jsonl').read_text().splitlines()];assert len(rows)==94
rss=[];missing=[]
for n,row in enumerate(rows):
 c=row['resources']['cgroup'];assert c['available'] and c['complete'] and c['enforced'] and c['effective']=={'daemon_memory_target_mib':512,'daemon_peak_limit_mib':640,'service_total_budget_mib':2048}
 m=row['resources']['measurement'];group=m.get('daemon_group')
 if group is None:
  assert not m['complete'] and m['error']=='RESOURCE_MEASUREMENT_UNAVAILABLE';missing.append({'index':n,'elapsed_s':row['elapsed_s'],'error':m['error']});continue
 rss.append(group['rss_bytes'])
assert len(rss)==93 and len(missing)==1
identities=[json.loads((root/n).read_text()) for n in ['seed-process.json','daemon-process.json']]+[ad['process'],json.loads((E/'mvp024-production-fts-control-launch-r1.launch.json').read_text())['process']]
for ident in identities:
 p=pathlib.Path('/proc')/str(ident['pid'])/'stat'
 if p.exists():assert p.read_text().rsplit(')',1)[1].split()[19]!=str(ident['start_ticks']),ident
initial=json.loads((root/'initial-status.json').read_text());cgroup=pathlib.Path(initial['resources']['cgroup']['path']);assert not cgroup.exists(),cgroup
data=root/'data';socket=pathlib.Path(ad['socket_root']);tmp=pathlib.Path('/mnt/ssd/mirror-rootfs/home/obj/tmp/a15-cache-s0s9a8n9')
assert data.resolve()==data and data.is_dir() and socket.parent==tmp and socket.name=='a24p-uaemhbms' and socket.is_dir() and not socket.is_symlink()
files={}
for p in sorted(data.rglob('*')):
 assert not p.is_symlink(),p
 if p.is_file():
  s=p.stat();assert s.st_uid==os.getuid() and stat.S_ISREG(s.st_mode)
  files[str(p.relative_to(data))]={'bytes':s.st_size,'allocated_bytes':s.st_blocks*512,'sha256':sha(p)}
metadata={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in root.iterdir() if p.is_file()}
verified={'utc':now(),'classification':'FAILED_STATUS_IPC_UNDER_ORIGINAL_LIMITS_FTS_1_32_INSUFFICIENT','head':ad['head'],'daemon_sha256':ad['daemon_sha256'],'seeder_sha256':ad['seeder_sha256'],'progress':json.loads((root/'progress.json').read_text()),'state':state,'metadata':metadata,'sample_count':94,'valid_rss_samples':93,'unavailable_measurements':missing,'max_sampled_rss_bytes':max(rss),'rss_over512_count':sum(x>512*1024**2 for x in rss),'rss_over640_count':sum(x>640*1024**2 for x in rss),'max_sampled_kernel_bytes':max(x['resources']['cgroup']['daemon_group']['peak_bytes'] for x in rows),'max_sampled_oom_kills':max(x['resources']['cgroup']['daemon_group']['oom_kills'] for x in rows),'last_memory_breakdown':rows[-1]['diagnostic_memory_breakdown'],'native_files':files,'native_allocated_bytes':sum(x['allocated_bytes'] for x in files.values()),'owned_process_identities_absent':identities,'cgroup_absent':str(cgroup),'aggregation_notes':'Two initial read-only summaries raised TypeError by assuming daemon_group was never null. Raw row50 explicitly records RESOURCE_MEASUREMENT_UNAVAILABLE; final aggregation retains it as unavailable, not zero.','limits':'Indexing and final output oracle incomplete; previous code/allocator control differ, so no paired completed performance claim or proven historical IPC cause.'}
receipt=E/'mvp024-production-fts-control-r1-verified.json'
with receipt.open('x') as f:json.dump(verified,f,indent=2);f.write('\n')
old=json.loads((E/'mvp024-production-mmap-control-r1-cleanup-admission.json').read_text())
known={(x['pid'],str(x['start_ticks']),x['comm']) for x in old['excluded_unrelated_services']}
references=[];excluded=[];unknown=[];inspected=0
roots=[data,socket]
def matches(value):
 return any(value==str(r) or value.startswith(str(r)+'/') for r in roots)
for p in pathlib.Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:
  if p.stat().st_uid!=os.getuid():continue
  s=(p/'stat').read_text().rsplit(')',1)[1].split();comm=(p/'comm').read_text().strip();identity=(int(p.name),s[19],comm)
  if s[0]=='Z':continue
  inspected+=1
  links=[p/'cwd',p/'exe',*list((p/'fd').iterdir())]
  for link in links:
   try:
    value=os.readlink(link)
    if matches(value):references.append({'pid':int(p.name),'kind':link.name,'path':value})
   except FileNotFoundError:pass
 except FileNotFoundError:pass
 except PermissionError:
  if identity in known:excluded.append({'pid':identity[0],'start_ticks':identity[1],'comm':identity[2],'reason':'Exact previously classified unrelated nondumpable service identity; no new exclusion inferred'})
  else:unknown.append({'pid':int(p.name)})
assert not references and not unknown,{'references':references,'unknown':unknown}
for rel,expected in files.items():
 p=data/rel;assert p.stat().st_size==expected['bytes'] and sha(p)==expected['sha256']
admit={'utc':now(),'roots':[str(x) for x in roots],'verified_receipt_sha256':sha(receipt),'owned_processes_and_cgroup_absent':True,'native_files_reverified':len(files),'native_allocated_bytes':verified['native_allocated_bytes'],'own_uid_processes_inspected':inspected,'accessible_references':references,'excluded_unrelated_services':excluded,'free_before_bytes':shutil.disk_usage('/mnt/ssd').free,'scope':'Only exact failed FTS control disposable native data and owned socket directory; preserve every metadata/source/corpus/cache file.'}
with (E/'mvp024-production-fts-control-r1-cleanup-admission.json').open('x') as f:json.dump(admit,f,indent=2);f.write('\n')
for p in roots:shutil.rmtree(p)
assert all(not p.exists() for p in roots)
done={**admit,'utc':now(),'removed':True,'free_after_bytes':shutil.disk_usage('/mnt/ssd').free,'free_delta_is_not_exact_reclaim_on_btrfs':True}
with (E/'mvp024-production-fts-control-r1-cleanup.json').open('x') as f:json.dump(done,f,indent=2);f.write('\n')
print(json.dumps({'classification':verified['classification'],'progress':verified['progress']['completed'],'total':8322,'valid_rss_samples':93,'unavailable_measurements':missing,'max_rss':max(rss),'over512':verified['rss_over512_count'],'over640':verified['rss_over640_count'],'kernel_peak':verified['max_sampled_kernel_bytes'],'sampled_oom':verified['max_sampled_oom_kills'],'native_files':len(files),'native_allocated_bytes':verified['native_allocated_bytes'],'cleanup':True,'excluded_known_services':len(excluded)}))
