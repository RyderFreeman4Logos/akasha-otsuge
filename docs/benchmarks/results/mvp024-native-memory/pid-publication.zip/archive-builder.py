import hashlib
import json
import pathlib
import subprocess
import zipfile

E = pathlib.Path(__file__).parent
W = pathlib.Path('/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025')
base = '6435c3e8365ea7f4ca1ca6445a7c1077279d83ba'
members = {'archive-builder.py': pathlib.Path(__file__).read_bytes()}
for path in sorted([*E.glob('mvp024-codex-pid-*'), *E.glob('mvp024-native-canonical-r1.*'), *E.glob('mvp024-native-canonical-failure-selector-r1.*')]):
    assert path.is_file() and not path.is_symlink()
    members['receipts/' + path.name] = path.read_bytes()
paths = ['tests/fixtures/codex/0.164.0/runner_host.py']
for name in paths:
    members['base/' + name] = subprocess.check_output(['git', '-C', str(W), 'show', base + ':' + name])
    members['candidate/' + name] = (W / name).read_bytes()
identity = {'base': base, 'candidate_source_sha256': {
    name: hashlib.sha256((W / name).read_bytes()).hexdigest() for name in paths},
    'scope': 'Canonical gate empty-PID failure, one isolated pass without waiver, unchanged-base producer provenance, deterministic source-derived publication RED/GREEN and atomic child PID fixture repair. All 32 native consult focused tests, full changed-Python syntax vector, Clippy and formatting pass. Exact successor canonical gate and independent review remain pending.'}
members['identity.json'] = (json.dumps(identity, indent=2) + '\n').encode()
path = E / 'mvp024-native-pid-fix-r1.zip'
with zipfile.ZipFile(path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
    for name, data in members.items():
        info = zipfile.ZipInfo(name, (2026, 11, 16, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        out.writestr(info, data)
manifest = {**identity, 'zip_bytes': path.stat().st_size,
            'zip_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'members': {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                        for name, data in members.items()}}
with zipfile.ZipFile(path) as saved:
    assert len(saved.namelist()) == len(set(saved.namelist())) == len(members)
    for name, expected in manifest['members'].items():
        data = saved.read(name)
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
with (E / 'mvp024-native-pid-fix-r1-manifest.json').open('x') as out:
    json.dump(manifest, out, indent=2)
    out.write('\n')
dest = W / 'docs/benchmarks/results/mvp024-native-memory'
for source, name in [(path, 'pid-publication.zip'), (E / 'mvp024-native-pid-fix-r1-manifest.json', 'pid-publication-manifest.json')]:
    with (dest / name).open('xb') as out:
        out.write(source.read_bytes())
    assert (dest / name).read_bytes() == source.read_bytes()
print(json.dumps({'members': len(members), 'bytes': manifest['zip_bytes'], 'sha256': manifest['zip_sha256']}))
