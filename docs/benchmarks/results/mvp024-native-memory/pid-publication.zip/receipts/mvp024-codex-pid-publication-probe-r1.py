import ast
import hashlib
import json
import os
import pathlib
import sys
import tempfile
import types
from unittest.mock import patch

source = pathlib.Path('tests/fixtures/codex/0.164.0/runner_host.py')
raw = source.read_bytes()
tree = ast.parse(raw)
sequences = []
for node in ast.walk(tree):
    for _, statements in ast.iter_fields(node):
        if not isinstance(statements, list):
            continue
        for index, statement in enumerate(statements):
            if not isinstance(statement, ast.Expr) or not isinstance(statement.value, ast.Call):
                continue
            call = statement.value
            if not isinstance(call.func, ast.Attribute) or call.func.attr != 'write_text':
                continue
            destination = call.func.value
            if not isinstance(destination, ast.BinOp) or not isinstance(destination.right, ast.Constant):
                continue
            name = destination.right.value
            if name in ('child.pid', 'child.pid.tmp'):
                sequence = [statement] if name == 'child.pid' else statements[index:index + 2]
                sequences.append(sequence)
assert len(sequences) == 2, 'fixture producer discovery failed before observation'
results = []
for sequence in sequences:
    with tempfile.TemporaryDirectory(prefix='akasha-pid-publication-') as temporary:
        root = pathlib.Path(temporary)
        observations = []

        def write_during_observation(path, text, **kwargs):
            with path.open('w', **kwargs) as out:
                marker = root / 'child.pid'
                observations.append({'ready_exists': marker.exists(),
                                     'ready_bytes': marker.read_text() if marker.exists() else None})
                return out.write(text)

        with patch.object(pathlib.Path, 'write_text', write_during_observation):
            exec(compile(ast.Module(body=sequence, type_ignores=[]), str(source), 'exec'),
                 {'root': root, 'child': types.SimpleNamespace(pid=os.getpid())})
        assert (root / 'child.pid').read_text() == str(os.getpid())
        assert len(observations) == 1
        results.append({'producer_line': sequence[0].lineno, 'during_open_before_write': observations[0],
                        'complete_pid_after_publication': True,
                        'producer_ast_sha256': hashlib.sha256(ast.dump(ast.Module(body=sequence, type_ignores=[])).encode()).hexdigest(),
                        'temporary_root': temporary})
    assert not root.exists()
passed = all(not row['during_open_before_write']['ready_exists'] for row in results)
receipt = {'source': str(source), 'source_sha256': hashlib.sha256(raw).hexdigest(),
           'scope': 'Source-derived actual PID producer statements with a deterministic read between file open and write. Not a full native-protocol execution or exact historical schedule claim.',
           'results': results, 'passed': passed, 'owned_temporary_roots_removed': True}
with (pathlib.Path(__file__).parent / ('mvp024-codex-pid-publication-' + sys.argv[1] + '.json')).open('x') as out:
    json.dump(receipt, out, indent=2)
    out.write('\n')
print(json.dumps(receipt))
raise SystemExit(0 if passed else 1)
