import pathlib,subprocess,json,hashlib,datetime,sys,time
E=pathlib.Path(__file__).parent;W=pathlib.Path.cwd()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head=='92031ea46c6dcb33e4810954aba00b91c5d3357d'
assert not subprocess.check_output(['git','status','--porcelain'])
command=['cargo','build','--release','--locked','--offline','--bin','akasha-otsuge','--example','corpus_seed']
t=time.monotonic();result=subprocess.run(command)
d={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),'command':command,'build_exit':result.returncode,'build_seconds':time.monotonic()-t,'driver_sha256':hashlib.sha256((E/'mvp024-production-native-default-r1.py').read_bytes()).hexdigest(),'purpose':'Committed production startup defaults without external native tuning; unchanged real corpus and resource limits.'}
if result.returncode==0:
 for key,path in [('daemon_sha256',W/'target/release/akasha-otsuge'),('seeder_sha256',W/'target/release/examples/corpus_seed'),('seeder_source_sha256',W/'examples/corpus_seed.rs')]:
  with path.open('rb') as f:d[key]=hashlib.file_digest(f,'sha256').hexdigest()
with (E/'mvp024-production-native-default-r1-build.json').open('x') as f:json.dump(d,f,indent=2);f.write('\n')
if result.returncode:raise SystemExit(result.returncode)
print(json.dumps(d),flush=True)
raise SystemExit(subprocess.call([str(W/'.spike-work/data-env/bin/python'),str(E/'mvp024-production-native-default-r1.py')]))
