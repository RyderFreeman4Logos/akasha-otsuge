import hashlib
import json
import pathlib
import subprocess
import zipfile

E = pathlib.Path(__file__).parent
W = pathlib.Path('/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025')
head = '92031ea46c6dcb33e4810954aba00b91c5d3357d'
tree = subprocess.check_output(['git', '-C', str(W), 'rev-parse', head + '^{tree}'], text=True).strip()
members, references = {}, {}
shared_archive = W / 'docs/benchmarks/results/mvp024-native-prune/scale-comparison.zip'
shared_manifest = json.loads(shared_archive.with_name('scale-comparison-manifest.json').read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
assert sha(shared_archive.read_bytes()) == shared_manifest['zip_sha256']
shared = ('input-manifest.json', 'pilot.toml', 'binding.json', 'oracle.json', 'acks.jsonl')
names = ('mvp024-production-native-default-r1',)
for name in names:
    root = W / '.spike-work' / name
    assert not (root / 'data').exists()
    verified = json.loads((E / (name + '-verified.json')).read_text())
    assert verified['head'] == head
    cleanup = json.loads((E / (name + '-cleanup.json')).read_text())
    assert cleanup['removed'] and all(not pathlib.Path(p).exists() for p in cleanup['roots'])
    for path in sorted(root.iterdir()):
        assert path.is_file() and not path.is_symlink()
        data = path.read_bytes()
        expected = verified['metadata'][path.name]
        assert len(data) == expected['bytes'] and sha(data) == expected['sha256']
        if path.name in shared:
            member = 'shared/' + path.name
            assert expected == shared_manifest['members'][member]
            with zipfile.ZipFile(shared_archive) as prior:
                assert data == prior.read(member)
            references[name + '/' + path.name] = {
                'archive': '../mvp024-native-prune/scale-comparison.zip',
                'archive_sha256': shared_manifest['zip_sha256'], 'member': member, **expected}
        else:
            members[name + '/' + path.name] = data
    for path in sorted(E.glob(name + '*')):
        assert path.is_file() and not path.is_symlink()
        members['receipts/' + path.name] = path.read_bytes()
identity = {'head': head, 'tree': tree, 'cases': list(names),
            'scope': 'Committed product default startup without external native overrides. Complete bounded 8192-source pilot under original limits and output oracles; full corpus/concurrency/vector/recovery acceptance pending.',
            'cleanup': 'All exact disposable databases and sockets removed after process/consumer checks; original source shards and shared oracles are not duplicated.'}
members['identity.json'] = (json.dumps(identity, indent=2) + '\n').encode()
members['shared-input-references.json'] = (json.dumps(references, indent=2) + '\n').encode()
members['archive-builder.py'] = pathlib.Path(__file__).read_bytes()
path = E / 'mvp024-native-default-r1.zip'
with zipfile.ZipFile(path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
    for name, data in members.items():
        assert not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts
        info = zipfile.ZipInfo(name, (2026, 11, 16, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        out.writestr(info, data)
manifest = {**identity, 'zip_sha256': sha(path.read_bytes()), 'zip_bytes': path.stat().st_size,
            'members': {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in members.items()}}
with zipfile.ZipFile(path) as saved:
    assert len(saved.namelist()) == len(set(saved.namelist())) == len(members)
    for name, expected in manifest['members'].items():
        data = saved.read(name)
        assert len(data) == expected['bytes'] and sha(data) == expected['sha256']
with (E / 'mvp024-native-default-r1-manifest.json').open('x') as out:
    json.dump(manifest, out, indent=2)
    out.write('\n')
print(json.dumps({'members': len(members), 'references': len(references), 'bytes': manifest['zip_bytes'], 'sha256': manifest['zip_sha256']}))
