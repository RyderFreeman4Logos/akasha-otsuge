import hashlib
import json
import pathlib
import subprocess
import zipfile

E = pathlib.Path(__file__).parent
W = pathlib.Path('/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025')
base = '63acf39d2138bc582ee746b6eefede970fd3f8cc'
members = {'archive-builder.py': pathlib.Path(__file__).read_bytes()}
for path in sorted(E.glob('mvp024-native-startup-*')):
    assert path.is_file() and not path.is_symlink()
    members['receipts/' + path.name] = path.read_bytes()
paths = ['src/main.rs', 'tests/support/daemon_resources.rs', 'scripts/check_daemon_command.py']
for name in paths:
    members['base/' + name] = subprocess.check_output(['git', '-C', str(W), 'show', base + ':' + name])
    members['candidate/' + name] = (W / name).read_bytes()
identity = {'base': base, 'candidate_source_sha256': {
    name: hashlib.sha256((W / name).read_bytes()).hexdigest() for name in paths},
    'scope': 'Real foreground startup RED, formatter-comparator setup failure, same-assertion GREEN and 32 focused tests plus actual detached lifecycle/UID/TCP, Clippy and formatting. Canonical gate and independent review pending.'}
members['identity.json'] = (json.dumps(identity, indent=2) + '\n').encode()
path = E / 'mvp024-native-regression-r1.zip'
with zipfile.ZipFile(path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
    for name, data in members.items():
        info = zipfile.ZipInfo(name, (2026, 11, 16, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        out.writestr(info, data)
manifest = {**identity, 'zip_bytes': path.stat().st_size,
            'zip_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'members': {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                        for name, data in members.items()}}
with zipfile.ZipFile(path) as saved:
    assert len(saved.namelist()) == len(set(saved.namelist())) == len(members)
    for name, expected in manifest['members'].items():
        data = saved.read(name)
        assert len(data) == expected['bytes'] and hashlib.sha256(data).hexdigest() == expected['sha256']
with (E / 'mvp024-native-regression-r1-manifest.json').open('x') as out:
    json.dump(manifest, out, indent=2)
    out.write('\n')
dest = W / 'docs/benchmarks/results/mvp024-native-memory'
for source, name in [(path, 'regression.zip'), (E / 'mvp024-native-regression-r1-manifest.json', 'regression-manifest.json')]:
    with (dest / name).open('xb') as out:
        out.write(source.read_bytes())
    assert (dest / name).read_bytes() == source.read_bytes()
print(json.dumps({'members': len(members), 'bytes': manifest['zip_bytes'], 'sha256': manifest['zip_sha256']}))
