import subprocess,json,pathlib,hashlib,time
E=pathlib.Path(__file__).parent
p=pathlib.Path('tests/support/daemon_resources.rs');before=p.read_text()
subprocess.run(['cargo','fmt','--all'],check=True)
after=p.read_text();assert ''.join(before.split())==''.join(after.split()), 'formatter changed regression tokens'
commands=[
 ['cargo','test','--locked','--test','daemon','resource_tests::native_startup_limits_preserve_pid_and_unrelated_environment','--','--exact'],
 ['cargo','test','--locked','--test','daemon','retrieval_tests::'],
 ['cargo','test','--locked','--test','cli'],
 ['python3','scripts/check_daemon_command.py','target/debug/akasha-otsuge'],
 ['cargo','clippy','--workspace','--all-targets','--locked','--','-D','warnings'],
 ['cargo','fmt','--all','--','--check'],
 ['git','diff','--check'],
]
results=[]
for command in commands:
 print('RUN '+json.dumps(command),flush=True);t=time.monotonic();r=subprocess.run(command);results.append({'argv':command,'exit_code':r.returncode,'seconds':time.monotonic()-t})
 (E/'mvp024-native-startup-focused-r2-results.json').write_text(json.dumps(results,indent=2)+'\n')
 if r.returncode:raise SystemExit(r.returncode)
print(json.dumps({'all_focused_commands_passed':True,'regression_format_only':True}),flush=True)
