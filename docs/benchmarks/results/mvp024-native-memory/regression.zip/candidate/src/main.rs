use std::io::{self, Write};
use std::path::PathBuf;
use std::process::ExitCode;

use akasha_otsuge::config::{self, Paths};
use akasha_otsuge::ipc::{self, Command, Error, Request, Result};
mod outcome_command;

const HELP: &str = "akasha-otsuge — local, traceable cross-agent memory

Usage: akasha-otsuge [--config FILE] [--profile NAME] [--socket PATH] COMMAND

Commands:
  daemon run                 Run the local daemon in the foreground
  daemon start               Start a detached local daemon
  daemon status              Show daemon and storage status
  daemon stop                Stop intake and drain the daemon
  doctor --json              Inspect the local daemon
  doctor --host codex|hermes|pi [--binary PATH]
                             Inspect the installed native CLI
  adapter install codex --binary PATH --launcher PATH --state-dir PATH
  adapter uninstall codex --launcher PATH
  adapter install hermes --binary PATH --home PATH
  adapter uninstall hermes --home PATH
  adapter install pi --binary PATH --agent-dir PATH
  adapter uninstall pi --agent-dir PATH
  doctor --host claude [--binary PATH] [--directory DIR]
                             Inspect the installed Claude CLI
  adapter install claude --directory DIR [--binary PATH]
  adapter uninstall claude --directory DIR
  config validate|reload|status
  config show --effective
  capture reconcile|codex|claude BINDING_JSON INPUT_JSONL --idempotency-key ID
  model run PLAN_JSON --idempotency-key ID
  extract run PLAN_JSON --idempotency-key ID
  grill run PLAN_JSON --idempotency-key ID
  grill resume JOB_ID --idempotency-key ID
  index sync --idempotency-key ID
  index rebuild --idempotency-key ID
  index status
  search QUERY --scope JSON_FILE --idempotency-key ID
  show SOURCE_ID --revision COMMIT --range START_BYTE END_BYTE
  job show|cancel ID
  job list [--after KEY]
  consult show JOB_ID
  outcome submit EVENT_JSON
  outcome show EVENT_ID
  outcome run PLAN_JSON -- COMMAND [ARGS]
  outcome log EVENT_ID INDEX [--start BYTE_OFFSET]
  incident list --scope JSON_FILE [--after ID]
  incident show ID [--after EVENT_CURSOR]
  incident update UPDATE_JSON --idempotency-key ID
  editor run FEEDBACK_JSON --idempotency-key ID
  consult receipt JOB_ID [--full]
  consult original JOB_ID SOURCE_INDEX [--start BYTE_OFFSET]
  memory show ID [--at COMMIT]
  memory export ID
  archive export NEW_DIRECTORY
                             Export the stopped store as JSON and original blobs
  archive import ARCHIVE_DIRECTORY
                             Restore history into a fresh offline store
  migrate mempal SNAPSHOT ARCHIVE_DIRECTORY [--previous PRIOR_ARCHIVE]
                             Convert a schema21/fork28 SQLite snapshot to an archive
  memory patch PATCH_JSON --idempotency-key ID
  patch show ID
  memory history ID [--from COMMIT] [--to COMMIT] [--cursor JSON_FILE]
  notify list --scope JSON_FILE [--after ID]
  notify show ID
  notify ack ID --generation NUMBER --idempotency-key ID
  review list --scope JSON_FILE [--after ID]
  review open TARGET_JSON --idempotency-key ID
  review show ID [--at COMMIT]
  review state UPDATE_JSON --idempotency-key ID
  review preview|apply DECISION_JSON --idempotency-key ID
  state show --scope JSON_FILE --at COMMIT [--cursor JSON_FILE]
  state diff FROM TO --scope JSON_FILE [--cursor JSON_FILE]
  receipt show|replay ID
  access grant SCOPE_JSON
  access revoke

Options:
  -h, --help                 Print help
  -V, --version              Print build version
";
const VERSION: &str = concat!("akasha-otsuge ", env!("CARGO_PKG_VERSION"), "\n");

fn output(bytes: &[u8], stderr: bool) -> Result<()> {
    if stderr {
        io::stderr().lock().write_all(bytes)?;
    } else {
        io::stdout().lock().write_all(bytes)?;
    }
    Ok(())
}
fn paths() -> Result<(PathBuf, Paths)> {
    let home = std::env::var_os("HOME")
        .map(PathBuf::from)
        .filter(|p| p.is_absolute())
        .ok_or(Error("INVALID_ARGUMENT"))?;
    let from_env = |key: &str, fallback: PathBuf| {
        std::env::var_os(key)
            .map(PathBuf::from)
            .filter(|p| p.is_absolute())
            .unwrap_or(fallback)
    };
    let config =
        from_env("XDG_CONFIG_HOME", home.join(".config")).join("akasha-otsuge/config.toml");
    let data_dir = from_env("XDG_DATA_HOME", home.join(".local/share")).join("akasha-otsuge");
    let socket_path =
        from_env("XDG_RUNTIME_DIR", home.join(".local/run")).join("akasha-otsuge/service.sock");
    Ok((
        config,
        Paths {
            data_dir,
            socket_path,
        },
    ))
}
async fn execute(args: Vec<std::ffi::OsString>) -> Result<u8> {
    let (mut config_path, defaults) = paths()?;
    let mut explicit_config = false;
    let mut socket = None;
    let mut profile = None;
    let mut index = 0;
    while index < args.len() {
        match args[index].to_str() {
            Some("--config") => {
                config_path = args.get(index + 1).ok_or(Error("INVALID_ARGUMENT"))?.into();
                explicit_config = true;
            }
            Some("--socket") => {
                socket = Some(PathBuf::from(
                    args.get(index + 1).ok_or(Error("INVALID_ARGUMENT"))?,
                ));
            }
            Some("--profile") => {
                profile = Some(
                    args.get(index + 1)
                        .and_then(|s| s.to_str())
                        .ok_or(Error("INVALID_ARGUMENT"))?
                        .to_owned(),
                );
            }
            _ => break,
        }
        index += 2;
    }
    let command: Vec<&str> = args[index..]
        .iter()
        .map(|s| s.to_str().ok_or(Error("INVALID_ARGUMENT")))
        .collect::<Result<_>>()?;
    if let ["doctor", "--host", "codex", flags @ ..] = command.as_slice() {
        let flags = options(flags, &["--binary"])?;
        let binary = std::path::Path::new(flags.get("--binary").copied().unwrap_or("codex"));
        let report = akasha_otsuge::adapter::codex::probe(binary).await?;
        let mut bytes = serde_json::to_vec(&serde_json::json!({"schema_version":1,"data":report,
            "coverage":{"version_supported":report.version.as_deref()==Some("0.164.0"),"supported_versions":["0.164.0"],"native_children":false,"model_auth":"not_checked","hook_trust":"not_checked"}}))?;
        bytes.push(b'\n');
        output(&bytes, false)?;
        return Ok(0);
    }
    if let ["doctor", "--host", "hermes", flags @ ..] = command.as_slice() {
        let flags = options(flags, &["--binary"])?;
        let binary = std::path::Path::new(flags.get("--binary").copied().unwrap_or("hermes"));
        let report = akasha_otsuge::adapter::hermes::probe(binary).await?;
        let supported = akasha_otsuge::adapter::hermes::SUPPORTED_VERSION;
        let mut bytes = serde_json::to_vec(&serde_json::json!({"schema_version":1,"data":report,
            "coverage":{"version_supported":akasha_otsuge::adapter::hermes::supported_version(report.version.as_deref()),"supported_versions":[supported],"qualified_builds":[akasha_otsuge::adapter::hermes::QUALIFIED_BUILD],"native_children":false,"model_auth":"not_checked","hook_trust":"not_checked"}}))?;
        bytes.push(b'\n');
        output(&bytes, false)?;
        return Ok(0);
    }
    if let ["doctor", "--host", "pi", flags @ ..] = command.as_slice() {
        let flags = options(flags, &["--binary"])?;
        let binary = std::path::Path::new(flags.get("--binary").copied().unwrap_or("pi"));
        let report = akasha_otsuge::adapter::pi::probe(binary).await?;
        let supported = akasha_otsuge::adapter::pi::SUPPORTED_VERSION;
        let mut bytes = serde_json::to_vec(&serde_json::json!({"schema_version":1,"data":report,
            "coverage":{"version_supported":report.version.as_deref()==Some(supported),"supported_versions":[supported],"native_children":false,"model_auth":"not_checked","hook_trust":"not_checked"}}))?;
        bytes.push(b'\n');
        output(&bytes, false)?;
        return Ok(0);
    }
    if let ["adapter", "codex-bound", path] = command.as_slice() {
        let response =
            akasha_otsuge::adapter::codex::hooks::bound_response(std::path::Path::new(path))?;
        let mut bytes = serde_json::to_vec(&response)?;
        bytes.push(b'\n');
        output(&bytes, false)?;
        return Ok(0);
    }
    if let ["adapter", "pi-context"] = command.as_slice() {
        use std::io::Read;
        let mut bytes = Vec::new();
        io::stdin().take(16385).read_to_end(&mut bytes)?;
        if bytes.len() > 16384 {
            return Err(Error("MESSAGE_TOO_LARGE"));
        }
        let reply =
            akasha_otsuge::adapter::pi::context_bridge::call(serde_json::from_slice(&bytes)?)
                .await?;
        let mut bytes = serde_json::to_vec(&reply)?;
        bytes.push(b'\n');
        output(&bytes, false)?;
        return Ok(if reply.get("error").is_some() { 1 } else { 0 });
    }
    if let [
        "adapter",
        "uninstall",
        host @ ("codex" | "hermes" | "pi"),
        flags @ ..,
    ] = command.as_slice()
    {
        let key = if *host == "pi" {
            "--agent-dir"
        } else if *host == "hermes" {
            "--home"
        } else {
            "--launcher"
        };
        let flags = options(flags, &[key])?;
        let path = std::path::Path::new(flags.get(key).ok_or(Error("INVALID_ARGUMENT"))?);
        let response = if *host == "pi" {
            akasha_otsuge::adapter::pi::installation::uninstall(path)?
        } else if *host == "hermes" {
            akasha_otsuge::adapter::hermes::installation::uninstall(path)?
        } else {
            akasha_otsuge::adapter::codex::installation::uninstall(path)?
        };
        let mut bytes =
            serde_json::to_vec(&serde_json::json!({"schema_version":1,"data":response}))?;
        bytes.push(b'\n');
        output(&bytes, false)?;
        return Ok(0);
    }
    let install_flags = if let [
        "adapter",
        "install",
        host @ ("codex" | "hermes" | "pi"),
        flags @ ..,
    ] = command.as_slice()
    {
        let keys: &[&str] = if *host == "pi" {
            &["--binary", "--agent-dir"]
        } else if *host == "hermes" {
            &["--binary", "--home"]
        } else {
            &["--binary", "--launcher", "--state-dir"]
        };
        Some((*host, options(flags, keys)?))
    } else {
        None
    };
    let hook_flags = if let ["adapter", "codex-hook", flags @ ..] = command.as_slice() {
        Some(options(flags, &["--binary", "--state-dir"])?)
    } else {
        None
    };
    if command == ["adapter", "claude-read"] {
        let (response, failed) = match akasha_otsuge::adapter::claude::read_bridge().await {
            Ok(response) => (response, false),
            Err(error) => (serde_json::json!({"error":error}), true),
        };
        let mut bytes = serde_json::to_vec(&response)?;
        bytes.push(b'\n');
        output(&bytes, failed)?;
        return Ok(u8::from(failed));
    }
    if let [
        "adapter",
        action @ ("install" | "uninstall"),
        "claude",
        flags @ ..,
    ] = command.as_slice()
    {
        let names: &[&str] = if *action == "install" {
            &["--directory", "--binary"]
        } else {
            &["--directory"]
        };
        let flags = options(flags, names)?;
        let directory =
            std::path::Path::new(flags.get("--directory").ok_or(Error("INVALID_ARGUMENT"))?);
        let data = if *action == "install" {
            let mut bridge_args = Vec::new();
            if explicit_config {
                bridge_args.extend([
                    "--config".into(),
                    std::path::absolute(&config_path)?
                        .to_str()
                        .ok_or(Error("INVALID_ARGUMENT"))?
                        .into(),
                ]);
            }
            if let Some(profile) = &profile {
                bridge_args.extend(["--profile".into(), profile.clone()]);
            }
            if let Some(socket) = &socket {
                bridge_args.extend([
                    "--socket".into(),
                    std::path::absolute(socket)?
                        .to_str()
                        .ok_or(Error("INVALID_ARGUMENT"))?
                        .into(),
                ]);
            }
            akasha_otsuge::adapter::claude::installation::install(
                std::path::Path::new(flags.get("--binary").copied().unwrap_or("claude")),
                directory,
                bridge_args,
            )
            .await?
        } else {
            akasha_otsuge::adapter::claude::installation::uninstall(directory)?
        };
        let mut bytes = serde_json::to_vec(&serde_json::json!({"schema_version":1,"data":data}))?;
        bytes.push(b'\n');
        output(&bytes, false)?;
        return Ok(0);
    }
    if let ["doctor", "--host", "claude", flags @ ..] = command.as_slice() {
        let flags = options(flags, &["--binary", "--directory"])?;
        let binary = std::path::Path::new(flags.get("--binary").copied().unwrap_or("claude"));
        let (response, failed) = match akasha_otsuge::adapter::claude::probe(binary).await {
            Ok(report) => {
                let installation = flags
                    .get("--directory")
                    .map(|path| {
                        akasha_otsuge::adapter::claude::installation::inspect(std::path::Path::new(
                            path,
                        ))
                    })
                    .transpose()?;
                let coverage = serde_json::json!({
                    "version_supported":report.version.as_deref()==Some("2.1.311"),
                    "supported_versions":["2.1.311"],
                    "session_loading":"explicit_plugin_dir",
                    "fork_parent":"unavailable",
                    "model_auth":"not_checked"
                });
                (
                    serde_json::json!({"schema_version":1,"data":report,"installation":installation,"coverage":coverage}),
                    false,
                )
            }
            Err(error) => (serde_json::json!({"schema_version":1,"error":error}), true),
        };
        let mut bytes = serde_json::to_vec(&response)?;
        bytes.push(b'\n');
        output(&bytes, failed)?;
        return Ok(u8::from(failed));
    }
    let operation = match command.as_slice() {
        ["archive", "export" | "import", _] => None,
        ["migrate", "mempal", _, _] | ["migrate", "mempal", _, _, "--previous", _] => None,
        ["adapter", "codex-hook", ..] => None,
        ["adapter", "install", "codex" | "hermes" | "pi", ..] => None,
        [
            "adapter",
            host @ ("codex-call" | "hermes-call" | "pi-call" | "claude-call"),
        ] => {
            use std::io::Read;
            let mut bytes = Vec::new();
            io::stdin().take(16 * 1024 + 1).read_to_end(&mut bytes)?;
            if bytes.len() > 16 * 1024 {
                return Err(Error("MESSAGE_TOO_LARGE"));
            }
            Some(if *host == "claude-call" {
                Command::Claude {
                    event: serde_json::from_slice(&bytes)?,
                }
            } else if *host == "pi-call" {
                Command::Pi {
                    event: serde_json::from_slice(&bytes)?,
                }
            } else if *host == "hermes-call" {
                Command::Hermes {
                    event: serde_json::from_slice(&bytes)?,
                }
            } else {
                Command::Codex {
                    event: serde_json::from_slice(&bytes)?,
                }
            })
        }
        ["daemon", "run" | "start"] => None,
        ["daemon", "status"] => Some(Command::Status),
        ["daemon", "stop"] => Some(Command::Stop),
        ["doctor"] | ["doctor", "--json"] => Some(Command::Doctor),
        ["config", "validate"] => Some(Command::ConfigValidate),
        ["config", "reload"] => Some(Command::ConfigReload),
        ["config", "status"] | ["config", "status", "--json"] => Some(Command::ConfigStatus),
        ["config", "show", "--effective"] => Some(Command::ConfigShow),
        [
            "capture",
            format @ ("reconcile" | "codex" | "claude"),
            binding,
            path,
            "--idempotency-key",
            id,
        ] => {
            let input = config::read_file(std::path::Path::new(binding))?;
            if input.len() > 16 * 1024 {
                return Err(Error("MESSAGE_TOO_LARGE"));
            }
            let mut binding: ipc::CaptureInput = serde_json::from_str(&input)?;
            if *format == "codex" {
                binding.host = Some(config::Host::Codex);
            } else if *format == "claude" {
                binding.host = Some(config::Host::ClaudeCode);
            }
            Some(Command::Reconcile {
                binding,
                path: PathBuf::from(path),
                idempotency_key: (*id).into(),
            })
        }
        ["model", "run", path, "--idempotency-key", id] => {
            let input = config::read_file(std::path::Path::new(path))?;
            if input.len() > akasha_otsuge::provider::MAX_PLAN_BYTES {
                return Err(Error("MESSAGE_TOO_LARGE"));
            }
            Some(Command::ModelRun {
                plan: serde_json::from_str(&input)?,
                idempotency_key: (*id).into(),
            })
        }
        ["grill", "resume", previous, "--idempotency-key", id] => Some(Command::GrillResume {
            job_id: (*previous).into(),
            idempotency_key: (*id).into(),
        }),
        [
            operation @ ("extract" | "grill"),
            "run",
            path,
            "--idempotency-key",
            id,
        ] => {
            let input = config::read_file(std::path::Path::new(path))?;
            if input.len() > 16 * 1024 {
                return Err(Error("MESSAGE_TOO_LARGE"));
            }
            Some(if *operation == "grill" {
                Command::GrillRun {
                    plan: serde_json::from_str(&input)?,
                    idempotency_key: (*id).into(),
                }
            } else {
                Command::ExtractionRun {
                    plan: serde_json::from_str(&input)?,
                    idempotency_key: (*id).into(),
                }
            })
        }
        ["show", id, "--revision", revision, "--range", start, end] => {
            Some(Command::OriginalShow {
                range: akasha_otsuge::domain::OriginalRange {
                    event_id: (*id).into(),
                    revision: number(revision)?,
                    start: usize::try_from(number(start)?)
                        .map_err(|_| Error("INVALID_ARGUMENT"))?,
                    end: usize::try_from(number(end)?).map_err(|_| Error("INVALID_ARGUMENT"))?,
                },
            })
        }
        ["index", "status"] => Some(Command::IndexStatus),
        ["index", "sync", "--idempotency-key", id] => Some(Command::RetrievalRun {
            plan: akasha_otsuge::retrieval::Request::Sync,
            idempotency_key: (*id).into(),
        }),
        ["index", "rebuild", "--idempotency-key", id] => Some(Command::RetrievalRun {
            plan: akasha_otsuge::retrieval::Request::Rebuild,
            idempotency_key: (*id).into(),
        }),
        ["search", query, "--scope", scope, "--idempotency-key", id] => {
            let input = config::read_file(std::path::Path::new(scope))?;
            if input.len() > 4096 {
                return Err(Error("MESSAGE_TOO_LARGE"));
            }
            Some(Command::RetrievalRun {
                plan: akasha_otsuge::retrieval::Request::Search {
                    query: (*query).into(),
                    scope: serde_json::from_str(&input)?,
                },
                idempotency_key: (*id).into(),
            })
        }
        ["job", "show", id] => Some(Command::JobShow { id: (*id).into() }),
        ["outcome", "run", _, "--", _, ..] => None,
        ["outcome", "log", id, index, flags @ ..] => {
            let flags = options(flags, &["--start"])?;
            Some(Command::OutcomeLog {
                id: (*id).into(),
                index: usize::try_from(number(index)?).map_err(|_| Error("INVALID_ARGUMENT"))?,
                start: usize::try_from(
                    flags
                        .get("--start")
                        .map(|v| number(v))
                        .transpose()?
                        .unwrap_or(0),
                )
                .map_err(|_| Error("INVALID_ARGUMENT"))?,
            })
        }
        ["outcome", "submit", path] => Some(Command::OutcomeSubmit {
            event: json_file_limit(path, akasha_otsuge::outcome::MAX_EVENT_BYTES)?,
        }),
        ["outcome", "show", id] => Some(Command::OutcomeShow { id: (*id).into() }),
        ["incident", "list", flags @ ..] => {
            let flags = options(flags, &["--scope", "--after"])?;
            Some(Command::IncidentList {
                scope: json_file(flags.get("--scope").ok_or(Error("INVALID_ARGUMENT"))?)?,
                after: flags.get("--after").map(|s| (*s).to_owned()),
            })
        }
        ["incident", "show", id] => Some(Command::IncidentShow {
            id: (*id).into(),
            after: None,
        }),
        ["incident", "show", id, "--after", after] => Some(Command::IncidentShow {
            id: (*id).into(),
            after: Some((*after).into()),
        }),
        ["incident", "update", path, "--idempotency-key", id] => Some(Command::IncidentUpdate {
            update: json_file(path)?,
            idempotency_key: (*id).into(),
        }),
        ["consult", "show", id] => Some(Command::ConsultShow { id: (*id).into() }),
        ["consult", "receipt", id] => Some(Command::ConsultReceipt {
            id: (*id).into(),
            full: false,
        }),
        ["consult", "receipt", id, "--full"] => Some(Command::ConsultReceipt {
            id: (*id).into(),
            full: true,
        }),
        ["consult", "original", id, source, flags @ ..] => {
            let flags = options(flags, &["--start"])?;
            Some(Command::ConsultOriginal {
                id: (*id).into(),
                source: usize::try_from(number(source)?).map_err(|_| Error("INVALID_ARGUMENT"))?,
                start: usize::try_from(
                    flags
                        .get("--start")
                        .map(|v| number(v))
                        .transpose()?
                        .unwrap_or(0),
                )
                .map_err(|_| Error("INVALID_ARGUMENT"))?,
            })
        }
        ["job", "cancel", id] => Some(Command::JobCancel { id: (*id).into() }),
        ["job", "list"] => Some(Command::JobList { after: None }),
        ["job", "list", "--after", after] => Some(Command::JobList {
            after: Some((*after).into()),
        }),
        ["memory", "show", id] => Some(Command::MemoryShow {
            id: (*id).into(),
            at: None,
        }),
        ["memory", "export", id] => Some(Command::MemoryExport { id: (*id).into() }),
        ["editor", "run", path, "--idempotency-key", id] => Some(Command::EditorRun {
            feedback: json_file(path)?,
            idempotency_key: (*id).into(),
        }),
        ["memory", "patch", path, "--idempotency-key", id] => Some(Command::PatchApply {
            patch: json_file_limit(path, akasha_otsuge::domain::MAX_PATCH_BYTES)?,
            idempotency_key: (*id).into(),
        }),
        ["patch", "show", id] => Some(Command::PatchShow { id: (*id).into() }),
        ["notify", "list", flags @ ..] => {
            let flags = options(flags, &["--scope", "--after"])?;
            Some(Command::NotifyList {
                scope: json_file(flags.get("--scope").ok_or(Error("INVALID_ARGUMENT"))?)?,
                after: flags.get("--after").map(|s| (*s).to_owned()),
            })
        }
        ["notify", "show", id] => Some(Command::NotifyShow { id: (*id).into() }),
        [
            "notify",
            "ack",
            id,
            "--generation",
            generation,
            "--idempotency-key",
            request,
        ] => Some(Command::NotifyAck {
            id: (*id).into(),
            generation: number(generation)?,
            idempotency_key: (*request).into(),
        }),
        ["review", "list", flags @ ..] => {
            let flags = options(flags, &["--scope", "--after"])?;
            Some(Command::ReviewList {
                scope: json_file(flags.get("--scope").ok_or(Error("INVALID_ARGUMENT"))?)?,
                after: flags.get("--after").map(|s| (*s).to_owned()),
            })
        }
        ["review", "show", id] => Some(Command::ReviewShow {
            id: (*id).into(),
            at: None,
        }),
        ["review", "show", id, "--at", at] => Some(Command::ReviewShow {
            id: (*id).into(),
            at: Some(number(at)?),
        }),
        ["review", "state", path, "--idempotency-key", id] => {
            let update: akasha_otsuge::domain::ReviewUpdate = json_file(path)?;
            Some(Command::ReviewState {
                id: update.id,
                expected_revision: update.expected_revision,
                state: update.state,
                reason: update.reason,
                idempotency_key: (*id).into(),
            })
        }
        ["review", "open", path, "--idempotency-key", id] => {
            let target: akasha_otsuge::domain::ReviewOpen = json_file(path)?;
            Some(Command::ReviewOpen {
                memory_id: target.memory_id,
                expected_revision: target.expected_revision,
                reason: target.reason,
                idempotency_key: (*id).into(),
            })
        }
        ["review", "preview" | "apply", path, "--idempotency-key", id] => {
            Some(Command::ReviewPreview {
                decision: json_file(path)?,
                idempotency_key: (*id).into(),
            })
        }
        ["memory", "show", id, "--at", at] => Some(Command::MemoryShow {
            id: (*id).into(),
            at: Some(number(at)?),
        }),
        ["memory", "history", id, flags @ ..] => {
            let flags = options(flags, &["--from", "--to", "--cursor"])?;
            Some(Command::MemoryHistory {
                id: (*id).into(),
                from: flags
                    .get("--from")
                    .map(|v| number(v))
                    .transpose()?
                    .unwrap_or(1),
                to: flags.get("--to").map(|v| number(v)).transpose()?,
                cursor: flags.get("--cursor").map(|v| json_file(v)).transpose()?,
            })
        }
        ["state", "show", flags @ ..] => {
            let flags = options(flags, &["--scope", "--at", "--cursor"])?;
            Some(Command::StateShow {
                scope: json_file(flags.get("--scope").ok_or(Error("INVALID_ARGUMENT"))?)?,
                at: number(flags.get("--at").ok_or(Error("INVALID_ARGUMENT"))?)?,
                cursor: flags.get("--cursor").map(|v| json_file(v)).transpose()?,
            })
        }
        ["state", "diff", from, to, flags @ ..] => {
            let flags = options(flags, &["--scope", "--cursor"])?;
            Some(Command::StateDiff {
                scope: json_file(flags.get("--scope").ok_or(Error("INVALID_ARGUMENT"))?)?,
                from: number(from)?,
                to: number(to)?,
                cursor: flags.get("--cursor").map(|v| json_file(v)).transpose()?,
            })
        }
        ["receipt", "show", id] => Some(Command::ReceiptShow { id: (*id).into() }),
        ["receipt", "replay", id] => Some(Command::ReceiptReplay { id: (*id).into() }),
        ["access", "revoke"] => Some(Command::AccessSet { scope: None }),
        ["access", "grant", scope] => Some(Command::AccessSet {
            scope: Some(json_file(scope)?),
        }),
        _ => return Err(Error("INVALID_ARGUMENT")),
    };
    let input = if operation.is_some() && socket.is_some() {
        String::new()
    } else if explicit_config || config_path.exists() {
        config::read_file(&config_path)?
    } else {
        String::new()
    };
    let resolved = config::resolve(
        &input,
        if operation.is_some() && socket.is_some() {
            None
        } else {
            profile.as_deref()
        },
        "",
        &defaults,
    )?;
    if let ["migrate", "mempal", source, destination, rest @ ..] = command.as_slice() {
        if socket.is_some() {
            return Err(Error("INVALID_ARGUMENT"));
        }
        let source = std::path::Path::new(source);
        let destination = std::path::Path::new(destination);
        let result = match rest {
            [] => akasha_otsuge::storage::migrate_mempal(source, destination)?,
            ["--previous", previous] => akasha_otsuge::storage::migrate_mempal_previous(
                source,
                destination,
                std::path::Path::new(previous),
            )?,
            _ => return Err(Error("INVALID_ARGUMENT")),
        };
        let mut bytes = serde_json::to_vec(&serde_json::json!({"schema_version":1,"data":result}))?;
        bytes.push(b'\n');
        output(&bytes, false)?;
        return Ok(0);
    }
    if let ["archive", action @ ("export" | "import"), destination] = command.as_slice() {
        if socket.is_some() {
            return Err(Error("INVALID_ARGUMENT"));
        }
        let destination = std::path::Path::new(destination);
        let manifest = if *action == "export" {
            akasha_otsuge::storage::Storage::export_archive(&resolved, destination).await?
        } else {
            akasha_otsuge::storage::Storage::import_archive(&resolved, destination).await?
        };
        let mut bytes =
            serde_json::to_vec(&serde_json::json!({"schema_version":1,"data":manifest}))?;
        bytes.push(b'\n');
        output(&bytes, false)?;
        return Ok(0);
    }
    if let ["outcome", "run", path, "--", argv @ ..] = command.as_slice() {
        let plan = json_file_limit(path, akasha_otsuge::outcome::MAX_EVENT_BYTES)?;
        let socket = socket
            .as_deref()
            .unwrap_or(&resolved.config().paths.socket_path);
        let (code, value, failed) =
            match outcome_command::run(socket, plan, argv.iter().map(|v| (*v).into()).collect())
                .await
            {
                Ok((code, record)) => (
                    code,
                    serde_json::json!({"schema_version":1,"data":record}),
                    false,
                ),
                Err(outcome_command::Failure::Local(error)) => return Err(error),
                Err(outcome_command::Failure::Remote(value)) => (1, value, true),
            };
        let mut bytes = serde_json::to_vec(&value)?;
        bytes.push(b'\n');
        output(&bytes, failed)?;
        return Ok(code);
    }
    if let Some((host, flags)) = install_flags {
        let path = |key| {
            flags
                .get(key)
                .map(std::path::Path::new)
                .ok_or(Error("INVALID_ARGUMENT"))
        };
        let socket = socket
            .as_deref()
            .unwrap_or(&resolved.config().paths.socket_path);
        let response = if host == "pi" {
            akasha_otsuge::adapter::pi::installation::install(
                path("--binary")?,
                path("--agent-dir")?,
                socket,
            )
            .await?
        } else if host == "hermes" {
            akasha_otsuge::adapter::hermes::installation::install(
                path("--binary")?,
                path("--home")?,
                socket,
            )
            .await?
        } else {
            akasha_otsuge::adapter::codex::installation::install(
                path("--binary")?,
                path("--launcher")?,
                path("--state-dir")?,
                socket,
            )
            .await?
        };
        let mut bytes =
            serde_json::to_vec(&serde_json::json!({"schema_version":1,"data":response}))?;
        bytes.push(b'\n');
        output(&bytes, false)?;
        return Ok(0);
    }
    if let Some(flags) = hook_flags {
        use std::io::Read;
        let binary = std::path::Path::new(flags.get("--binary").ok_or(Error("INVALID_ARGUMENT"))?);
        let state =
            std::path::Path::new(flags.get("--state-dir").ok_or(Error("INVALID_ARGUMENT"))?);
        let socket = socket.unwrap_or_else(|| resolved.config().paths.socket_path.clone());
        let mut bytes = Vec::new();
        io::stdin().take(65537).read_to_end(&mut bytes)?;
        let response = match akasha_otsuge::adapter::codex::hooks::handle(
            &socket, binary, state, &bytes,
        )
        .await
        {
            Ok(value) => value,
            Err(error)
                if serde_json::from_slice::<serde_json::Value>(&bytes)
                    .is_ok_and(|v| v["hook_event_name"] == "PreToolUse") =>
            {
                serde_json::json!({"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"deny","permissionDecisionReason":error.0}})
            }
            Err(error) => return Err(error),
        };
        let mut output_bytes = serde_json::to_vec(&response)?;
        output_bytes.push(b'\n');
        output(&output_bytes, false)?;
        return Ok(0);
    }
    if let Some(operation) = operation {
        let socket = socket.unwrap_or_else(|| resolved.config().paths.socket_path.clone());
        let now = ipc::now_ms()?;
        let request = Request {
            protocol_version: ipc::VERSION,
            request_id: format!("cli/{}/{now}", std::process::id()),
            deadline_ms: Some(now + ipc::TRANSPORT_TIMEOUT.as_millis() as u64),
            command: operation,
        };
        let replay = matches!(&request.command, Command::ReceiptReplay { .. });
        let response = if matches!(command.as_slice(), ["review", "apply", ..]) {
            review_apply(&socket, request).await?
        } else if replay {
            ipc::replay(&socket, &request, |bytes| {
                output(bytes, false)?;
                io::stdout().lock().flush()?;
                Ok(())
            })
            .await?
        } else {
            ipc::call(&socket, &request).await?
        };
        let code = response.get("error").and_then(|e| e["code"].as_str());
        if replay && code.is_none() {
            return Ok(0);
        }
        let mut bytes = serde_json::to_vec(&response)?;
        bytes.push(b'\n');
        output(&bytes, code.is_some())?;
        Ok(match code {
            None => 0,
            Some("RESOURCE_BUSY") => 4,
            Some(_) => 1,
        })
    } else {
        if socket
            .as_ref()
            .is_some_and(|s| *s != resolved.config().paths.socket_path)
        {
            return Err(Error("CONFIG_INVALID"));
        }
        if command == ["daemon", "start"] {
            let response = akasha_otsuge::daemon::start(&resolved, &args).await?;
            let mut bytes = serde_json::to_vec(&response)?;
            bytes.push(b'\n');
            output(&bytes, false)?;
            return Ok(0);
        }
        let native_environment = [
            ("MALLOC_ARENA_MAX", "2"),
            ("LANCE_FTS_NUM_SHARDS", "1"),
            ("LANCE_FTS_PARTITION_SIZE", "32"),
        ];
        if native_environment.iter().any(|(key, value)| {
            std::env::var_os(key).as_deref() != Some(std::ffi::OsStr::new(value))
        }) {
            use std::os::unix::process::CommandExt;
            // glibc startup and Lance's lazy update defaults must see bounded settings.
            return Err(std::process::Command::new(std::env::current_exe()?)
                .args(&args)
                .envs(native_environment)
                .exec()
                .into());
        }
        akasha_otsuge::daemon::run(resolved, config_path, profile).await?;
        Ok(0)
    }
}

async fn review_apply(socket: &std::path::Path, mut request: Request) -> Result<serde_json::Value> {
    use std::io::{BufRead, IsTerminal, Read};
    if !io::stdin().is_terminal() || !io::stderr().is_terminal() {
        return Err(Error("REVIEW_OPERATOR_REQUIRED"));
    }
    let response = ipc::call(socket, &request).await?;
    if response.get("error").is_some() {
        return Ok(response);
    }
    let preview = &response["data"];
    let digest = preview["preview_sha256"]
        .as_str()
        .ok_or(Error("PROTOCOL_ERROR"))?
        .to_owned();
    if digest.len() != 64 || !digest.bytes().all(|b| b.is_ascii_hexdigit()) {
        return Err(Error("PROTOCOL_ERROR"));
    }
    // JSON escapes source-controlled terminal sequences. The complete before/after is shown.
    output(&serde_json::to_vec(preview)?, true)?;
    output(
        format!("\nType confirm {digest} to apply: ").as_bytes(),
        true,
    )?;
    io::stderr().lock().flush()?;
    let mut answer = String::new();
    io::stdin().lock().take(128).read_line(&mut answer)?;
    if answer.trim() != format!("confirm {digest}") {
        return Err(Error("REVIEW_CANCELLED"));
    }
    let Command::ReviewPreview {
        decision,
        idempotency_key,
    } = request.command
    else {
        return Err(Error("INVALID_ARGUMENT"));
    };
    request.command = Command::ReviewApply {
        decision,
        idempotency_key,
        preview_sha256: digest,
    };
    request.deadline_ms = Some(ipc::now_ms()? + ipc::TRANSPORT_TIMEOUT.as_millis() as u64);
    ipc::call(socket, &request).await
}
fn options<'a>(
    args: &'a [&str],
    names: &[&str],
) -> Result<std::collections::BTreeMap<&'a str, &'a str>> {
    let mut options = std::collections::BTreeMap::new();
    for pair in args.chunks(2) {
        if pair.len() != 2
            || !names.contains(&pair[0])
            || options.insert(pair[0], pair[1]).is_some()
        {
            return Err(Error("INVALID_ARGUMENT"));
        }
    }
    Ok(options)
}
fn number(value: &str) -> Result<u64> {
    value.parse().map_err(|_| Error("INVALID_ARGUMENT"))
}
fn json_file<T: serde::de::DeserializeOwned>(path: &str) -> Result<T> {
    json_file_limit(path, 16384)
}
fn json_file_limit<T: serde::de::DeserializeOwned>(path: &str, limit: usize) -> Result<T> {
    let input = config::read_file(std::path::Path::new(path))?;
    if input.len() > limit {
        return Err(Error("MESSAGE_TOO_LARGE"));
    }
    Ok(serde_json::from_str(&input)?)
}
fn run() -> Result<u8> {
    let args: Vec<_> = std::env::args_os().skip(1).collect();
    if args.first().is_some_and(|s| s == "__native-runner") {
        return akasha_otsuge::adapter::run_guard(&args[1..]).map_err(Into::into);
    }
    if args.is_empty()
        || args.len() == 1 && matches!(args[0].to_str(), Some("-h" | "--help" | "help"))
    {
        output(HELP.as_bytes(), false)?;
        return Ok(0);
    }
    if args.len() == 1 && matches!(args[0].to_str(), Some("-V" | "--version" | "version")) {
        output(VERSION.as_bytes(), false)?;
        return Ok(0);
    }
    tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()?
        .block_on(execute(args))
}
fn main() -> ExitCode {
    match run() {
        Ok(code) => ExitCode::from(code),
        Err(error) => {
            let value = error.value();
            let _ = writeln!(
                io::stderr().lock(),
                "{{\"schema_version\":1,\"error\":{value}}}"
            );
            ExitCode::from(error.exit_code())
        }
    }
}
