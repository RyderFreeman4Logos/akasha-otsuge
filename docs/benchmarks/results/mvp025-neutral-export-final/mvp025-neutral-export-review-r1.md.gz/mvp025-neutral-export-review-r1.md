VERDICT: PASS

The complete frozen neutral-export leaf has zero actionable introduced findings. The requested focused command passed once: four archive, five CLI and seventeen storage tests. Source tracing and evidence validation support this verdict independently of the supplied green canonical gate. This is offline archive EXPORT only; it does not complete issue #25.

**Range and custody**

| Item | Verified identity |
|---|---|
| Repository, logical and resolved | `/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025` |
| Branch | `feat/mvp-025-migration` |
| Base, origin/main and merge-base | `c059fda030e1c7f5d4ec922f793088450c6bc4f0` |
| HEAD | `7ad2aab5721a2f840865da8a77d9bb367b6d9909` |
| Tree | `a62bcafa76ebd834cb8d1b06cf528787e64617bc` |
| Review range | Complete `origin/main...HEAD`, two commits, 48 changed files |
| Initial and final source state | Empty porcelain including all untracked files; all 48 changed working files equal their HEAD blobs |

Commits reviewed, oldest first:

- `f3d4c9e703df3e8a1333df60851335d3430fb4b0`: documentation-only observability closure archive and migration plan.
- `7ad2aab5721a2f840865da8a77d9bb367b6d9909`: neutral export, public CLI wiring, tests, documentation and focused evidence.

`git diff --binary --full-index origin/main...HEAD` is 225,985 bytes, SHA-256 `da0ab5d7455817553661652dfc0b30937660ea3d483a0faaa3c1c0cbeffc1dc1`. `git diff --check origin/main...HEAD` exited 0.

Source remained read-only. Only the requested external report and focused log were authored. No source edits, commits, publication, worktrees, agents, broad gates, canonical rerun, provider calls or configuration/environment changes occurred. Native-child transcripts were not inspected. WD remained parent-owned; the sole Cargo test invocation ran without concurrent Cargo.

**Filesystem instructions**

Actual filesystem inspection preceded source reads. Both `AGENTS.md` and `CLAUDE.md` were verified absent at every directory below. Logical and resolved paths are identical; each exact checked filename is the listed directory joined with `/AGENTS.md` or `/CLAUDE.md`. There are no applicable instruction files, so there are no present-file line counts to report.

```text
/
/mnt
/mnt/ssd
/mnt/ssd/mirror-rootfs
/mnt/ssd/mirror-rootfs/home
/mnt/ssd/mirror-rootfs/home/obj
/mnt/ssd/mirror-rootfs/home/obj/project
/mnt/ssd/mirror-rootfs/home/obj/project/github
/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos
/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025
```

Let R be the exact checkout root above. Both filenames are also actually absent at each applicable nested directory, with logical and resolved directories equal by exact R substitution:

```text
R/src
R/src/storage
R/tests
R/docs
R/docs/plan
R/docs/benchmarks
R/docs/benchmarks/results
R/docs/benchmarks/results/mvp024-observability-final
R/docs/benchmarks/results/mvp025-neutral-export
```

The initial filesystem scan inspected the ordinary nested checkout directories. A subsequent exact-parent census used filesystem `lexists` and path resolution for every changed path's ancestors, confirming these absences, including absence of dangling instruction symlinks. No Git-only absence inference was used. The unrelated root symlinks `R/target` and `R/.spike-work` resolve respectively to `/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/target` and `/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/.spike-work`; their foreign dependency trees were outside the changed-source scope.

Both instruction names were additionally verified absent at `/home`, `/home/obj`, `/home/obj/project`, `/home/obj/project/github`, `/home/obj/project/github/RyderFreeman4Logos`, `/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge`, its `.git`, and its `.git/akasha-evidence`. These logical paths resolve to themselves. The report/log directory is a real directory at the requested path.

Applied `native-code-review`, including its regression attribution, evidence, Rust, receipt-integrity, verdict and frozen-report rules. The explicit prohibition on agents overrides the skill's transport preference. No prior memory-derived project fact was used as review evidence.

**Complete scope**

Every changed file was reviewed as source/documentation or validated as an archived artifact, including gzip contents and receipt bindings. The full 48-file inventory consists of:

- Four code/test files: `src/main.rs`, `src/storage/mod.rs`, `src/storage/archive.rs`, `tests/archive.rs`.
- Three documentation files: `README.md`, `docs/neutral-archive.md`, `docs/plan/todo.md`.
- All 16 files in `docs/benchmarks/results/mvp024-observability-final`: manifest plus all 15 members.
- All 25 files in `docs/benchmarks/results/mvp025-neutral-export`: manifest plus all 24 members.

Traced baseline consumers in CLI global parsing, config/profile resolution, IPC error/output handling, storage layout/open/commit/revision/history/close, and the pinned native transaction/iterator/lock implementation. Existing CLI/storage tests were inspected for the affected contracts. This was a bounded full-leaf review, not a new audit of unrelated baseline features or the foreign mempal repository.

**Findings**

Actionable introduced findings: **0**. No severity/file/line/trigger defect is asserted. The brief's zero-actionable-defect rule was applied; supplied green gates alone would not establish PASS. No concrete introduced counterexample requiring an additional runtime probe was found.

| Boundary | Source evidence and conclusion |
|---|---|
| Public command and argument parsing | `src/main.rs:349` admits exactly `archive export DESTINATION` as an offline operation. Existing global parsing consumes config/profile/socket before the command; malformed arity and non-UTF-8 command arguments fail through the existing stable error path. Help advertises the new command. No daemon operation or adapter/provider launch is selected. |
| Config/profile/socket selection | `src/main.rs:669` reads the normal selected config for this offline operation; `:676` passes the selected profile to `config::resolve`. The resolver applies defaults, user settings and the selected validated profile (`src/config/mod.rs:329`). `src/main.rs:686` explicitly rejects `--socket` before opening storage. There is no socket fallback or accidental online export. Config validation may fail before socket rejection; both paths are nonzero and have no export side effects. |
| Missing or exclusively owned source | `src/storage/archive.rs:106` requires an existing non-symlink authority directory and exact format marker before `Storage::open`; missing source cannot silently become an empty store. Existing open also checks native `kv` directory and schema. Native exclusive locking prevents a second owner before destination creation. The archive test exercises missing source, held source and successful stopped empty source. Opening/recovery is not claimed to preserve native physical bytes. |
| Source close and errors | `src/storage/archive.rs:110` saves the write result, awaits source close even after write failure, then propagates the write error or, after successful writing, the close error. If both fail, the original write error wins. `src/ipc.rs:27` preserves the storage code; ordinary storage/I/O failures exit 1, bad arguments/config exit 2. Errors use static messages without printing original content or paths. |
| Relative, absolute and symlink paths | `src/storage/archive.rs:119` canonicalizes the existing parent, treating an empty relative parent as `.`; it joins only the final filename and canonicalizes the source. Component-aware containment checks reject the authority directory, descendants and ancestors (`:126`). Parent symlinks and `..` therefore resolve before comparison. A final destination symlink, file or existing directory cannot pass nonrecursive new-directory creation. Missing parent fails without recursive destination creation. The relative-path regression is fixed and freshly passes. Symlink/ancestor conclusions are source tracing, not additional runtime coverage. |
| No overwrite and private modes | `src/storage/archive.rs:129` uses the existing nonrecursive `0700` directory helper. `Sink::new` (`:56`) uses `create_new` and `0600`; the manifest helper does the same. Existing destinations are refused, not cleaned or reused. Fresh tests check directory/file modes and preservation of an existing manifest. These checks do not claim protection against a hostile same-UID process replacing paths during execution. |
| Snapshot and iterator | `src/storage/archive.rs:130` holds one transaction for sequence, receipts, outbox, revisions and clocks. The range is `[receipt/, receipt0)`, with explicit seek, valid, value and next error propagation. Each application receipt has a unique immutable key; all historical application revisions have unique revision keys, so a latest-value native range loses no application history. Request-key order, not commit/time order, is intentional and documented. |
| Receipts and request normalization | `src/storage/archive.rs:143` checks receipt identity, nonzero/in-range sequence and 1–64 references. `:152` checks matching outbox sequence and complete references. `:160` checks reference sequences and loads exact revisions. `:182` reconstructs the request with original request ID, config generation, policy revision, previous revision and content; existing validation and the writer's same RecordKey sort precede request hashing. It does not substitute export time or recalculate a different identity. |
| Revision/content/clock identity | Existing `read_revision` checks key, sequence, content length, strictly earlier nonzero previous links and exact content digest. Export preserves those links and uses the stored clock (`src/storage/archive.rs:197`), failing if required metadata is missing/malformed. Normal commit production creates previous links from the same key's existing head; export preserves this invariant rather than reordering or inventing history. Receipt count must equal durable commit sequence (`:212`). This is logical export validation, not an exhaustive forensic verifier for arbitrary malicious native-store rewrites. |
| All four record kinds and original bytes | `src/storage/archive.rs:167` writes the stored String's UTF-8 bytes directly, before JSON encoding metadata. Evidence, Memory, State and Job use the same path with distinct kind/ID. No parsing, normalization, deduplication or activation occurs. The fresh test covers all four kinds, NUL, Unicode, newlines, corrections, five revisions, both receipts and clocks, original byte ranges and previous links. Equal content remains separate revisions; zero-length content naturally has a zero-length contiguous range. |
| Determinism and empty archives | Receipt iteration follows native lexicographic keys; fixed field serialization and BTreeMap file entries are stable. The test deliberately makes request order differ from commit order. No current export timestamp enters output. Empty stores generate two empty data files and a zero-count manifest, freshly tested. |
| Bounds and growth | `src/storage/archive.rs:140` bounds receipt bytes; shared validation bounds 64 revisions, 128 KiB content each and 1 MiB total batch content. Revisions are read/decompressed one at a time, with only the current bounded batch retained. JSONL serialization is checked below 1 MiB before LF (`:203`). Blob bytes and commit/revision counters use checked u64 addition. Export has two growing data files and one fixed-size manifest, not one file or in-memory entry per historical commit. Total archive bytes grow with retained history; there is no disk quota or fixed total size claim. Engine caches/iterator structures remain native engine costs, not a measured constant-RSS guarantee. |
| Write, flush, fsync and publication | `Sink::write` (`:71`) checks byte arithmetic, calls write_all and updates the digest only after success. `finish` (`:81`) flushes BufWriter before file sync_all. Both finishes complete before manifest serialization/write/sync (`:221`); only then is manifest.tmp renamed to manifest.json, followed by destination and parent directory syncs (`:231`). No success is returned before those steps. |
| Failure and incomplete directories | Every fallible write/flush/sync/rename propagates failure. Before publication, errors may leave private data files or manifest.tmp with no completion marker. Later sync/close/stdout failure can leave a valid manifest while the command still fails, explicitly documented. There is no automatic deletion that could erase a prior destination. The fresh EFBIG test proves blob-write failure, no manifest and intact source content/receipt; it proves neither ENOSPC nor power-loss behavior. |
| CLI output | After successful export and source close, `src/main.rs:695` prints the manifest in the existing schema_version/data JSON envelope plus LF, through fallible output. The archive test compares stdout data with the disk manifest. Existing CLI stdout-failure coverage and source tracing establish nonzero output errors; a distinct archive-close or archive-stdout fault was not injected. |

Pinned API verification used the local SurrealKV checkout at `/home/obj/.cargo/git/checkouts/surrealkv-e974f5998ebcb4c5/4338a79`, HEAD `4338a790c8edc56ef5ea1e46157427af4815be3c`, matching Cargo.toml/Cargo.lock. Read source bytes for `src/lsm.rs`, `src/transaction.rs` and `src/lockfile.rs` were compared with that exact Git pin. `lsm.rs:2494` creates a transaction; `transaction.rs:397` captures the visible native sequence and snapshot; `:920` defines inclusive-start/exclusive-end range iteration. Its range iterator merges an empty export write set with the snapshot and resolves values through the VLog; explicit next/seek errors are returned. `lockfile.rs:68` acquires the native exclusive lock. The dependency's untracked `.cargo-ok` marker does not alter those source bindings. No dependency build, update or remote lookup was needed.

**Documentation and scope boundaries**

`docs/neutral-archive.md` accurately describes archive version 1 / record format 2, three completed files, byte offsets, hashes, request-key ordering, stored clocks, private output and incomplete-directory handling. JSON metadata and raw blobs can be read without either native storage engine; record content deliberately retains the application's logical schema rather than becoming a universal foreign schema.

Historical job, host-binding and configuration content stays opaque. Export does not execute it, install paths, activate credentials/policies, restore leases or launch jobs. The document explicitly prohibits treating arbitrary text as human approval. SHA-256 values detect integrity changes; they are not signatures or provenance proof.

Import, a validating reader, mempal conversion, duplicate/incremental application, interruption recovery and full round-trip acceptance remain explicitly pending (`docs/neutral-archive.md:78` and MVP-025 TODO). They are future work, not regressions in this independently shippable export leaf. Issue #25 stays open. The earlier docs-only commit records PR #56 closure while issue #24 stays open for enforcement and full production acceptance.

Pre-existing observations are separate: native open/recovery can change physical files; baseline configuration/CLI error and UTF-8 argument policies are reused; engine caches and physical lock behavior predate this range. No additional pre-existing defect is asserted. Earlier observability compile failures, causal REDs, production-acceptance gaps and unknown historical causality remain unresolved as previously recorded. None is relabeled by this PASS.

**Fresh commands and results**

The requested command ran exactly once, with no retry:

```text
cargo test --locked --test archive --test cli --test storage
archive: 4 passed, 0 failed, 0 ignored
cli:     5 passed, 0 failed, 0 ignored
storage: 17 passed, 0 failed, 0 ignored
EXIT_CODE=0
```

Complete stdout/stderr and the numeric exit are retained at `/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/.git/akasha-evidence/mvp025-neutral-export-review-r1-tests.log`: 3,465 bytes, SHA-256 `f8f6527b55fb43769b7dd3df23780843ca8b1864314da973cc71c5afc050d3a5`. The log includes the real EFBIG test and denied mise cache-write warnings. Those warnings did not change the zero command exit.

`command -v cargo` resolved `/home/obj/.local/share/mise/shims/cargo`; `cargo --version` reported `cargo 1.99.1 (5f94df478 2026-08-27)`. Inherited settings were preserved:

```text
RUSTUP_TOOLCHAIN=1.99.1
CARGO_HOME=/home/obj/.cargo
CARGO_TARGET_DIR=/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/target
RUSTC_WRAPPER=/mnt/ssd/mirror-rootfs/home/obj/.local/share/mise-rebuilt/installs/sccache/0.19.0/sccache-v0.19.0-x86_64-unknown-linux-musl/sccache
SCCACHE_SERVER_UDS=/mnt/ssd/mirror-rootfs/home/obj/tmp/a15-cache-s0s9a8n9/s
TMPDIR=/mnt/ssd/mirror-rootfs/home/obj/tmp/a15-cache-s0s9a8n9
```

Other checks were read-only identity, source/diff, filesystem instruction, SHA-256, gzip and JSON/receipt consistency checks. All final assertions succeeded. Two initial native-source filename lookups and one IPC-directory lookup used nonexistent paths; corrected lookups found the pinned implementation and `src/ipc.rs`. These were navigation misses, not test failures or missing evidence. No additional runtime probe or disposable fixture was created; focused tests cleaned their owned fixtures.

**Archive bindings and preserved history**

| Archive | Manifest SHA-256 | Members excluding manifest | Member bytes |
|---|---|---:|---:|
| MVP-025 neutral export | `d915f24b161b1294a1766bbec1019230d59caeabc21844520ec5b59eb1cfca53` | 24 | 58,179 |
| MVP-024 observability final | `ee28443a30454ff73111bee0bf7e673e6c1237a9a5e974001241df7244e82b5b` | 15 | 80,506 |

Both exact member sets, each byte length and SHA-256 validate. All seven MVP-025 source bindings match final working bytes and HEAD blobs. All eleven MVP-024 source bindings were checked with `git show ffc279fe7aaf7aa1ac9e6d3160926b90c17abaca:<path>`, not the changed checkout. Its tree is `5d697d798ebf180c929b33bb81634c73b2c4b57f`, also recorded for the historical merge.

Every gzip member decompresses. Raw log hashes match standalone terminal or CI receipts; collected terminal objects equal their standalone terminals. Classification files preserve the original failures rather than replacing their exits. MVP-025 history remains four separate runs:

| Run | Actual result | Exit / seconds | Raw log SHA-256 |
|---|---|---|---|
| Initial public CLI RED | Compiled; two archive tests failed with INVALID_ARGUMENT because the command was absent | 101 / 17.058276613242924 | `81b2c2176531dcac8cd62bc62dedfd48f901c9a24f4a8592e88fa5c454661036` |
| First focused GREEN | 2 archive, 5 CLI, 17 storage; all-target Clippy and diff check | 0 / 27.133179710246623 | `6695793c3407c001170102b458d62d494fb4661a8d88a1d23dab7989774e3943` |
| Boundary RED | Relative-directory test failed with STORAGE_IO; three archive controls passed, including EFBIG/source preservation | 101 / 1.0810283655300736 | `ff7dcd7d1d70834ba588d1b53c7d144365fa0c95d8f59dd9f716d99f8c32c725` |
| Final focused GREEN | 4 archive, 5 CLI, 17 storage; all-target Clippy and diff check | 0 / 23.295746099203825 | `dab40ad909f34a2af2bd0ff5df8ddfc1b82af6a91ab0f3e334acd720a19c58fb` |

Those admissions identify earlier HEAD `f3d4c9e...`, dirty diffs and untracked candidate files. They are not exact committed-head gates. The final source hashes bind the completed bytes; the later canonical receipt supplies separate exact-HEAD evidence.

The mempal report's decompressed SHA-256 is exactly `12cf1cb11509e1cbd5c20466617b9e695be2b67af22697dd8a506299845e00c4` (18,084 bytes). Gzip preserves its original bytes, including whitespace. Its pin and all fourteen report hash rows agree with the independent source-hash receipt for `4593a5c5e6a9ea1140256cd42fa5838511a24e14`. This review validated those archived bindings without repeating foreign-repository discovery. The report is exploration for a FUTURE importer: schema21/fork28, source-only, no live data, real sample or migration acceptance. Missing old full text, approval facts and runtime compatibility remain unknown.

The new focused archive's CI42755182650 success is historical postmerge evidence for `c059fda...`; its raw log SHA-256 is `0a37a36dddd66a25faf0e4146fe8c5bb08918f196779d9f34ed58e06f1967852`. Cache-restored/hit lines and head/status agree with its receipt. The earlier archive retains candidate CI42753418883, review, publication/readback and PR56 closure for `ffc279f...`, while issue24 remains open. Neither historical CI is promoted to validation of `7ad2aab...`; no live remote refresh occurred.

**Supplied canonical gate, not rerun**

The requested verified receipt at `/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/.git/akasha-evidence/mvp025-neutral-export-canonical-r1-verified.json` has SHA-256 `9866e4cbcb842759993584b0d86c559b2d3029a55a155ebef7d51b64e3e8ae64`. Its base/HEAD/tree match this review. All referenced artifact hashes independently validate:

| Artifact | SHA-256 |
|---|---|
| Admission | `cd29ec45ce7eca3e9353947123ac03235b5153c281b22f15366c40df4daf67eb` |
| Terminal | `956a426eabc1c64e6b3f60153f7aabcef98311d04bcda0dbc24417536ee1b5e4` |
| Collected | `3913db033f044e29c1d295196eb968ca79bcdbb8642daae5dcb8058778fd4c4e` |
| Complete raw log | `7d7c47d28e4e6132a59a1de373b8495c4fd8d652228cf7f3a66ea572f82b86bf` |

Admission records exact HEAD/tree, empty dirty diff and no untracked files. Terminal exit is 0 in 511.61918575689197 seconds; collection repeats the same terminal and records the producer absent. Parsing the retained log yields 21 Rust result rows, 545 passed and 31 ignored including installed repeat, with 157 daemon passes each run. It includes 34 Python tests and the installation record with binary SHA-256 `cd2fc3ca3271202f7517c2bb3de84950502e26f692132b0d027c7b8b2a4fc28a`, passed lifecycle/private-UID/peer-UID checks and zero TCP listeners.

The exact recipe is `just check` → `bash scripts/check.sh`: plan/reference checks, Python unittest discovery, Node tests, cargo fmt check, all-target locked Clippy with denied warnings, locked workspace tests, locked release build, capture and installed-daemon checks, release help/version and diff check. The recipe was read, not executed. This is authenticated supplied canonical/installation evidence, not a fresh canonical run, live installation validation, production stress result or candidate hosted-CI result.

**Final attestation and limits**

Final HEAD is `7ad2aab5721a2f840865da8a77d9bb367b6d9909`; tree is `a62bcafa76ebd834cb8d1b06cf528787e64617bc`; branch remains `feat/mvp-025-migration`; origin/main and merge-base remain `c059fda030e1c7f5d4ec922f793088450c6bc4f0`. Porcelain including all untracked files is empty. All 48 changed working-tree blobs still equal frozen HEAD. The report and focused log are outside the source tree; the saved report was reread and its first/last verdict lines checked. No review Cargo process remains running.

Skipped: canonical rerun, extra broad gates, provider/live acceptance, foreign discovery and publication, as requested.
Risk: EFBIG is not ENOSPC/power-loss proof; import, validating-reader and round-trip acceptance remain pending, and issues #24/#25 stay open.

VERDICT: PASS