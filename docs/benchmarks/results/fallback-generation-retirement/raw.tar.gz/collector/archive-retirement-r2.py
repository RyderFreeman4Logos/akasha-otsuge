import hashlib,json,pathlib,sys,tarfile
repo=pathlib.Path.cwd();sys.path.insert(0,str(repo/'spikes/helix'))
from run_case import digest,publish
storage=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023')
files={}
for prefix,name in [('red','fallback-retire-red-r1'),('green-r1','fallback-retire-green-r1'),('green-r2','fallback-retire-green-r2')]:
    root=storage/name
    if prefix!='red':
        result=json.loads((root/'result.json').read_text());verified=json.loads((root/'verified.json').read_text())
        assert result['status']=='passed' and verified['exact_processes_gone'] and verified['scratch_removed'] and verified['fixture_removed']
        for name,want in result['artifact_sha256'].items():assert digest(root/name)==want,name
    for p in root.rglob('*'):
        if p.is_file():files[prefix+'/'+str(p.relative_to(root))]=p
    files[prefix+'/memory.jsonl']=root.with_name(root.name+'-memory.jsonl')
for version in ['r1','r2']:
    root=repo/'.spike-work'/('retire-generation-'+version)
    for p in root.rglob('*'):
        if p.is_file() and p.name!='probe' and '__pycache__' not in p.parts:
            files['frozen-'+version+'/'+str(p.relative_to(root))]=p
source=json.loads((repo/'.spike-work/retire-generation-r2/source.json').read_text())
assert digest(repo/'.spike-work/retire-generation-r2/probe')==source['native_sha256']
for name,want in source['source_sha256'].items():
    assert digest(repo/name)==want,name;files['candidate-source/'+name]=repo/name
for name in ['retire-native-red-r1.log','retire-native-green-r1.log','retire-native-green-r2.log',
             'retire-release-tests-r1.log','retire-clippy-r1.log','retire-build-r1.log',
             'retire-observer-red-r1.log','retire-observer-green-r1.log','retire-controller-units-r1.log',
             'retire-controller-units-r2.log','retire-preflight.json','archive-retirement-r2.py']:
    files['collector/'+name]=repo/'.git/akasha-evidence'/name
out=repo/'docs/benchmarks/results/fallback-generation-retirement';out.mkdir();archive=out/'raw.tar.gz'
hashes={name:digest(p) for name,p in sorted(files.items())}
with tarfile.open(archive,'w:gz') as tf:
    for name,p in sorted(files.items()):tf.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tf:
    assert set(tf.getnames())==set(hashes)
    for m in tf.getmembers():assert hashlib.sha256(tf.extractfile(m).read()).hexdigest()==hashes[m.name],m.name
publish(out/'files.json',hashes)
verified=json.loads((storage/'fallback-retire-green-r2/verified.json').read_text())
summary=dict(**verified,source_parent=source['parent'],archive_files=len(files),archive_bytes=archive.stat().st_size,archive_sha256=digest(archive),release_units=11,release_all_targets_clippy='passed',controller_units=7,
    red='Prior d25 native rejects retire_generation after successful load; controller initially observes stale backfill999 instead of retirement1.',
    oracle_custody='RED admission retains its harness hash and raw failure. Subsequent progress/lag/raw-query controls and the four-family baseline extension are explicit; no byte-identical RED/GREEN harness claim. Frozen green-r1 and green-r2 sources are retained.',
    coverage=['inactive ready target; active generation ready and drained','no pending target append','native exclusive lock rejects competitor','durable retirement before any deletion','SIGKILL before intent, after intent and after native deletion before progress','four native table families removed by public drop_table','generation number permanently unusable by readers, writers and builders','status and historical indexed receipt remain visible with retirement marker','authority receipts and historical/current queries preserved','retry is idempotent and does not extend original deadline','cleanup below ordinary admission floor'],
    not_proven=['full-size retirement resource bounds','online retirement','expired retirement deadline extension','concurrent full rebuild physical peak'])
publish(out/'summary.json',summary);print({k:summary[k] for k in ['archive_files','archive_bytes','archive_sha256','checks','seconds','rss_max_bytes']})
