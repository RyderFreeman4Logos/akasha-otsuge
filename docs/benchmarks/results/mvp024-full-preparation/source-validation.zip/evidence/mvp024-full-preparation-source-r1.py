"""Read-only reproduction of the existing full manifest; no corpus/store copy."""
import datetime,hashlib,json,os,pathlib,re,subprocess,sys,time,tomllib
W=pathlib.Path.cwd();E=pathlib.Path(__file__).parent
sys.dont_write_bytecode=True
sys.path.insert(0,str(W/'spikes/data'))
from download import publish
sys.path.insert(0,str(W/'spikes/helix'))
from run_case import process_identity
def sha(p):
    with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def peak(text):
    found=re.findall(r'^\s*Maximum resident set size \(kbytes\): (\d+)$',text,re.M)
    if len(found)!=1:raise ValueError('GNU time peak is missing or ambiguous')
    return int(found[0])*1024
if sys.argv[1:]==['--self-test']:
    assert peak('Maximum resident set size (kbytes): 42\n')==43008
    for text in ['', 'Maximum resident set size (kbytes): 1\nMaximum resident set size (kbytes): 2\n']:
        try:peak(text)
        except ValueError:pass
        else:raise AssertionError('ambiguous peak accepted')
    print('PASS: bounded resource receipt parser');raise SystemExit
assert len(sys.argv)==1
manifest_path=W/'docs/benchmarks/results/full-corpus-manifest.json'
expected=json.loads(manifest_path.read_text())
assert sha(manifest_path)=='0b38c64fd5f5d77571ef9c76af4ccea298a96e76720f577d2d0b5c88adc43a66'
assert expected['status']=='full_corpus_prepared' and expected['source_counts']==[26,16]
import pyarrow
assert expected['environment']==dict(python=sys.version.split()[0],pyarrow=pyarrow.__version__)
code={name:sha(W/'spikes/data'/name) for name in expected['code_sha256']}
assert code['prepare_corpus.py']=='0218ccfe3db90314683fccf7d914290d5c2a890ba330d8933f4aed5d0d3f8e56'
assert all(code[name]==digest for name,digest in expected['code_sha256'].items() if name!='prepare_corpus.py')
original=subprocess.check_output(['git','show','1c6eed5d35569cd3f7427853fd0f0a0a47ac6275:spikes/data/prepare_corpus.py'],text=True)
assert (W/'spikes/data/prepare_corpus.py').read_text()==original.replace('parquet.ParquetFile(path).iter_batches','parquet.ParquetFile(path, pre_buffer=False).iter_batches')
expected_new={**expected,'code_sha256':code}
assert pathlib.Path('/usr/bin/time').is_file() and pathlib.Path('/usr/bin/timeout').is_file()
git=lambda *a:subprocess.check_output(['git',*a],text=True).strip()
assert not git('status','--porcelain')
root=(W/'.spike-work/mvp024-full-preparation-source-r1').resolve();root.mkdir(mode=0o700)
(root/'OWNER').write_text('akasha-otsuge:mvp024-full-preparation-source-r1\n')
config='[resources]\nobserved_client_rss_ceiling_bytes=2147483648\n[reliability]\nmax_attempts=1\nunit_timeout_s=14400\n'
with (root/'run.toml').open('x') as f:f.write(config);f.flush();os.fsync(f.fileno())
policy=tomllib.loads(config);epoch=sha(root/'run.toml')
head=git('rev-parse','HEAD');tree=git('rev-parse','HEAD^{tree}');start=time.monotonic()
assert head=='af8eb1f834cd2ef21fe0bdd65f6a1d3e9cd4a69d'
command=['nohup','/usr/bin/timeout','--signal=TERM','--kill-after=30s',str(policy['reliability']['unit_timeout_s']),
         '/usr/bin/time','--verbose','--output',str(root/'time.txt'),sys.executable,str(E/'mvp024-full-preparation-source-inspect-r1.py'),
         'scan',str((W/'.spike-work/corpus-full-v1').resolve(strict=True)),'26','16',str(root/'verified-manifest.json')]
admission=dict(head=head,tree=tree,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),process=process_identity(os.getpid()),
 command=command,script_sha256=sha(__file__),input_manifest_sha256=sha(manifest_path),code_sha256=code,inspector_sha256=sha(E/'mvp024-full-preparation-source-inspect-r1.py'),instrumentation='Check production record/claim shape around the unchanged generator; no reader or output override',
 config_epoch=epoch,environment=expected['environment'],unit='reproduce_frozen_full_corpus',expected_documents=expected['corpus']['documents'],
 expected_actual_shards=len(expected['corpus']['inputs']),requested_max_shards=sum(expected['source_counts']),
 progress_path=str(root/'verified-manifest.progress.json'),mode='read-only source reproduction; no production data directory or JSONL corpus',
 memory_contract='Separate offline preparer observed high-water <=2GiB; not a daemon/runner/service memory result or a claimed kernel hard limit',
 resume='Adopt the exact surviving nohup process. If terminal, reconcile this result. No automatic duplicate run or silent partial overwrite.')
publish(root/'admission.json',admission);publish(root/'state.json',dict(phase='running',completed_units=[],admission_sha256=sha(root/'admission.json')))
env=dict(os.environ,LC_ALL='C',PYTHONDONTWRITEBYTECODE='1')
child=subprocess.Popen(command,stdin=subprocess.DEVNULL,env=env,start_new_session=True)
publish(root/'child-process.json',process_identity(child.pid))
rc=child.wait();publish(root/'child-terminal.json',dict(exit_code=rc,elapsed_s=time.monotonic()-start))
try:
    assert rc==0,('source reproduction failed',rc)
    assert sha(root/'run.toml')==epoch and git('rev-parse','HEAD')==head and git('rev-parse','HEAD^{tree}')==tree and not git('status','--porcelain')
    actual=json.loads((root/'verified-manifest.json').read_text())
    assert actual==expected_new,'new code-bound manifest differs beyond the preparer code hash'
    assert actual['corpus']==expected['corpus'],'complete corpus statistics or byte-stream identity differs'
    shape=json.loads((root/'production-shape.json').read_text())
    assert shape['counts']['records']==expected['corpus']['documents'] and shape['counts']['vector_cohort']==999963
    timing=(root/'time.txt').read_text();rss=peak(timing)
    assert re.search(r'^\s*Exit status: 0$',timing,re.M),'GNU time exit missing'
    complete=dict(phase='complete',completed_units=['reproduce_frozen_full_corpus'],admission_sha256=sha(root/'admission.json'),
        elapsed_s=time.monotonic()-start,manifest_sha256=sha(root/'verified-manifest.json'),time_sha256=sha(root/'time.txt'),
        max_rss_bytes=rss,rss_ceiling_bytes=policy['resources']['observed_client_rss_ceiling_bytes'],
        full_manifest_byte_equal=False,complete_corpus_equal=True,only_manifest_difference='code_sha256.prepare_corpus.py',production_shape=shape,corpus_sha256=expected['corpus']['prepared_sha256'],source_rows=expected['corpus']['source_rows'],
        documents=expected['corpus']['documents'],unique_content_utf8_bytes=expected['corpus']['unique_content_utf8_bytes'],
        prepared_stream_bytes=expected['corpus']['prepared_bytes'],raw_corpus_copies=0,production_import=False)
    if rss>complete['rss_ceiling_bytes']:
        complete.update(phase='failed',classification='SOURCE_REPRODUCTION_PASS_PREPARER_RSS_CONTRACT_FAIL')
        publish(root/'failure.json',complete);publish(root/'state.json',complete)
        raise RuntimeError('Offline preparer RSS exceeds its predeclared observation contract')
    if not shape['passed']:
        complete.update(phase='failed',classification='SOURCE_REPRODUCTION_PASS_PRODUCTION_RECORD_ADMISSION_FAIL')
        publish(root/'failure.json',complete);publish(root/'state.json',complete)
        raise RuntimeError('Full source contains records or claims rejected by the production seeder')
    complete['classification']='COMMITTED_SOURCE_REPRODUCTION_MEMORY_AND_RECORD_SHAPE_PASS_NOT_PRODUCTION_ACCEPTANCE'
    publish(root/'result.json',complete);publish(root/'state.json',complete);print(json.dumps(complete))
except BaseException as error:
    if not (root/'failure.json').exists():
        failure=dict(phase='failed',error_type=type(error).__name__,error=str(error),child_exit=rc,elapsed_s=time.monotonic()-start)
        publish(root/'failure.json',failure);publish(root/'state.json',failure)
    raise

