"""Validate production frame/claim shape while retaining the preparer's complete stream."""
import collections,json,pathlib,sys
sys.dont_write_bytecode=True
W=pathlib.Path.cwd()
sys.path.insert(0,str(W/'spikes/data'))
import prepare_corpus
from download import publish

RUST_SPACE="\t\n\v\f\r \x85\xa0\u1680\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200a\u2028\u2029\u202f\u205f\u3000"
def shape(row):
    body=row['body'];encoded=body.encode('utf-8');issues=[]
    if not row['key'].strip(RUST_SPACE) or len(row['key'].encode('utf-8'))>256:issues.append('invalid_key')
    if row['partition'] not in {f'p{i}' for i in range(8)}:issues.append('invalid_partition')
    if not body.strip(RUST_SPACE):issues.append('empty_source')
    if len(encoded)>65536:issues.append('oversized_source')
    start=0;claims=0
    while start<len(encoded):
        end=min(start+32768,len(encoded))
        while end<len(encoded) and encoded[end]&0xc0==0x80:end-=1
        claim=encoded[start:end].decode('utf-8')
        assert 0<end-start<=32768
        claims+=1
        if not claim.strip(RUST_SPACE):issues.append('empty_claim')
        start=end
    return dict(bytes=len(encoded),claims=claims,issues=issues,vector_cohort='embedding' in row and len(encoded)<=4096)

def self_test():
    row=dict(key='dbpedia:one',body='a',partition='p0',embedding=[1.0])
    assert shape(row)==dict(bytes=1,claims=1,issues=[],vector_cohort=True)
    for text,n in [('a'*32768,1),('a'*32767+'你',2),('🦀'*16384,2)]:
        actual=shape(dict(row,body=text));assert actual['claims']==n and not actual['issues']
    assert shape(dict(row,body='a'*32768+' '*32768))['issues']==['empty_claim']
    assert shape(dict(row,body=' '))['issues']==['empty_source','empty_claim']
    assert shape(dict(row,body='a'*65537))['issues']==['oversized_source']
    assert shape(dict(row,key='你'*86))['issues']==['invalid_key']
    assert shape(dict(row,body='\x1c'))['issues']==[]
    assert shape(dict(row,body='a'*4096))['vector_cohort']
    assert not shape(dict(row,body='a'*4097))['vector_cohort']
    assert shape(dict(row,partition='p8'))['issues']==['invalid_partition']
    print('PASS: complete source and UTF-8 claim admission checks')

if sys.argv[1:]==['--self-test']:
    self_test()
elif __name__=='__main__':
    original=prepare_corpus.records
    counts=collections.Counter();partitions={f'p{i}':collections.Counter() for i in range(8)};examples=[]
    def records(*args,**kwargs):
        for ordinal,row in enumerate(original(*args,**kwargs),1):
            actual=shape(row);counts['records']+=1;counts['claims']+=actual['claims']
            counts['vector_cohort']+=actual['vector_cohort']
            counts['max_source_bytes']=max(counts['max_source_bytes'],actual['bytes'])
            if actual['issues']:
                counts['rejected_records']+=1
                for issue in actual['issues']:counts[issue]+=1
                if len(examples)<16:
                    import hashlib
                    examples.append(dict(ordinal=ordinal,key_sha256=hashlib.sha256(row['key'].encode()).hexdigest(),
                     body_sha256=hashlib.sha256(row['body'].encode()).hexdigest(),bytes=actual['bytes'],issues=actual['issues']))
            if row['partition'] in partitions:
                partitions[row['partition']]['sources']+=1
                partitions[row['partition']]['claims']+=actual['claims']
                partitions[row['partition']]['vector_cohort']+=actual['vector_cohort']
            yield row
    prepare_corpus.records=records
    prepare_corpus.main()
    output=pathlib.Path(sys.argv[5]).parent/'production-shape.json'
    publish(output,dict(counts=counts,partitions=partitions,first_rejections=examples,
        passed=counts['rejected_records']==0,
        scope='All original deduplicated records; check-only generator instrumentation; no production import; supplement separate'))

