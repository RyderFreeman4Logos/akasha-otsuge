import hashlib,json,pathlib,re,subprocess,datetime
E=pathlib.Path("/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/.git/akasha-evidence");W=pathlib.Path("/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025");R=(W/'.spike-work/mvp024-full-prefetch-control-r1').resolve()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
ad=json.loads((R/'admission.json').read_text());result=json.loads((R/'result.json').read_text());col=json.loads((E/'mvp024-full-prefetch-control-r1.collected.json').read_text())
assert col['process_absent'] and col['terminal']['exit_code']==0
assert result['admission_sha256']==sha(R/'admission.json')
assert result['manifest_sha256']==sha(R/'verified-manifest.json')==sha(W/'docs/benchmarks/results/full-corpus-manifest.json')
assert result['time_sha256']==sha(R/'time.txt')
timing=(R/'time.txt').read_text()
peak=re.findall(r'^\s*Maximum resident set size \(kbytes\): (\d+)$',timing,re.M)
assert len(peak)==1 and int(peak[0])*1024==result['max_rss_bytes']<=result['rss_ceiling_bytes']==2147483648
assert re.search(r'^\s*Exit status: 0$',timing,re.M)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=W)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==ad['head']=='1c6eed5d35569cd3f7427853fd0f0a0a47ac6275'
for key,expected in ad['code_sha256'].items():assert sha(W/'spikes/data'/key)==expected
receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),result=result,head=ad['head'],tree=ad['tree'],control=ad['control'],
 files={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(R.iterdir()) if p.is_file()},
 classification='PASS: runtime pre_buffer=False control, exact original manifest bytes; not yet a committed-source scan or production import',
 collected_sha256=sha(E/'mvp024-full-prefetch-control-r1.collected.json'),
 action='One-line preparer repair; keep 2GiB observed ceiling and original failure; no disk dedup or extra corpus copy.')
out=E/'mvp024-full-prefetch-control-r1-verified.json'
with out.open('x') as f:json.dump(receipt,f,indent=2,sort_keys=True);f.write('\n')
print(json.dumps(dict(path=str(out),sha256=sha(out),files=len(receipt['files']),max_rss_bytes=result['max_rss_bytes'],byte_equal=True)))
