"""One-variable diagnostic: disable Parquet prefetch in unchanged preparer."""
import pathlib,sys
W=pathlib.Path.cwd();sys.dont_write_bytecode=True
sys.path.insert(0,str(W/'spikes/data'))
import prepare_corpus
original=prepare_corpus.parquet.ParquetFile
def reader(*args,**kwargs):
    assert 'pre_buffer' not in kwargs
    return original(*args,pre_buffer=False,**kwargs)
prepare_corpus.parquet.ParquetFile=reader
prepare_corpus.main()

