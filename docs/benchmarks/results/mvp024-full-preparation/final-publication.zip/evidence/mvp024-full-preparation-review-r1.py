import datetime,hashlib,json,pathlib,subprocess,time
E=pathlib.Path(__file__).parent;W=pathlib.Path('/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025')
git=lambda *a:subprocess.check_output(['git','--no-optional-locks',*a],cwd=W,text=True).strip()
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
gate=json.loads((E/'mvp024-full-preparation-canonical-r1-verified.json').read_text())
scope=json.loads((E/'mvp024-full-preparation-parent-scope-r1.json').read_text())
assert gate['head']==git('rev-parse','HEAD')==scope['head'] and gate['tree']==git('rev-parse','HEAD^{tree}')==scope['tree']
assert gate['status']=='PASS' and gate['clean_before_after'] and not git('status','--porcelain')
assert git('rev-parse','origin/main')==scope['origin_main'] and git('merge-base','origin/main','HEAD')==scope['base']
for name,digest in scope['source_sha256'].items():assert sha(W/name)==digest
pin=json.loads((E/'mvp020-review-runtime-r2.json').read_text())
for key in ['binary','companion']:assert sha(pin[key])==pin[key+'_sha256']
stem='mvp024-full-preparation-review-r1';outdir=E/stem;outdir.mkdir(mode=0o700);report=outdir/'report.md'
assert not report.exists() and not (E/(stem+'.final.txt')).exists()
protected=[E/'mvp024-full-preparation-parent-scope-r1.json',E/'mvp024-full-preparation-parent-complete-instructions-r1.json',E/'mvp024-full-preparation-canonical-r1-verified.json']
protected += [E/('mvp024-full-preparation-canonical-r1'+suffix) for suffix in ['.admission.json','.terminal.json','.collected.json','.log']]
protected_sha={str(p):sha(p) for p in protected}
cmd=['nohup',pin['binary'],'exec','--sandbox','workspace-write','--add-dir',str(outdir.resolve()),'--ephemeral','--json','--color','never','--cd',str(W),'--output-last-message',str(E/(stem+'.final.txt')),'-']
start=time.monotonic()
with (E/'mvp024-full-preparation-review-r1-brief.md').open('rb') as brief,(E/(stem+'.stdout')).open('xb') as out,(E/(stem+'.stderr')).open('xb') as err:
 child=subprocess.Popen(cmd,stdin=brief,stdout=out,stderr=err,start_new_session=True);rc=child.wait()
assert protected_sha=={str(p):sha(p) for p in protected}
for name,digest in scope['source_sha256'].items():assert sha(W/name)==digest
events=[]
for line in (E/(stem+'.stdout')).open():
 try:v=json.loads(line)
 except ValueError:continue
 if v.get('type') in ['thread.started','turn.completed','turn.failed','error']:events.append(v)
receipt=dict(exit_code=rc,seconds=time.monotonic()-start,events=events,head=git('rev-parse','HEAD'),tree=git('rev-parse','HEAD^{tree}'),
 clean_after=not git('status','--porcelain'),protected_inputs_unchanged=True,report_exists=report.exists(),report_sha256=sha(report) if report.exists() else None,
 transport='independent Codex exec; Hermes previously unavailable',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),runtime=pin)
for key in ['binary','companion']:assert sha(pin[key])==pin[key+'_sha256']
with (E/(stem+'.exit.json')).open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt),flush=True)
raise SystemExit(rc)

