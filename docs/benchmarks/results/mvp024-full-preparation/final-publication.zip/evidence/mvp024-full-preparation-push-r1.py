import pathlib,json,subprocess,hashlib,datetime
E=pathlib.Path(__file__).parent;W=pathlib.Path("/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025")
def git(*args):return subprocess.check_output(['git',*args],cwd=W,text=True).strip()
scope=json.loads((E/'mvp024-full-preparation-parent-scope-r1.json').read_text())
accepted=json.loads((E/'mvp024-full-preparation-review-accepted-r1.json').read_text())
assert accepted['status']=='PASS' and accepted['head']==scope['head']==git('rev-parse','HEAD')
assert not git('status','--porcelain')
branch='feat/mvp-024-full-preparation';assert git('branch','--show-current')==branch
report=E/'mvp024-full-preparation-review-r1/report.md'
assert hashlib.sha256(report.read_bytes()).hexdigest()==accepted['report_sha256']
subprocess.run(['git','push','--set-upstream','origin',branch],cwd=W,check=True)
remote=git('ls-remote','--heads','origin','refs/heads/'+branch).split()
assert remote==[scope['head'],'refs/heads/'+branch]
assert git('rev-parse','HEAD')==scope['head'] and not git('status','--porcelain')
receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=scope['head'],tree=scope['tree'],branch=branch,
 remote_head=remote[0],normal_push=True,force=False,clean=True,report_sha256=accepted['report_sha256'])
with (E/'mvp024-full-preparation-push-r1-verified.json').open('x') as f:json.dump(receipt,f,indent=2)
print(json.dumps(receipt))

