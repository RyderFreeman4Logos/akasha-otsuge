import json,pathlib,subprocess,time
E=pathlib.Path(__file__).parent;repo='RyderFreeman4Logos/akasha-otsuge';run='44009285018';head='d49e812bcb8bee8030175412d2eef7bfefbecffa'
attempts=[]
for connection in range(1,4):
 watched=subprocess.run(['gh','run','watch',run,'--exit-status','--interval','60','--compact','--repo',repo])
 fetched=subprocess.run(['gh','api',f'repos/{repo}/actions/runs/{run}'],text=True,capture_output=True)
 item={'connection_attempt':connection,'watch_exit':watched.returncode,'fetch_exit':fetched.returncode};attempts.append(item)
 if fetched.returncode==0:
  raw=json.loads(fetched.stdout);receipt={k:raw[k] for k in ['id','head_sha','run_attempt','status','conclusion','event','html_url']}
  assert receipt['head_sha']==head and receipt['run_attempt']==1
  if receipt['status']=='completed':
   receipt['watch_connections']=attempts
   with (E/'mvp024-full-preparation-ci-r1.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
   print(json.dumps(receipt),flush=True)
   raise SystemExit(0 if receipt['conclusion']=='success' else 1)
  item['remote_status']=receipt['status']
 else:
  item['fetch_error']=fetched.stderr[-1500:]
 print(json.dumps({'wait_transport_reconnect':item,'no_remote_rerun':True}),flush=True)
 if connection<3:time.sleep(5*connection)
with (E/'mvp024-full-preparation-ci-wait-r1-transport-exhausted.json').open('x') as f:json.dump({'run_id':run,'head':head,'attempts':attempts},f,indent=2)
raise RuntimeError('CI completion unverified after three wait connections; inspect existing remote run without rerunning it')
