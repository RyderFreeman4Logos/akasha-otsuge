import hashlib,json,pathlib,shutil,subprocess,zipfile
E=pathlib.Path("/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/.git/akasha-evidence");W=pathlib.Path("/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025")
def sha(data):return hashlib.sha256(data).hexdigest()
cohort=W/'docs/benchmarks/results/mvp024-vector-cohort'
manifest=json.loads((E/'mvp024-vector-cohort-final-publication-manifest.json').read_text())
archive=E/'mvp024-vector-cohort-final-publication.zip'
assert sha(archive.read_bytes())==manifest['archive_sha256']
with zipfile.ZipFile(archive) as z:
    assert set(z.namelist())==set(manifest['members'])
    for name,meta in manifest['members'].items():
        data=z.read(name);assert len(data)==meta['bytes'] and sha(data)==meta['sha256']
for src,dst in [(archive,cohort/'final-publication.zip'),(E/'mvp024-vector-cohort-final-publication-manifest.json',cohort/'final-publication-manifest.json')]:
    assert not dst.exists();shutil.copyfile(src,dst)
readme=cohort/'README.md'
text=readme.read_text()
old='The final canonical gate, independent review and publication are separate from\nthis archive. Full 50 GB import/coverage, one million production vectors,\n100,000 changes, 100-client load and the unchanged recovery criteria remain open.\n'
new="""## Final publication

[PR #73](https://github.com/RyderFreeman4Logos/akasha-otsuge/pull/73) merged as
`1c6eed5d35569cd3f7427853fd0f0a0a47ac6275`, with the same tree as reviewed head
`235884dc1d4d85039130697745c42cee49a698ac`. The exact canonical gate passed
651 Rust executions / 39 intentional ignores, 35 Python and seven Node tests,
including the installed lifecycle, private/peer UID and no-TCP checks.
Hosted CI43993016887 passed on a checkout with the same tree.

Independent review passed the source/evidence scope with zero actionable findings
and ten fresh Python tests. Its fresh Rust command stopped before executing tests
because the shared target was read-only in that review sandbox. That prerequisite
failure remains explicit; four example tests passed separately in the parent
environment and in the canonical gate. The complete immutable report is published
in the PR description, not a separate review comment.

`final-publication.zip` contains 89 members, 143,306 bytes, SHA-256
`249dd3c759d87f7c2659124a2eb9bb92ff07b14aa42d4a80232bd4a3664dcd08`.
`final-publication-manifest.json` gives every member hash. It retains complete
gate/review/CI logs, the review prerequisite and parent aggregation failures,
the separate parent test result, push/merge identities and public readbacks.
These publication receipts supplement the earlier pilot archive.

Full 50 GB import/coverage, one million production vectors, 100,000 changes,
100-client load and the unchanged recovery criteria remain open in #65.
"""
assert text.count(old)==1;readme.write_text(text.replace(old,new))
out=W/'docs/benchmarks/results/mvp024-full-preparation';out.mkdir()
members={}
for name in ('mvp024-full-preparation-r1','mvp024-full-prefetch-control-r1'):
    root=(W/'.spike-work'/name).resolve()
    for path in sorted(root.iterdir()):
        if path.is_file():
            assert path.stat().st_size<1024**2
            members['runs/'+name+'/'+path.name]=path.read_bytes()
    for suffix in ('.py','.log','.launch.json','.terminal.json','.collected.json'):
        path=E/(name+suffix)
        assert path.is_file();members['evidence/'+path.name]=path.read_bytes()
for name in ('mvp024-full-preparation-preflight-r1.json','mvp024-full-preparation-r1-verified-failure.json',
 'mvp024-full-prefetch-control-reader-r1.py','mvp024-full-prefetch-control-r1-verified.json',
 'mvp024-full-prefetch-control-verify-r2.py','mvp024-full-prefetch-control-aggregation-failure-r1.json',
 'mvp024-full-preparation-focused-r1.log','mvp024-full-preparation-focused-r1.json'):
    path=E/name;members['evidence/'+name]=path.read_bytes()
members['source/original/prepare_corpus.py']=subprocess.check_output(['git','show','HEAD:spikes/data/prepare_corpus.py'],cwd=W)
members['source/candidate/prepare_corpus.py']=(W/'spikes/data/prepare_corpus.py').read_bytes()
members['source/unchanged/test_corpus.py']=(W/'spikes/data/test_corpus.py').read_bytes()
target=out/'evidence.zip'
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(members.items()):
        info=zipfile.ZipInfo(name,(2026,11,17,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16
        z.writestr(info,data,compresslevel=9)
receipt=dict(archive_bytes=target.stat().st_size,archive_sha256=sha(target.read_bytes()),
 members={name:dict(bytes=len(data),sha256=sha(data)) for name,data in sorted(members.items())},
 scope='Original full reproduction resource failure and one explicit runtime prefetch control; not production acceptance.')
(out/'manifest.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
(out/'README.md').write_text("""# Full corpus preparation memory

The original full scan at `1c6eed5` reproduced the retained manifest byte for byte:
11,428,831 deduplicated documents, 11,806,304 source rows and 50,000,002,783
eligible UTF-8 bytes. It hashed the 84,147,341,473-byte serialized stream without
writing that JSONL expansion. Source hashing consumed 41 shards from the maximum
42-shard selection; the text-byte target ends inside the final consumed shard.

The scan exited successfully, but its GNU time peak RSS was 3,829,080,064 bytes,
above the predeclared 2 GiB observed preparer ceiling. The overall run remains
failed. This is an offline preparation measurement, separate from daemon,
runner and service budgets; no kernel hard-limit enforcement is claimed.

One control changed only `ParquetFile(pre_buffer=False)` at runtime, retaining
the original frozen source files and manifest code identities. It reproduced
the complete original manifest exactly, with peak RSS 2,012,385,280 bytes below
the unchanged 2,147,483,648-byte ceiling. There was no cache eviction. These two
observations do not establish a general performance interval or worst-case bound.
The control is not mislabeled as execution of a new committed source.

The candidate applies that reader setting in `spikes/data/prepare_corpus.py`.
All four existing preparation tests pass, including real Parquet deduplication,
UTF-8 chunk boundaries and vector validation. The source change requires a new
manifest; its committed-source scan and full production import are still pending.

`evidence.zip` and `manifest.json` retain both complete run receipts, the original
failed resource result, runtime override, exact source snapshots, focused tests
and a parent aggregation path error. No raw Parquet or native database is copied.
""")
todo=W/'docs/plan/todo.md';text=todo.read_text()
changes=[
('The existing SSD worktree is reused on feat/mvp-024-vector-cohort, based on\nmerged vector-coverage commit `c51f97b`. No additional corpus or Rust target is copied.',
 'The existing SSD worktree is reused on feat/mvp-024-full-preparation, based on\nmerged cohort commit `1c6eed5`. No additional corpus or Rust target is copied.'),
('- [ ] Publish the cohort seeder, exact-input lookup and bounded real-vector\n  evidence after the final canonical gate, independent review and hosted CI.',
 '- [x] Publish the cohort seeder, exact-input lookup and bounded real-vector\n  evidence after the final canonical gate, independent review and hosted CI.\n  PR #73 merged with the reviewed tree; its final archive retains all limitations.\n- [x] Reproduce the complete original corpus manifest and isolate preparation\n  memory through one unchanged-budget prefetch control. Preserve the baseline\n  resource failure separately from the successful source reproduction.\n- [ ] Freeze the repaired preparer and generate its new code-bound manifest;\n  verify full corpus equality and production record/claim admission.'),
('historical 50,000,002,783-byte lexical dedup count was not recounted.',
 'historical lexical count was not recounted in that census. The subsequent\nfull-preparation runs reproduce all 50,000,002,783 eligible bytes exactly.'),
('Final gate/review/publication and full import/load/recovery remain pending.',
 'PR #73 merged as `1c6eed5` with the reviewed `235884d` tree. Its exact\ncanonical gate and CI pass 651 Rust executions / 39 ignores, Python 35 and\nNode 7. Independent source/evidence review passes with zero findings and ten\nfresh Python tests; its Rust invocation failed the read-only shared-target\nprerequisite before tests. The canonical and separate parent example runs\neach pass four tests. The [final publication archive](../benchmarks/results/mvp024-vector-cohort/README.md#final-publication)\nretains these distinct results and complete public readbacks.\nThe [full preparation evidence](../benchmarks/results/mvp024-full-preparation/README.md)\nretains a byte-identical baseline with RSS 3,829,080,064 bytes above its 2 GiB\nceiling, and a single prefetch-disabled control with the same complete manifest\nand RSS 2,012,385,280 bytes below that unchanged ceiling. Both stream hashes\nwere computed without retaining the 84 GB JSONL expansion. Committed-source\npreparation and full production import/load/recovery remain pending.')
]
for before,after in changes:
    assert text.count(before)==1,before
    text=text.replace(before,after)
todo.write_text(text)
print(json.dumps(dict(preparation_members=len(members),preparation_archive_bytes=receipt['archive_bytes'],preparation_archive_sha256=receipt['archive_sha256'],publication_members=len(manifest['members']))))

