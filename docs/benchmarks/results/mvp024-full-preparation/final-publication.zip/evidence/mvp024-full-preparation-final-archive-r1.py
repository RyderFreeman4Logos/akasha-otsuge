import hashlib,json,pathlib,zipfile,datetime
E=pathlib.Path(__file__).parent;W=pathlib.Path.cwd()
already=set()
for name in ("manifest.json","source-validation-manifest.json"):
 p=W/"docs/benchmarks/results/mvp024-full-preparation"/name
 old=json.loads(p.read_text())
 already.update(n.removeprefix("evidence/") for n in old["members"] if n.startswith("evidence/"))
state=json.loads((E/"wd-state.json").read_text());assert not state["active_work"]["primaries"]
members={}
for p in sorted(E.iterdir()):
 if p.is_file() and p.name.startswith("mvp024-full-preparation") and p.name not in already:
  if p.name.endswith((".stdout",".stderr",".final.txt",".supervisor.log")):continue
  if p.name in ("mvp024-full-preparation-final-publication.zip","mvp024-full-preparation-final-publication-manifest.json"):continue
  if p.name=="mvp024-full-preparation-ci44009285018.log":continue
  members["evidence/"+p.name]=p
for p in sorted((E/"mvp024-full-preparation-review-r1").iterdir()):
 assert p.is_file() and not p.is_symlink()
 members["review/"+p.name]=p
members["runtime/mvp020-review-runtime-r2.json"]=E/"mvp020-review-runtime-r2.json"
archive=E/"mvp024-full-preparation-final-publication.zip";entries={}
with zipfile.ZipFile(archive,"x",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,p in sorted(members.items()):
  raw=p.read_bytes();i=zipfile.ZipInfo(name,(2026,11,17,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,raw)
  entries[name]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and set(z.namelist())==set(entries)
 for name,v in entries.items():assert hashlib.sha256(z.read(name)).hexdigest()==v["sha256"]
receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),reviewed_head="d49e812bcb8bee8030175412d2eef7bfefbecffa",merge="bf1576828c2797f28f702370857b8bbc523e515e",tree="d37d9be8012702194a7700710ef5d12428e9e02f",archive_bytes=archive.stat().st_size,archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=entries,scope="Final PR74 exact gate, independent review, CI, push, PR body/readback, merge and tracker reconciliation; prior source/memory/admission evidence remains in evidence.zip and source-validation.zip.",publication="Complete immutable PASS report is in PR74 description. Source/memory PASS does not erase the 13-record admission failure. No full production import/index acceptance.",staged_outside_frozen_worktree=True)
with (E/"mvp024-full-preparation-final-publication-manifest.json").open("x") as f:json.dump(receipt,f,indent=2);f.write("\n")
print(json.dumps({k:v for k,v in receipt.items() if k!="members"}|dict(members=len(entries))))
