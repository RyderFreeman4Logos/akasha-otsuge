import hashlib,json,pathlib,sys,tarfile
repo=pathlib.Path.cwd();sys.path.insert(0,str(repo/'spikes/helix'))
from run_case import digest,publish
storage=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023');frozen=repo/'.spike-work/partial-retirement-r2';source=json.loads((frozen/'source.json').read_text());validation=json.loads((repo/'.git/akasha-evidence/partial-retirement-validation.json').read_text());assert source['native_sha256']==validation['native_sha256']==digest(frozen/'probe')
files={}
def add(prefix,root):
 for p in root.rglob('*'):
  if p.is_file() and p.name!='probe' and '__pycache__' not in p.parts:
   assert not p.is_symlink();files[prefix+'/'+str(p.relative_to(root))]=p
for phase in ['red-r1','green-r1','green-r2']:add(phase,storage/('fallback-partial-retirement-'+phase))
for n in [1,2]:add(f'frozen-r{n}',repo/f'.spike-work/partial-retirement-r{n}')
for group in ['source_sha256','helpers_sha256']:
 for name,want in source[group].items():assert digest(repo/name)==want,name
for p in (repo/'.git/akasha-evidence').iterdir():
 if p.is_file() and ('partial-retirement' in p.name):files['collector/'+p.name]=p
out=repo/'docs/benchmarks/results/fallback-partial-retirement';out.mkdir();archive=out/'raw.tar.gz';hashes={n:digest(p) for n,p in sorted(files.items())}
with tarfile.open(archive,'w:gz') as tf:
 for name,p in sorted(files.items()):tf.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tf:
 assert set(tf.getnames())==set(hashes)
 for m in tf.getmembers():assert hashlib.sha256(tf.extractfile(m).read()).hexdigest()==hashes[m.name],m.name
publish(out/'files.json',hashes)
summary=dict(status='passed_native_fixture',source_parent=source['parent'],native_sha256=source['native_sha256'],archive_files=len(files),archive_bytes=archive.stat().st_size,archive_sha256=digest(archive),validation=validation,regression='Retire empty, pending-baseline-backfill and failed-index-build candidates; SIGKILL after intent and deletion, idempotent resume, active queries and receipts unchanged',oracle_custody=json.loads((repo/'.git/akasha-evidence/partial-retirement-oracle-custody-r2.json').read_text()),review='implementing-agent self-review only',not_proven=['full generation4 reclamation','full concurrent resource acceptance','sole backend decision'])
publish(out/'summary.json',summary);print(json.dumps({k:summary[k] for k in ['status','native_sha256','archive_files','archive_bytes','archive_sha256']}))
