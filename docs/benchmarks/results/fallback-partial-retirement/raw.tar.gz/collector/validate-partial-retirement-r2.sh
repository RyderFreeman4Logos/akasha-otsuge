#!/usr/bin/env bash
set -euo pipefail
export PATH=/home/obj/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin:/usr/local/bin:/usr/bin:/bin
export RUSTUP_TOOLCHAIN=1.99.1 CARGO_TARGET_DIR=/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/target/storage-spike CARGO_BUILD_JOBS=2 LANCE_CPU_THREADS=2 MALLOC_MMAP_THRESHOLD_=131072
python3 .git/akasha-evidence/freeze-partial-retirement-r2.py
systemd-run --user --quiet --wait --pipe --collect --unit=akasha-partial-retirement-green-r2 -p MemoryMax=671088640 -p MemorySwapMax=0 -p LimitNOFILE=8192 -p WorkingDirectory="$PWD" -p Environment=MALLOC_MMAP_THRESHOLD_=131072 -p Environment=LANCE_CPU_THREADS=2 -p Environment=LANCE_FTS_NUM_SHARDS=1 -p Environment=LANCE_FTS_PARTITION_SIZE=32 -p Environment=LANCE_DEFAULT_IO_BUFFER_SIZE=16777216 python3 .spike-work/partial-retirement-r2/measure.py .git/akasha-evidence/partial-retirement-green-r2-memory.jsonl python3 .spike-work/partial-retirement-r2/fallback/check_lifecycle.py .spike-work/partial-retirement-r2/probe .spike-work/partial-retirement-r2/eight-real.jsonl /ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023/fallback-partial-retirement-green-r2 > .git/akasha-evidence/partial-retirement-green-r2.log 2>&1
cargo test --release --locked --offline --manifest-path spikes/fallback/Cargo.toml > .git/akasha-evidence/partial-retirement-unit-r2.log 2>&1
cargo clippy --release --all-targets --locked --offline --manifest-path spikes/fallback/Cargo.toml -- -D warnings > .git/akasha-evidence/partial-retirement-clippy-r2.log 2>&1
