# Implementing-agent self-review — incomplete generation retirement

Verdict: PASS for this source change. This is self-review, not independent
review or full-size acceptance. Parent ccbe34e; native8f0b2b2f.

- Public generation retirement is the only caller. The controller and native
  authority ownership locks still exclude competing processes.
- Remove only the inactive target's ready requirement and permit its durable
  tombstone in read_state. All identity/corpus/cursor/pending-wave validation
  remains. The active generation must remain ready and drained; active-target
  deletion and pending delta work remain rejected.
- Existing retirement writes its tombstone before deletion, removes only names
  derived from the target generation, persists every completed table, and treats
  public TableNotFound as already removed. This works for never-created tables,
  interrupted baseline backfill, and partially built indexes without claiming
  they were ready or extending their build deadline.
- State access prevents reuse/build/backfill after the tombstone. Authority
  history, receipts and active search results remain outside deletion scope.
- Native RED reaches the new regression and rejects the unready target. GREEN-r1
  instead exposes one old contradictory negative fixture. Its failure is kept;
  remove that obsolete expectation, with all new assertion bytes unchanged.
- GREEN-r2 passes223 commands,19 SIGKILL barriers and2 competing-owner refusals.
  Twelve release units and all-targets Clippy pass. Current admission/concurrent
  behavior is unchanged; no redundant160s workload rerun is claimed.
- Actual full generation4 cleanup and fresh concurrent acceptance remain separate
  pending steps. Deleted derived tables cannot be reused under the retired ID;
  their authority content remains available for a new generation.
