import json,pathlib,subprocess,sys
repo=pathlib.Path.cwd();sys.path.insert(0,str(repo/'spikes/helix'))
from run_case import digest,process_identity,publish
storage=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023');frozen=repo/'.spike-work/partial-retirement-r2';source=json.loads((frozen/'source.json').read_text());sha=source['native_sha256'];assert digest(frozen/'probe')==sha
for group in ['source_sha256','helpers_sha256']:
 for name,want in source[group].items():assert digest(repo/name)==want,name
reports={}
for phase,code in [('red-r1',1),('green-r1',1),('green-r2',0)]:
 root=storage/('fallback-partial-retirement-'+phase);admission=json.loads((root/'admission.json').read_text());memory=repo/'.git/akasha-evidence'/('partial-retirement-'+phase+'-memory.jsonl');events=[json.loads(line) for line in memory.open()];exes=[e for e in events if e['event']=='executable'];assert len(exes)==1
 assert events[0]['limits']['memory.max']=='671088640' and events[0]['limits']['memory.swap.max']=='0' and events[0]['nofile_soft_hard']==[8192,8192]
 assert events[-1]['event']=='exit' and events[-1]['code']==events[-1]['native_code']==code
 scratch=events[-1]['scratch_cleanup'];assert scratch['removed'] and not pathlib.Path(scratch['path']).exists()
 for ident in [admission['controller'],*exes]:
  now=process_identity(ident['pid']);assert now is None or now['start_ticks']!=ident['start_ticks']
 assert not pathlib.Path(admission['temporary_root']).exists()
 unit='akasha-partial-retirement-'+phase;assert subprocess.check_output(['systemctl','--user','show',unit,'-p','ActiveState','--value'],text=True).strip() in {'inactive','failed'}
 samples=[e for e in events if e['event']=='sample'];assert not any(int(e['memory_events'].get(k,0)) for e in samples for k in ['oom','oom_kill'])
 report=dict(status='passed' if not code else 'expected_red' if phase=='red-r1' else 'obsolete_fixture_expectation',exit=code,seconds=events[-1]['seconds'],rss_max_bytes=max(e['engine_rss_bytes'] for e in samples),observer_and_controller_gone=True,unit_inactive=True,fixture_removed=True,scratch_removed=True,memory_sha256=digest(memory))
 if not code:
  result=json.loads((root/'result.json').read_text());assert result['status']=='passed' and result['checks']==223 and result['temporary_root_removed'];assert admission['binary_sha256']==sha
  for name,want in result['artifact_sha256'].items():assert digest(root/name)==want,name
  for r in result['records']:
   now=process_identity(r['child']['pid']);assert now is None or now['start_ticks']!=r['child']['start_ticks']
  kills=sum(r['kill'] is not None for r in result['records']);assert kills==19 and len(result['contenders'])==2
  report.update(commands=223,sigkill_barriers=kills,contenders=2,artifacts_verified=True,exact_native_processes_gone=True)
 else:report['artifact_sha256']={p.name:digest(p) for p in root.iterdir() if p.is_file()}
 publish(root/'verified.json',report);reports[phase]=report
assert '12 passed; 0 failed' in (repo/'.git/akasha-evidence/partial-retirement-unit-r2.log').read_text()
publish(repo/'.git/akasha-evidence/partial-retirement-validation.json',dict(native_sha256=sha,release_units=12,release_clippy='passed',reports=reports,concurrent_retest='not repeated: only offline retirement policy and its state validation changed'))
print(json.dumps(reports['green-r2']))
