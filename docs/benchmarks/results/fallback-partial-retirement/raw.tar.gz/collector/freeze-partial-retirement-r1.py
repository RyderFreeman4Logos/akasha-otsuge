import hashlib,json,pathlib,shutil,subprocess
repo=pathlib.Path.cwd();old=repo/'.spike-work/shared-session-r1';root=repo/'.spike-work/partial-retirement-r1'
x=json.loads((old/'source.json').read_text());root.mkdir()
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for group in ['source_sha256','helpers_sha256']:
 for name in x[group]:
  source=repo/name;target=root/pathlib.Path(name).relative_to('spikes');target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target);x[group][name]=digest(source)
shutil.copy2(repo/'target/storage-spike/release/akasha-fallback-probe',root/'probe')
shutil.copyfile(old/'eight-real.jsonl',root/'eight-real.jsonl')
assert digest(root/'eight-real.jsonl')==x['fixture_sha256']
x.update(parent=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),native_sha256=digest(root/'probe'),change='retire inactive incomplete candidates through existing durable tombstone and native table deletion; preserve active authority and deadlines')
(root/'source.json').write_text(json.dumps(x,indent=2)+'\n')
print(json.dumps(dict(native_sha256=x['native_sha256'],source_files=len(x['source_sha256']))))
