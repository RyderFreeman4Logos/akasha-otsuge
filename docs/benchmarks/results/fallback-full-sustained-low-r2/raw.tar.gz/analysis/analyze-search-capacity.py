import collections,json,pathlib,sys
root=pathlib.Path(sys.argv[1]);state=json.loads((root/'state.json').read_text());assert state['phase']=='completed'
rows=[json.loads(line) for line in (root/'runtime/requests.jsonl').read_text().splitlines()];requests=[r for r in rows if r['operation'] in {'bm25','ann'}];queries=json.loads(pathlib.Path(json.loads((root/'request.json').read_text())['fixture']).read_text())['queries']
def distribution(values):
 values=sorted(values);return dict(count=len(values),mean=sum(values)/len(values),p50=values[(len(values)-1)//2],p95=values[(95*len(values)+99)//100-1],maximum=values[-1]) if values else None
previous_client={};previous_search=0;estimates=[]
for row in sorted(requests,key=lambda r:r['completed_seconds']):
 arrival=max(row['scheduled_seconds'],previous_client.get(row['client'],0));start=max(arrival,previous_search);end=row['completed_seconds'];index=row.get('receipt',{}).get('query_index');q=queries[index] if index is not None else {}
 estimates.append(dict(client=row['client'],ordinal=row['ordinal'],operation=row['operation'],completed_seconds=end,scheduled_debt_s=arrival-row['scheduled_seconds'],estimated_wait_s=max(0,start-arrival),estimated_service_s=max(0,end-start),observed_latency_s=row['seconds'],query_index=index,term=q.get('term'),partition=q.get('partition')));previous_client[row['client']]=end;previous_search=end
windows=[]
for lo in range(0,1800,300):
 window=[r for r in estimates if lo<=r['completed_seconds']<lo+300];windows.append(dict(start=lo,end=lo+300,counts=dict(collections.Counter(r['operation'] for r in window)),estimated_service=distribution([r['estimated_service_s'] for r in window]),latency=distribution([r['observed_latency_s'] for r in window])))
report={'basis':'inference from one search permit, FIFO acquisition and previous client completion; queue/service times were not directly instrumented; includes possible ordinary-admission scheduling overhead','operations':{k:{'observed_latency_s':distribution([r['observed_latency_s'] for r in estimates if r['operation']==k]),'estimated_service_s':distribution([r['estimated_service_s'] for r in estimates if r['operation']==k])} for k in ['bm25','ann']},'windows':windows,'slowest_estimated_service':sorted(estimates,key=lambda r:r['estimated_service_s'],reverse=True)[:20]}
(root/'search-capacity-inference.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='slowest_estimated_service'}));print('slowest',json.dumps(report['slowest_estimated_service'][:5]))
