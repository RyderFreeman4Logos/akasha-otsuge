import hashlib,json,pathlib,subprocess,sys,tarfile
repo=pathlib.Path.cwd();sys.path.insert(0,str(repo/'spikes/helix'))
from run_case import digest,process_identity,publish
storage=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023');root=storage/'fallback-legacy-reserve-green-r1';frozen=repo/'.spike-work/legacy-reserve-r1';source=json.loads((frozen/'source.json').read_text());sha=source['native_sha256'];custody=json.loads((repo/'.git/akasha-evidence/legacy-reserve-oracle-custody.json').read_text())
assert digest(frozen/'probe')==sha and digest(repo/'spikes/fallback/check_legacy_binding.py')==custody['oracle_sha256']
for group in ['source_sha256','helpers_sha256']:
 for name,want in source[group].items():assert digest(repo/name)==want,name
subprocess.run([sys.executable,str(repo/'.git/akasha-evidence/collect-rebuild-recovery-step.py'),str(root),str(repo/'.git/akasha-evidence/legacy-reserve-green-r1-memory.jsonl'),'akasha-legacy-reserve-green-r1'],check=True)
verified=json.loads((root/'verified.json').read_text());assert verified['commands']==15
admission=json.loads((root/'admission.json').read_text());assert admission['binary_sha256']==sha and admission['legacy_binary_sha256']==custody['legacy_native_sha256'] and not pathlib.Path(admission['temporary_root']).exists()
records=json.loads((root/'commands.json').read_text())
for i,row in enumerate(records):
 expected=custody['legacy_native_sha256'] if i<3 else sha;assert digest(row['command'][0])==expected
 assert row['exit']==(1 if row['expected_error'] else 0)
for n in [1,2]:
 failed=storage/f'fallback-legacy-reserve-red-r{n}';a=json.loads((failed/'admission.json').read_text());assert not pathlib.Path(a['temporary_root']).exists()
 for row in json.loads((failed/'commands.json').read_text()):
  actual=process_identity(row['child']['pid']);assert actual is None or actual['start_ticks']!=row['child']['start_ticks']
 events=[json.loads(line) for line in (repo/f'.git/akasha-evidence/legacy-reserve-red-r{n}-memory.jsonl').open()];end=events[-1];assert end['event']=='exit' and end['code']==end['native_code']==1 and end['scratch_cleanup']['removed'] and not pathlib.Path(end['scratch_cleanup']['path']).exists()
 assert subprocess.check_output(['systemctl','--user','show',f'akasha-legacy-reserve-red-r{n}','-p','ActiveState','--value'],text=True).strip()=='inactive'
unit=(repo/'.git/akasha-evidence/legacy-reserve-unit-r1.log').read_text();assert '13 passed; 0 failed' in unit
validation=dict(status='passed_focused_native',native_sha256=sha,unit_tests=13,clippy='passed_release_all_targets',native=verified,oracle_custody=custody,source_parent=source['parent'],full_case='not_started')
publish(repo/'.git/akasha-evidence/legacy-reserve-validation.json',validation)
files={}
for prefix,path in [('red-r1',storage/'fallback-legacy-reserve-red-r1'),('red-r2',storage/'fallback-legacy-reserve-red-r2'),('green-r1',root),('frozen-r1',frozen)]:
 for p in path.rglob('*'):
  if p.is_file() and p.name!='probe' and '__pycache__' not in p.parts:
   assert not p.is_symlink();files[prefix+'/'+str(p.relative_to(path))]=p
for p in (repo/'.git/akasha-evidence').iterdir():
 if p.is_file() and ('legacy-reserve' in p.name or p.name=='corpus-identity-independent-review-r2.md'):files['collector/'+p.name]=p
out=repo/'docs/benchmarks/results/fallback-legacy-reserve';out.mkdir();archive=out/'raw.tar.gz';hashes={n:digest(p) for n,p in sorted(files.items())}
with tarfile.open(archive,'w:gz') as tf:
 for name,p in sorted(files.items()):tf.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tf:
 assert set(tf.getnames())==set(hashes)
 for m in tf.getmembers():assert hashlib.sha256(tf.extractfile(m).read()).hexdigest()==hashes[m.name],m.name
publish(out/'files.json',hashes)
summary=dict(**validation,archive_files=len(files),archive_bytes=archive.stat().st_size,archive_sha256=digest(archive),change='One reservation check before missing legacy manifest write; already-bound reuse/status remain readable',review='independent R2 closed original identity/EOF findings, found this reservation gap; successor re-review pending',not_repeated=['231-command lifecycle','85-command search','160s concurrent fixture'],not_proven=['full original-manifest binding','full concurrent resource acceptance','sole backend decision'])
publish(out/'summary.json',summary);print(json.dumps({k:summary[k] for k in ['status','native_sha256','archive_files','archive_bytes','archive_sha256']}))
