#!/usr/bin/env bash
set -euo pipefail
export PATH=/home/obj/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin:/usr/local/bin:/usr/bin:/bin
export RUSTUP_TOOLCHAIN=1.99.1 CARGO_TARGET_DIR=/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/target/storage-spike CARGO_BUILD_JOBS=2 LANCE_CPU_THREADS=2 MALLOC_MMAP_THRESHOLD_=131072
cargo test --release --locked --offline --manifest-path spikes/fallback/Cargo.toml > .git/akasha-evidence/legacy-reserve-unit-r1.log 2>&1
cargo clippy --release --all-targets --locked --offline --manifest-path spikes/fallback/Cargo.toml -- -D warnings > .git/akasha-evidence/legacy-reserve-clippy-r1.log 2>&1
cargo build --release --locked --offline --manifest-path spikes/fallback/Cargo.toml > .git/akasha-evidence/legacy-reserve-build-r1.log 2>&1
python3 .git/akasha-evidence/freeze-legacy-reserve-r1.py
systemd-run --user --quiet --wait --pipe --collect --unit=akasha-legacy-reserve-green-r1 -p MemoryMax=671088640 -p MemorySwapMax=0 -p LimitNOFILE=8192 -p WorkingDirectory="$PWD" -p Environment=MALLOC_MMAP_THRESHOLD_=131072 python3 .spike-work/legacy-reserve-r1/measure.py .git/akasha-evidence/legacy-reserve-green-r1-memory.jsonl python3 .spike-work/legacy-reserve-r1/fallback/check_legacy_binding.py .spike-work/legacy-reserve-r1/probe .spike-work/partial-retirement-r2/probe /ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023/fallback-legacy-reserve-green-r1 > .git/akasha-evidence/legacy-reserve-green-r1.log 2>&1
