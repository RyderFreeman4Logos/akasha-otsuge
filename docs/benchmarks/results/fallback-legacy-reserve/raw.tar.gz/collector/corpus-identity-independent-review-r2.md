VERDICT: FAIL

# Issue #3 / draft PR #31 independent native re-review, round 2

R1 (corpus identity) and R2 (trailing EOF blank line) are closed. One MODERATE regression remains in the new legacy metadata binding: it commits a write before native disk-reservation admission. ACTIONABLE_COUNT: 1. This is a bounded frozen-source verdict, not benchmark acceptance, a CSA tier verdict, merge approval, or issue-closure evidence.

## Frozen identity and execution boundary

- Repository: `/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge`.
- Branch: `spike/mvp-003-storage`.
- HEAD: `bf5e62ced38926e7ca2cfda543f724f8d251e2bb`.
- Tree: `f802fb1a59154f1e61a6a292d005d92a01783b11`.
- Observed `origin/main` and independently resolved merge-base: `349431a350e9e4ae3364b126c4d2a7133dd37d22`.
- Regression attribution: `origin/main...bf5e62ced38926e7ca2cfda543f724f8d251e2bb`; immediate repair parent: `0060e4255d03c485ea58ab34f1ef90ba3f1652c1`.
- Retained native binary SHA-256, independently rehashed without execution: `4028cb8e9164218029f6396c88172ace7d7f356f148247794b14ce4c9d955125`.

The applied skill was `/home/obj/.codex/skills/native-code-review/SKILL.md`, with applicable scope/attribution, source/evidence, acceptance, identity, materialized-index, integrity, durable-state, verdict and frozen-report finalization references. Source was read from immutable Git blobs. The assignment expressly prohibited Cargo, tests, benchmarks, full database/corpus reads, large-archive extraction, fetching/pushing, other agents and another WD relay. No such operation occurred. Only this report and its named companion progress JSON were written. The parent retained implementation, database and shared-relay ownership.

## Actionable finding

### R3 — REGRESSION / MODERATE (P2): legacy manifest binding bypasses the configured native disk reservation

**Trigger and result.** On an existing imported root whose `meta:import-manifest` is absent, submit `begin` for an existing valid generation with its unchanged bundle and byte-identical original manifest. Configure `AKASHA_SPIKE_DISK_RESERVE_BYTES` above available free space, for example the already supported test value `18446744073709551615`. The new path durably writes the missing manifest and returns the existing generation successfully. A fresh-generation request on the same legacy root instead writes the manifest first and only then rejects for insufficient reservation.

**Exact path.** `spikes/fallback/src/main.rs:310-315` exposes `derive` and `--generation` through `search::run`. `search.rs:53-69` accepts a sufficiently large reserve; `Settings::read` does not enforce free space. `Authority::open` at `authority.rs:202-215` likewise does not call `check_disk`. In `search.rs:1165-1173`, the new missing-manifest branch executes `tx.set_durability(Durability::Immediate)`, `tx.set(load::MANIFEST, &bytes)?`, and `tx.commit().await?` without `settings.check_disk(root)?`. The only Begin reservation check remains at `search.rs:1200`, inside the fresh-generation branch after the manifest commit. The existing-generation branch at `1175-1181` never reaches it.

This is a reachable native admission bypass, not a claim that the parent performed a low-space write. The generation controller has its own admission, but the direct native entry point is supported and is exercised by the native fixtures; that controller does not make the native path unreachable. The pre-repair Begin did not perform this metadata write. The new hunk therefore introduces the bypass; these runtime files are also additions in the authoritative base range.

**Contract and consequence.** The brief preserves existing resource boundaries. `docs/benchmarks/storage-contract.md:51-53` requires reservation before ingestion/reindex effects; `spikes/fallback/README.md:412-413` says read-only status ignores free-space admission while mutations retain their reservation check. The new bounded metadata write is neither read-only status nor the explicitly allowed space-reclaiming prune/retire operations. It can consume reserved commit space despite the caller's explicit denial budget. No data-corruption outcome is asserted.

**Required repair.** Check `settings.check_disk(root)?` immediately before the missing-manifest write/commit. Keep already-bound Begin reuse and status readable under the exhausted-reservation setting. Add a focused negative control proving that a valid legacy binding with an exhausted reservation fails and leaves `meta:import-manifest` absent, then restore the normal reserve and prove binding/reopen succeeds without changing the original generation/deadlines. Existing identity and cleanup assertions should remain unchanged. Source tracing establishes this finding; execution was prohibited and no dynamic reproduction is claimed.

## Prior-finding closure and class sweep

| Boundary | Source proof and disposition |
| --- | --- |
| Original bytes and source SHA | `load.rs:144-164` bounds the manifest to 1 MiB and hashes exact input bytes. `199-204` persists those bytes with initial import state in one Immediate transaction. `122-131` rejects absent, oversized or hash-mismatched persisted metadata. Existing malformed metadata cannot be silently overwritten by a supplied good file: `search.rs:1166-1167` validates the persisted copy. |
| Semantic publisher identity | `search.rs:138-201` either deserializes an explicit `embedding_bundle` or validates the fixed publisher model/dimension/date/chunk size and every recognized vector input repository/revision. Empty/missing vector inputs fail. Required malformed types or fields fail validation. The explicit-bundle branch rejects coexisting publisher fields or `corpus.inputs`, so mixed declaration forms cannot select an alternate identity. |
| Publisher consistency | `spikes/data/prepare_corpus.py:87-105` records pinned input provenance and copies whole source vector documents; `181-186` publishes the checked fields. The fingerprint input at `search.rs:182-190` matches the existing Helix corpus rule at `spikes/helix/src/generations/corpus.rs:55-104`. The fixed fallback lockfile does not enable serde_json's indexmap-backed preserve-order dependency. No new provider or general corpus importer is claimed. |
| Fresh generations and schema upgrades | `search.rs:1149-1164` validates shape, original SHA and semantic identity before any generation creation; the comparison at `194-199` binds model/fingerprint/dimension/chunker while deliberately excluding schema. `validate` still requires nonzero schema and dimension 1536. Existing-generation reuse at `1177-1179` compares the entire requested bundle. R1's fresh-ID relabeling path is closed. |
| Legacy binding and deadlines | Missing metadata fails ordinary reads. Begin accepts only the original import SHA and persists exact bytes; `1176-1181` returns existing state without a `save` or resetting deadlines. The old state and byte equality checks in `changes.rs:1078-1099` cover deletion/rebinding and repeated binding. The reservation ordering defect above is separate from identity correctness. |
| Common state read | `search.rs:349-379` reads generation, import state and persisted manifest through one transaction, validates semantic identity, then validates generation/source/counts. `state` at `382-387` adds retirement rejection. Previously relabeled persisted state is rejected, rather than trusted because its query/output labels agree. |
| Query/workload | CLI baseline query uses `state` at `search.rs:1331`. Current query does so at `changes.rs:855` before query availability/bundle checks and candidate retrieval. `workload_backend.rs:100-105` pins through `state`; `122-139` checks both rebuild states; `150-168` routes workload search through current query. Its derived oracle also requires `changes::status` before returning at `261-275`. No returning evidence path bypass was found. |
| Apply and replay | `changes.rs:321-338` validates `state` before checking output or completed-job reuse; both already-completed and pending replay therefore inherit the guard. Output model/fingerprint/body/dimension checks at `130-152`, completion hash checks, pending source/payload checks and watermark progression remain intact. Catch-up starts with `state` at `952` and dispatches through the same `apply` at `997`. |
| Other consumers | Advance (`changes.rs:495-498`), lifecycle status (`500-501`), prune (`522-523`), retirement (`627-631`), indexed receipts (`712`), activation (`741`) and baseline build (`search.rs:1097`, `1115`) all use `state` or `read_state`. No sibling generation decoder bypass was found. |
| Close and error precedence | `search.rs:1138-1338` evaluates request work into a Result, always awaits `tree.close()`, then propagates `result?` before `closed?`. This fixes rejected-request lock retention while preserving the primary operation error. Existing stored operation deadlines, timeout arguments and resource settings are unchanged apart from the R3 insertion ordering gap. No bound on close latency or resistant-cancellation behavior is inferred. |
| R2 whitespace | The read-only `git diff --check origin/main...bf5e62ced38926e7ca2cfda543f724f8d251e2bb` returned zero twice during review. `spikes/oracle_model.rs` no longer adds the trailing blank line. |

## Supplied execution evidence and its limits

The retained release unit log explicitly reports 13 selected tests, including `corpus_identity_survives_legacy_binding_and_rejects_relabeling`; release all-target Clippy output completes successfully. The exact focused GREEN log reports 1 passed, 12 filtered out. The new unit enters the real `search::run` request boundary, rejects three fresh-ID semantic changes, proves no generation is left, allows schema-only upgrade, rejects absent/wrong legacy metadata, preserves state/deadlines on binding, and refuses relabeled state through workload pin, status, query-current and apply. `check_lifecycle.py:60-64` adds native model/fingerprint/chunker/dimension refusals; the same fixture still covers schema upgrade, delta/replay and crash cases. These are supplied executed results, not executions by this reviewer.

The native RED log reaches a failing assertion for command 001 after old-native load; the unit RED log selects one test and fails with `fresh generation accepted mismatched corpus identity`. The first native attempt is a Python syntax failure before load, and the first unit attempt is an ambiguous `Vec::as_ref` compile failure: both are retained setup failures and excluded from behavioral RED. GREEN attempts 1 and 2 retained the lock failure after the first identity denial; GREEN 3 shows both the denial and subsequent successful reopen. The custody file's historical region-transition claim remains supplied provenance; the reviewer did not recreate historical test source or execute either side.

The compact native summary reports 231 lifecycle commands / 19 SIGKILL boundaries / 2 contenders, 21 import commands, 85 search commands, and a 160-second / 100-client / 4,528-request small concurrent fixture. Its absent optional legacy text-layout binary run is explicit. The root gate receipt binds this exact HEAD/tree and its log reports plan validation, 6 Python tests, 4 CLI tests, 17 config tests, root Clippy/build/version. The root manifest contains only the root package; this gate is distinct from native fallback execution.

All 12 native source hashes and 11 helper hashes in `.spike-work/corpus-identity-r1/source.json` were recomputed from frozen Git blobs and matched both receipt entries and retained snapshot files. The retained executable was independently rehashed and matches the native SHA above. The source receipt names the precommit parent; content equality binds its source to this frozen candidate. Large archives and raw corpus files were not opened. Raw native leaf archives were not exhaustively re-inspected; summary verification flags remain supplied evidence.

| Retained artifact | Independently computed SHA-256 |
| --- | --- |
| `.spike-work/corpus-identity-r1/source.json` | `614cce744782c3c4d8a9c3a2a7c9a069f2c27146e041db8749849edd9fcd8b95` |
| `.git/akasha-evidence/corpus-identity-root-gate-r1.json` | `62ed1e31c383ba43b4817ce9bd5ce1f2b76823a991159f16f6e5dd875121b035` |
| `.git/akasha-evidence/corpus-identity-root-gate-r1.log` | `95b91ecf6c7d4df7980a88aa41a14d52ded5efda4ae74257dc6748f2315d85ee` |
| `.git/akasha-evidence/corpus-identity-unit-r1.log` | `fee530e850c0a1c17442cc6b5d08ff4fbc05bb04517e0e475e70dabdf49b8835` |
| `.git/akasha-evidence/corpus-identity-clippy-r1.log` | `680a34e66a0a0db7c2cb8c79703d4255ad9173cae68383552a748033c520a3dd` |
| `.git/akasha-evidence/corpus-identity-oracle-custody-final.json` | `c37aa8e1249facf85768a961600a740f2b6ce254fad63cef3e4eca51a8943a77` |
| `docs/benchmarks/results/fallback-corpus-identity/summary.json` | `205c13df74f74a757bd2884f34bd9da2f247000fd17b3a14f1c428a977f814fd` |

Other inspected attempt hashes are retained in the companion progress JSON. Source/custody identity does not turn the untested disk-reservation branch into a passing control.

## Read coverage, instructions and final custody

Read in full from frozen blobs: fallback `src/load.rs`, `src/search.rs`, `src/search/changes.rs`, `src/search/workload_backend.rs`, `check_lifecycle.py`, `check_search.py`, `Cargo.toml`; data `prepare_corpus.py`, `prepare_vectors.py`; root `Cargo.toml`, `scripts/check.sh`; issue `MVP-003.md`. Selectively read: Authority open, main storage settings/dispatch, fallback lock dependency section, README identity/resource clauses, storage contract, Helix publisher identity helper and generation controller, and the compact corpus-identity summary. Whole-file hashes are recorded separately and do not imply whole-file semantic review. Prior R1 broad-source review remains context; this re-review is limited to its repair class.

Exact filesystem `AGENTS.md` and `CLAUDE.md` checks preceded source reads. Both were absent and not symlinks at `/`, `/home`, `/home/obj`, `/home/obj/project`, `/home/obj/project/github`, `/home/obj/project/github/RyderFreeman4Logos`, and the repository root. The initial repository source traversal found no nested instruction files. Exact evidence/source descendant checks also found none: `spikes`, fallback/src/search, data, Helix/src/generations, docs/benchmarks/results/fallback-corpus-identity, docs/spec/issues, scripts, `.git/akasha-evidence`, and `.spike-work/corpus-identity-r1`, including their intermediate directories. The companion progress JSON records all 52 exact logical paths; there are no resolved instruction targets or line counts because every checked file was absent.

At review start HEAD/tree matched the freeze and porcelain was empty. Pre-report attestation at `2026-10-24T10:57:16.465305+00:00` and post-provisional-write attestation at `2026-10-24T10:57:16.488704+00:00` confirm the same HEAD/tree/base/merge-base/branch, empty porcelain, no index lock and equality of all 20 reviewed working blobs with frozen bytes. `.git` and the evidence directory are real directories, not symlinks. A final post-report attestation and the report's actual whole-file SHA-256 are recorded externally in the progress JSON and terminal receipt; the report does not self-embed its hash.

No tests/builds/benchmarks, full database binding or optional legacy binary rerun were performed by this reviewer. The parent-reported full database remains legacy with active generation 3 and candidate 5; it was not inspected or mutated. Full concurrent resource acceptance, backend selection, merge and issue closure remain separate. R3 must be fixed and reviewed on a new frozen candidate before this source verdict can pass.

VERDICT: FAIL
