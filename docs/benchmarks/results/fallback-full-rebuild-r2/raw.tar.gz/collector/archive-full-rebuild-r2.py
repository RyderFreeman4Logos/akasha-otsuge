import hashlib,json,pathlib,sys,tarfile
repo=pathlib.Path.cwd();sys.path.insert(0,str(repo/'spikes/helix'))
from run_case import digest,publish
root=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023/fallback-full-rebuild-r2')
result=json.loads((root/'result.json').read_text());assert result['status']=='failed_full_concurrent_rebuild'
files={}
for prefix,tree in [('failed-run-and-reconciliation',root),('frozen-source',repo/'.spike-work/shared-session-r1')]:
    for p in tree.rglob('*'):
        if p.is_file() and p.name!='probe' and '__pycache__' not in p.parts:
            assert not p.is_symlink();files[prefix+'/'+str(p.relative_to(tree))]=p
names=['r2-reconcile-full-rebuild-r1.py','r2-verify-full-rebuild-acknowledgements.py','r2-verify-full-rebuild-acknowledgements-failed-r1.py','r2-restore-full-rebuild-sources.py','r2-drain-failed-rebuild-generation.py','collect-rebuild-r2-step.py','prepare-full-rebuild-r2.py','measure-rebuild-disk.py','archive-full-rebuild-r2.py','full-rebuild-r2-prefix-metrics.json','full-rebuild-r2-query-peak-correlation.json','obsolete-native-inventory-r1.json','obsolete-native-cleanup-r1.json']
for name in names:files['collector/'+name]=repo/'.git/akasha-evidence'/name
for name in ['reconcile','acks','acks2','restore','drain3']:
    for suffix in ['-memory.jsonl','.log']:
        p=repo/'.git/akasha-evidence'/f'full-rebuild-r2-{name}{suffix}'
        assert p.is_file();files['collector/'+p.name]=p
out=repo/'docs/benchmarks/results/fallback-full-rebuild-r2';out.mkdir()
archive=out/'raw.tar.gz';hashes={n:digest(p) for n,p in sorted(files.items())}
with tarfile.open(archive,'w:gz') as tf:
    for name,p in sorted(files.items()):tf.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tf:
    assert len(tf.getnames())==len(hashes) and set(tf.getnames())==set(hashes)
    for member in tf.getmembers():assert hashlib.sha256(tf.extractfile(member).read()).hexdigest()==hashes[member.name]
publish(out/'files.json',hashes)
cleanup=json.loads((repo/'.git/akasha-evidence/obsolete-native-cleanup-r1.json').read_text())
summary=dict(result,archive_files=len(files),archive_bytes=archive.stat().st_size,archive_sha256=digest(archive),prefix_metrics=json.loads((repo/'.git/akasha-evidence/full-rebuild-r2-prefix-metrics.json').read_text()),obsolete_copy_cleanup={k:cleanup[k] for k in ['count','inode_allocated_bytes','filesystem_free_delta','note']},retained_harness_failure='Initial acknowledgement reader rejected the one incomplete trailing line before any native verification; complete-prefix reader controls passed, original bytes preserved, successful verification covers only complete receipts.')
publish(out/'summary.json',summary)
print(json.dumps({k:summary[k] for k in ['status','archive_files','archive_bytes','archive_sha256']}))
