import fcntl, hashlib, json, pathlib, sys, time
repo=pathlib.Path.cwd();sys.path[:0]=[str(repo/'spikes/helix'),str(repo/'spikes/fallback')]
from run_case import digest, publish
from check_real_search import run_native
storage=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023')
case=storage/'fallback-full-rebuild-r2/low'
state=json.loads((case/'state.json').read_text());assert state['phase']=='abandoned'
config=state['identity']['config'];binary=pathlib.Path(config['paths']['binary']);database=pathlib.Path(config['paths']['database'])
assert digest(binary)==state['identity']['binary_sha256']
owner=(database/'.akasha-case-owner.lock').open('a');fcntl.flock(owner,fcntl.LOCK_EX|fcntl.LOCK_NB)
output=storage/'fallback-full-rebuild-r2/reconcile';output.mkdir()
(output/'OWNER').write_text('akasha-otsuge MVP-003 failed rebuild readonly reconciliation\n')
sources=json.loads((case/'corrections.json').read_text());latest={};acknowledged=0;requests=0;incomplete=0;maximum=0
for line in (case/'runtime/requests.jsonl').open():
    if not line.endswith('\n'): incomplete+=1;continue
    row=json.loads(line);requests+=1
    if row['operation'] in {'write','correction'} and row['status']=='success' and 'oracle' in row['receipt']:
        acknowledged+=1;maximum=max(maximum,row['receipt']['commit_seq'])
        if row['operation']=='correction': latest[row['receipt']['oracle']['memory']]=row
assert set(latest)=={s['memory'] for s in sources}
records=[];started=time.monotonic()
def call(channel,request):
    path=output/f'{len(records):03d}.request.json';publish(path,request)
    stdout,stderr=run_native([str(binary),str(database),'--'+channel,str(path)],output,records)
    assert records[-1]['exit']==0 and not records[-1]['timed_out'],stderr[-1000:]
    publish(output/'progress.json',dict(completed=len(records),total=20,elapsed_s=time.monotonic()-started))
    return json.loads(stdout)
point=call('authority',dict(op='status'))['commit_seq']
candidate=call('generation',dict(op='status',generation=4))
lifecycle={g:call('generation',dict(op='lifecycle_status',generation=g)) for g in [3,4]}
assert not candidate['ready'] and candidate['cursor']==candidate['documents']==11428831 and candidate['vector_rows']==candidate['vectors']==1000000
assert all(v['active']==3 and v['committed']==point for v in lifecycle.values())
heads=[]
for source in sources:
    row=latest[source['memory']]
    entry=call('authority',dict(op='get',memory=source['memory'],at=point))
    receipt=call('authority',dict(op='receipt',request_id=f"{config['run']['id']}:{row['client']}:{row['ordinal']}"))
    expected={k:v for k,v in row['receipt'].items() if k!='oracle'}
    assert receipt==expected
    assert entry['seq']>=row['receipt']['commit_seq']
    heads.append(dict(memory=entry['memory'],seq=entry['seq'],scope=entry['scope'],active=entry['active'],body_sha256=hashlib.sha256(entry['body'].encode()).hexdigest(),restored=entry['active'] and entry['scope']==source['scope'] and entry['body']==source['body'],latest_logged_seq=row['receipt']['commit_seq']))
assert len(records)==20 and point>=maximum
publish(output/'result.json',dict(status='passed_readonly_sample',commands=20,committed=point,maximum_logged_commit=maximum,complete_logged_requests=requests,logged_acknowledgements=acknowledged,incomplete_lines=incomplete,candidate=candidate,lifecycle=lifecycle,heads=heads,all_acknowledgements_verified=False,request_log_sha256=digest(case/'runtime/requests.jsonl'),case_state_sha256=digest(case/'state.json'),driver_sha256=digest(__file__),native_sha256=digest(binary)))
print(json.dumps(dict(status='passed_readonly_sample',committed=point,logged_acknowledgements=acknowledged,restored_sources=sum(h['restored'] for h in heads),candidate_ready=candidate['ready'],original_deadline_ms=candidate['index_deadline_ms'])),flush=True)
