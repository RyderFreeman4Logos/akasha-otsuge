import fcntl,json,math,pathlib,sys,time
repo=pathlib.Path.cwd();sys.path[:0]=[str(repo/'spikes/helix'),str(repo/'spikes/fallback')]
from run_case import digest,process_identity,publish
from check_real_search import run_native

def complete_lines(path):
    with path.open() as source:
        for line in source:
            if not line.endswith('\n'):
                assert source.read() == '', 'incomplete interior request line'
                return
            yield line

def receipts(case):
    state=json.loads((case/'state.json').read_text());run=state['identity']['config']['run']['id']
    baseline=json.loads((case/'runtime/baseline.json').read_text());assert baseline['run_id']==run
    acknowledgements=[]
    for ordinal,entry in enumerate(baseline['heads']):
        memory,seq=entry['memory'],entry['seq']
        assert memory==baseline['base']+ordinal
        acknowledgements.append(dict(stage='committed',request_id=f'{run}-seed-{ordinal}',commit_seq=seq,revision=f'{memory:020}:{seq:020}',config_generation=1,oracle=entry))
    assert len(acknowledgements)==50
    requests=0
    for line in complete_lines(case/'runtime/requests.jsonl'):
        row=json.loads(line);requests+=1
        if row['operation'] in {'write','correction'} and row['status']=='success':
            receipt=row['receipt'];assert receipt['request_id']==f"{run}:{row['client']}:{row['ordinal']}"
            assert receipt['oracle']['seq']==receipt['commit_seq']>0
            acknowledgements.append(receipt)
    assert len({r['request_id'] for r in acknowledgements})==len({r['commit_seq'] for r in acknowledgements})==len(acknowledgements)
    return acknowledgements,requests

def main():
    binary=pathlib.Path(sys.argv[1]).resolve(strict=True)
    storage=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023');root=storage/'fallback-full-rebuild-r2';case=root/'low'
    state=json.loads((case/'state.json').read_text());assert state['phase']=='abandoned'
    reconciliation=json.loads((root/'reconcile/result.json').read_text());expected=reconciliation['committed']
    assert digest(case/'runtime/requests.jsonl')==reconciliation['request_log_sha256']
    assert digest(case/'state.json')==reconciliation['case_state_sha256']
    database=pathlib.Path(state['identity']['config']['paths']['database'])
    lock=(database/'.akasha-case-owner.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    acknowledgements,requests=receipts(case)
    assert requests==reconciliation['complete_logged_requests'] and len(acknowledgements)==reconciliation['logged_acknowledgements']+50
    output=root/'acknowledgements';output.mkdir();(output/'OWNER').write_text('akasha-otsuge MVP-003 full failed-workload acknowledgement verification\n')
    publish(output/'admission.json',dict(binary_sha256=digest(binary),driver_sha256=digest(__file__),controller=process_identity(__import__('os').getpid()),requests_sha256=digest(case/'runtime/requests.jsonl'),baseline_sha256=digest(case/'runtime/baseline.json'),case_state_sha256=digest(case/'state.json'),reconciliation_sha256=digest(root/'reconcile/result.json'),expected_commit_seq=expected,receipts=len(acknowledgements),batch_size=256,read_only=True))
    records=[];started=time.monotonic();verified=0
    for offset in range(0,len(acknowledgements),256):
        batch=acknowledgements[offset:offset+256];request=output/f'{len(records):03d}.request.json';publish(request,dict(op='verify_acknowledgements',receipts=batch))
        assert request.stat().st_size<=1024**2
        stdout,stderr=run_native([str(binary),str(database),'--authority',str(request)],output,records)
        assert records[-1]['exit']==0 and not records[-1]['timed_out'],stderr[-1000:]
        assert json.loads(stdout)==dict(verified=len(batch),commit_seq=expected)
        current=process_identity(records[-1]['child']['pid']);assert current is None or current['start_ticks']!=records[-1]['child']['start_ticks']
        verified+=len(batch);elapsed=time.monotonic()-started
        publish(output/'progress.json',dict(completed=verified,total=len(acknowledgements),elapsed_s=elapsed,rate_per_s=verified/elapsed,eta_s=(len(acknowledgements)-verified)*elapsed/verified))
    assert verified==len(acknowledgements) and len(records)==math.ceil(verified/256)
    seqs={r['commit_seq'] for r in acknowledgements}
    unknown=sorted(set(range(min(seqs),expected+1))-seqs)
    result=dict(status='passed_all_recorded_acknowledgements',recorded_requests=requests,workload_acknowledgements=verified-50,seed_acknowledgements=50,total_verified=verified,batches=len(records),commit_seq=expected,unlogged_committed_sequences=unknown,incomplete_trailing_lines=reconciliation['incomplete_lines'],scope='All complete persisted successful workload receipts and seed manifest entries; final incomplete line and missing buffered outcomes remain unknown. The original request log is unchanged.',seconds=time.monotonic()-started,artifacts={p.name:digest(p) for p in output.iterdir() if p.is_file()})
    publish(output/'result.json',result)
    print(json.dumps({k:result[k] for k in ['status','total_verified','batches','commit_seq','seconds','unlogged_committed_sequences']}),flush=True)

if __name__=='__main__':main()
