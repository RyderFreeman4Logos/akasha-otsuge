import datetime,importlib.util,json,os,pathlib,platform,subprocess,sys
repo=pathlib.Path.cwd();sys.path.insert(0,str(repo/'spikes/helix'))
from run_case import digest,publish
storage=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023');prior=storage/'fallback-full-rebuild-r1';root=storage/'fallback-full-rebuild-r2';database=storage/'fallback-full-compressed-r1/database';frozen=repo/'.spike-work/shared-session-r1'
prepared=json.loads((storage/'fallback-full-generation4-r1/result.json').read_text());assert prepared['status']=='prepared_not_built' and prepared['generation']==4 and prepared['active']==3
source=json.loads((frozen/'source.json').read_text());assert prepared['native_sha256']==source['native_sha256']==digest(frozen/'probe')
for group in ['source_sha256','helpers_sha256']:
 for name,want in source[group].items():assert digest(repo/name)==want,name
publication=json.loads((repo/'.git/akasha-evidence/shared-session-publication.json').read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert publication['head']==head and publication['remote_head']==head and publication['ci_conclusion']=='success' and publication['exact_head_gate']=='passed'
root.mkdir();(root/'OWNER').write_text('akasha-otsuge MVP-003 full concurrent rebuild shared-session candidate\n')
config=(prior/'low.toml').read_text().replace('fallback-full-rebuild-r1','fallback-full-rebuild-r2').replace('.spike-work/corpus-corrections-r2/','.spike-work/shared-session-r1/').replace('generation = 2','generation = 3').replace('rebuild_generation = 3','rebuild_generation = 4')
(root/'low.toml').write_text(config)
environment=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),platform=platform.uname()._asdict(),distribution=pathlib.Path('/etc/os-release').read_text(),affinity_cpus=sorted(os.sched_getaffinity(0)),load_average=os.getloadavg(),meminfo=pathlib.Path('/proc/meminfo').read_text(),swap=pathlib.Path('/proc/swaps').read_text(),pressure={p.name:p.read_text() for p in pathlib.Path('/proc/pressure').iterdir()},filesystem=subprocess.check_output(['df','-T',str(database)],text=True),rust=subprocess.check_output(['/home/obj/.rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustc','-Vv'],text=True),competing_work='No other task-owned native benchmark, Cargo build or full gate; parent evidence/source audit only. Other user activity is not controlled.')
publish(root/'environment.json',environment)
plan=json.loads((prior/'disk-plan.json').read_text());plan.update(active_generation=3,candidate_generation=4,candidate_commit=head,command=[sys.executable,str(frozen/'helix/run_case.py'),str(root/'low.toml')],run_output=str(root/'low'),evidence_output=str(root/'disk'),environment_sha256=digest(root/'environment.json'),publication_sha256=digest(repo/'.git/akasha-evidence/shared-session-publication.json'),created_utc=environment['utc'],finalized_utc=environment['utc'],status='ready_for_atomic_launch_admission',unchanged_workload_and_caps=True,reused_compressed_source_bytes=43986181099,expanded_input_retained_bytes=0)
spec=importlib.util.spec_from_file_location('disk_observer',repo/'.git/akasha-evidence/measure-rebuild-disk.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
initial=module.snapshot(database,root/'low',3,4);assert not module.violations(initial,plan)
remaining=sum(max(0,limit-initial['categories'][k]['allocated_bytes']) for k,limit in plan['allocated_byte_limits'].items());assert initial['free_bytes']>=remaining+plan['headroom_bytes']
publish(root/'physical-preflight.json',dict(admitted=True,initial=initial,remaining_allocated_budget_bytes=remaining,headroom_bytes=plan['headroom_bytes'],source='same unchanged category caps; actual snapshot after retirement/pruning/backfill'))
plan['preflight_sha256']=digest(root/'physical-preflight.json');publish(root/'disk-plan.json',plan)
print(json.dumps(dict(status='prepared_full_rebuild_r2',active_generation=3,candidate_generation=4,head=head,native_sha256=source['native_sha256'],free_bytes=initial['free_bytes'],initial_allocated_bytes=sum(v['allocated_bytes'] for v in initial['categories'].values()),seconds=3840)))
