Archive import accepts a longer matching history when the destination has no local tail, and replays older matching archives while retaining newer history. Complete validation precedes atomic directory exchange. Recovery preserves local commits and validates the replacement before deleting displaced history.

Ordinary opens require durable publication and a matching pending marker. Cleanup validates the opened directory inode. Native storage owns its runtime and directory through final asynchronous shutdown; cancelling a close waiter or ending the calling runtime cannot release that directory early. Admission locks explicitly unlock when their owner exits, including partial acquisition failures.

Refs #25. Changed mempal snapshot identities, updates and deletions remain unfinished under that issue.

Validation at e4f973de0c963f7cc26d577f735da04739fb682e:

- Exact clean-HEAD `just check` passed: 595 Rust passes, 35 intentional ignores, plus installed daemon lifecycle and UID isolation checks.
- Focused validation passed 71 Rust tests, six supervisor-child ignores, formatting and Clippy. Maintained regressions cover final native drop, caller-runtime handoff, admission descriptor copies and incremental recovery.
- [Independent conventional whole-range R3](https://github.com/RyderFreeman4Logos/akasha-otsuge/pull/61#issuecomment-6774692217) passed with zero actionable findings and its own 71-test focused run.
- [CI42866447962](https://github.com/RyderFreeman4Logos/akasha-otsuge/actions/runs/42866447962) passed on this exact HEAD. Logs confirm restoration and a primary-key Cargo cache hit.

The [shutdown repair archive](https://github.com/RyderFreeman4Logos/akasha-otsuge/blob/e4f973de0c963f7cc26d577f735da04739fb682e/docs/benchmarks/results/mvp025-incremental-final-drop/README.md) preserves the complete R2 FAIL, causal REDs and all failed diagnostics. A transient IMPORT_BUSY holder was not captured; the separate descriptor-copy failure and its repair are established. Earlier R1 evidence explicitly distinguishes its reconstructed report from the lost original.

Daybreak and new red-team campaigns are temporarily deferred by the owner; this review uses conventional code review and existing functional regressions. Product stress, changed legacy snapshots and actual Claude authentication remain separate acceptance work.
