VERDICT: PASS
ACTIONABLE_COUNT=0

# PR #61 / issue #25: independent conventional native review R3

No introduced regression or required in-scope contract gap was found in the complete frozen origin/main...HEAD range. This is the requested native fallback after Hermes failed, not a Hermes, CSA, Daybreak, hosted-CI, release, or whole-issue verdict. The reviewer performed the review directly. No nested delegate, reviewer, model session, or CSA was launched. The parent remains the sole product-source writer.

## Frozen scope and instructions

Original issue start: 2026-11-10T04:22:08.149789Z.
Original leaf start: 2026-11-10T12:23:08.907438Z.
Neither start was reset.

Checkout: /mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025.
Logical alias: /ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025, resolving to that checkout.
The exact /home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025 path is absent: exists=false and lexists=false, observed on the live filesystem. It was not treated as a required working checkout.

Branch: feat/mvp-025-incremental.
HEAD: e4f973de0c963f7cc26d577f735da04739fb682e.
Tree: 82e8ef59eab12c8bf79c1798c9f567f1da6008cd.
Frozen origin/main and independently computed merge base: fe30c78169fbf87bfa47cf06912b7c64d3a418b3.

All five commits were covered:

- a6a4b14: archive merged mempal reader acceptance.
- 6e692d6: exact common-history import and atomic publication.
- 0856401: persist incident admission before restart expiry in its fixture.
- 4a542e3: publication identity/durability and shared native directory ownership.
- e4f973d: owned native shutdown and admission-lock lifetimes.

The complete range has 234 changed paths: 12 Rust source/test files, two product/planning documents, five archive manifests and 215 manifest members. The tests log contains the exhaustive changed-path inventory, live instruction census, source-pin/member hashes and final filesystem-versus-Git blob attestations. Product source and tests were read, with shared callers and the actual native dependency followed; evidence was reviewed for identity, scope, failures and attribution, rather than promoting historical success to current acceptance.

Before source review, the live filesystem census checked 108 exact AGENTS.md/CLAUDE.md paths across changed subtrees and ancestors of the /mnt, /ssd and absent home spellings. All were absent, including lexists checks; there were no present symlinks requiring content/target/line-count reporting. Evidence-destination ancestors were also checked and absent. These are filesystem observations, not Git-tree inference. Read the named native-code-review skill and applicable conventional scope/regression attribution, exact-evidence, Rust, lifecycle, filesystem and report-integrity guidance. Applied Ponytail full. The memory lookup found older MVP-020 material and supplied no review facts.

The user scope override governs this leaf. No new adversarial campaign, ptrace probe or interposition attack probe was created or run. The requested maintained suites include existing final-drop, directory-ownership and fsync-EIO regressions for confirmed defects; those ran unchanged. Historical campaign sources were not executed. Deferred work is not labelled passed.

## Contract and source assessment

All source anchors below refer to the frozen HEAD above.

| Boundary | Assessment and evidence |
| --- | --- |
| Exact semantic prefixes | src/storage/import.rs:289, :375 and :494 compare the supplied receipt, outbox, clock and complete reconstructed revisions with stored history. Request-key ordering is not mistaken for a byte prefix. Older/equal input validates all supplied bytes and preserves newer imported and local history. Maintained roundtrip/prefix tests passed. |
| Longer history | import.rs:311 rejects any sequence beyond the old import boundary. The common-history comparison precedes publication. One complete native stage holds the longer history; bounded per-line/per-batch input and native sequence reconstruction avoid an all-history memory sort or second raw corpus copy. import_heads at :554 validates predecessor chains in sequence order. Divergent/local/corrupt successor regressions passed without loss of exported existing history. |
| Admission and path ownership | layout.rs:46 obtains shared ordinary-open or exclusive import/restore admission on both the data directory and compatible lock file. Named identities are revalidated. Root at import_publish.rs:54 retains an opened directory and uses its proc-FD path. Ordinary admission bridges native acquisition and validation; import retains exclusive admission through both native closes, publication and cleanup. Restore retains it through native copy, close, reopen and format publication. Existing live-exclusion and replacement regressions passed. |
| Durable publication | import_publish.rs:242 durably writes the bounded old/new directory/archive marker, then performs Linux EXCHANGE only for matching identities. Cleanup at :311 synchronizes the parent before removing old members, synchronizes removal, then removes and synchronizes the marker. Initial publication remains NOREPLACE. Native close errors prevent publication. Unsupported operations return errors instead of changing the protocol. |
| Recovery | import.rs:202 onward resolves pre/post-exchange identity; :221 validates native import identity; read_archive validates complete new input before :271 cleanup. Published recovery performs comparison rather than replacement, retaining post-exchange local commits. Pre-exchange local commits conflict. Invalid input/markers or foreign stage identity prevent deletion. Nine maintained incremental crash phases and local-write cases passed. |
| Ordinary open durability | mod.rs:293 synchronizes admission before native use and before returning success. Pending marker validation binds the authority Root and native import identity; export uses this shared open path, and daemon startup does too. Failure closes/refuses the store. The maintained public export/daemon fsync regression passed. This establishes controlled EIO behavior, not power-loss testing. |
| Runtime inactivity | import identity remains the imported history boundary. locally_created uses history at that boundary, so changing an imported job does not make its origin local. configuration.rs:188/:242 creates local runtime controls; jobs.rs:676 fences imported job admission/claim. The new incremental-runtime case and existing bootstrap/token/invocation/notification cases passed, including restart stability and fresh authorized work. No external model or actual host authentication was used. |

The CLI archive dispatch at src/main.rs:704 propagates import/export errors before success output. Export at src/storage/archive.rs:138 closes its store and propagates close failure. Daemon startup at src/daemon.rs:655 passes through Storage::open before imported runtime initialization. Existing commit, checkpoint and restore paths use the same PinnedTree constructor, not a sibling raw Tree builder.

## Native lifetime repair and prior-finding closure

The dependency remains SurrealKV 4338a790c8edc56ef5ea1e46157427af4815be3c. Cargo.toml and Cargo.lock equal the frozen base. The inspected dependency lsm.rs, transaction.rs and task.rs equal their pinned Git blobs; hashes are logged.

At src/storage/native.rs:25 the worker owns a Root clone before spawning, builds a current-thread Tokio runtime and constructs Tree inside that runtime. It holds an independent Arc<Tree>. Application handles share Arc<PinnedTree>, whose private bounded channel sender disappears only when the last shared wrapper disappears. No sender cycle exists in the worker. Channel exhaustion makes the worker await native close; runtime teardown precedes drop(owner) at :59-60. The descriptor consequently remains valid throughout the native deferred-close path that R2 identified.

The dependency's Core::new starts its flusher/background tasks only after fallible initialization completes (lsm.rs around :1998). Core::close at :2158 serializes close, drains checkpoints/restores and admitted commits, waits for flusher/background work, then closes/synchronizes native state. Tree::drop at :2872 only schedules Core::close when still open. The application now calls close while the worker still owns both the tree and Root, then drops the runtime before Root. The old field-order-only ownership defect is therefore removed at the shared boundary.

Lifecycle paths traced:

- Shared handles: the three production clone sites are commit (mod.rs:475), checkpoint (backup.rs:173) and restore (backup.rs:219). Each carries Arc<PinnedTree>, hence the root and channel sender, through owned work.
- Normal close: Storage::close first acquires the application writer lease; PinnedTree::close at native.rs:72 submits a oneshot reply through a capacity-one channel. The worker awaits native close and returns its actual result. Explicit close does not claim the worker thread has already exited; Root stays retained until final handle drop and teardown.
- Cancellation: cancellation before channel send admission does not schedule a close. Once sent, dropping the reply waiter does not cancel native close. Final sender loss still triggers shutdown. The commit task retains its writer lease and shared tree; native checkpoint/restore work retains the shared tree in spawn_blocking. Native close waits for admitted native operations.
- Caller-runtime destruction: native workers were created on the owned runtime, so destroying the caller runtime cannot remove their scheduler. The fresh handoff regression destroys the first runtime, then commits, reads, checkpoints and closes on another runtime successfully.
- Open errors: thread/runtime/build errors return explicit errors, and owned captures release on their normal error paths. Upstream startup has no fallible operation after launching background tasks. Failed initializer delivery still closes the constructed tree.
- Close errors: an explicit request returns the native error; import/restore do not publish on that error. The worker retains Root while its runtime is torn down even on native close error. Upstream closed-state/error retry behavior is unchanged; this review does not claim new error reporting from Rust Drop or an independent injected close-error campaign.
- Final Drop: the worker's tree reference and Root survive destruction of the application wrapper. The maintained supervised final-drop regression passed; its child waits for the owned descriptor to disappear, then exercises reuse of that free number. This is separate from the live-clone checkpoint regression, which also passed.

Prior obligations are closed for this frozen source review:

| Obligation | Current closure |
| --- | --- |
| R1 cleanup-inode adoption | import_publish.rs:336 compares the opened Root.id with marker.old.directory before deletion. Maintained substitution regression passed. |
| R1 ordinary-open durability | Shared open synchronizes/validates before returning; maintained export/daemon EIO regression passed. |
| R1 additional shared-handle custody | Native handle checkpoint-after-Storage-drop regression passed; all production tree clones retain Root. |
| R2 HIGH final-drop lifetime | Owned native runtime/tree/Root shutdown ordering above; fresh maintained final-drop and caller-runtime regressions passed. |
| Admission lifetime class | LockedFile::drop explicitly unlocks both guard types; wrapping precedes lock acquisition, so partial failures release already-acquired guards too. Fresh descriptor-copy regression passed. |

The transient historical IMPORT_BUSY holder remains UNKNOWN. The saved targeted diagnostic observed WouldBlock and no remaining /proc/locks holder. The deterministic descriptor-copy RED proves that guard destruction previously could leave its flock held through copied open descriptions; it does not identify the historical process. Neither fresh green tests nor this source review rewrite that uncertainty.

## Incident fixture and archive evidence

The incident change at src/daemon/editor_tests.rs:199 persists admitted-but-unlinked state through the real submission API, verifies accepted time and accepted+5000ms deadline, then waits until expiry before restart. The supervisor still kills at the same admission checkpoint; missing link, timeout, attempt-zero and no-extra-receipt assertions remain. src/daemon/incident.rs is byte-identical to base and has SHA-256 da5ea261be3b9eabe2e2322b42a1e70292b619a3d6719082837b2e97adae9ae7. Its prior negative control and historical canonical failure remain separately classified. This leaf did not mutate/retest that negative or rerun the incident selector separately; its exact-HEAD canonical result is supporting evidence. The original failure trigger remains UNCLASSIFIED.

All 215 archive members match manifest byte lengths and SHA-256; compressed members decode. Historical source pins match the designated frozen Git blobs:

| Archive | Pin and actual manifest key |
| --- | --- |
| mvp025-mempal-final | b98eec93cd2a2d6ca525eaa56d681864280bed05; historical_source_sha256 |
| mvp025-incremental | 6e692d6dbb0ac329372166a65d3029c913621049; candidate_file_sha256 |
| mvp025-incremental-gate-repair | 085640133221975943ec4ebc7d28cc86d5df879b; candidate_file_sha256, plus production_unchanged_sha256 |
| mvp025-incremental-review-repair | 4a542e3e4f86fc6182c603c7880a75ba5b793299; source_file_sha256 |
| mvp025-incremental-final-drop | this candidate; source_file_sha256 |

The first verifier used the brief's source_file_sha256 spelling for the two older candidate manifests and stopped with KeyError. The corrected verifier uses their actual keys at the same required pins and passes. That was verifier setup, not product RED. It is recorded in the log.

R1's original full report was overwritten; its retained reconstruction is explicitly a reconstruction, not recovered original bytes. R2's complete .md.gz is preserved. Its decompressed SHA-256 b7fd397a8acc54e22025000426b6fca33b284a72aaf422af0c0bf0326c234b59 matches the retained two-part publication's full-report digest and character count. No new remote comment readback is claimed. Historical failed focused/canonical attempts, diagnostics and corrected classifications remain retained. Historical pins are not assertions about current source.

## Fresh focused results and supporting canonical gate

Exactly one sequential vector ran, using the inherited toolchain/cache and one Cargo build writer. No new target, dependency installation, standalone --bin build, formatting, config change or just check rerun occurred.

| Fresh command after cargo test --locked --offline | Passed | Failed | Intentional ignores |
| --- | ---: | ---: | ---: |
| --lib storage:: | 20 | 0 | 5 |
| --test archive | 24 | 0 | 0 |
| --test storage | 18 | 0 | 0 |
| --lib daemon::jobs::import_tests | 7 | 0 | 1 |
| --test daemon import | 2 | 0 | 0 |
| Total | 71 | 0 | 6 |

All five command exits were zero. These are this review's own counts, separately obtained from the parent's 71/6 result. Ignored entries are supervised child entrypoints, not six claimed failures or six extra top-level passes. The full commands and output are in mvp025-incremental-review-r3-tests.log. No new ordinary probe was needed to settle a finding. git diff --check origin/main...HEAD also passed.

RUSTUP_TOOLCHAIN=1.99.1; RUSTUP_HOME=/home/obj/.rustup; CARGO_HOME=/home/obj/.cargo. PATH begins with the requested Hermes node, Rust 1.99.1 and Cargo directories. The supplied sccache wrapper/socket and TMPDIR=TMP=TEMP were retained. CARGO_TARGET_DIR and the checkout target symlink both have the exact lexical /ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/target value; resolving through /mnt/ssd did not replace that requirement.

The named mvp025-incremental-canonical-r4-verified.json and only its explicitly referenced admission, terminal, collected and log artifacts were verified. All four artifact hashes match; admission HEAD/tree/clean inputs and terminal HEAD/exit match this candidate. The receipt's base and clean-before/after claim agree with current frozen custody. Recomputed log totals: 21 Rust result rows, 595 passes, zero failures, 35 ignores including the installed repeat. just check exited 0 in 455.0589423952624 seconds; collected process_absent=true. Recorded installed lifecycle/private-UID/peer-UID checks passed with zero TCP sockets. This is accepted supporting exact-HEAD gate evidence, not a newly executed gate or current installation attestation. Hosted CI/publication remain separate; no fresh CI result or issue completion is claimed.

## Final custody and limits

After tests, HEAD/tree/base/merge-base remained exact, worktree/index remained clean, index.lock was absent, and all 234 changed filesystem blobs matched frozen Git bytes. Lexical target was rechecked. All Cargo launcher commands ended; the maintained supervisors own and wait/reap their children before removing their fixtures. A /proc executable census found no remaining matching test or CLI processes and zero permission-denied executable reads. No reviewer scratch directory, custom probe, detached build or model child was created; no shared scratch or unrelated process was deleted.

Only the requested report and tests log were written as review artifacts. No refs, source, docs, tests, index, dependencies or configuration were changed. The report was written separately from the wrapper's .final.txt destination and does not embed its own hash.

Tests-log full-file SHA-256: f0a0610b3d7debc6162c8af78efaf3a45558ab6c7f2fda7189bf8eb440fcc4e0.

Skipped deferred Daybreak/red-team campaigns, private/live mempal data, new model/host authentication, product stress/enforcement, packaging/quality/final release, and canonical rerun. Existing maintained regressions are the fresh dynamic boundary; no new close-error injection, power-loss or production-scale acceptance is claimed. Changed mempal snapshot semantics and whole issue #25 completion remain outside this leaf.

VERDICT: PASS
