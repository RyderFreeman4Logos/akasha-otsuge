import fcntl, hashlib, importlib.util, json, math, os, pathlib, sys, time

repo = pathlib.Path.cwd()
sys.path[:0] = [str(repo / 'spikes/helix'), str(repo / 'spikes/fallback')]
from run_case import digest, process_identity, publish
from check_real_search import run_native

phase = sys.argv[1]
assert phase in {'acknowledgements', 'vector-replay', 'drain', 'activation'}
storage = pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023')
root = storage / 'fallback-full-rebuild-r3'
case = root / 'low'
state = json.loads((case / 'state.json').read_text())
assert state['phase'] == 'completed' and state['result']['status'] == 'passed'
assert json.loads((case / 'verified.json').read_text())['status'] == 'passed'
assert json.loads((root / 'disk/result.json').read_text())['status'] == 'passed_sampled_storage_bound'
config = state['identity']['config']
assert config['run']['generation'] == 3 and config['run']['rebuild_generation'] == 5
binary, database = [pathlib.Path(config['paths'][key]) for key in ['binary', 'database']]
assert digest(binary) == state['identity']['binary_sha256']
expected = state['result']['engine']['snapshot']['derived']['committed']
for name, want in state['result']['artifact_sha256'].items():
    assert digest(case / name) == want, name
dependencies = {'acknowledgements': [], 'vector-replay': ['acknowledgements', 'witness-before'], 'drain': ['vector-replay'], 'activation': ['drain']}
for dependency in dependencies[phase]:
    assert json.loads((root / dependency / 'verified.json').read_text())['status'] == 'passed'
owner = (database / '.akasha-case-owner.lock').open('a')
fcntl.flock(owner, fcntl.LOCK_EX | fcntl.LOCK_NB)
output = root / phase
output.mkdir()
(output / 'OWNER').write_text('akasha-otsuge MVP-003 completed full rebuild generation5 verification\n')
publish(output / 'admission.json', dict(controller=process_identity(os.getpid()), case_state_sha256=digest(case / 'state.json'), driver_sha256=digest(__file__), binary_sha256=digest(binary), phase=phase, committed=expected, active_before=3, candidate=5))
records, facts = [], {}
started = time.monotonic()
total = {'acknowledgements': 0, 'vector-replay': 26, 'drain': 3, 'activation': 5}[phase]

def call(channel, request, timeout=180):
    path = output / f'{len(records):03d}.request.json'
    publish(path, request)
    assert path.stat().st_size <= 1024**2
    stdout, stderr = run_native([str(binary), str(database), '--' + channel, str(path)], output, records, timeout=timeout)
    assert records[-1]['exit'] == 0 and not records[-1]['timed_out'], stderr[-1500:]
    elapsed = time.monotonic() - started
    publish(output / 'progress.json', dict(completed=len(records), total=total, elapsed_s=elapsed, rate_per_s=len(records) / elapsed, eta_s=(total-len(records))*elapsed/len(records)))
    return json.loads(stdout)

def lifecycle(generation, active):
    value = call('generation', dict(op='lifecycle_status', generation=generation))
    assert value['committed'] == expected and value['active'] == active
    assert value['text']['pending'] is value['vector']['pending'] is None
    return value

if phase == 'acknowledgements':
    path = repo / '.git/akasha-evidence/verify-full-rebuild-acknowledgements.py'
    spec = importlib.util.spec_from_file_location('prior_acknowledgements', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    acknowledgements, requests = module.receipts(case)
    oracle = state['result']['content_oracle']
    assert requests == oracle['requests'] and len(acknowledgements) == oracle['distinct_commits']
    seqs = {r['commit_seq'] for r in acknowledgements}
    assert max(seqs) == expected and len(seqs) == expected - min(seqs) + 1
    total = math.ceil(len(acknowledgements) / 256)
    for offset in range(0, len(acknowledgements), 256):
        batch = acknowledgements[offset:offset+256]
        assert call('authority', dict(op='verify_acknowledgements', receipts=batch)) == dict(verified=len(batch), commit_seq=expected)
    facts.update(verified_receipts=len(acknowledgements), workload_acknowledgements=len(acknowledgements)-50, seed_acknowledgements=50, unlogged_committed_sequences=[], helper_sha256=digest(path))
elif phase == 'vector-replay':
    prior = storage / 'fallback-full-corpus-lifecycle-r1/case'
    old = json.loads((prior / 'state.json').read_text())
    assert old['phase'] == 'completed' and old['result']['status'] == 'passed'
    before = lifecycle(5, 3)
    assert before['text']['watermark'] == before['vector']['watermark'] == 0
    sources = []
    for row in old['result']['cases']:
        if row['mode'] != 'ann':
            continue
        tag = f"p{row['scope']}-ann"
        names = [tag+'-restore-vector.request.json', tag+'-restore.request.json', tag+'-source.reply.json']
        for name in names:
            assert digest(prior / name) == old['result']['artifact_sha256'][name]
            (output / name).write_bytes((prior / name).read_bytes())
        request, change, source = [json.loads((prior / name).read_text()) for name in names]
        seq = row['commits'][-1]
        assert request['seq'] == seq and request['family'] == 'vector' and request['generation'] == 2
        current = call('authority', dict(op='get', memory=row['memory'], at=expected))
        assert current['seq'] == seq and current['body'] == source['body'] and current['scope'] == row['scope'] and current['active'] and not current['text_only'] and current['source_key'] == source['key']
        assert request['vector']['values'] == source['embedding'] and request['vector']['body_sha256'] == hashlib.sha256(source['body'].encode()).hexdigest()
        call('generation', {**request, 'generation': 5})
        receipt = call('generation', dict(op='indexed_receipt', generation=5, request_id=change['change']['request_id']))
        assert receipt['stage'] == 'committed' and receipt['commit_seq'] == seq and receipt['reasons'] == dict(vector='applied')
        sources.append(dict(memory=row['memory'], scope=row['scope'], seq=seq, vector_request_sha256=digest(prior / names[0])))
    assert len(sources) == 8
    after = lifecycle(5, 3)
    assert after['text']['watermark'] == after['vector']['watermark'] == 0
    facts.update(sources=sources, historical_case_sha256=digest(prior / 'state.json'))
elif phase == 'drain':
    before = lifecycle(5, 3)
    assert before['text']['watermark'] == before['vector']['watermark'] == 0
    result = call('generation', dict(op='catch_up', generation=5, waves=1000000), timeout=7260)
    after = lifecycle(5, 3)
    assert after == {k: v for k, v in result.items() if k not in {'target', 'done'}}
    assert after['text']['watermark'] == after['vector']['watermark'] == expected
    facts.update(before=before, after=after)
else:
    for generation in [3, 5]:
        value = lifecycle(generation, 3)
        assert value['text']['watermark'] == value['vector']['watermark'] == expected
    assert call('generation', dict(op='activate', generation=5))['active'] == 5
    for generation in [3, 5]:
        value = lifecycle(generation, 5)
        assert value['text']['watermark'] == value['vector']['watermark'] == expected
assert len(records) == total
publish(output / 'result.json', dict(status='passed', phase=phase, commands=len(records), seconds=time.monotonic()-started, committed=expected, facts=facts, artifacts={p.name:digest(p) for p in output.iterdir() if p.is_file()}))
print(json.dumps(dict(status='passed', phase=phase, commands=len(records), committed=expected)), flush=True)
