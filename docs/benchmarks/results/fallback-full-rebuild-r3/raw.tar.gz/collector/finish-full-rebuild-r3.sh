#!/usr/bin/env bash
set -euo pipefail
cd /home/obj/project/github/RyderFreeman4Logos/akasha-otsuge
session_root=/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023/fallback-full-rebuild-r3
session_frozen="$PWD/.spike-work/legacy-reserve-r1"
python3 - <<'CHECK'
import json
from pathlib import Path
root = Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023/fallback-full-rebuild-r3')
result = json.loads((root / 'verified.json').read_text())
assert result['status'] == 'passed_full_concurrent_rebuild_and_sampled_disk'
assert result['source_commit'] == '3b3994a525d642e021e0df9ddf5373b8a8d224a0'
assert result['native_sha256'] == '860c32fa49451574f4d1d81bfaae88d9593999e770e1e4966cdb94c35ac41d35'
CHECK
run_phase() {
    local phase="$1"
    shift
    local unit="akasha-full-rebuild-r3-$phase"
    local memory=".git/akasha-evidence/full-rebuild-r3-$phase-memory.jsonl"
    systemd-run --user --quiet --wait --pipe --collect --unit="$unit" \
        -p MemoryMax=671088640 -p MemorySwapMax=0 -p LimitNOFILE=8192 \
        -p WorkingDirectory="$PWD" -p Environment=MALLOC_MMAP_THRESHOLD_=131072 \
        -p Environment=LANCE_FTS_NUM_SHARDS=1 -p Environment=LANCE_FTS_PARTITION_SIZE=32 \
        -p Environment=LANCE_CPU_THREADS=2 -p Environment=LANCE_DEFAULT_IO_BUFFER_SIZE=16777216 \
        -p Environment=LANCE_SHUFFLE_BATCH_BYTES=16777216 \
        -p Environment=LANCE_SHUFFLE_MAX_PRELOADED_OFFSETS_BYTES=0 \
        python3 "$session_frozen/measure.py" "$memory" "$@" \
        > ".git/akasha-evidence/full-rebuild-r3-$phase.log" 2>&1
    python3 .git/akasha-evidence/collect-rebuild-recovery-step.py "$session_root/$phase" "$memory" "$unit"
}
run_phase acknowledgements python3 .git/akasha-evidence/finish-full-rebuild-r3-step.py acknowledgements
run_phase witness-before python3 .git/akasha-evidence/full-rebuild-witness.py "$session_root/low" "$session_root/witness-before" before
run_phase vector-replay python3 .git/akasha-evidence/finish-full-rebuild-r3-step.py vector-replay
run_phase drain python3 .git/akasha-evidence/finish-full-rebuild-r3-step.py drain
run_phase activation python3 .git/akasha-evidence/finish-full-rebuild-r3-step.py activation
run_phase witness-after python3 .git/akasha-evidence/full-rebuild-witness.py "$session_root/low" "$session_root/witness-after" after
