import datetime,fcntl,hashlib,json,os,pathlib,subprocess,sys,time
repo=pathlib.Path.cwd();sys.path[:0]=[str(repo/'spikes/helix'),str(repo/'spikes/fallback')]
from run_case import digest,process_identity,publish
from check_real_search import run_native
storage=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023');prepared=storage/'fallback-full-generation5-r1';out=storage/'fallback-full-corpus-identity-r1';database=storage/'fallback-full-compressed-r1/database';frozen=repo/'.spike-work/legacy-reserve-r1';old=repo/'.spike-work/partial-retirement-r2/probe';manifest=pathlib.Path('/tmp/akasha-otsuge-storage-20261022/full-corpus-v2.json')
source=json.loads((frozen/'source.json').read_text());publication=json.loads((repo/'.git/akasha-evidence/legacy-reserve-publication.json').read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert publication['head']==publication['remote_head']==head and publication['ci_conclusion']=='success' and publication['exact_head_gate']=='passed' and publication['independent_review']=='PASS'
assert digest(frozen/'probe')==source['native_sha256']==publication['source_native_sha256']
assert digest(old)=='8f0b2b2f1a6890a78b0efba421176e95e906a4d03607fd5efab8292c00942d00'
assert digest(manifest)=='0b38c64fd5f5d77571ef9c76af4ccea298a96e76720f577d2d0b5c88adc43a66'
for group in ['source_sha256','helpers_sha256']:
 for name,want in source[group].items():assert digest(repo/name)==want,name
owner=(database/'.akasha-case-owner.lock').open('a');fcntl.flock(owner,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['.akasha-generation-owner.json','.akasha-case-owner.json']:
 prior=json.loads((database/name).read_text());assert json.loads((pathlib.Path(prior['output'])/'state.json').read_text())['phase'] in ['completed','abandoned']
out.mkdir();(out/'OWNER').write_text('akasha-otsuge MVP-003 full original-manifest binding and unchanged-state witnesses\n')
plan=json.loads((prepared/'witness-plan.json').read_text());assert len(plan['requests'])==66
steps=[*plan['requests'],dict(channel='generation',request=dict(op='status',generation=5))];records=[];started=time.monotonic();total=139
publish(out/'admission.json',dict(controller=process_identity(os.getpid()),driver_sha256=digest(__file__),helper_sha256=digest(repo/'spikes/fallback/check_real_search.py'),source=source,publication_sha256=digest(repo/'.git/akasha-evidence/legacy-reserve-publication.json'),old_native_sha256=digest(old),manifest_sha256=digest(manifest),witness_plan_sha256=digest(prepared/'witness-plan.json'),head=head,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),planned_commands=total))
def call(binary,step,phase,error=None):
 n=len(records);request=out/f'{n:03d}.request.json';publish(request,step['request']);stdout,stderr=run_native([str(binary),str(database),'--'+step['channel'],str(request)],out,records)
 row=records[-1];assert not row['timed_out'] and row['exit']==(1 if error else 0),(n,stderr[-2000:]);actual=process_identity(row['child']['pid']);assert actual is None or actual['start_ticks']!=row['child']['start_ticks']
 if error:assert error.encode() in stderr
 elapsed=time.monotonic()-started;publish(out/'progress.json',dict(phase=phase,completed=len(records),total=total,elapsed_s=elapsed,rate_per_s=len(records)/elapsed,eta_s=(total-len(records))*elapsed/len(records),controller=process_identity(os.getpid())))
 return None if error else json.loads(stdout)
before=[call(old,step,'before') for step in steps]
assert before[0]['generation']==3 and before[0]['ready']
assert before[1]['active']==3 and before[1]['committed']==before[1]['text']['watermark']==before[1]['vector']['watermark']==309711
assert before[-1]==json.loads((prepared/'backfill/verified.json').read_text())['reply']
assert not before[-1]['ready'] and before[-1]['index_deadline_ms'] is None
call(frozen/'probe',steps[0],'unbound-refusal','missing persisted corpus manifest')
for state in [before[0],before[-1],before[0],before[-1]]:
 step=dict(channel='generation',request=dict(op='begin_corpus',generation=state['generation'],bundle=state['bundle'],manifest=str(manifest)))
 assert call(frozen/'probe',step,'bind-original-manifest')==state
changes=[]
for i,step in enumerate(steps):
 actual=call(frozen/'probe',step,'after');expected=before[i]
 if step['request']['op']=='query_current':
  if actual!=expected:changes.append(i)
  actual={**actual,'hits':sorted(actual['hits'],key=lambda x:json.dumps(x,sort_keys=True))};expected={**expected,'hits':sorted(expected['hits'],key=lambda x:json.dumps(x,sort_keys=True))}
 assert actual==expected,i
assert len(records)==total
publish(out/'result.json',dict(status='passed',commands=total,seconds=time.monotonic()-started,native_sha256=source['native_sha256'],source_commit=head,active_generation=3,candidate_generation=5,committed=309711,original_state_and_deadlines_preserved=True,original_manifest_sha256=digest(manifest),unbound_refusal=True,idempotent_binding=True,witnesses_before=67,witnesses_after=67,query_order_changes=changes,candidate_index_deadline_ms=None,source_reimported=False,artifact_sha256={p.name:digest(p) for p in out.iterdir() if p.is_file()}))
print(json.dumps(dict(status='passed_full_manifest_binding',commands=total,active=3,candidate=5,committed=309711,query_order_changes=changes)))
