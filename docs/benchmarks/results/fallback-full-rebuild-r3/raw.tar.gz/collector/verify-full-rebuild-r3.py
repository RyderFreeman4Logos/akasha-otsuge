import json, pathlib, subprocess, sys

repo = pathlib.Path.cwd()
sys.path.insert(0, str(repo / 'spikes/helix'))
from run_case import digest, process_identity, publish

root = pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023/fallback-full-rebuild-r3')
case = root / 'low'
state = json.loads((case / 'state.json').read_text())
assert state['phase'] == 'completed' and state['result']['status'] == 'passed'
expected = '860c32fa49451574f4d1d81bfaae88d9593999e770e1e4966cdb94c35ac41d35'
assert state['identity']['binary_sha256'] == expected
with (root / 'verification.log').open('x') as log:
    subprocess.run([sys.executable, str(repo / '.git/akasha-evidence/verify-full-case.py'), str(case), expected], stdout=log, stderr=subprocess.STDOUT, check=True)
verified = json.loads((case / 'verified.json').read_text())
assert verified['status'] == 'passed' and not verified['failures'] and verified['unit_state'] == 'inactive'
events = [json.loads(line) for line in (case / 'memory.jsonl').open()]
assert events[0]['limits']['memory.max']=='671088640' and events[0]['limits']['memory.swap.max']=='0' and events[0]['nofile_soft_hard']==[8192,8192]
samples = [event for event in events if event['event'] == 'sample']
assert samples and not any(int(event['memory_events'].get(key, 0)) for event in samples for key in ['oom', 'oom_kill'])
assert events[-1]['event'] == 'exit' and events[-1]['code'] == events[-1]['native_code'] == 0
plan = json.loads((root / 'disk-plan.json').read_text())
admission = json.loads((root / 'disk/admission.json').read_text())
disk = json.loads((root / 'disk/result.json').read_text())
assert disk['status'] == 'passed_sampled_storage_bound' and disk['child_exit'] == 0
assert admission['plan'] == plan and admission['plan_sha256'] == digest(root / 'disk-plan.json')
for key, path in [('driver_sha256', repo / '.git/akasha-evidence/measure-rebuild-disk.py'), ('controller_sha256', pathlib.Path(plan['command'][1])), ('config_sha256', root / 'low.toml')]:
    assert admission[key] == digest(path), key
disk_samples = [json.loads(line) for line in (root / 'disk/samples.jsonl').open()]
assert len(disk_samples) == disk['samples'] and disk_samples[-1] == disk['final']
for sample in disk_samples:
    assert sample['free_bytes'] >= plan['headroom_bytes']
    assert all(sample['categories'][name]['allocated_bytes'] <= limit for name, limit in plan['allocated_byte_limits'].items())
assert {name: max(sample['categories'][name]['allocated_bytes'] for sample in disk_samples) for name in plan['allocated_byte_limits']} == disk['sampled_peaks']
assert min(sample['free_bytes'] for sample in disk_samples) == disk['free_bytes_min']
assert max(sum(value['allocated_bytes'] for value in sample['categories'].values()) for sample in disk_samples) == disk['sampled_total_peak_bytes']
assert max(sample['observer_rss_bytes'] for sample in disk_samples) == disk['observer_sampled_rss_max_bytes']
for identity in [admission['observer'], json.loads((root / 'disk/controller.json').read_text())]:
    actual = process_identity(identity['pid'])
    assert actual is None or actual['start_ticks'] != identity['start_ticks']
before = digest(case / 'state.json')
with (root / 'completed-reuse.stdout').open('x') as stdout, (root / 'completed-reuse.stderr').open('x') as stderr:
    subprocess.run(plan['command'] + ['--resume'], stdout=stdout, stderr=stderr, check=True)
assert digest(case / 'state.json') == before
assert json.loads((root / 'completed-reuse.stdout').read_text()) == state['result']
result = dict(status='passed_full_concurrent_rebuild_and_sampled_disk', source_commit=plan['candidate_commit'], native_sha256=expected, case_verified_sha256=digest(case / 'verified.json'), disk_result_sha256=digest(root / 'disk/result.json'), disk_samples_sha256=digest(root / 'disk/samples.jsonl'), disk_plan_sha256=digest(root / 'disk-plan.json'), collector_sha256=digest(__file__), no_oom_samples=True, exact_processes_gone=True, scratch_removed=True, completed_reuse_verified=True, content_oracle=verified['content_oracle'], rss_p99_bytes=verified['rss_p99_bytes'], rss_max_bytes=verified['rss_max_bytes'], rebuild=state['result']['rebuild'], disk=disk, seconds=verified['seconds'])
publish(root / 'verified.json', result)
print(json.dumps({key:result[key] for key in ['status', 'seconds', 'rss_p99_bytes', 'rss_max_bytes', 'no_oom_samples', 'exact_processes_gone', 'completed_reuse_verified']}))
