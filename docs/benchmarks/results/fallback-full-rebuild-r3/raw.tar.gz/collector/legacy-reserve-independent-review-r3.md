VERDICT: PASS

# Issue #3 / draft PR #31 independent R3 successor re-review

R3 is closed. ACTIONABLE_COUNT: 0. No new regression was found within the requested single-write-boundary scope. R1/R2 closure from the preceding review is retained by exact production-diff and unchanged-blob attestation. This source verdict is not full benchmark acceptance, a CSA tier verdict, merge approval, backend selection or issue closure.

## Frozen scope and custody

- Repository: `/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge`.
- Branch: `spike/mvp-003-storage`.
- HEAD: `3b3994a525d642e021e0df9ddf5373b8a8d224a0`.
- Tree: `2d28d662d5e51cd7bf5c48521301789e14130674`.
- Observed `origin/main` and independently resolved merge-base: `349431a350e9e4ae3364b126c4d2a7133dd37d22`.
- Attribution range: `origin/main...3b3994a525d642e021e0df9ddf5373b8a8d224a0`.
- Previous independently reviewed candidate: `bf5e62ced38926e7ca2cfda543f724f8d251e2bb`.
- Retained successor native SHA-256, independently rehashed without execution: `860c32fa49451574f4d1d81bfaae88d9593999e770e1e4966cdb94c35ac41d35`.

The existing native-code-review skill and its scope/attribution, receipt-integrity and frozen-artifact rules were applied. The parent owns implementation and the single WD relay. The assignment prohibited source changes, tests/Cargo/benchmarks, full database or raw corpus reads, large extraction, fetch/push and further agents. Only this report and `.git/akasha-evidence/legacy-reserve-independent-review-r3.progress.json` were written. Existing receipts were inspected, not re-executed.

## R3 closure

`spikes/fallback/src/search.rs:1170` now calls `settings.check_disk(root)?` immediately before the missing-manifest branch sets Immediate durability, writes `load::MANIFEST` and commits at `1171-1173`. All manifest shape, semantic provenance and original-import SHA validation still precede this point. The transaction has only performed a read before the new guard. A failed reservation returns without metadata or generation mutation; the unchanged outer Result/close boundary awaits database close and preserves the primary error.

Both legacy cases share this guard: Begin for an existing generation and Begin for a new generation on the same unbound import. The existing-manifest branch at `1166-1167` performs validation without this write admission. Existing-generation reuse at `1177-1182` remains read-only; fresh-generation creation retains its separate reservation check at `1201`. Status does not enter Begin. Thus the repair blocks the newly introduced write while preserving exhausted-reservation reads/reuse and ordinary fresh-generation admission.

The entire successor Rust/manifest/lock diff against the prior reviewed candidate contains only this one Rust insertion. A mechanical byte comparison established that inserting the exact guard after the existing legacy-binding comment into the prior `search.rs` yields the entire successor file. `load.rs`, `changes.rs`, `workload_backend.rs`, main/authority code, native tests, shared workload code and dependency manifests/lock are unchanged. The prior source findings for exact original bytes, model/fingerprint/dimension/chunker binding, schema-only upgrades, common generation reads, apply/replay, work pinning, deadlines and primary-error precedence therefore remain applicable. No broader source audit or historical execution rerun is implied.

## New fixture and observed evidence

The full new `spikes/fallback/check_legacy_binding.py` was read from the frozen blob. It creates a fresh owned temporary root with the importer's exact OWNER marker (`22-32`), then invokes the retained pre-binding binary for actual import, Begin and backfill (`62-65`). It does not manufacture legacy KV state with a raw edit. The fixture uses explicit synthetic text-only provenance; it makes no real-model vector claim.

The invocation wrapper (`37-55`) sets the impossible reserve only for the selected child, restores the parent environment in `finally`, checks exit class and expected error text, and rejects timed-out commands. The reused `check_real_search.py:41-66` launches the supplied executable with that inherited environment and preserves stdout/stderr, process identity, exit and timeout data. The source does not substitute a stub for the native boundary.

The retained RED and GREEN command/admission JSON and stderr leaves were read directly from their small receipt directories and their hashes compared with the frozen archive inventory. No raw corpus or archive extraction was needed. The two admission receipts have the identical oracle SHA-256 `74178144dad0d3a2a4470b0eb31b3dfc883bf6a2d620ee12ade6e4d465c65f1a`, also matching the frozen new fixture and retained successor snapshot.

| Commands | Checked behavior |
| --- | --- |
| 000-002 | Retained native `8f0b2b2f1a6890a78b0efba421176e95e906a4d03607fd5efab8292c00942d00` imports, begins and backfills. Original cursor is 1 and a backfill deadline exists. |
| RED 003 | Prior native `4028cb8e9164218029f6396c88172ace7d7f356f148247794b14ce4c9d955125` returns exit 0 under reserve `18446744073709551615`, where exit 1 / `disk reservation reached` is expected. The first three commands succeeded, so this reaches the actual reported defect. |
| GREEN 003-004 | Existing-generation binding rejects at the reserve boundary. A following ordinary status still returns `missing persisted corpus manifest`. |
| GREEN 005-007 | Fresh-generation binding also rejects, ordinary original-generation status still proves metadata absent, and generation 2 remains missing. |
| GREEN 008-010 | Normal binding succeeds; subsequent already-bound Begin reuse and status succeed under the impossible reserve. All three stdout state blobs are byte-identical to the original backfilled state from command 002. |
| GREEN 011-014 | Normal schema-only generation 2 creation succeeds; ordinary fresh generation 3 creation under the impossible reserve rejects and leaves it absent; import verification retains the original prepared hash. |

The GREEN receipt contains all 15 commands, expected exit classes and no timeout. Original state/deadline preservation is both a fixture assertion and an independently compared retained-output equality. The earlier R1 identity unit, still present in the supplied successor unit run, separately covers non-null retained backfill/index deadlines.

The first RED attempt failed during command 000 with `foreign import parent`; it is an excluded fixture setup failure, not behavioral RED. The corrected RED log reaches command 003. The initial collector's inability to find command 003 is likewise not a product outcome. These failed attempts remain retained. Cleanup, exact child identity and unit-inactive fields in `legacy-reserve-validation.json`/`verified.json` are supplied collector evidence; the reviewer did not rerun their process or systemd checks.

## Source and gate provenance

All 12 native source entries and 12 helper entries in `.spike-work/legacy-reserve-r1/source.json` were recomputed from the frozen Git objects and matched the receipt, retained snapshot files and working bytes. The retained probe was independently hashed and matches the successor native SHA above. Its source receipt names the precommit parent; the content comparisons bind those inputs to the reviewed commit. The reused prior review report was rehashed as `ad78a151762a8fd60eb82e4c3d7e9208e5c195c65f73f3c493028c2b3cac95c1`.

Supplied release-unit output explicitly reports 13 passed / 0 failed, including the identity regression and the existing shared-index-admission regression. Supplied release all-target Clippy output finishes successfully. The new focused native receipt reports 15 commands passed. The root gate's HEAD/tree match this successor and its log digest was recomputed; the log reports plan validation, 6 Python tests, 4 CLI tests, 17 config tests, root Clippy/release/version. Native fallback and root-workspace gates remain separate evidence.

| Artifact | Independently computed SHA-256 |
| --- | --- |
| `.spike-work/legacy-reserve-r1/source.json` | `8025d6c6f00314c916b414313b1df2a1f01aeec54bb33d57943667ae502e14b7` |
| `.git/akasha-evidence/legacy-reserve-root-gate-r1.json` | `d0c8ea6dc1a947f953b98e376d419f56074970f2026953252033f11f1b73937e` |
| `.git/akasha-evidence/legacy-reserve-root-gate-r1.log` | `5b779ae3ccfb95bf20f1b1a7607361ea4448bd274dbde4b98499d08e87c80da9` |
| `.git/akasha-evidence/legacy-reserve-unit-r1.log` | `f265c3bae707923d81ad9bf5b5df6f325b9b100c8cd7fa9a4d02373751da7665` |
| `.git/akasha-evidence/legacy-reserve-clippy-r1.log` | `898c9c11f8ef63e47296705cac2d5fda2af2f1b0bca4a797da70a8b607e1be7b` |
| `.git/akasha-evidence/legacy-reserve-validation.json` | `2763caed9921bc2c9ad8dbd29c98199c245a2fdc4fe2494ae47292e097969dc4` |
| `.git/akasha-evidence/legacy-reserve-oracle-custody.json` | `3231c0cbde30211793a3c4c45d114d6d6d04e76a8196491540496e2b4652d13c` |

The earlier 231-command lifecycle, 85-command search and 160-second concurrent fixtures were not rerun; their `4028cb8e` identity is not relabeled as successor execution. The successor documentation and compact summary preserve those exclusions. The archive inventory was inspected, but the archive itself was not extracted. This review does not infer a resource envelope from the subsecond focused fixture.

## Instruction and final-file custody

Filesystem ancestor instruction checks preceded source reads. Exact `AGENTS.md` and `CLAUDE.md` paths were absent and not symlinks at `/`, `/home`, `/home/obj`, `/home/obj/project`, `/home/obj/project/github`, `/home/obj/project/github/RyderFreeman4Logos`, and the repository root. Relevant descendants were checked through fallback/src/search, docs/benchmarks/results/fallback-legacy-reserve, docs/plan, spikes/helix, `.git/akasha-evidence` and `.spike-work/legacy-reserve-r1`, including intermediates. The companion JSON records all 42 logical checks. There were no instruction targets or line counts to report because every checked file was absent. Existing native-review skill references were retained from this same independent review session.

Read coverage in this round: the new fixture in full; the changed Begin boundary, reused native process helper, all successor documentation hunks, compact summary/inventory and supplied logs/JSON receipts. Unchanged prior runtime source was compared by immutable blobs/diffs without repeating its earlier full-file reads. The base-relative `git diff --check origin/main...3b3994a525d642e021e0df9ddf5373b8a8d224a0` returned zero at entry and finalization.

At review start, HEAD/tree matched the freeze and porcelain was empty. Pre-report custody at `2026-10-24T11:07:17.897228+00:00` and post-provisional-write custody at `2026-10-24T11:07:18.452163+00:00` confirm the same HEAD/tree/base/merge-base/branch, clean porcelain, no index lock, and matching working bytes for all 24 source/helper entries and 10 specifically read paths. Final post-report custody and the report's actual SHA-256 are stored externally in the companion progress JSON and terminal receipt; this report does not self-embed its digest.

No execution was repeated by the reviewer. Full database binding and full concurrent resource acceptance remain unperformed in this review; the full database was not opened or changed. CI/publication, full-scale acceptance, backend selection, merge and issue closure require their own evidence.

VERDICT: PASS
