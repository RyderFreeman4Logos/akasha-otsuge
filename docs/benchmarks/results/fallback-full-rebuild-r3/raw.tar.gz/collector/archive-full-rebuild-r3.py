import hashlib, json, pathlib, sys, tarfile

repo = pathlib.Path.cwd()
sys.path.insert(0, str(repo / 'spikes/helix'))
from run_case import digest, publish

storage = pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023')
root = storage / 'fallback-full-rebuild-r3'
binding = storage / 'fallback-full-corpus-identity-r1'
frozen = repo / '.spike-work/legacy-reserve-r1'
collector = repo / '.git/akasha-evidence'
verified = json.loads((root / 'verified.json').read_text())
assert verified['status'] == 'passed_full_concurrent_rebuild_and_sampled_disk'
assert verified['source_commit'] == '3b3994a525d642e021e0df9ddf5373b8a8d224a0'
phases = ['acknowledgements', 'witness-before', 'vector-replay', 'drain', 'activation', 'witness-after']
steps = {name: json.loads((root / name / 'verified.json').read_text()) for name in phases}
assert all(value['status'] == 'passed' for value in steps.values())
binding_verified = json.loads((binding / 'verified.json').read_text())
assert binding_verified['status'] == 'passed' and binding_verified['commands'] == 139
for directory, receipt in [(binding, binding_verified), *((root / name, steps[name]) for name in phases)]:
    assert digest(directory / 'result.json') == receipt['result_sha256']
    result = json.loads((directory / 'result.json').read_text())
    for name, want in result.get('artifacts', result.get('artifact_sha256')).items():
        assert digest(directory / name) == want, (directory.name, name)
assert digest(root / 'low/verified.json') == verified['case_verified_sha256']
state = json.loads((root / 'low/state.json').read_text())
for name, want in state['result']['artifact_sha256'].items():
    assert digest(root / 'low' / name) == want, name
source = json.loads((frozen / 'source.json').read_text())
assert verified['native_sha256'] == source['native_sha256'] == digest(frozen / 'probe')
for group in ['source_sha256', 'helpers_sha256']:
    for name, want in source[group].items():
        assert digest(repo / name) == want, name
preparation = json.loads((collector / 'full-rebuild-r3-followup-preparation.json').read_text())
for name, want in preparation['sha256'].items():
    assert digest(collector / name) == want, name

files = {}
for prefix, tree in [('full-run-and-followup', root), ('full-original-manifest-binding', binding), ('frozen-source', frozen)]:
    for path in tree.rglob('*'):
        if path.is_file() and path.name != 'probe' and '__pycache__' not in path.parts:
            assert not path.is_symlink()
            files[prefix + '/' + str(path.relative_to(tree))] = path
names = [
    'run-full-rebuild-r3.sh', 'bind-full-corpus-identity-r1.py',
    'prepare-full-rebuild-r3.py', 'verify-full-rebuild-r3.py',
    'measure-rebuild-disk.py', 'verify-full-case.py',
    'finish-full-rebuild-r3.sh', 'finish-full-rebuild-r3-step.py',
    'full-rebuild-witness.py', 'verify-full-rebuild-acknowledgements.py',
    'collect-rebuild-recovery-step.py', 'archive-full-rebuild-r3.py',
    'full-rebuild-r3-admission.json', 'full-rebuild-r3-dispatch-preparation-r2.json',
    'full-rebuild-r3-followup-preparation.json', 'full-rebuild-r3-run.log',
    'full-corpus-identity-r1-memory.jsonl', 'full-corpus-identity-r1.log',
    'legacy-reserve-publication.json', 'legacy-reserve-root-gate-r1.json',
    'legacy-reserve-root-gate-r1.log', 'legacy-reserve-independent-review-r3.md',
    'legacy-reserve-independent-review-r3.progress.json',
]
for phase in phases:
    names += [f'full-rebuild-r3-{phase}{suffix}' for suffix in ['-memory.jsonl', '.log']]
for name in names:
    path = collector / name
    assert path.is_file() and not path.is_symlink(), name
    files['collector/' + name] = path
out = repo / 'docs/benchmarks/results/fallback-full-rebuild-r3'
out.mkdir()
archive = out / 'raw.tar.gz'
hashes = {name: digest(path) for name, path in sorted(files.items())}
with tarfile.open(archive, 'w:gz') as stream:
    for name, path in sorted(files.items()):
        stream.add(path, arcname=name, recursive=False)
with tarfile.open(archive, 'r:gz') as stream:
    assert len(stream.getnames()) == len(hashes) and set(stream.getnames()) == set(hashes)
    for member in stream.getmembers():
        assert hashlib.sha256(stream.extractfile(member).read()).hexdigest() == hashes[member.name], member.name
publish(out / 'files.json', hashes)
state = json.loads((root / 'low/state.json').read_text())
binding_result = json.loads((binding / 'result.json').read_text())
after = json.loads((root / 'witness-after/result.json').read_text())
summary = dict(
    status='passed_full_concurrent_rebuild_and_activation',
    source_commit=verified['source_commit'], native_sha256=verified['native_sha256'],
    archive_files=len(files), archive_bytes=archive.stat().st_size, archive_sha256=digest(archive),
    full_case=state['result'], verification=verified, followup=steps,
    binding={key: value for key, value in binding_result.items() if key != 'artifact_sha256'},
    binding_verification=binding_verified, active_generation=after['active_generation'],
    committed_and_both_watermarks=after['committed'],
    source_review='independent R3 PASS before full admission; evidence review remains separate',
    not_proven=['production daemon protocol/resource acceptance', 'automatic daemon recovery', 'hardware power-loss safety', 'instantaneous disk quota or exclusive Btrfs extent ownership'],
)
publish(out / 'summary.json', summary)
print(json.dumps({key: summary[key] for key in ['status', 'archive_files', 'archive_bytes', 'archive_sha256', 'active_generation', 'committed_and_both_watermarks']}))
