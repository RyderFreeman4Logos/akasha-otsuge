#!/usr/bin/env bash
set -euo pipefail
cd /home/obj/project/github/RyderFreeman4Logos/akasha-otsuge
session_storage=/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023
session_frozen="$PWD/.spike-work/legacy-reserve-r1"
systemd-run --user --quiet --wait --pipe --collect --unit=akasha-full-corpus-identity-r1 \
    -p MemoryMax=671088640 -p MemorySwapMax=0 -p LimitNOFILE=8192 \
    -p WorkingDirectory="$PWD" -p Environment=MALLOC_MMAP_THRESHOLD_=131072 \
    -p Environment=LANCE_CPU_THREADS=2 \
    python3 "$session_frozen/measure.py" .git/akasha-evidence/full-corpus-identity-r1-memory.jsonl \
    python3 .git/akasha-evidence/bind-full-corpus-identity-r1.py \
    > .git/akasha-evidence/full-corpus-identity-r1.log 2>&1
python3 .git/akasha-evidence/collect-rebuild-recovery-step.py \
    "$session_storage/fallback-full-corpus-identity-r1" \
    .git/akasha-evidence/full-corpus-identity-r1-memory.jsonl akasha-full-corpus-identity-r1
python3 .git/akasha-evidence/prepare-full-rebuild-r3.py
python3 .git/akasha-evidence/measure-rebuild-disk.py "$session_storage/fallback-full-rebuild-r3/disk-plan.json"
python3 .git/akasha-evidence/verify-full-rebuild-r3.py
