"""Mount just the selected native hosts and run one offline Consult regression."""

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path as P

parser = argparse.ArgumentParser(
    description="Replay an isolated native Caller/Runner Consult on the released Linux x86_64 binary."
)
parser.add_argument("caller", choices=("pi", "codex", "hermes"))
parser.add_argument("runner", choices=("pi", "codex", "hermes"))
parser.add_argument("hint", choices=("none", "short"))
for flag in ("product", "scratch", "output"):
    parser.add_argument("--" + flag, type=P, required=True)
for flag in (
    "pi-root",
    "node",
    "codex",
    "codex-catalog",
    "hermes-owner",
    "hermes-install",
):
    parser.add_argument("--" + flag, type=P)
parser.add_argument("--fd", type=P, required=True)
parser.add_argument("--rg", type=P, required=True)
parser.add_argument("--hermes-tui-dist", type=P)
args = parser.parse_args()
if args.caller != args.runner:
    parser.error("select the same host in both positions")
if args.caller == "hermes" and not (args.hermes_tui_dist and args.node):
    parser.error("Hermes TUI requires --node and --hermes-tui-dist")

caller, runner, hint = args.caller, args.runner, args.hint
hosts = {caller, runner}
if args.output.exists():
    parser.error("output already exists")
if "pi" in hosts and not (args.pi_root and args.node):
    parser.error("Pi requires --pi-root and --node")
if "codex" in hosts and not args.codex:
    parser.error("Codex requires --codex")
if runner == "codex" and not args.codex_catalog:
    parser.error("Codex Runner requires --codex-catalog")
if "hermes" in hosts and not (args.hermes_owner and args.hermes_install):
    parser.error("Hermes requires --hermes-owner and --hermes-install")
if "hermes" in hosts:
    hroot = args.hermes_owner.resolve() / "hermes-agent"
pi, node, codex = args.pi_root, args.node, args.codex


def digest(p):
    with p.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def run():
    hosts = {caller, runner}
    with tempfile.TemporaryDirectory(prefix="m027-matrix-", dir=args.scratch) as t:
        root = P(t)
        case = root / "case"
        case.mkdir(mode=0o700)
        app = args.product.resolve()
        exercise = P(__file__).with_name("exercise.py")
        assert (
            digest(app)
            == "8c0114b2803df101fcebb934a9c1bd170abf67b522b5775c820b14e69c1c1133"
        )
        cmd = [
            "bwrap",
            "--die-with-parent",
            "--new-session",
            "--unshare-all",
            "--ro-bind",
            "/usr",
            "/usr",
            "--symlink",
            "usr/bin",
            "/bin",
            "--symlink",
            "usr/lib",
            "/lib",
            "--symlink",
            "usr/lib64",
            "/lib64",
            "--proc",
            "/proc",
            "--dev",
            "/dev",
            "--tmpfs",
            "/tmp",
            "--bind",
            str(case),
            "/case",
            "--dir",
            "/host",
            "--dir",
            "/tools",
            "--ro-bind",
            str(app),
            "/tools/akasha-otsuge",
            "--ro-bind",
            str(exercise),
            "/exercise.py",
        ]
        mounts = [
            (P(__file__).with_name("native_tui.py"), "/native_tui.py"),
            (args.fd.resolve(), "/tools/fd"),
            (args.rg.resolve(), "/tools/rg"),
        ]
        if "hermes" in hosts:
            mounts.extend(
                [
                    (args.hermes_tui_dist.resolve(), "/host/hermes-tui/dist"),
                    (args.node.resolve(), "/tools/node"),
                ]
            )
        if runner == "codex":
            model = next(
                m
                for m in json.loads(args.codex_catalog.read_bytes())["models"]
                if m["slug"] == "gpt-6.1-sol"
            )
            catalog = root / "catalog"
            catalog.write_text(json.dumps({"models": [model]}))
            mounts.append((catalog, "/catalog"))

        if "pi" in hosts:
            mounts.extend([(pi, "/host/pi"), (node, "/tools/node")])
            cmd += ["--symlink", "/host/pi/node_modules/.bin/pi", "/tools/pi"]
        if "codex" in hosts:
            assert (
                digest(codex)
                == "b93f6811d3f653f0fb83be4050d857fb9abbb111dfa2ce160563327daff7f306"
            )
            mounts.append((codex, "/tools/codex"))
        if "hermes" in hosts:
            pristine = root / "qualified-hermes"
            git_env = dict(
                os.environ,
                GIT_CONFIG_GLOBAL="/dev/null",
                GIT_CONFIG_NOSYSTEM="1",
                GIT_LFS_SKIP_SMUDGE="1",
            )
            subprocess.run(
                [
                    "git",
                    "clone",
                    "--quiet",
                    "--shared",
                    "--local",
                    "--no-checkout",
                    hroot,
                    pristine,
                ],
                check=True,
                timeout=60,
                env=git_env,
            )
            subprocess.run(
                [
                    "git",
                    "-C",
                    pristine,
                    "checkout",
                    "--quiet",
                    "--detach",
                    "4960e41cec01de499ab99c4251437bc8039e41db",
                ],
                check=True,
                timeout=120,
                env=git_env,
            )
            assert not subprocess.check_output(
                [
                    "git",
                    "-C",
                    pristine,
                    "status",
                    "--porcelain",
                    "--untracked-files=no",
                ],
                env=git_env,
            )
            (pristine / ".venv").mkdir()
            active = hroot.parent
            inst = args.hermes_install.resolve()
            assert inst.parent == active / "installs"
            clone = case / "offline-owner"
            clone.mkdir()
            private_inst = clone / "installs" / inst.name
            private_inst.mkdir(parents=True)
            private_tools = clone / "tools"
            private_tools.mkdir()
            shutil.copy2(inst / "facts.json", private_inst / "facts.json")
            shutil.copytree(inst / "inputs", private_inst / "inputs", symlinks=False)
            shutil.copy2(active / "tools/facts.json", private_tools / "facts.json")
            cur = P(
                json.loads((inst / "facts.json").read_text())["packages"]["venv"][
                    "environment"
                ]
            ).parent
            envcopy = private_inst / "environments" / cur.name
            envcopy.mkdir(parents=True)
            (envcopy / ".leases").mkdir()
            (private_inst / "pm-runtime" / "generations").mkdir(parents=True)
            shutil.copy2(
                inst / "pm-runtime/selected.json",
                private_inst / "pm-runtime/selected.json",
            )
            (clone / "hermes-agent").mkdir()
            (clone / "profiles" / "trial").mkdir(parents=True)
            cmd += ["--bind", str(clone), str(active)]
            for c in cur.iterdir():
                if c.name == ".leases":
                    continue
                (envcopy / c.name).mkdir() if c.is_dir() else (envcopy / c.name).touch()
                mounts.append((c, str(c)))
            for pg in (inst / "pm-runtime/generations").iterdir():
                dst = private_inst / "pm-runtime/generations" / pg.name
                dst.mkdir()
                (dst / ".leases").mkdir()
                for c in pg.iterdir():
                    if c.name == ".leases":
                        continue
                    (dst / c.name).mkdir() if c.is_dir() else (dst / c.name).touch()
                    mounts.append((c, str(c)))
            for tool in ("python", "uv"):
                entry = json.loads((active / "tools/facts.json").read_text())[
                    "packages"
                ][tool]["entry"]
                (private_tools / entry).mkdir()
                mounts.append((active / "tools" / entry, str(active / "tools" / entry)))
            cmd += [
                "--symlink",
                "/usr/bin/python3",
                str(active.parent / ".local/bin/python3"),
                "--bind",
                str(pristine),
                str(hroot),
            ]
            mounts.extend(
                [
                    (hroot / ".git/objects", str(hroot / ".git/objects")),
                    (hroot / ".venv", str(hroot / ".venv")),
                ]
            )
        for a, b in mounts:
            cmd += ["--ro-bind", str(a), str(b)]
        cmd += [
            "--clearenv",
            "--setenv",
            "PATH",
            "/tools:/usr/bin:/bin",
            "--setenv",
            "PYTHONDONTWRITEBYTECODE",
            "1",
            "--setenv",
            "LANG",
            "C.UTF-8",
            "--setenv",
            "HOME",
            "/case/home",
            "--chdir",
            "/case",
            "/usr/bin/python3",
            "-B",
            "/exercise.py",
            caller,
            runner,
            hint,
        ]
        if "hermes" in hosts:
            i = cmd.index("--chdir")
            cfg = [
                "--setenv",
                "MATRIX_HERMES_PROFILE",
                str(active / "profiles/trial"),
                "--setenv",
                "MATRIX_HERMES_SOURCE",
                str(hroot),
                "--setenv",
                "MATRIX_HERMES_BINARY",
                str(cur / "venv/bin/hermes"),
            ]
            cmd[i:i] = cfg
        ret = subprocess.run(
            cmd,
            check=False,
            timeout=320,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
        )
        result = (
            json.loads((case / "report.json").read_bytes())
            if (case / "report.json").exists()
            else {}
        )
        result["exercise_sha256"] = digest(exercise)
        result["exit"] = ret.returncode
        result["installed_binary_sha256"] = digest(app)
        result["package_source"] = "4e7b3a2799ebc2055750eb044b056cc1d887625a"
        with args.output.open("x") as f:
            json.dump(result, f, indent=2)
            f.write("\n")
        if ret.returncode:
            print(ret.stdout.decode(errors="replace")[-2500:], flush=True)
            raise SystemExit(ret.returncode)
        print("verified", caller, runner, hint, flush=True)


run()
