"""Run the native CLI round trip inside the isolated Linux mount namespace."""

import functools
import hashlib
import http.server
import json
import operator
import os
import shutil
import signal
import subprocess
import sys
import threading
import time
import uuid
from pathlib import Path

from native_tui import interactive

CALLER, RUNNER, MODE = sys.argv[1:]
HINT = None if MODE == "none" else "offline mirrors"
MESSAGE = "Keep the local mirror available when the network is offline."


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


REPORT = {
    "caller": CALLER,
    "runner": RUNNER,
    "hint": MODE,
    "provider": "deterministic isolated loopback",
    "real_model_calls": 0,
    "billed_usd": 0,
    "calls": [],
}
A = Path("/case")
home = A / "home"
work = A / "workspace"
ch = A / "codex-home"
pp = A / "pi-profile"
hp = Path(os.environ.get("MATRIX_HERMES_PROFILE", "/case/hermes-profile"))
runtime = A / "runtime"
for d in [home, work, ch, pp, runtime]:
    d.mkdir(mode=0o700, exist_ok=True)
os.umask(0o077)
os.environ.update(
    HOME=str(home),
    TMPDIR="/tmp",
    XDG_RUNTIME_DIR=str(runtime),
    PYTHONDONTWRITEBYTECODE="1",
    NO_PROXY="*",
    no_proxy="*",
    PI_SKIP_VERSION_CHECK="1",
    PI_CODING_AGENT_DIR=str(pp),
    CODEX_HOME=str(ch),
)
binaries = {
    "pi": "/tools/pi",
    "codex": "/tools/codex",
    "hermes": os.environ.get("MATRIX_HERMES_BINARY", "/tools/hermes"),
}
if "hermes" in (CALLER, RUNNER):
    real_hermes = binaries["hermes"]
    wrapper = A / "hermes"
    wrapper.write_text(
        '#!/bin/sh\nexport PYTHONPATH="$MATRIX_HERMES_SOURCE"\nexec '
        + real_hermes
        + ' "$@" 2>>/case/hermes-native.stderr.log\n'
    )
    wrapper.chmod(0o700)
    binaries["hermes"] = str(wrapper)
    os.environ["PATH"] = str(Path(real_hermes).parent) + ":" + os.environ["PATH"]
    os.environ.update(HERMES_HOME=str(hp), HERMES_DISABLE_LAZY_INSTALLS="1")
missing = [h for h in ("pi", "hermes", "claude", "codex") if h not in {CALLER, RUNNER}]
assert all(shutil.which(h) is None for h in missing)
REPORT["other_clis_absent_from_path"] = missing
scope = None
desc = None
selected = None
source = None
fail = []
children = []
responses = {}
caller_saved = False


def unwrap(v):
    if isinstance(v, str):
        return unwrap(json.loads(v))
    if isinstance(v, list):
        assert len(v) == 1
        return unwrap(v[0])
    if "value" in v:
        return v["value"]
    if "text" in v and isinstance(v["text"], str):
        return unwrap(v["text"])
    if "output" in v:
        return unwrap(v["output"])
    raise ValueError("unexpected native envelope " + str(list(v))[:100])


def decide(role, results, available):
    global desc, selected, source, caller_saved
    n = len(results)
    name = None
    args = {}
    answer = None
    if role == "caller":
        if n == 0:
            if CALLER == "codex":
                name = "exec_command"
                args = {
                    "cmd": "akasha-otsuge consult"
                    + (" " + json.dumps(HINT) if HINT else "")
                }
            else:
                name = "akasha_consult"
                args = {"hint": HINT} if HINT else {}
        else:
            assert n == 1
            if any(
                k in str(results[0])
                for k in (
                    "HISTORY_GAP",
                    "PROTOCOL_INVALID",
                    "DAEMON_UNAVAILABLE",
                    "IPC_TIMEOUT",
                    "BINDING_UNAVAILABLE",
                )
            ):
                raise RuntimeError(
                    "Caller tool returned an error " + str(results[0])[:500]
                )
            answer = "The consult was submitted."
            caller_saved = True
    elif n == 0:
        name = "context_describe"
    elif n == 1:
        desc = unwrap(results[-1])
        assert desc["source"]["adapter"] == CALLER, tuple(desc)
        assert (
            desc["requested_cursor"] == desc["available_cursor"]
            and desc["requested_cursor"] > 0
        ), desc
        name = "context_search"
        args = {"query": MESSAGE, "limit": 8}
    elif n == 2:
        page = unwrap(results[-1])
        assert len(page["events"]) > 0, ("empty native search", list(page))
        selected = page["events"][0]["reference"]
        name = "context_read"
        args = {"handle": page["events"][0]["handle"], "start": 0, "max_bytes": 4096}
    elif n == 3:
        read = unwrap(results[-1])
        assert read["text"] == MESSAGE and not read["truncated"], (
            "native exact bytes",
            str(read.get("text"))[:140],
        )
        (source,) = read["sources"]
        answer = json.dumps(
            {
                "status": "found",
                "answer": MESSAGE,
                "sources": [source],
                "memories": [],
                "conditions": [],
                "conflicts": [],
                "gaps": [],
            }
        )
    else:
        raise RuntimeError("extra model request " + str((role, n)))
    assert name is None or name in available, (name, available)
    REPORT["calls"].append([role, name or "final", n])
    return name, args, answer


class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def do_GET(self):
        v = json.dumps(
            {"object": "list", "data": [{"id": "fixture", "object": "model"}]}
        ).encode()
        self.send_response(200)
        self.send_header("Content-Length", str(len(v)))
        self.end_headers()
        self.wfile.write(v)

    def do_POST(self):
        try:
            if self.path == "/api/show":
                self.rfile.read(int(self.headers["Content-Length"]))
                self.send_error(404, "No local Ollama model")
                return
            raw = self.rfile.read(int(self.headers["Content-Length"]))
            if self.headers.get("Content-Encoding") == "zstd":
                raw = subprocess.run(
                    ["/usr/bin/zstd", "-qd", "-c"],
                    input=raw,
                    capture_output=True,
                    check=True,
                ).stdout
            req = json.loads(raw)
            rid = uuid.uuid4().hex
            if self.path.endswith("/responses"):
                inp = req["input"]
                decl = req.get("tools", []) + functools.reduce(
                    operator.iadd,
                    (i["tools"] for i in inp if i.get("type") == "additional_tools"),
                    [],
                )
                names = {z.get("name", "") for z in decl} | {
                    z.get("name", "") for t in decl for z in t.get("tools", [])
                }
                role = "caller" if "exec_command" in names else "runner"
                results = [
                    m["output"] for m in inp if m.get("type") == "function_call_output"
                ]
                if names:
                    name, args, answer = decide(role, results, names)
                else:
                    name, args, answer = None, {}, "Local check"
                    REPORT["auxiliary_no_tool_requests"] = (
                        REPORT.get("auxiliary_no_tool_requests", 0) + 1
                    )
                self.start_sse()

                def emit(kind, **kw):
                    self.wfile.write(
                        b"event: "
                        + kind.encode()
                        + b"\ndata: "
                        + json.dumps(dict(type=kind, **kw)).encode()
                        + b"\n\n"
                    )
                    self.wfile.flush()

                emit(
                    "response.created",
                    response={
                        "id": "resp_" + rid,
                        "status": "in_progress",
                        "output": [],
                    },
                )
                item = (
                    {
                        "type": "function_call",
                        "id": "fc_" + rid,
                        "call_id": "call_" + rid,
                        "name": name,
                        "arguments": json.dumps(args),
                        "status": "completed",
                    }
                    if name
                    else {
                        "type": "message",
                        "id": "msg_" + rid,
                        "role": "assistant",
                        "status": "completed",
                        "content": [
                            {"type": "output_text", "text": answer, "annotations": []}
                        ],
                    }
                )
                emit("response.output_item.done", output_index=0, item=item)
                emit(
                    "response.completed",
                    response={
                        "id": "resp_" + rid,
                        "status": "completed",
                        "output": [item],
                        "usage": {
                            "input_tokens": 16,
                            "output_tokens": 4,
                            "total_tokens": 20,
                        },
                    },
                )
            else:
                assert self.path.endswith("/chat/completions"), self.path
                names = {q["function"]["name"] for q in req.get("tools", [])}
                role = "caller" if "akasha_consult" in names else "runner"
                results = [m["content"] for m in req["messages"] if m["role"] == "tool"]
                if names:
                    name, args, answer = decide(role, results, names)
                else:
                    name, args, answer = None, {}, "Local check"
                    REPORT["auxiliary_no_tool_requests"] = (
                        REPORT.get("auxiliary_no_tool_requests", 0) + 1
                    )
                message = {"role": "assistant"}
                if name:
                    message["tool_calls"] = [
                        {
                            "id": "call_" + rid,
                            "type": "function",
                            "function": {"name": name, "arguments": json.dumps(args)},
                        }
                    ]
                else:
                    message["content"] = answer
                reason = "tool_calls" if name else "stop"
                if not req.get("stream"):
                    v = json.dumps(
                        {
                            "id": "chatcmpl_" + rid,
                            "object": "chat.completion",
                            "created": 1,
                            "model": "fixture",
                            "choices": [
                                {
                                    "index": 0,
                                    "message": message,
                                    "finish_reason": reason,
                                }
                            ],
                            "usage": {
                                "prompt_tokens": 16,
                                "completion_tokens": 4,
                                "total_tokens": 20,
                            },
                        }
                    ).encode()
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Content-Length", str(len(v)))
                    self.end_headers()
                    self.wfile.write(v)
                    return
                self.start_sse()

                def chunk(delta, fin=None):
                    self.wfile.write(
                        b"data: "
                        + json.dumps(
                            {
                                "id": "chatcmpl_" + rid,
                                "object": "chat.completion.chunk",
                                "created": 1,
                                "model": "fixture",
                                "choices": [
                                    {"index": 0, "delta": delta, "finish_reason": fin}
                                ],
                            }
                        ).encode()
                        + b"\n\n"
                    )

                if name:
                    message["tool_calls"][0]["index"] = 0
                chunk(message)
                chunk({}, reason)
                self.wfile.write(b"data: [DONE]\n\n")
                self.wfile.flush()
            self.close_connection = True
        except Exception as e:
            fail.append(repr(e))
            print("fixture", repr(e), flush=True)
            self.close_connection = True

    def start_sse(self):
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Connection", "close")
        self.end_headers()


srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
threading.Thread(target=srv.serve_forever, daemon=True).start()
url = f"http://127.0.0.1:{srv.server_port}/v1"
os.environ.update(OPENAI_API_KEY="isolated-fixture", OPENAI_BASE_URL=url)


def run(cmd, timeout=65):
    p = subprocess.run(
        [str(c) for c in cmd], cwd=work, capture_output=True, text=True, timeout=timeout
    )
    if p.returncode:
        raise ValueError(
            ("command", str(cmd[0]), p.returncode, p.stderr[-550:], p.stdout[-360:])
        )
    return p.stdout


base = ["/tools/akasha-otsuge", "--config", "/case/akasha.toml"]


def cli(*args):
    return json.loads(run([*base, *args]))["data"]


def start(argv, tag):
    log = (A / (tag + ".log")).open("w")
    p = subprocess.Popen(
        list(map(str, argv)),
        cwd=work,
        stdin=subprocess.DEVNULL,
        stdout=log,
        stderr=subprocess.STDOUT,
        start_new_session=True,
    )
    log.close()
    children.append(p)
    return p


def wait(check, timeout=85):
    limit = time.monotonic() + timeout
    while time.monotonic() < limit:
        result = check()
        if result:
            return result
        if fail:
            raise RuntimeError("fixture failure " + str(fail[:2]))
        time.sleep(0.1)
    raise TimeoutError("wait")


def try_state(p):
    try:
        return json.loads(p.read_bytes())
    except (ValueError, FileNotFoundError):
        return {}


def main():
    hosts = {CALLER, RUNNER}
    for h in sorted(hosts):
        REPORT.setdefault("versions", {})[h] = (
            run([binaries[h], "--version"], 40).strip().splitlines()[0]
        )
    if "pi" in hosts:
        (pp / "models.json").write_text(
            json.dumps(
                {
                    "providers": {
                        "local": {
                            "baseUrl": url,
                            "api": "openai-completions",
                            "apiKey": "fixture",
                            "models": [
                                {
                                    "id": "fixture",
                                    "name": "fixture",
                                    "reasoning": False,
                                    "input": ["text"],
                                    "contextWindow": 32768,
                                    "maxTokens": 2048,
                                    "cost": {
                                        "input": 0,
                                        "output": 0,
                                        "cacheRead": 0,
                                        "cacheWrite": 0,
                                    },
                                }
                            ],
                        }
                    }
                }
            )
        )
        (pp / "settings.json").write_text(
            json.dumps(
                {
                    "defaultProvider": "local",
                    "defaultModel": "fixture",
                    "defaultThinkingLevel": "off",
                }
            )
        )
    if "hermes" in hosts:
        os.environ.update(HERMES_TUI_DIR="/host/hermes-tui", HERMES_NODE="/tools/node")
        (hp / "config.yaml").write_text(
            json.dumps(
                {
                    "_config_version": 12,
                    "updates": {"check": False},
                    "model": {
                        "default": "fixture",
                        "provider": "custom",
                        "base_url": url,
                        "api_mode": "chat_completions",
                        "key_env": "OPENAI_API_KEY",
                    },
                    "plugins": {
                        "enabled": ["akasha-otsuge"],
                        "isolation": "in_process",
                    },
                    "tools": {"tool_search": {"enabled": "off"}},
                    "agent": {"max_turns": 7, "run_budget_seconds": 90},
                    "terminal": {"cwd": str(work)},
                    "gateway": {"standalone": True, "auto_multiplex_migration": False},
                    "sessions": {"max_export_messages": 128},
                    "telemetry": {
                        "shared_metrics": {
                            "enabled": False,
                            "send": False,
                            "offer_version": 2,
                        }
                    },
                }
            )
        )
    if "codex" in hosts:
        if RUNNER == "codex":
            shutil.copyfile("/catalog", ch / "models_cache.json")
        (ch / "config.toml").write_text(
            'model="fixture"\nmodel_reasoning_effort="high"\nmodel_provider="fixture"\n[model_providers.fixture]\nname="Fixture"\nbase_url="'
            + url
            + '"\nwire_api="responses"\nsupports_websockets=false\nrequest_max_retries=0\nstream_max_retries=0\n[features]\nremote_models=false\nskip_host_skill_discovery=true\nshell_tool=true\nmulti_agent=false\napps=false\ncode_mode=false\ncode_mode_only=false\ncode_mode_host=false\n'
        )
    profiles = {"pi": pp, "codex": ch, "hermes": hp}
    if RUNNER == "codex":
        rhome = A / "codex-runner-home"
        rhome.mkdir(mode=0o700)
        profiles["codex"] = rhome
        (rhome / "config.toml").write_text(
            (ch / "config.toml")
            .read_text()
            .replace('model="fixture"', 'model="gpt-6.1-sol"')
        )
        shutil.move(ch / "models_cache.json", rhome / "models_cache.json")
    (A / "akasha.toml").write_text(
        "[paths]\ndata_dir='/case/store'\nsocket_path='/case/runtime/a.sock'\n[access]\nread_roots=['/case'"
        + ("," + json.dumps(str(hp)) if "hermes" in hosts else "")
        + "]\n[consult]\nexecutor='matrix'\n[executors.matrix]\nkind="
        + json.dumps(RUNNER)
        + "\nbinary="
        + json.dumps(binaries[RUNNER])
        + "\nnative_home="
        + json.dumps(str(profiles[RUNNER]))
        + "\n"
    )
    d = start([*base, "daemon", "run"], "daemon")

    def ready_service():
        if d.poll() is not None:
            raise RuntimeError("early daemon exit")
        if not (runtime / "a.sock").exists():
            return False
        try:
            return cli("daemon", "status")
        except ValueError as e:
            if any(code in str(e) for code in ("IPC_TIMEOUT", "DAEMON_UNAVAILABLE")):
                return False
            raise

    wait(ready_service, 65)
    for h in sorted(hosts):
        if h == "pi":
            cli("adapter", "install", "pi", "--binary", binaries[h], "--agent-dir", pp)
        if h == "hermes":
            cli("adapter", "install", "hermes", "--binary", binaries[h], "--home", hp)
        if h == "codex" and CALLER == "codex":
            cli(
                "adapter",
                "install",
                "codex",
                "--binary",
                binaries[h],
                "--launcher",
                A / "launcher",
                "--state-dir",
                A / "hook-state",
            )
    if CALLER == "pi":
        cmd = [
            binaries[CALLER],
            "--mode",
            "json",
            "--print",
            "--session",
            A / "caller.jsonl",
            "--no-builtin-tools",
            "--no-extensions",
            "--no-mcp",
            "--no-skills",
            "--no-prompt-templates",
            "--no-themes",
            "--no-context-files",
            "--no-approve",
            "-e",
            pp / "extensions/akasha-otsuge/index.ts",
            "--tools",
            "akasha_consult",
            MESSAGE,
        ]
    elif CALLER == "codex":
        cmd = [
            A / "launcher",
            "--dangerously-bypass-hook-trust",
            "-c",
            'model="fixture"',
            "exec",
            "--json",
            "--skip-git-repo-check",
            "--sandbox",
            "read-only",
            MESSAGE,
        ]
    else:
        gateway = start(
            [
                binaries["hermes"],
                "gateway",
                "run",
                "--quiet",
                "--no-supervise",
                "--external-supervisor",
            ],
            "gateway",
        )

        def ready():
            state = try_state(hp / "gateway_state.json")
            if gateway.poll() is not None:
                raise RuntimeError("gateway early exit")
            return state.get("pid") == gateway.pid and state.get("gateway_state") in (
                "running",
                "degraded",
            )

        wait(ready, 85)
        (A / "task.txt").write_text(MESSAGE)
        cmd = [
            binaries["hermes"],
            "chat",
            "--oneshot",
            "--query-file",
            A / "task.txt",
            "--format",
            "stream-json",
            "--toolsets",
            "akasha",
            "--ignore-rules",
            "--in",
            work,
        ]
    if CALLER == "pi":
        flag = A / "ready.ts"
        flag.write_text(
            "import fs from 'node:fs';export default function(pi){pi.on('session_start',()=>fs.writeFileSync('/case/pi-ready','ready'));}"
        )
        cmd = [
            binaries["pi"],
            "--session",
            A / "caller.jsonl",
            "--no-builtin-tools",
            "--no-extensions",
            "--no-mcp",
            "--no-skills",
            "--no-prompt-templates",
            "--no-themes",
            "--no-context-files",
            "--no-approve",
            "-e",
            pp / "extensions/akasha-otsuge/index.ts",
            "-e",
            flag,
            "--tools",
            "akasha_consult",
        ]
    elif CALLER == "codex":
        with (ch / "config.toml").open("a") as cfg:
            cfg.write('[projects."/case/workspace"]\ntrust_level="trusted"\n')
        cmd = [
            A / "launcher",
            "--dangerously-bypass-hook-trust",
            "--no-alt-screen",
            "--sandbox",
            "read-only",
            "--ask-for-approval",
            "never",
            "-c",
            'model="fixture"',
        ]
    else:
        cmd = [
            binaries["hermes"],
            "chat",
            "--tui",
            "--toolsets",
            "akasha",
            "--ignore-rules",
            "--in",
            work,
        ]
    interactive(A, work, cmd, CALLER, MESSAGE, lambda: caller_saved, REPORT, children)

    ls = cli("job", "list")["items"]
    jobs = [j["id"] for j in ls if j["id"].startswith("consult/")]
    assert len(jobs) == 1, len(jobs)
    jid = jobs[0]

    def completed():
        j = cli("job", "show", jid)
        return j if j["state"] not in ("queued", "running") else None

    job = wait(completed, 100)
    print("job state", job["state"], job.get("error"), flush=True)
    assert job["state"] == "succeeded", (job["state"], job.get("error"))
    pub = cli("consult", "show", jid)
    rec = cli("consult", "receipt", jid)
    assert (
        pub == json.loads(rec["data"]["output"])
        and pub["status"] == "found"
        and pub["answer"] == MESSAGE
        and pub["gaps"] == []
    ), ("public", pub.get("status"), pub.get("gaps"))
    assert len(pub["evidence"]) == 1
    s = pub["evidence"][0]
    assert s == source
    orig = cli("consult", "original", jid, 0)
    assert orig.get("output", orig.get("text")) == MESSAGE, (
        "original keys",
        list(orig),
    )
    check = cli(
        "show",
        s["event_id"],
        "--revision",
        s["revision"],
        "--range",
        s["start"],
        s["end"],
    )
    assert (
        check["output"] == MESSAGE
        and sha(MESSAGE.encode()) == s["content_sha256"]
        and check["scope"] == pub["scope"]
    )
    (runrow,) = job["run_trace"]["runs"]
    assert (
        runrow["host"] == RUNNER
        and runrow["state"] == "succeeded"
        and len(runrow["fence"]) == 64
    )
    plan = job["consult_plan"]
    assert (
        runrow["origin"] == plan["invocation_id"] and runrow["fence"] == plan["fence"]
    )
    assert (
        plan["args"].get("hint") == HINT
        and rec["data"]["record"]["scope"] == check["scope"]
    )
    assert (
        desc["source"]["adapter"] == CALLER
        and desc["requested_cursor"] <= desc["available_cursor"]
        and selected["source"]["adapter"] == CALLER
    )
    assert pub["scope"]["user"] == f"uid:{os.geteuid()}"
    assert caller_saved and not fail
    REPORT.update(
        saved_invocation_matches_origin_and_fence=True,
        registered_hint_persisted=True,
        terminal=job["state"],
        public_status=pub["status"],
        receipt_identical=True,
        canonical_source_sha256=s["content_sha256"],
        original_exact=True,
        scopes_agree=True,
        scope_user_bound_to_os=True,
        caller_source=desc["source"]["adapter"],
        runner_host=runrow["host"],
        fence_digest_length=len(runrow["fence"]),
        bound_requested_cursor=desc["requested_cursor"],
        available_cursor=desc["available_cursor"],
        bound_read_seq=desc["read_seq"],
        published_read_seq=rec["read_seq"],
        provider_errors=0,
    )
    cli("daemon", "stop")
    assert d.wait(timeout=35) == 0


try:
    main()
except Exception as e:
    REPORT["failed"] = type(e).__name__
    raise
finally:
    if "failed" in REPORT and hp.exists():
        for f in sorted(hp.rglob("*.log"))[-8:]:
            try:
                print(
                    "native diagnostic",
                    f.name,
                    "\n".join(
                        l[:300]
                        for l in f.read_text(errors="replace").splitlines()
                        if any(
                            key in l.lower()
                            for key in (
                                "akasha",
                                "exception",
                                "error",
                                "traceback",
                                "fail",
                                "denied",
                                "no such",
                            )
                        )
                    )[-4400:],
                    flush=True,
                )
            except OSError:
                pass
    for p in reversed(children):
        if p.poll() is None:
            try:
                os.killpg(p.pid, signal.SIGTERM)
                p.wait(timeout=6)
            except (ProcessLookupError, subprocess.TimeoutExpired):
                try:
                    os.killpg(p.pid, signal.SIGKILL)
                    p.wait(timeout=5)
                except ProcessLookupError:
                    pass
    srv.shutdown()
    (A / "report.json").write_text(json.dumps(REPORT))
