"""Drive a native controlling terminal through the normal interactive input path."""

import errno
import fcntl
import json
import os
import pty
import re
import select
import sqlite3
import struct
import subprocess
import termios
import time
from pathlib import Path


def hermes_turn_committed():
    db = Path(os.environ["HERMES_HOME"]) / "state.db"
    active = list(Path("/tmp").glob("hermes-tui-active-session-*.json"))
    if len(active) != 1 or not db.is_file():
        return False
    try:
        session = json.loads(active[0].read_bytes()).get("session_id")
        with sqlite3.connect(db.as_uri() + "?mode=ro", uri=True, timeout=0.25) as c:
            return bool(
                c.execute(
                    "SELECT 1 FROM messages WHERE session_id=? AND active=1 AND role='assistant' AND instr(content,?)>0 LIMIT 1",
                    (session, "The consult was submitted."),
                ).fetchone()
            )
    except (sqlite3.Error, OSError, ValueError):
        return False


def interactive(root, work, argv, host, message, registered, report, children):
    launch = root / "terminal-child.py"
    launch.write_text(
        "import os,sys,fcntl,termios\nos.setsid()\nfcntl.ioctl(0,termios.TIOCSCTTY,0)\nos.execvpe(sys.argv[1],sys.argv[1:],os.environ)\n"
    )
    master, slave = pty.openpty()
    fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", 40, 135, 0, 0))
    proc = subprocess.Popen(
        ["/usr/bin/python3", "-B", str(launch), *map(str, argv)],
        cwd=work,
        env=dict(os.environ, TERM="xterm-256color", COLORTERM="truecolor"),
        stdin=slave,
        stdout=slave,
        stderr=slave,
    )
    os.close(slave)
    children.append(proc)
    raw = bytearray()
    entered = False
    typed = None
    quit_at = None
    state = "enter"
    begin = time.monotonic()
    foreground = False
    trusted = False
    try:
        while proc.poll() is None and time.monotonic() - begin < 92:
            ready, _, _ = select.select([master], [], [], 0.1)
            if ready:
                try:
                    chunk = os.read(master, 65536)
                except OSError as e:
                    if e.errno != errno.EIO:
                        raise
                    break
                raw.extend(chunk)
                assert len(raw) < 2 * 1024 * 1024
                for query, response in [
                    (b"\x1b[6n", b"\x1b[1;1R"),
                    (b"\x1b[c", b"\x1b[?1;2c"),
                    (b"\x1b[?u", b"\x1b[?0u"),
                    (b"\x1b]11;?", b"\x1b]11;rgb:0000/0000/0000\x1b\\"),
                    (b"\x1b]10;?", b"\x1b]10;rgb:ffff/ffff/ffff\x1b\\"),
                ]:
                    if query in chunk:
                        os.write(master, response)
            if not foreground:
                foreground = os.tcgetpgrp(master) == proc.pid
            clean = re.sub(rb"\x1b\[[0-?]*[ -/]*[@-~]", b"", raw).lower()
            if not entered:
                if typed is not None:
                    if time.monotonic() - typed > 0.35:
                        os.write(master, b"\r")
                        entered = True
                    continue
                if host == "pi":
                    ready_input = (root / "pi-ready").exists()
                elif host == "hermes":
                    ready_input = any(
                        Path("/tmp").glob("hermes-tui-active-session-*.json")
                    )
                else:
                    if b"trust" in clean[-1500:] and not trusted:
                        os.write(master, b"\r")
                        trusted = True
                    ready_input = b"codex" in clean and (
                        b"for shortcuts" in clean
                        or b"context left" in clean
                        or b"ask codex to do anything" in clean
                        or b"state=idle:app=codex" in raw
                        or b"/help" in clean
                    )
                if ready_input and foreground:
                    if host == "pi":
                        os.write(master, message.encode())
                        typed = time.monotonic()
                    else:
                        os.write(master, b"\x1b[200~" + message.encode() + b"\x1b[201~")
                        typed = time.monotonic()
            elif (
                registered()
                and quit_at is None
                and (
                    b"consult was submitted" in clean
                    or b"state=done:app=codex" in raw
                    or host == "hermes"
                    and hermes_turn_committed()
                )
            ):
                quit_at = time.monotonic()
            elif quit_at and state == "enter" and time.monotonic() - quit_at > 0.7:
                if host == "pi":
                    os.write(master, b"/quit\r")
                else:
                    os.write(master, b"\x04")
                state = "exit"
        exit_code = proc.poll()
        if exit_code is None and state == "exit":
            try:
                exit_code = proc.wait(timeout=7)
            except subprocess.TimeoutExpired:
                pass
        if exit_code != 0:
            print(
                "terminal diagnostics",
                host,
                entered,
                foreground,
                registered(),
                bytes(clean[-1500:]).decode(errors="replace"),
                flush=True,
            )
        assert entered and foreground and exit_code == 0, (
            host,
            "TUI",
            entered,
            foreground,
            exit_code,
        )
        report.update(
            interactive_pty=True,
            interactive_input_submitted=True,
            foreground_process_group_verified=True,
            terminal_exit=0,
        )
    finally:
        os.close(master)
