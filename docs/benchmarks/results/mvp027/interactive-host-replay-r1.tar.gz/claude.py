"""Run the repository's release-matched Claude Caller checks in a private namespace."""

import argparse
import hashlib
import json
import subprocess
import tempfile
from pathlib import Path

p = argparse.ArgumentParser(__doc__)
for flag in ("scratch", "product", "claude", "repository", "output"):
    p.add_argument("--" + flag, type=Path, required=True)
a = p.parse_args()
if a.output.exists():
    p.error("output already exists")


def sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


assert (
    sha(a.product) == "8c0114b2803df101fcebb934a9c1bd170abf67b522b5775c820b14e69c1c1133"
    and sha(a.claude)
    == "86dc1fcc69498159eaf15f446613e847010f9036bfbbdffd4c49350be8489ada"
)
with tempfile.TemporaryDirectory(prefix="claude-pty-", dir=a.scratch) as tmp:
    root = Path(tmp)
    case = root / "case"
    case.mkdir(mode=0o700)
    cmd = [
        "bwrap",
        "--unshare-all",
        "--new-session",
        "--die-with-parent",
        "--ro-bind",
        "/usr",
        "/usr",
        "--symlink",
        "usr/bin",
        "/bin",
        "--symlink",
        "usr/lib",
        "/lib",
        "--symlink",
        "usr/lib64",
        "/lib64",
        "--proc",
        "/proc",
        "--dev",
        "/dev",
        "--tmpfs",
        "/tmp",
        "--bind",
        str(case),
        "/case",
        "--ro-bind",
        str(a.product.resolve()),
        "/tools/akasha-otsuge",
        "--ro-bind",
        str(a.claude.resolve()),
        "/native/claude",
    ]
    for fn in ("scripts/check-claude-caller.py", "src/adapter/claude/caller.js"):
        local = root / fn
        local.parent.mkdir(parents=True, exist_ok=True)
        local.write_bytes(
            subprocess.check_output(
                ["git", "show", "4e7b3a2799ebc2055750eb044b056cc1d887625a:" + fn],
                cwd=a.repository,
            )
        )
        cmd.extend(["--ro-bind", str(local), "/repo/" + fn])
    cmd += [
        "--clearenv",
        "--setenv",
        "HOME",
        "/tmp",
        "--setenv",
        "PATH",
        "/tools:/usr/bin:/bin",
        "--chdir",
        "/case",
        "/usr/bin/python3",
        "-B",
        "/repo/scripts/check-claude-caller.py",
        "/native/claude",
        "/tools/akasha-otsuge",
        "/case/claude-work",
    ]
    run = subprocess.run(cmd, capture_output=True, timeout=240, check=False)
    if run.returncode:
        print(run.stderr.decode(errors="replace")[-1400:], flush=True)
        raise SystemExit(run.returncode)
    data = json.loads(run.stdout.splitlines()[-1])
    assert (
        data["native_bindings"] == 5
        and len(data["traces"]) >= 5
        and any(c["stage"] == "tui" and c["capture_jobs"] for c in data["checks"])
    )
    report = {
        "host": "claude",
        "product_sha256": sha(a.product),
        "native_sha256": data["native_sha256"],
        "checks": data["checks"],
        "traces": [
            {
                k: t[k]
                for k in ("captured_bytes", "captured_sha256", "checkpoint_revision")
            }
            for t in data["traces"]
        ],
        "native_backfill_jobs": data["native_backfill_jobs"],
        "external_model_requests": 0,
    }
with a.output.open("x") as file:
    json.dump(report, file, indent=2)
