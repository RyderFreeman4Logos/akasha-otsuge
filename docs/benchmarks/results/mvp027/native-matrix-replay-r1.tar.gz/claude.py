"""Real CLI pair, deterministic loopback only, synthetic data."""

import argparse
import functools
import hashlib
import http.server
import json
import operator
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path
from types import SimpleNamespace

MSG = "Use the cobalt mirror when offline."
KEY = "akasha-fixture-private-network-only"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(p):
    with Path(p).open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def encoded(x):
    return json.dumps(x, ensure_ascii=False).encode()


def write(p, x):
    p.write_bytes(encoded(x))


def render(x):
    if isinstance(x, str):
        return x
    if isinstance(x, list):
        return "".join(i["text"] for i in x if i.get("type") == "text")
    raise ValueError("tool result has no text")


def run():
    root = Path("/case")
    root.chmod(0o700)
    for sub in (
        "home",
        "claude-home",
        "codex-home",
        "pi-home",
        "work",
        "runtime",
        "tmp",
    ):
        (root / sub).mkdir(mode=0o700)
    args = SimpleNamespace(
        caller=sys.argv[2],
        runner=sys.argv[3],
        hint={"none": None, "short": "offline mirror"}[sys.argv[4]],
    )
    report = {
        "caller": args.caller,
        "runner": args.runner,
        "hint": args.hint,
        "claude_runner_timeout_s": 45 if args.runner == "claude" else None,
        "model_calls": 0,
        "billed_usd": 0,
        "network": "private loopback",
        "provider": "deterministic synthetic transport",
    }
    rows = []
    errors = []
    selected = []
    server = http.server.ThreadingHTTPServer

    class Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def senddata(self, typ, data):
            self.send_response(200)
            self.send_header("Content-Type", typ)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def do_POST(self):
            try:
                raw = self.rfile.read(int(self.headers["Content-Length"]))
                if self.headers.get("Content-Encoding") == "zstd":
                    raw = subprocess.run(
                        ["/usr/bin/zstd", "-qd", "-c"],
                        input=raw,
                        stdout=subprocess.PIPE,
                        check=True,
                    ).stdout
                req = json.loads(raw)
                if self.path.startswith("/v1/messages/count_tokens"):
                    self.senddata("application/json", b'{"input_tokens":32}')
                    return
                if self.path.startswith("/v1/messages"):
                    assert self.headers.get("x-api-key") == KEY
                    tools = [t["name"] for t in req.get("tools", [])]
                    msgs = req["messages"]
                    caller = "mcp__akasha-otsuge__consult" in tools
                    if not caller and not any(
                        t.startswith("mcp__akasha-runner__") for t in tools
                    ):
                        self.anthropic(req, None, {}, "Fixture session.", None)
                        return
                    prefix = (
                        "mcp__akasha-otsuge__" if caller else "mcp__akasha-runner__"
                    )
                    results = [
                        render(b["content"])
                        for m in msgs
                        if isinstance(m["content"], list)
                        for b in m["content"]
                        if b.get("type") == "tool_result"
                    ]
                    fn, params, answer = self.action(caller, results, req)
                    tool = prefix + fn if fn else None
                    assert tool is None or tool in tools, (tool, tools)
                    self.anthropic(req, tool, params, answer, len(results))
                    return
                if self.path == "/v1/chat/completions":
                    assert args.caller == "pi"
                    tools = [t["function"]["name"] for t in req["tools"]]
                    assert "akasha_consult" in tools
                    results = [
                        render(m["content"])
                        for m in req["messages"]
                        if m["role"] == "tool"
                    ]
                    fn, params, answer = self.action(True, results, req)
                    tool = "akasha_consult" if fn else None
                    ident = "chatcmpl_fixture_" + str(len(rows))
                    chunks = [{"role": "assistant"}]
                    if tool:
                        chunks.append(
                            {
                                "tool_calls": [
                                    {
                                        "index": 0,
                                        "id": "call_fixture_caller",
                                        "type": "function",
                                        "function": {
                                            "name": tool,
                                            "arguments": json.dumps(params),
                                        },
                                    }
                                ]
                            }
                        )
                    else:
                        chunks.append({"content": answer})
                    base = {
                        "id": ident,
                        "object": "chat.completion.chunk",
                        "created": 1,
                        "model": req["model"],
                    }
                    data = b"".join(
                        b"data: "
                        + encoded(
                            dict(
                                **base,
                                choices=[
                                    {"index": 0, "delta": c, "finish_reason": None}
                                ],
                            )
                        )
                        + b"\n\n"
                        for c in chunks
                    )
                    data += (
                        b"data: "
                        + encoded(
                            dict(
                                **base,
                                choices=[
                                    {
                                        "index": 0,
                                        "delta": {},
                                        "finish_reason": "tool_calls"
                                        if tool
                                        else "stop",
                                    }
                                ],
                            )
                        )
                        + b"\n\ndata: [DONE]\n\n"
                    )
                    self.senddata("text/event-stream", data)
                    return
                if self.path == "/v1/responses":
                    assert args.runner == "codex"
                    inputs = req["input"]
                    tools = req.get("tools", []) + functools.reduce(
                        operator.iadd,
                        (
                            i["tools"]
                            for i in inputs
                            if i.get("type") == "additional_tools"
                        ),
                        [],
                    )
                    names = [t.get("name") for t in tools] + [
                        v.get("name") for t in tools for v in t.get("tools", [])
                    ]
                    results = [
                        render(i["output"])
                        for i in inputs
                        if i.get("type") == "function_call_output"
                    ]
                    fn, params, answer = self.action(False, results, req)
                    assert fn is None or fn in names, (fn, names)
                    rid = "resp_local_" + str(len(rows))
                    fid = "fc_" + str(len(rows))
                    item = (
                        {
                            "type": "function_call",
                            "id": fid,
                            "call_id": "call_" + fid,
                            "name": fn,
                            "arguments": json.dumps(params),
                            "status": "completed",
                        }
                        if fn
                        else {
                            "type": "message",
                            "id": "msg_" + fid,
                            "role": "assistant",
                            "status": "completed",
                            "content": [
                                {
                                    "type": "output_text",
                                    "text": answer,
                                    "annotations": [],
                                }
                            ],
                        }
                    )
                    events = [
                        {
                            "type": "response.created",
                            "response": {
                                "id": rid,
                                "status": "in_progress",
                                "output": [],
                            },
                        },
                        {
                            "type": "response.output_item.done",
                            "output_index": 0,
                            "item": item,
                        },
                        {
                            "type": "response.completed",
                            "response": {
                                "id": rid,
                                "status": "completed",
                                "output": [item],
                                "usage": {
                                    "input_tokens": 32,
                                    "output_tokens": 8,
                                    "total_tokens": 40,
                                },
                            },
                        },
                    ]
                    self.senddata(
                        "text/event-stream",
                        b"".join(
                            b"event: "
                            + e["type"].encode()
                            + b"\ndata: "
                            + encoded(e)
                            + b"\n\n"
                            for e in events
                        ),
                    )
                    return
                raise ValueError(self.path)
            except (
                AssertionError,
                IndexError,
                KeyError,
                OSError,
                TypeError,
                ValueError,
            ) as exc:
                errors.append(f"{type(exc).__name__}: {str(exc)[:600]}")
                print("fixture protocol failure", type(exc).__name__, flush=True)
                self.send_error(400)

        def action(self, caller, results, req):
            assert len(rows) < 32
            n = len(results)
            fn = None
            params = {}
            answer = None
            if caller:
                assert MSG in str(req)
                if not n:
                    fn = "consult"
                    if args.hint is not None:
                        params = {"hint": args.hint}
                else:
                    assert n == 1
                    answer = "Submitted."
            elif n == 0:
                fn = "context_search"
                params = {"limit": 16, "query": MSG}
            else:
                v = json.loads(results[-1])
                if v["kind"] == "page":
                    page = v["value"]
                    if not page["events"]:
                        assert page.get("next") and n < 12, (
                            "no matching original at fence",
                            n,
                            page.get("gaps"),
                        )
                        fn = "context_search"
                        params = {"limit": 16, "query": MSG, "cursor": page["next"]}
                    else:
                        event = next(
                            v
                            for v in page["events"]
                            if v["reference"]["source"]["adapter"]
                            in (
                                args.caller,
                                "claude_code"
                                if args.caller == "claude"
                                else args.caller,
                            )
                        )
                        selected.append(event["reference"])
                        fn = "context_read"
                        params = {
                            "handle": event["handle"],
                            "start": 0,
                            "max_bytes": 4096,
                        }
                else:
                    assert v["kind"] == "text"
                    read = v["value"]
                    assert read["text"] == MSG and not read["truncated"], (
                        read.get("text"),
                        read.get("truncated"),
                    )
                    answer = json.dumps(
                        {
                            "status": "found",
                            "answer": MSG,
                            "conditions": ["when offline"],
                            "conflicts": [],
                            "gaps": [],
                            "memories": [],
                            "sources": read["sources"],
                        }
                    )
            rows.append(
                {
                    "role": "caller" if caller else "runner",
                    "tool": fn,
                    "preceding_results": n,
                }
            )
            return fn, params, answer

        def anthropic(self, req, tool, params, answer, n):
            ident = "local" + str(len(rows)) + ("title" if n is None else "")
            block = (
                {"type": "tool_use", "id": "toolu_" + ident, "name": tool, "input": {}}
                if tool
                else {"type": "text", "text": ""}
            )
            delta = (
                {"type": "input_json_delta", "partial_json": json.dumps(params)}
                if tool
                else {"type": "text_delta", "text": answer}
            )
            msg = {
                "id": "msg_" + ident,
                "type": "message",
                "role": "assistant",
                "model": req["model"],
                "content": [],
                "stop_reason": None,
                "stop_sequence": None,
                "usage": {"input_tokens": 32, "output_tokens": 0},
            }
            events = [
                {"type": "message_start", "message": msg},
                {"type": "content_block_start", "index": 0, "content_block": block},
                {"type": "content_block_delta", "index": 0, "delta": delta},
                {"type": "content_block_stop", "index": 0},
                {
                    "type": "message_delta",
                    "delta": {
                        "stop_reason": "tool_use" if tool else "end_turn",
                        "stop_sequence": None,
                    },
                    "usage": {"output_tokens": 8},
                },
                {"type": "message_stop"},
            ]
            self.senddata(
                "text/event-stream",
                b"".join(
                    b"event: " + e["type"].encode() + b"\ndata: " + encoded(e) + b"\n\n"
                    for e in events
                ),
            )

    srv = server(("127.0.0.1", 0), Handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    url = "http://127.0.0.1:" + str(srv.server_port)
    env = {
        "HOME": "/case/home",
        "XDG_RUNTIME_DIR": "/case/runtime",
        "TMPDIR": "/case/tmp",
        "USER": "obj",
        "LOGNAME": "obj",
        "PATH": "/tools:/usr/bin:/bin",
        "LANG": "C.UTF-8",
        "CLAUDE_CONFIG_DIR": "/case/claude-home",
        "ANTHROPIC_API_KEY": KEY,
        "ANTHROPIC_BASE_URL": url,
        "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC": "1",
        "DISABLE_AUTOUPDATER": "1",
        "CLAUDE_CODE_DISABLE_CLAUDE_MDS": "1",
        "PI_CODING_AGENT_DIR": "/case/pi-home",
        "PI_SKIP_VERSION_CHECK": "1",
        "CODEX_HOME": "/case/codex-home",
        "PYTHONDONTWRITEBYTECODE": "1",
    }
    write(
        root / "claude-home/.claude.json",
        {
            "hasCompletedOnboarding": True,
            "lastOnboardingVersion": "2.1.311",
            "customApiKeyResponses": {"approved": [KEY[-20:]], "rejected": []},
        },
    )
    write(
        root / "pi-home/models.json",
        {
            "providers": {
                "local-fixture": {
                    "baseUrl": url + "/v1",
                    "api": "openai-completions",
                    "apiKey": "synthetic",
                    "models": [
                        {
                            "id": "fixture",
                            "name": "Fixture",
                            "reasoning": False,
                            "input": ["text"],
                            "contextWindow": 32768,
                            "maxTokens": 2048,
                            "cost": {
                                "input": 0,
                                "output": 0,
                                "cacheRead": 0,
                                "cacheWrite": 0,
                            },
                        }
                    ],
                }
            }
        },
    )
    write(
        root / "pi-home/settings.json",
        {"defaultProvider": "local-fixture", "defaultModel": "fixture"},
    )
    if args.runner == "codex":
        cat = json.loads(Path("/fixture/catalog").read_bytes())
        write(root / "codex-home/models_cache.json", {"models": [cat]})
        (root / "codex-home/config.toml").write_text(
            "model="
            + json.dumps(cat["slug"])
            + '\nmodel_provider="local"\nmodel_reasoning_effort="high"\n[model_providers.local]\nname="Frozen local transport"\nbase_url="'
            + url
            + '/v1"\nwire_api="responses"\nsupports_websockets=false\nrequires_openai_auth=false\n'
        )
    cfg = root / "akasha.toml"
    kind = "claude_code" if args.runner == "claude" else args.runner
    cfg.write_text(
        '[paths]\ndata_dir="/case/data"\nsocket_path="/case/runtime/akasha.sock"\n[access]\nread_roots=["/case"]\n[consult]\nexecutor="selected"\n[executors.selected]\nkind="'
        + kind
        + '"\nbinary="/tools/'
        + args.runner
        + '"\nnative_home="/case/'
        + args.runner
        + '-home"\n'
    )
    if args.runner == "claude":
        with cfg.open("a") as f:
            f.write('timeout="45s"\n')
    app = "/tools/akasha-otsuge"
    base = [app, "--config", str(cfg)]

    def command(cmd, timeout=70):
        p = subprocess.run(
            cmd,
            check=False,
            cwd=root / "work",
            env=env,
            capture_output=True,
            timeout=timeout,
        )
        if p.returncode:
            raise RuntimeError(
                "command "
                + str(cmd[:2])
                + " exit "
                + str(p.returncode)
                + " "
                + p.stderr.decode(errors="replace")[-650:]
                + " "
                + p.stdout.decode(errors="replace")[-400:]
            )
        return p.stdout

    def cli(*c):
        return json.loads(command([*base, *map(str, c)]))["data"]

    def wait_for(call):
        stop = time.monotonic() + 80
        while time.monotonic() < stop:
            result = call()
            if result:
                return result
            time.sleep(0.15)
        raise RuntimeError("timeout waiting for condition")

    report["versions"] = {
        h: command(["/tools/" + h, "--version"]).decode().strip()
        for h in {args.caller, args.runner}
    }
    report["other_host_clis_absent"] = {
        h: shutil.which(h, path=env["PATH"]) is None
        for h in ("claude", "codex", "hermes", "pi")
        if h not in (args.caller, args.runner)
    }
    assert all(report["other_host_clis_absent"].values())
    try:
        cli("daemon", "start")
        if args.caller == "pi":
            cli(
                "adapter",
                "install",
                "pi",
                "--binary",
                "/tools/pi",
                "--agent-dir",
                "/case/pi-home",
            )
            command(
                [
                    "/tools/pi",
                    "--mode",
                    "json",
                    "--print",
                    "--session",
                    "/case/pi-home/source.jsonl",
                    "--no-builtin-tools",
                    "--no-extensions",
                    "--no-mcp",
                    "--no-skills",
                    "--no-prompt-templates",
                    "--no-themes",
                    "--no-context-files",
                    "--no-approve",
                    "-e",
                    "/case/pi-home/extensions/akasha-otsuge/index.ts",
                    "--tools",
                    "akasha_consult",
                    MSG,
                ]
            )
        else:
            cli(
                "adapter",
                "install",
                "claude",
                "--binary",
                "/tools/claude",
                "--directory",
                "/case/plugin",
            )
            command(
                [
                    "/tools/claude",
                    "--plugin-dir",
                    "/case/plugin",
                    "-p",
                    MSG,
                    "--tools",
                    "ToolSearch",
                    "--strict-mcp-config",
                    "--mcp-config",
                    '{"mcpServers":{}}',
                    "--setting-sources",
                    "",
                    "--output-format",
                    "stream-json",
                    "--verbose",
                ]
            )
        jobs = [
            i for i in cli("job", "list")["items"] if i["id"].startswith("consult/")
        ]
        assert len(jobs) == 1, ("consult jobs", len(jobs), rows)
        ident = jobs[0]["id"]

        def terminal():
            j = cli("job", "show", ident)
            return j if j["state"] not in ("queued", "running") else None

        j = wait_for(terminal)
        print(
            "job",
            j["state"],
            j.get("error"),
            [
                (v["host"], v["state"], v.get("error"))
                for v in j.get("run_trace", {}).get("runs", [])
            ],
            flush=True,
        )
        assert j["state"] == "succeeded", (j.get("error"), rows)
        public = cli("consult", "show", ident)
        receipt = cli("consult", "receipt", ident)
        assert json.loads(receipt["data"]["output"]) == public
        assert (
            public["answer"] == MSG
            and public["status"] == "found"
            and not public["gaps"]
        )
        (source,) = public["evidence"]
        original = cli(
            "show",
            source["event_id"],
            "--revision",
            source["revision"],
            "--range",
            source["start"],
            source["end"],
        )
        assert (
            original["scope"]["user"] == "uid:" + str(os.geteuid())
            and original["output"] == MSG
            and source["content_sha256"] == sha(MSG.encode())
            and [source["start"], source["end"]] == [0, len(MSG)]
        )
        (run,) = j["run_trace"]["runs"]
        assert (
            run["state"] == "succeeded"
            and run["host"] == kind
            and len(run["fence"]) == 64
        )
        assert len(selected) == 1 and selected[0]["source"]["adapter"] in (
            args.caller,
            "claude_code" if args.caller == "claude" else args.caller,
        )
        plan = j["consult_plan"]
        assert run["origin"] == plan["invocation_id"] and run["fence"] == plan["fence"]
        assert (
            receipt["data"]["record"]["scope"] == public["scope"]
            and public["scope"] == original["scope"]
        )
        report.update(
            run_origin_and_fence_match_saved_invocation=True,
            receipt_public_and_source_scopes_match=True,
        )
        require_hint = j.get("consult_plan", {}).get("args", {}).get("hint")
        assert require_hint == args.hint, (
            require_hint,
            j.get("consult_plan", {}).keys(),
        )
        report.update(
            job_state="succeeded",
            public_status=public["status"],
            source_adapter=selected[0]["source"]["adapter"],
            runner_host=run["host"],
            scope_uid_matches=True,
            original_byte_range=[0, len(MSG)],
            source_sha256=sha(MSG.encode()),
            same_public_receipt=True,
            protocol_steps=rows,
            capture_state_verified=True,
            persisted_hint=require_hint,
        )
        assert not errors, errors
        write(root / "verified.json", report)
    finally:
        try:
            cli("daemon", "stop")
        finally:
            srv.shutdown()
            srv.server_close()


def launch():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("caller", choices=["claude", "pi"])
    parser.add_argument("runner", choices=["claude", "codex"])
    parser.add_argument("hint", choices=["none", "short"])
    for flag in ("product", "claude", "scratch", "output"):
        parser.add_argument("--" + flag, type=Path, required=True)
    for flag in ("pi-root", "node", "codex", "codex-catalog"):
        parser.add_argument("--" + flag, type=Path)
    args = parser.parse_args()
    if args.caller == "pi" and not (args.pi_root and args.node):
        parser.error("Pi requires --pi-root and --node")
    if args.runner == "codex" and not (args.codex and args.codex_catalog):
        parser.error("Codex requires --codex and --codex-catalog")
    commit = "4e7b3a2799ebc2055750eb044b056cc1d887625a"
    binary = "8c0114b2803df101fcebb934a9c1bd170abf67b522b5775c820b14e69c1c1133"
    assert file_sha(args.product) == binary
    hosts = {args.caller, args.runner}
    versions = {
        h: file_sha(
            {
                "claude": args.claude,
                "codex": args.codex,
                "pi": args.pi_root / "node_modules/.bin/pi" if args.pi_root else None,
            }[h]
        )
        for h in hosts
    }
    with tempfile.TemporaryDirectory(dir=args.scratch) as scratch:
        root = Path(scratch)
        data = root / "data"
        data.mkdir(mode=0o700)
        cmd = [
            "bwrap",
            "--die-with-parent",
            "--new-session",
            "--unshare-all",
            "--ro-bind",
            "/usr",
            "/usr",
            "--symlink",
            "usr/bin",
            "/bin",
            "--symlink",
            "usr/lib",
            "/lib",
            "--symlink",
            "usr/lib64",
            "/lib64",
            "--proc",
            "/proc",
            "--dev",
            "/dev",
            "--tmpfs",
            "/tmp",
            "--dir",
            "/etc",
            "--ro-bind",
            "/etc/passwd",
            "/etc/passwd",
            "--dir",
            "/tools",
            "--dir",
            "/opt",
            "--dir",
            "/fixture",
            "--ro-bind",
            str(Path(__file__).resolve()),
            "/fixture/test",
            "--ro-bind",
            str(args.product.resolve()),
            "/tools/akasha-otsuge",
            "--bind",
            str(data),
            "/case",
        ]
        for h in sorted(hosts):
            if h == "pi":
                cmd += [
                    "--ro-bind",
                    str(args.pi_root.resolve()),
                    "/opt/pi",
                    "--symlink",
                    "/opt/pi/node_modules/.bin/pi",
                    "/tools/pi",
                    "--ro-bind",
                    str(args.node.resolve()),
                    "/tools/node",
                ]
            else:
                cmd += ["--ro-bind", str(getattr(args, h).resolve()), "/tools/" + h]
        if args.runner == "codex":
            models = json.loads(args.codex_catalog.read_bytes())["models"]
            write(
                root / "catalog", next(x for x in models if x["slug"] == "gpt-6.1-sol")
            )
            cmd += ["--ro-bind", str(root / "catalog"), "/fixture/catalog"]
        cmd += [
            "--clearenv",
            "--setenv",
            "PATH",
            "/tools:/usr/bin:/bin",
            "--setenv",
            "HOME",
            "/tmp",
            "--chdir",
            "/case",
            "/usr/bin/python3",
            "-B",
            "/fixture/test",
            "inside",
            args.caller,
            args.runner,
            args.hint,
        ]
        subprocess.run(cmd, timeout=200, check=True)
        result = json.loads((data / "verified.json").read_bytes())
    result.update(
        product_source=commit,
        product_sha256=binary,
        harness_sha256=file_sha(__file__),
        private_pid_mount_network=True,
        private_scratch_removed=True,
        native_executable_sha256=versions,
    )
    with args.output.open("x") as out:
        json.dump(result, out, sort_keys=True, indent=2)
        out.write("\n")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "inside":
        run()
    else:
        launch()
