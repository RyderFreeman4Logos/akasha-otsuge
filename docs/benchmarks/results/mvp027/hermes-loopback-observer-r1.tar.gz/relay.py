"""Forward bounded native Hermes Runner requests to the configured loopback route."""

import http.client
import http.server
import json
import os
import socketserver
import threading
import time
from contextlib import contextmanager

import yaml

MODEL = "grok-4.7"
MAX_REQUESTS = 6


@contextmanager
def serve(local, config, provider_name, port):
    route = f"http://127.0.0.1:{port}/v1"
    cfg = yaml.safe_load(config.read_bytes())
    (selected,) = [
        r
        for r in cfg["custom_providers"]
        if r["name"] == provider_name
        and r["base_url"] == route
        and r["api_mode"] == "chat_completions"
    ]
    token = selected["api_key"]
    assert isinstance(token, str) and token and not token.startswith("$")
    record = []
    gate = threading.Lock()

    class Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self, *unused):
            pass

        def do_POST(self):
            if self.path != "/v1/chat/completions":
                self.send_error(404)
                return
            n = int(self.headers.get("Content-Length", "0"))
            if not 0 < n < 250000:
                self.send_error(413)
                return
            req = json.loads(self.rfile.read(n))
            names = sorted(t["function"]["name"] for t in req.get("tools", []))
            if (
                req.get("model") != MODEL
                or not names
                or not set(names)
                <= {
                    "context_describe",
                    "context_list",
                    "context_search",
                    "context_read",
                    "memory_get",
                    "memory_search",
                    "code_read",
                    "code_search",
                    "delegate",
                }
            ):
                self.send_error(403)
                return
            req["tools"] = [
                t
                for t in req["tools"]
                if t["function"]["name"]
                in {
                    "context_describe",
                    "context_read",
                    "context_search",
                    "context_list",
                    "memory_search",
                    "memory_get",
                }
            ]
            names = sorted(t["function"]["name"] for t in req["tools"])
            with gate:
                if len(record) >= MAX_REQUESTS:
                    self.send_error(429)
                    return
                row = {"ordinal": len(record) + 1, "tools_offered": names}
                record.append(row)
            req["max_tokens"] = min(req.get("max_tokens") or 1200, 1200)
            begin = time.monotonic()
            endpoint = http.client.HTTPConnection("127.0.0.1", port, timeout=45)
            try:
                endpoint.request(
                    "POST",
                    "/v1/chat/completions",
                    json.dumps(req).encode(),
                    {
                        "Authorization": "Bearer " + token,
                        "Content-Type": "application/json",
                    },
                )
                r = endpoint.getresponse()
                raw = r.read(2_000_001)
                assert len(raw) <= 2_000_000
                row["http_status"] = r.status
                ct = r.getheader("Content-Type", "application/json")
                data = []
                if r.status == 200:
                    if ct.startswith("text/event-stream"):
                        for line in raw.splitlines():
                            if line.startswith(b"data: ") and line[6:] != b"[DONE]":
                                data.append(json.loads(line[6:]))
                    else:
                        data = [json.loads(raw)]
                    row["provider_models"] = sorted(
                        {v["model"] for v in data if isinstance(v.get("model"), str)}
                    )
                    row["usage"] = {
                        k: v
                        for chunk in data
                        for k, v in (chunk.get("usage") or {}).items()
                        if k in ("prompt_tokens", "completion_tokens", "total_tokens")
                        and isinstance(v, int)
                    }
                self.send_response(r.status)
                self.send_header("Content-Type", ct)
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)
            except Exception as exc:
                row["transport_failure"] = type(exc).__name__
                self.send_error(502)
            finally:
                endpoint.close()
                row["elapsed_ms"] = round(1000 * (time.monotonic() - begin))

    class Server(socketserver.UnixStreamServer):
        pass

    srv = Server(str(local), Handler)
    os.chmod(local, 0o600)
    thread = threading.Thread(target=srv.serve_forever, daemon=True)
    thread.start()
    try:
        yield record
    finally:
        srv.shutdown()
        srv.server_close()
        thread.join(timeout=5)
