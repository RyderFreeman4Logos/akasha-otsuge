"""Deterministic local replies for actual native extraction and Auto-Grill invocations."""

import json


def decode_after(text, marker):
    return json.JSONDecoder().raw_decode(text.split(marker, 1)[1].lstrip())[0]


def find_strings(obj):
    if isinstance(obj, str):
        yield obj
    elif isinstance(obj, dict):
        for value in obj.values():
            yield from find_strings(value)
    elif isinstance(obj, list):
        for value in obj:
            yield from find_strings(value)


def stage_report(request, message, stages):
    for text in find_strings(request):
        if (
            "extraction-v1" in text
            and "Requested scope: " in text
            and "\nEvidence: " in text
        ):
            scope = decode_after(text, "Requested scope: ")
            evidence = decode_after(text, "\nEvidence: ")
            assert len(evidence) == 1 and evidence[0]["text"] == message
            stages.append("extraction")
            return json.dumps(
                {
                    "schema_version": 1,
                    "candidates": [
                        {
                            "kind": "decision",
                            "scope": scope,
                            "claim": message,
                            "rationale": "",
                            "conditions": ["when offline"],
                            "assumptions": [],
                            "sources": [
                                {"source": 0, "start": 0, "end": len(message.encode())}
                            ],
                            "valid_from_ms": None,
                            "valid_until_ms": None,
                        }
                    ],
                }
            )
        if "auto-grill-v1" in text and "\nInput: " in text:
            payload = decode_after(text, "\nInput: ")
            role = payload["stage"]["role"]
            assert payload["evidence"][0]["text"] == message
            stages.append("grill_" + role)
            if role == "interviewer":
                return json.dumps(
                    {
                        "schema_version": 1,
                        "questions": [
                            {
                                "id": "q1",
                                "text": "What should happen offline?",
                                "depends_on": [],
                            }
                        ],
                        "answers": [],
                    }
                )
            assert role in {"expert", "reviewer"}
            answers = [
                {
                    "question": q["id"],
                    "kind": "decision",
                    "claim": message,
                    "rationale": "The original records the local decision.",
                    "strongest_opposition": "A local mirror can become stale.",
                    "conditions": ["when offline"],
                    "assumptions": [],
                    "unresolved": [],
                    "sources": [
                        {"source": 0, "start": 0, "end": len(message.encode())}
                    ],
                    "resolved": True,
                }
                for q in payload["questions"]
            ]
            return json.dumps(
                {"schema_version": 1, "questions": [], "answers": answers}
            )
    return None


def finish(cli, wait, config, root, source, scope, host, binary, message, report):
    def fixture(name, data):
        path = root / name
        path.write_text(json.dumps(data))
        return path

    def done(job_id):
        def read():
            job = cli("job", "show", job_id)
            if job["state"] in ("running", "queued"):
                return False
            assert job["state"] == "succeeded", (job["state"], job.get("error"))
            return job

        return wait(read, 120)

    report["daemon_doctor"] = bool(cli("doctor", "--json"))
    extra = ("--directory", "/case/plugin") if host == "claude" else ()
    doctor = cli("doctor", "--host", host, "--binary", binary, *extra)
    report["host_doctor"] = bool(doctor)
    source_input = fixture(
        "extract-evidence.json", {"scope": scope, "sources": [source]}
    )
    extracted = done(
        cli("extract", "run", source_input, "--idempotency-key", "matrix-extraction")[
            "id"
        ]
    )
    (candidate,) = extracted["result"]["candidates"]
    scope_file = fixture("operator-scope.json", scope)
    (review,) = [
        v
        for v in cli("review", "list", "--scope", scope_file)["items"]
        if v["memory_id"] == candidate["memory_id"]
    ]
    assert review["state"] == "open"
    action = fixture(
        "review-action.json",
        {
            "id": review["id"],
            "expected_revision": review["revision"],
            "state": "investigating",
            "reason": "Check the original offline condition.",
        },
    )
    cli("review", "state", action, "--idempotency-key", "matrix-investigate")
    saved = cli("review", "show", review["id"])
    assert (
        saved["item"]["state"] == "investigating"
        and saved["proposal"]["record"]["authority"] == "candidate"
    )
    assert (
        saved["proposal"]["record"]["draft"]["source_spans"] == [source]
        and saved["proposal"]["record"]["approval"] is None
    )

    def delivered():
        return next(
            (
                v
                for v in cli("notify", "list", "--scope", scope_file)["items"]
                if v["review_id"] == review["id"]
                and v["source_revision"] == saved["item"]["revision"]
                and v["deliveries"].get("inbox", {}).get("status") == "sent"
                and v["deliveries"]["inbox"]["generation"] == v["generation"]
            ),
            None,
        )

    notice = wait(delivered, 45)
    args = (
        "notify",
        "ack",
        notice["notification_id"],
        "--generation",
        notice["generation"],
        "--idempotency-key",
        "matrix-ack",
    )
    assert cli(*args) == cli(*args)
    report.update(
        native_extraction_candidate=True,
        extraction_sources_exact=True,
        review_state="investigating",
        review_authority="candidate",
        human_approval=None,
        local_notice_ack_idempotent=True,
    )
    grill = fixture(
        "grill-evidence.json",
        {
            "question": "What local decision applies offline?",
            "scope": scope,
            "sources": [source],
        },
    )
    job = done(cli("grill", "run", grill, "--idempotency-key", "matrix-grill")["id"])
    result = job["result"]
    assert len(result["candidates"]) >= 1, ("empty grill candidates", list(result))
    assert {"grill_interviewer", "grill_expert", "grill_reviewer", "extraction"} <= set(
        report["native_stages"]
    ), report["native_stages"]
    assert result["origin"] == "auto_grill"
    pending = {
        row["memory_id"]: row
        for row in cli("review", "list", "--scope", scope_file)["items"]
    }
    for candidate in result["candidates"]:
        inspected = cli("review", "show", pending[candidate["memory_id"]]["id"])[
            "proposal"
        ]["record"]
        assert inspected["authority"] == "candidate" and inspected["approval"] is None
        assert inspected["provenance"]["origin"] == "auto_grill"
    report["grill_candidate_authority_verified"] = True
    report.update(
        grill_terminal=job["state"],
        grill_stop_reason=result["stop_reason"],
        grill_candidate_count=len(result["candidates"]),
    )
