import datetime,hashlib,json,pathlib,subprocess,zipfile
E=pathlib.Path(__file__).parent
paths=['docs/benchmarks/production-scale.md','docs/plan/todo.md','docs/benchmarks/results/mvp024-vector-cohort/README.md','docs/benchmarks/results/mvp024-vector-cohort/evidence.zip','docs/benchmarks/results/mvp024-vector-cohort/manifest.json']
for command in [['python3','scripts/check_plan.py'],['python3','scripts/check_reference.py'],['git','diff','--check']]:subprocess.run(command,check=True)
root=pathlib.Path('docs/benchmarks/results/mvp024-vector-cohort');m=json.loads((root/'manifest.json').read_text())
assert hashlib.sha256((root/'evidence.zip').read_bytes()).hexdigest()==m['archive_sha256']
with zipfile.ZipFile(root/'evidence.zip') as z:
    assert z.testzip() is None and set(z.namelist())==set(m['members'])
    for name,item in m['members'].items():
        b=z.read(name);assert len(b)==item['bytes'] and hashlib.sha256(b).hexdigest()==item['sha256']
result=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),source_sha256={p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest() for p in paths},status='DOCS_AND_ARCHIVE_CHECK_PASS')
with (E/'mvp024-vector-cohort-docs-focused-r1.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(dict(status=result['status'],paths=paths,archive_members=len(m['members']))))

