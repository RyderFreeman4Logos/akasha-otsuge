import hashlib,json,pathlib,zipfile,datetime
E=pathlib.Path(__file__).parent;W=pathlib.Path.cwd()
old=json.loads((W/'docs/benchmarks/results/mvp024-vector-cohort/manifest.json').read_text())
already={n.removeprefix('evidence/') for n in old['members'] if n.startswith('evidence/')}
state=json.loads((E/'wd-state.json').read_text())
assert all(not p['name'].startswith('mvp024-vector-cohort') for p in state['active_work']['primaries'])
members={}
for p in sorted(E.iterdir()):
    if p.is_file() and p.name.startswith('mvp024-vector-cohort') and p.name not in already:
        if p.name.endswith(('.stdout','.stderr','.final.txt','.supervisor.log')):continue
        if p.name in ('mvp024-vector-cohort-final-publication.zip','mvp024-vector-cohort-final-publication-manifest.json'):continue
        members['evidence/'+p.name]=p
R=E/'mvp024-vector-cohort-review-r1'
for p in sorted(R.iterdir()):
    assert p.is_file() and not p.is_symlink()
    members['review/'+p.name]=p
members['runtime/mvp020-review-runtime-r2.json']=E/'mvp020-review-runtime-r2.json'
archive=E/'mvp024-vector-cohort-final-publication.zip';entries={}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in sorted(members.items()):
        raw=p.read_bytes();i=zipfile.ZipInfo(name,(2026,11,17,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16;z.writestr(i,raw)
        entries[name]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(entries)
    for name,v in entries.items():assert hashlib.sha256(z.read(name)).hexdigest()==v['sha256']
receipt=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),reviewed_head='235884dc1d4d85039130697745c42cee49a698ac',
    merge='1c6eed5d35569cd3f7427853fd0f0a0a47ac6275',tree='5fab952ee7a787584319ce9f7934f96cfb0bb7f1',archive_bytes=archive.stat().st_size,
    archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=entries,scope='Final PR73 gate/review/failure supplements/CI/push/readback/merge; earlier pilot evidence remains in evidence.zip.',
    publication='Full immutable review is in PR73 description, not a separate comment. Reviewer Rust prerequisite failure remains; separate parent4 and exact canonical/CI executions passed.',
    staged_outside_frozen_worktree=True)
with (E/'mvp024-vector-cohort-final-publication-manifest.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='members'}|dict(members=len(entries))))

