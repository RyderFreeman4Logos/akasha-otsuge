The production corpus seeder can now mark complete inputs of at most 4,096 UTF-8 bytes for the explicit vector scopes. A local benchmark lookup returns only hash-pinned retained embeddings for exact inputs. Existing source spans, default lexical scopes, binding/replay checks and product input limits remain intact.

The evidence archive records all 8,359 current-claim checks and 1,061 exact input/vector pairs from 8,229 real sources. The initial keyword witness used the wrong scope and failed. Reopening the same store passed eight corrected keyword witnesses and eight vector self hits without reimport or reindex. Original failures, distinct binary identities, separate helper memory and exact disposable-store cleanup are preserved.

Validation on `235884dc1d4d85039130697745c42cee49a698ac`:
- Complete `just check`: 651 Rust passes / 39 intentional ignores, Python 35, Node 7, Clippy/format, and installed lifecycle/UID/no-TCP checks.
- Lookup/preparation fixtures: ten Python tests; seeder: four real Domain tests.
- Independent review and hosted CI will be linked after their exact results are verified.

The 50 GB import/coverage, one million production vectors, 100,000 changes, 100-client load and recovery criteria remain pending. The lookup replays retained vectors; it is not live model inference. Its first memory-limit failure and the corrected bounded runs remain separately labeled.

Refs #65.

