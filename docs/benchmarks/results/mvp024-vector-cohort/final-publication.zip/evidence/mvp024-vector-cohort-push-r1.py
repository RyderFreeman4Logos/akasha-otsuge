import pathlib,json,subprocess,hashlib,datetime
E=pathlib.Path(__file__).parent
gate=json.loads((E/'mvp024-vector-cohort-canonical-r1-verified.json').read_text())
review=json.loads((E/'mvp024-vector-cohort-review-accepted-r2.json').read_text())
git=lambda *a:subprocess.check_output(['git',*a],text=True).strip()
head=git('rev-parse','HEAD');branch='feat/mvp-024-vector-cohort'
assert gate['status']==review['verdict']=='PASS' and head==gate['head']==review['head']
assert git('branch','--show-current')==branch and not git('status','--porcelain')
assert hashlib.sha256((E/'mvp024-vector-cohort-review-r1/report.md').read_bytes()).hexdigest()==review['review_report_sha256']
assert git('ls-remote','--heads','origin','refs/heads/main').split()[0]==gate['base']
subprocess.run(['git','push','--set-upstream','origin',branch],check=True)
remote=git('ls-remote','--heads','origin','refs/heads/'+branch).split()[0];assert remote==head
assert not git('status','--porcelain') and git('rev-parse','HEAD')==head
r=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=head,tree=git('rev-parse','HEAD^{tree}'),branch=branch,remote_head=remote,normal_push=True,force=False,clean=True)
with (E/'mvp024-vector-cohort-pushed-r1.json').open('x') as f:json.dump(r,f,indent=2);f.write('\n')
print(json.dumps(r))

