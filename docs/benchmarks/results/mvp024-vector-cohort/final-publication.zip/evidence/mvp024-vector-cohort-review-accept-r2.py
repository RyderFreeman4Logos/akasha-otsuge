import datetime,hashlib,json,pathlib,re,subprocess
E=pathlib.Path(__file__).parent;R=E/'mvp024-vector-cohort-review-r1'
load=lambda p:json.loads(p.read_text())
scope=load(E/'mvp024-vector-cohort-parent-scope-r1.json');gate=load(E/'mvp024-vector-cohort-canonical-r1-verified.json')
final=load(R/'custody-final.json');exit=load(E/'mvp024-vector-cohort-review-r1.exit.json')
git=lambda *a:subprocess.check_output(['git','--no-optional-locks',*a],text=True).strip()
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
assert scope['head']==gate['head']==final['post_report_custody']['head']==git('rev-parse','HEAD')
assert scope['tree']==gate['tree']==final['post_report_custody']['tree']==git('rev-parse','HEAD^{tree}')
assert scope['base']==git('merge-base','origin/main','HEAD') and not git('status','--porcelain')
for p,h in scope['source_sha256'].items():assert sha(p)==h
report=(R/'report.md').read_text();assert report.splitlines()[0]==report.splitlines()[-1]=='VERDICT: PASS'
assert final['verdict']=='PASS' and final['actionable_count']==0 and exit['protected_inputs_unchanged']
assert sha(R/'report.md')==final['report_sha256']==exit['report_sha256']
for n,item in final['artifacts'].items():assert (R/n).stat().st_size==item['bytes'] and sha(R/n)==item['sha256']
stem='mvp024-vector-cohort-parent-seeder-r1'
ad=load(E/(stem+'.admission.json'));end=load(E/(stem+'.terminal.json'));assert (E/(stem+'.collected.json')).exists()
assert ad['head']==end['head']==scope['head'] and ad['tree']==scope['tree'] and end['exit_code']==0 and sha(E/(stem+'.log'))==end['log_sha256']
assert 'test result: ok. 4 passed; 0 failed; 0 ignored;' in (E/(stem+'.log')).read_text()
assert load(R/'python-tests.json')['exit_code']==0 and load(R/'rust-tests.json')['exit_code']==101
# Verify the executable anchors cited for the new scope and unchanged exact-scope boundary.
checks={'examples/corpus_seed.rs':['vector_cohort: bool','row.vector_cohort && row.body.len() > 4096','row.vector_cohort.then(|| "vectors".into())','while !row.body.is_char_boundary(end)','source_spans: vec![SourceSpan'],
'spikes/data/precomputed.py':['pre_buffer=False','64 * 1024**2','stamp(path) != original','body(row, layout) != text','http.server.HTTPServer(("127.0.0.1", port), Handler)'],
'src/storage/mod.rs':['IDEMPOTENCY_CONFLICT'],'src/retrieval/vector.rs':['4096','hash(&serde_json::to_vec(scope)?)'],'src/retrieval.rs':['hash(&serde_json::to_vec(scope)?)']}
for p,anchors in checks.items():
 text=pathlib.Path(p).read_text()
 for anchor in anchors:assert anchor in text,(p,anchor)
result=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=scope['head'],tree=scope['tree'],base=scope['base'],clean=True,verdict='PASS',actionable_count=0,
 review_report_sha256=sha(R/'report.md'),final_attestation_sha256=sha(R/'custody-final.json'),canonical_gate_sha256=sha(E/'mvp024-vector-cohort-canonical-r1-verified.json'),
 fresh_review_python=10,fresh_review_rust=0,review_rust_prerequisite_failure='Shared target is outside child workspace-write roots and returned EROFS before tests; original exit101 remains.',
 separate_parent_rust=4,parent_rust_log_sha256=end['log_sha256'],report_unchanged=True,
 acceptance='Accept source/evidence PASS with explicit fresh-review Rust limitation, exact canonical four-test execution and separate parent four-test supplement; no full-scale acceptance.')
with (E/'mvp024-vector-cohort-review-accepted-r2.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result))

