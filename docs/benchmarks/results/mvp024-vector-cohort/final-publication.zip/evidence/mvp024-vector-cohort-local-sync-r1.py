import datetime,json,pathlib,subprocess
E=pathlib.Path(__file__).parent;M=pathlib.Path('/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge');W=pathlib.Path.cwd()
def git(repo,*a):return subprocess.check_output(['git','-C',str(repo),*a],text=True).strip()
head='235884dc1d4d85039130697745c42cee49a698ac';merged='1c6eed5d35569cd3f7427853fd0f0a0a47ac6275';tree='5fab952ee7a787584319ce9f7934f96cfb0bb7f1'
assert git(W,'rev-parse','HEAD')==head and git(M,'branch','--show-current')=='main'
assert not git(M,'status','--porcelain') and not git(W,'status','--porcelain')
subprocess.run(['git','-C',str(M),'fetch','origin','main'],check=True)
assert git(M,'rev-parse','origin/main')==merged and git(M,'rev-parse',merged+'^{tree}')==tree
subprocess.run(['git','-C',str(M),'merge','--ff-only','origin/main'],check=True)
subprocess.run(['git','switch','-c','feat/mvp-024-full-preparation','origin/main'],check=True)
assert git(M,'rev-parse','HEAD')==git(W,'rev-parse','HEAD')==merged and git(W,'rev-parse','HEAD^{tree}')==tree
assert not git(M,'status','--porcelain') and not git(W,'status','--porcelain')
r=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),merged_head=merged,tree=tree,main_fast_forwarded=True,main_clean=True,worktree_clean=True,
 branch=git(W,'branch','--show-current'),base=merged,reused_ssd_worktree=True,new_target_or_corpus_copy=False)
with (E/'mvp024-vector-cohort-local-sync-r1.json').open('x') as f:json.dump(r,f,indent=2);f.write('\n')
print(json.dumps(r))

