import datetime, hashlib, json, os, pathlib, subprocess
E = pathlib.Path('/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/.git/akasha-evidence')
receipt = json.loads((E/'mvp024-vector-cohort-docs-focused-r1.json').read_text())
paths = sorted(receipt['source_sha256'])
base = receipt['head']
identity = ['git','-c','user.name=RyderFreeman','-c','user.email=RyderFreeman4Logos@gmail.com']
def git(*args):
    return subprocess.check_output([*identity,*args],text=True).strip()
assert git('rev-parse','HEAD') == base
assert git('branch','--show-current') == 'feat/mvp-024-vector-cohort'
lock = pathlib.Path(git('rev-parse','--git-path','index.lock'))
assert not lock.exists()
assert not git('diff','--cached','--name-only')
for name, sha in receipt['source_sha256'].items():
    assert hashlib.sha256(pathlib.Path(name).read_bytes()).hexdigest() == sha
author, committer = git('var','GIT_AUTHOR_IDENT'), git('var','GIT_COMMITTER_IDENT')
assert author.startswith('RyderFreeman <RyderFreeman4Logos@gmail.com> ')
assert committer.startswith('RyderFreeman <RyderFreeman4Logos@gmail.com> ')
configured = subprocess.run(['git','config','--get','core.hooksPath'],text=True,capture_output=True)
assert configured.returncode == 1
hookdir = pathlib.Path(git('rev-parse','--git-path','hooks'))
hooks = sorted(p.name for p in hookdir.iterdir() if not p.name.endswith('.sample') and p.is_file() and os.access(p,os.X_OK)) if hookdir.exists() else []
assert hooks == []
subprocess.run(['git','diff','--check'],check=True)
subprocess.run(['git','add','--',*paths],check=True)
assert git('diff','--cached','--name-only').splitlines() == paths
assert not git('diff','--name-only')
subprocess.run(['git','diff','--cached','--check'],check=True)
pre = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),base=base,paths=paths,
           staged_tree=git('write-tree'),patch_sha256=hashlib.sha256(subprocess.check_output(['git','diff','--cached','--binary'])).hexdigest(),
           author=author,committer=committer,hooks=hooks,identity_configuration='command-scoped; repository and global configuration unchanged')
with (E/'mvp024-vector-cohort-commit-r3-preflight.json').open('x') as stream:
    json.dump(pre,stream,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())
subprocess.run([*identity,'commit','-m','docs: retain exact vector cohort pilot evidence','-m','Refs #65.'],check=True)
head = git('rev-parse','HEAD')
assert git('rev-parse','HEAD^') == base and git('rev-parse','HEAD^{tree}') == pre['staged_tree']
assert git('diff-tree','--no-commit-id','--name-only','-r','HEAD').splitlines() == paths
assert not git('status','--porcelain=v1') and not lock.exists()
subprocess.run(['git','diff','--check',base+'..HEAD'],check=True)
result = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=head,tree=pre['staged_tree'],base=base,paths=paths,clean=True,hooks=hooks,
              authors=git('show','-s','--format=%an <%ae>%n%cn <%ce>','HEAD'))
with (E/'mvp024-vector-cohort-commit-r3-result.json').open('x') as stream:
    json.dump(result,stream,indent=2);stream.write('\n')
print(json.dumps(result))
