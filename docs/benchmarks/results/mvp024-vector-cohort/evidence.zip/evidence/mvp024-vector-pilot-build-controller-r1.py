import ast, hashlib, pathlib
E=pathlib.Path(__file__).parent
old_path=E/'mvp024-production-final-binary-r1.py'
old=old_path.read_text()
nodes={n.name:n for n in ast.parse(old).body if isinstance(n,ast.FunctionDef)}
functions='\n\n'.join(ast.get_source_segment(old,nodes[n]) for n in ['progress','cli','sample','wait_job','allocation'])
functions=functions.replace("    metrics.write(json.dumps({'elapsed_s'", "    assert provider.poll() is None, 'lookup provider exited'\n    helper = {}\n    for line in pathlib.Path(f'/proc/{provider.pid}/status').read_text().splitlines():\n        field, _, rest = line.partition(':')\n        if field in ('VmRSS', 'VmHWM'):\n            helper[field] = int(rest.split()[0]) * 1024\n    controller_peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024\n    assert helper['VmHWM'] <= 512 * 1024**2 and controller_peak <= 512 * 1024**2\n    metrics.write(json.dumps({'elapsed_s'")
functions=functions.replace("'diagnostic_memory_breakdown': breakdown}","'diagnostic_memory_breakdown': breakdown, 'lookup_helper': helper, 'controller_peak_bytes': controller_peak}")
prefix=r'''"""Bounded real-vector production pilot; no full scale/load/recovery claim."""
import collections, datetime, hashlib, json, os, pathlib, re, resource, select, shutil, signal, subprocess, sys, tempfile, time, tomllib
import pyarrow.parquet as pq
W=pathlib.Path.cwd();E=pathlib.Path(__file__).parent
sys.path.insert(0,str(W/'spikes/helix'))
from run_case import publish, process_identity, digest
sys.path.insert(0,str(W/'spikes/data'))
from download import verify
from prepare_corpus import chunks, vector_fingerprint
assert len(sys.argv)==1
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'])
build=json.loads((E/'mvp024-vector-pilot-r1-build.json').read_text());assert build['head']==head
binary=(W/'target/release/akasha-otsuge').resolve(strict=True)
seeder=(W/'target/release/examples/corpus_seed').resolve(strict=True)
assert digest(binary)==build['daemon_sha256'] and digest(seeder)==build['seeder_sha256']
assert digest(W/'spikes/data/precomputed.py')==build['lookup_source_sha256']
assert all(os.environ.get(k) is None for k in ('LD_PRELOAD','MALLOC_MMAP_THRESHOLD_','GLIBC_TUNABLES','MALLOC_ARENA_MAX','LANCE_FTS_NUM_SHARDS','LANCE_FTS_PARTITION_SIZE'))
root=(W/'.spike-work/mvp024-vector-pilot-r1').resolve()
assert shutil.disk_usage(root.parent).free >= 50*1024**3
root.mkdir(mode=0o700);(root/'OWNER').write_text('akasha-otsuge:mvp024-vector-pilot-r1\n')
socket_root=pathlib.Path(tempfile.mkdtemp(prefix='a24v-',dir=os.environ['TMPDIR']));endpoint=socket_root/'service.sock'
assert len(os.fsencode(endpoint))<108
config_text='[execution]\nvector_source_rows=1024\ntext_source_records=7168\nindex_timeout_s=1800\ncommand_timeout_s=30\nmax_native_disk_bytes=2147483648\n[reliability]\nmax_attempts=1\nreason="No replay of ambiguous durable effects"\n'
(root/'pilot.toml').write_text(config_text);config=tomllib.loads(config_text)['execution'];epoch=hashlib.sha256(config_text.encode()).hexdigest()
(root/'lookup.toml').write_text('[resources]\nrss_ceiling_bytes=536870912\n[reliability]\nmax_attempts=5\nunit_timeout_s=3600\n')
started=time.monotonic();inventory=json.loads((W/'spikes/data/sources.json').read_text())['sources'];inputs=[]
for group,prefix in enumerate(('vectors','text')):
    item=inventory[group]['files'][0];path=(W/f'.spike-work/corpus-full-v1/{prefix}-00000.parquet').resolve(strict=True)
    verify(path,item);inputs.append(dict(path=str(path),sha256=item['sha256'],bytes=item['size'],repository=inventory[group]['repository'],revision=inventory[group]['revision'],license=inventory[group]['license']))
supp_root=(W/'.spike-work/mvp024-vector-supplement-r1').resolve(strict=True)
supp=json.loads((supp_root/'candidate-manifest.json').read_text());assert digest(supp_root/'candidate-manifest.json')=='596c52593ca2dc971a588db52cc1527ac4a57e141148d2df01dd7ff690736cf3'
verify(supp_root/supp['output']['file'],dict(size=supp['output']['bytes'],sha256=supp['output']['sha256']))
lookup_manifest=json.loads((W/'.spike-work/mvp024-precomputed-real-r1/manifest.json').read_text());publish(root/'lookup-manifest.json',lookup_manifest)
manifest=dict(schema_version=1,inputs=inputs,supplement_manifest_sha256=digest(supp_root/'candidate-manifest.json'),subset=config,
    lookup_manifest_sha256=digest(root/'lookup-manifest.json'),selection='first 1024 DBpedia records; all 37 pinned supplementary words; first 7168 unique FineWeb chunks',
    scope_partition='sha256(original key)[0] modulo 8',vector_selection='complete DBpedia input <=4096 bytes and all 37 supplementary words; branch vectors',kind='bounded_production_vector_pilot')
publish(root/'input-manifest.json',manifest)
binding=dict(source_manifest_sha256=digest(root/'input-manifest.json'),observed_time_ms=1793000000000);publish(root/'binding.json',binding)
admission=dict(head=head,tree=build['tree'],daemon_sha256=build['daemon_sha256'],seeder_sha256=build['seeder_sha256'],
    lookup_source_sha256=build['lookup_source_sha256'],driver_sha256=digest(__file__),provider_driver_sha256=digest(E/'mvp024-lookup-service-r1.py'),
    input_manifest_sha256=binding['source_manifest_sha256'],config_epoch=epoch,socket_root=str(socket_root),process=process_identity(os.getpid()),utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    resume='Existing run refused; reconcile durable acknowledgements and processes before any new run.',
    limits=['8229 actual source records; no full 50 GB/million-vector daemon/100-client/recovery acceptance.',
            'Seeder uses production Domain; indexing, current and keyword/vector queries use the actual daemon CLI.',
            'Lookup has one million retained inputs but the daemon imports only this bounded selected subset.',
            'Lookup and controller have separately checked 512 MiB observed RSS ceilings; their external helper processes are not charged to the daemon service cgroup.',
            'Daemon cgroup original 512/640/2048 MiB limits remain required; no aggregate helper cgroup enforcement claim.',
            'No live inference, paid model calls, new faults or Daybreak campaigns. File caches are not evicted.'])
publish(root/'admission.json',admission)
state=dict(admission_sha256=digest(root/'admission.json'),completed_units=[],phase='seed',error=None);publish(root/'state.json',state)
oracle=[];witnesses={};ann_witnesses={};vector_pairs=[];seen=set();unique_bytes=0
seed=daemon=provider=None
commands=(root/'commands.jsonl').open('x');metrics=(root/'metrics.jsonl').open('x')
base=[str(binary),'--config',str(root/'daemon.toml'),'--socket',str(endpoint)]
'''
records=r'''
def records():
    count=0
    for batch in pq.ParquetFile(inputs[0]['path'],pre_buffer=False).iter_batches(batch_size=64,columns=['_id','title','text','text-embedding-3-large-1536-embedding']):
        for item in batch.to_pylist():
            text=item['title']+'\n'+item['text'];selected=len(text.encode())<=4096
            yield dict(key='dbpedia:'+item['_id'],body=text,vector_cohort=selected),1,vector_fingerprint(item['text-embedding-3-large-1536-embedding']).hex() if selected else None
            count+=1
            if count==config['vector_source_rows']:break
        if count==config['vector_source_rows']:break
    for item in pq.read_table(supp_root/supp['output']['file']).to_pylist():
        text=item['word']
        yield dict(key='dictionary:'+hashlib.sha256(text.encode()).hexdigest(),body=text,vector_cohort=True),0,vector_fingerprint(item['embedding']).hex()
    count=0;local_seen=set()
    for batch in pq.ParquetFile(inputs[1]['path'],pre_buffer=False).iter_batches(batch_size=64,columns=['text']):
        for item in batch.to_pylist():
            for text in chunks(item['text']):
                sha=hashlib.sha256(text.encode()).hexdigest()
                if sha in local_seen:continue
                local_seen.add(sha)
                yield dict(key='fineweb:'+sha,body=text),0,None
                count+=1
                if count==config['text_source_records']:return
'''
main=old[old.index('try:\n    phase_start = time.monotonic()'):]
changes=[
("total = config['vector_source_rows'] + config['text_source_records']","total = config['vector_source_rows'] + config['text_source_records'] + 37"),
("for number, (row, separators) in enumerate(records(), 1):","for number, (row, separators, vector_sha) in enumerate(records(), 1):"),
("'start': offset, 'end': end}","'start': offset, 'end': end, 'vector_cohort': row.get('vector_cohort',False)}"),
("            assert offset == len(encoded), 'source not fully covered by seed memories'","            assert offset == len(encoded), 'source not fully covered by seed memories'\n            if vector_sha is not None:\n                assert len(ack['memories']) == 1\n                vector_pairs.append(bytes.fromhex(body_hash+vector_sha))\n                if len(encoded) <= 2048 and row['body'].strip() == row['body'] and row['partition'] not in ann_witnesses:\n                    ann_witnesses[row['partition']] = dict(id=ack['memories'][0][0],revision=ack['memories'][0][1],query=row['body'],vector_sha256=vector_sha)"),
("    for name in ('oracle.json', 'acks.jsonl'):\n        assert (root / name).read_bytes() == (baseline / name).read_bytes(), ('paired seed/oracle differs', name)","    assert len(ann_witnesses) == 8\n    publish(root/'vector-oracle.json',dict(pairs=[p.hex() for p in vector_pairs],witnesses=ann_witnesses))"),
("    assert indexed['indexed_rows'] == len(oracle) and indexed['vector'] is None","    assert indexed['indexed_rows'] == len(oracle) and indexed['vector']['indexed_rows'] == len(vector_pairs)\n    audit=(root/'lookup-events.bin').read_bytes()\n    assert len(audit)==64*len(vector_pairs) and collections.Counter(audit[i:i+64] for i in range(0,len(audit),64))==collections.Counter(vector_pairs)\n    publish(root/'index-vector-coverage.json',dict(expected=len(vector_pairs),returned=len(audit)//64,event_sha256=hashlib.sha256(audit).hexdigest(),exact_input_vector_multiset=True))"),
("        assert draft['scope']['project'] == 'corpus/' + expected['partition']","        assert draft['scope']['project'] == 'corpus/' + expected['partition']\n        assert draft['scope']['branch_or_version'] == ('vectors' if expected['vector_cohort'] else None)"),
("    final = sample()", "    assert (root/'lookup-events.bin').stat().st_size == 64*len(vector_pairs), 'keyword-only scopes called the embedding provider'\n    vector_queries=[]\n    for partition,expected in sorted(ann_witnesses.items()):\n        scope_file=root/f'{partition}-vector-scope.json'\n        publish(scope_file,dict(user=f'uid:{os.geteuid()}',project='corpus/'+partition,branch_or_version='vectors',session=None))\n        name='pilot-vector-'+partition\n        cli('search',expected['query'],'--scope',scope_file,'--idempotency-key',name)\n        job,seconds=wait_job(name,120)\n        output=json.loads(job['result']['output']);assert output['mode']=='hybrid'\n        items=[i['memory'] for i in output['items']]\n        assert any(i['revision']['key']['id']==expected['id'] and i['revision']['commit_seq']==expected['revision'] for i in items), ('vector self-hit missing',partition)\n        assert all(i['record']['draft']['scope']['project']=='corpus/'+partition and i['record']['draft']['scope']['branch_or_version']=='vectors' for i in items)\n        vector_queries.append(dict(partition=partition,id=expected['id'],seconds=seconds,receipt_id=job['result']['receipt_id'],model_identity=output['index']['vector']['model_identity']))\n    assert (root/'lookup-events.bin').stat().st_size==64*(len(vector_pairs)+8)\n    final = sample()"),
("'all_current_claim_hashes_verified': len(oracle), 'lexical_partition_witnesses': search_receipts,","'all_current_claim_hashes_verified': len(oracle), 'lexical_partition_witnesses': search_receipts,\n              'vector_ingest_pairs':len(vector_pairs),'vector_scope_self_hits':vector_queries,'lookup_manifest_sha256':digest(root/'lookup-manifest.json'),"),
("    state['processes_terminal'] = {'seed':", "    if provider and provider.poll() is None:\n        provider.send_signal(signal.SIGTERM);provider.wait(timeout=60)\n    state['provider_terminal'] = None if provider is None else provider.returncode\n    if provider is not None and state['phase']=='complete':\n        assert provider.returncode==0\n        terminal=json.loads((root/'lookup-terminal.json').read_text())\n        assert terminal['phase']=='stopped' and terminal['snapshot']['returned_vectors']==len(vector_pairs)+8 and terminal['snapshot']['failed_requests']==0\n    state['processes_terminal'] = {'seed':")]
for before,after in changes:
    assert main.count(before)==1,before
    main=main.replace(before,after)
old_config="    (root / 'daemon.toml').write_text('[paths]\\ndata_dir=' + json.dumps(str(root / 'data')) + '\\nsocket_path=' + json.dumps(str(endpoint)) + '\\n')"
assert old_config in main
new_config=r'''    with (root/'lookup.log').open('xb') as log:
        provider=subprocess.Popen(['nohup',sys.executable,str(E/'mvp024-lookup-service-r1.py'),str(root),head],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    publish(root/'lookup-process.json',process_identity(provider.pid))
    deadline=time.monotonic()+300
    while not (root/'lookup-ready.json').exists():
        assert provider.poll() is None, 'lookup provider failed before readiness'
        assert time.monotonic()<deadline, 'lookup admission deadline'
        time.sleep(0.2)
    ready=json.loads((root/'lookup-ready.json').read_text());assert ready['process']['pid']==provider.pid
    profile='[retrieval]\nembedding="corpus_vectors"\nembedding_scopes=['+','.join('{user='+json.dumps(f'uid:{os.geteuid()}')+',project='+json.dumps('corpus/p'+str(n))+',branch_or_version="vectors"}' for n in range(8))+']\n'
    profile+='[models.corpus_vectors]\nkind="embedding"\nendpoint='+json.dumps(f'http://127.0.0.1:{ready["address"][1]}/v1')+'\nmodel='+json.dumps(ready['model'])+'\ndimension=1536\nlocal=true\ntimeout="30s"\n'
    (root/'daemon.toml').write_text('[paths]\ndata_dir='+json.dumps(str(root/'data'))+'\nsocket_path='+json.dumps(str(endpoint))+'\n'+profile)
'''
main=main.replace(old_config,new_config.rstrip())
source=prefix+'\n'+functions+'\n'+records+'\n'+main
compile(source,'vector-pilot','exec')
target=E/'mvp024-vector-pilot-r1.py'
with target.open('x') as f:f.write(source)
print(dict(script=str(target),bytes=len(source.encode()),sha256=hashlib.sha256(source.encode()).hexdigest(),reused_driver_sha256=hashlib.sha256(old.encode()).hexdigest()))
