"""Bounded real-vector production pilot; no full scale/load/recovery claim."""
import collections, datetime, hashlib, json, os, pathlib, re, resource, select, shutil, signal, subprocess, sys, tempfile, time, tomllib
import pyarrow.parquet as pq
W=pathlib.Path.cwd();E=pathlib.Path(__file__).parent
sys.path.insert(0,str(W/'spikes/helix'))
from run_case import publish, process_identity, digest
sys.path.insert(0,str(W/'spikes/data'))
from download import verify
from prepare_corpus import chunks, vector_fingerprint
assert len(sys.argv)==1
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'])
build=json.loads((E/'mvp024-vector-pilot-r1-build.json').read_text());assert build['head']==head
binary=(W/'target/release/akasha-otsuge').resolve(strict=True)
seeder=(W/'target/release/examples/corpus_seed').resolve(strict=True)
assert digest(binary)==build['daemon_sha256'] and digest(seeder)==build['seeder_sha256']
assert digest(W/'spikes/data/precomputed.py')==build['lookup_source_sha256']
assert all(os.environ.get(k) is None for k in ('LD_PRELOAD','MALLOC_MMAP_THRESHOLD_','GLIBC_TUNABLES','MALLOC_ARENA_MAX','LANCE_FTS_NUM_SHARDS','LANCE_FTS_PARTITION_SIZE'))
root=(W/'.spike-work/mvp024-vector-pilot-r1').resolve()
assert shutil.disk_usage(root.parent).free >= 50*1024**3
root.mkdir(mode=0o700);(root/'OWNER').write_text('akasha-otsuge:mvp024-vector-pilot-r1\n')
socket_root=pathlib.Path(tempfile.mkdtemp(prefix='a24v-',dir=os.environ['TMPDIR']));endpoint=socket_root/'service.sock'
assert len(os.fsencode(endpoint))<108
config_text='[execution]\nvector_source_rows=1024\ntext_source_records=7168\nindex_timeout_s=1800\ncommand_timeout_s=30\nmax_native_disk_bytes=2147483648\n[reliability]\nmax_attempts=1\nreason="No replay of ambiguous durable effects"\n'
(root/'pilot.toml').write_text(config_text);config=tomllib.loads(config_text)['execution'];epoch=hashlib.sha256(config_text.encode()).hexdigest()
(root/'lookup.toml').write_text('[resources]\nrss_ceiling_bytes=536870912\n[reliability]\nmax_attempts=5\nunit_timeout_s=3600\n')
started=time.monotonic();inventory=json.loads((W/'spikes/data/sources.json').read_text())['sources'];inputs=[]
for group,prefix in enumerate(('vectors','text')):
    item=inventory[group]['files'][0];path=(W/f'.spike-work/corpus-full-v1/{prefix}-00000.parquet').resolve(strict=True)
    verify(path,item);inputs.append(dict(path=str(path),sha256=item['sha256'],bytes=item['size'],repository=inventory[group]['repository'],revision=inventory[group]['revision'],license=inventory[group]['license']))
supp_root=(W/'.spike-work/mvp024-vector-supplement-r1').resolve(strict=True)
supp=json.loads((supp_root/'candidate-manifest.json').read_text());assert digest(supp_root/'candidate-manifest.json')=='596c52593ca2dc971a588db52cc1527ac4a57e141148d2df01dd7ff690736cf3'
verify(supp_root/supp['output']['file'],dict(size=supp['output']['bytes'],sha256=supp['output']['sha256']))
lookup_manifest=json.loads((W/'.spike-work/mvp024-precomputed-real-r1/manifest.json').read_text());publish(root/'lookup-manifest.json',lookup_manifest)
manifest=dict(schema_version=1,inputs=inputs,supplement_manifest_sha256=digest(supp_root/'candidate-manifest.json'),subset=config,
    lookup_manifest_sha256=digest(root/'lookup-manifest.json'),selection='first 1024 DBpedia records; all 37 pinned supplementary words; first 7168 unique FineWeb chunks',
    scope_partition='sha256(original key)[0] modulo 8',vector_selection='complete DBpedia input <=4096 bytes and all 37 supplementary words; branch vectors',kind='bounded_production_vector_pilot')
publish(root/'input-manifest.json',manifest)
binding=dict(source_manifest_sha256=digest(root/'input-manifest.json'),observed_time_ms=1793000000000);publish(root/'binding.json',binding)
admission=dict(head=head,tree=build['tree'],daemon_sha256=build['daemon_sha256'],seeder_sha256=build['seeder_sha256'],
    lookup_source_sha256=build['lookup_source_sha256'],driver_sha256=digest(__file__),provider_driver_sha256=digest(E/'mvp024-lookup-service-r1.py'),
    input_manifest_sha256=binding['source_manifest_sha256'],config_epoch=epoch,socket_root=str(socket_root),process=process_identity(os.getpid()),utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    resume='Existing run refused; reconcile durable acknowledgements and processes before any new run.',
    limits=['8229 actual source records; no full 50 GB/million-vector daemon/100-client/recovery acceptance.',
            'Seeder uses production Domain; indexing, current and keyword/vector queries use the actual daemon CLI.',
            'Lookup has one million retained inputs but the daemon imports only this bounded selected subset.',
            'Lookup and controller have separately checked 512 MiB observed RSS ceilings; their external helper processes are not charged to the daemon service cgroup.',
            'Daemon cgroup original 512/640/2048 MiB limits remain required; no aggregate helper cgroup enforcement claim.',
            'No live inference, paid model calls, new faults or Daybreak campaigns. File caches are not evicted.'])
publish(root/'admission.json',admission)
state=dict(admission_sha256=digest(root/'admission.json'),completed_units=[],phase='seed',error=None);publish(root/'state.json',state)
oracle=[];witnesses={};ann_witnesses={};vector_pairs=[];seen=set();unique_bytes=0
seed=daemon=provider=None
commands=(root/'commands.jsonl').open('x');metrics=(root/'metrics.jsonl').open('x')
base=[str(binary),'--config',str(root/'daemon.toml'),'--socket',str(endpoint)]

def progress(phase, completed, total, phase_start):
    assert (root / 'pilot.toml').read_text() == config_text, 'immutable pilot configuration changed'
    elapsed = time.monotonic() - phase_start
    value = {'phase': phase, 'completed': completed, 'total': total,
        'elapsed_s': elapsed, 'campaign_elapsed_s': time.monotonic() - started,
        'rate_per_s': completed / elapsed if elapsed else None,
        'eta_s': elapsed * (total - completed) / completed if completed else None,
        'config_epoch': epoch, 'process': admission['process']}
    publish(root / 'progress.json', value)
    publish(root / 'progress.yaml', value)

def cli(*args, required=True):
    clock = time.monotonic()
    result = subprocess.run([*base, *map(str, args)], stdin=subprocess.DEVNULL, capture_output=True,
                            timeout=config['command_timeout_s'])
    entry = {'argv': list(map(str, args)), 'seconds': time.monotonic() - clock,
             'exit_code': result.returncode, 'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
             'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()}
    commands.write(json.dumps(entry) + '\n'); commands.flush()
    if required:
        assert result.returncode == 0, (args[:2], result.returncode, result.stderr.decode()[:2048])
    if result.returncode:
        return None
    return json.loads(result.stdout)['data']

def sample():
    value = cli('daemon', 'status')
    breakdown = {}
    try:
        assert process_identity(daemon.pid)['start_ticks'] == json.loads((root / 'daemon-process.json').read_text())['start_ticks']
        for line in pathlib.Path('/proc', str(daemon.pid), 'status').read_text().splitlines():
            field, _, rest = line.partition(':')
            if field in ('VmRSS', 'RssAnon', 'RssFile', 'RssShmem', 'VmSwap', 'VmData'):
                amount, unit = rest.split()
                assert unit == 'kB'
                breakdown[field + '_bytes'] = int(amount) * 1024
        group = pathlib.Path(value['resources']['cgroup']['daemon_group']['path'])
        for name in ('memory.stat', 'memory.events'):
            breakdown[name] = {key: int(amount) for key, amount in
                (line.split() for line in (group / name).read_text().splitlines())}
    except (OSError, KeyError, ValueError) as error:
        breakdown['unavailable'] = type(error).__name__
    assert provider.poll() is None, 'lookup provider exited'
    helper = {}
    for line in pathlib.Path(f'/proc/{provider.pid}/status').read_text().splitlines():
        field, _, rest = line.partition(':')
        if field in ('VmRSS', 'VmHWM'):
            helper[field] = int(rest.split()[0]) * 1024
    controller_peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * 1024
    assert helper['VmHWM'] <= 512 * 1024**2 and controller_peak <= 512 * 1024**2
    metrics.write(json.dumps({'elapsed_s': time.monotonic() - started, 'resources': value['resources'],
                             'diagnostic_memory_breakdown': breakdown, 'lookup_helper': helper, 'controller_peak_bytes': controller_peak}) + '\n')
    metrics.flush(); os.fsync(metrics.fileno())
    group = value['resources']['cgroup']
    assert group.get('enforced') and group.get('complete'), ('cgroup control unavailable', group)
    assert group['daemon_group']['high_bytes'] == 512 * 1024**2
    assert group['daemon_group']['max_bytes'] == 640 * 1024**2
    assert group['service_total']['max_bytes'] == 2048 * 1024**2
    disk = allocation(root / 'data')
    publish(root / 'disk-latest.json', disk)
    assert disk['allocated_bytes'] <= config['max_native_disk_bytes'], ('pilot disk budget', disk)
    return value

def wait_job(name, limit, build=False):
    start = time.monotonic()
    while True:
        job = cli('job', 'show', name)
        if job['state'] in ('succeeded', 'failed', 'cancelled'):
            publish(root / f'{name}-terminal.json', job)
            assert job['state'] == 'succeeded', (name, job.get('error'))
            return job, time.monotonic() - start
        assert time.monotonic() - start < limit, ('unit deadline', name)
        if build:
            indexed = cli('index', 'status')
            progress('index', indexed['indexed_rows'], len(oracle), start)
            sample()
        time.sleep(1 if build else 0.02)

def allocation(path):
    def fail(error):
        raise error
    for attempt in range(3):
        try:
            total = files = apparent = 0
            for directory, _, names in os.walk(path, onerror=fail):
                for name in names:
                    st = (pathlib.Path(directory) / name).stat()
                    total += st.st_blocks * 512; apparent += st.st_size; files += 1
            return {'allocated_bytes': total, 'apparent_bytes': apparent, 'files': files,
                    'census_attempts': attempt + 1}
        except FileNotFoundError:
            if attempt == 2:
                raise

def records():
    count=0
    for batch in pq.ParquetFile(inputs[0]['path'],pre_buffer=False).iter_batches(batch_size=64,columns=['_id','title','text','text-embedding-3-large-1536-embedding']):
        for item in batch.to_pylist():
            text=item['title']+'\n'+item['text'];selected=len(text.encode())<=4096
            yield dict(key='dbpedia:'+item['_id'],body=text,vector_cohort=selected),1,vector_fingerprint(item['text-embedding-3-large-1536-embedding']).hex() if selected else None
            count+=1
            if count==config['vector_source_rows']:break
        if count==config['vector_source_rows']:break
    for item in pq.read_table(supp_root/supp['output']['file']).to_pylist():
        text=item['word']
        yield dict(key='dictionary:'+hashlib.sha256(text.encode()).hexdigest(),body=text,vector_cohort=True),0,vector_fingerprint(item['embedding']).hex()
    count=0;local_seen=set()
    for batch in pq.ParquetFile(inputs[1]['path'],pre_buffer=False).iter_batches(batch_size=64,columns=['text']):
        for item in batch.to_pylist():
            for text in chunks(item['text']):
                sha=hashlib.sha256(text.encode()).hexdigest()
                if sha in local_seen:continue
                local_seen.add(sha)
                yield dict(key='fineweb:'+sha,body=text),0,None
                count+=1
                if count==config['text_source_records']:return

try:
    phase_start = time.monotonic()
    total = config['vector_source_rows'] + config['text_source_records'] + 37
    with (root / 'seed.stderr').open('xb') as err, (root / 'acks.jsonl').open('x') as acks:
        seed = subprocess.Popen(['nohup', str(seeder), str(root / 'data'), str(root / 'binding.json')],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=err, start_new_session=True)
        publish(root / 'seed-process.json', process_identity(seed.pid))
        progress('seed', 0, total, phase_start)
        for number, (row, separators, vector_sha) in enumerate(records(), 1):
            row['partition'] = 'p' + str(hashlib.sha256(row['key'].encode()).digest()[0] % 8)
            encoded = row['body'].encode()
            body_hash = hashlib.sha256(encoded).hexdigest()
            if body_hash not in seen:
                seen.add(body_hash); unique_bytes += len(encoded) - separators
            seed.stdin.write((json.dumps(row, ensure_ascii=False) + '\n').encode()); seed.stdin.flush()
            assert select.select([seed.stdout], [], [], 120)[0], 'seed acknowledgement deadline'
            ack_bytes = seed.stdout.readline(4097)
            assert 0 < len(ack_bytes) <= 4096, 'missing or oversized seed acknowledgement'
            ack = json.loads(ack_bytes)
            assert ack['body_sha256'] == body_hash and ack['utf8_bytes'] == len(encoded)
            assert ack['key_sha256'] == hashlib.sha256(row['key'].encode()).hexdigest()
            offset = 0
            for memory_id, seq in ack['memories']:
                end = min(offset + 32768, len(encoded))
                while end < len(encoded) and encoded[end] & 0xC0 == 0x80:
                    end -= 1
                body = encoded[offset:end].decode()
                oracle.append({'id': memory_id, 'revision': seq, 'claim_sha256': hashlib.sha256(encoded[offset:end]).hexdigest(),
                               'partition': row['partition'], 'source_id': ack['source_id'], 'source_revision': ack['source_revision'],
                               'start': offset, 'end': end, 'vector_cohort': row.get('vector_cohort',False)})
                words = re.findall(r'\b[A-Za-z]{8,40}\b', body)
                if words and row['partition'] not in witnesses:
                    witnesses[row['partition']] = {'id': memory_id, 'revision': seq, 'query': max(words, key=len)}
                offset = end
            assert offset == len(encoded), 'source not fully covered by seed memories'
            if vector_sha is not None:
                assert len(ack['memories']) == 1
                vector_pairs.append(bytes.fromhex(body_hash+vector_sha))
                if len(encoded) <= 2048 and row['body'].strip() == row['body'] and row['partition'] not in ann_witnesses:
                    ann_witnesses[row['partition']] = dict(id=ack['memories'][0][0],revision=ack['memories'][0][1],query=row['body'],vector_sha256=vector_sha)
            acks.write(ack_bytes.decode())
            if number % 64 == 0:
                acks.flush(); os.fsync(acks.fileno())
                progress('seed', number, total, phase_start)
        seed.stdin.close()
        assert seed.wait(timeout=120) == 0, 'seed process failed; see retained stderr'
        assert number == total and len(witnesses) == 8
        acks.flush(); os.fsync(acks.fileno())
    seed_seconds = time.monotonic() - phase_start
    publish(root / 'oracle.json', {'memories': oracle, 'witnesses': witnesses, 'unique_utf8_bytes': unique_bytes})
    assert len(ann_witnesses) == 8
    publish(root/'vector-oracle.json',dict(pairs=[p.hex() for p in vector_pairs],witnesses=ann_witnesses))
    state.update(phase='index', seed_seconds=seed_seconds, seed_records=total, memories=len(oracle), unique_utf8_bytes=unique_bytes)
    state['completed_units'].append('seed'); publish(root / 'state.json', state)
    with (root/'lookup.log').open('xb') as log:
        provider=subprocess.Popen(['nohup',sys.executable,str(E/'mvp024-lookup-service-r1.py'),str(root),head],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    publish(root/'lookup-process.json',process_identity(provider.pid))
    deadline=time.monotonic()+300
    while not (root/'lookup-ready.json').exists():
        assert provider.poll() is None, 'lookup provider failed before readiness'
        assert time.monotonic()<deadline, 'lookup admission deadline'
        time.sleep(0.2)
    ready=json.loads((root/'lookup-ready.json').read_text());assert ready['process']['pid']==provider.pid
    profile='[retrieval]\nembedding="corpus_vectors"\nembedding_scopes=['+','.join('{user='+json.dumps(f'uid:{os.geteuid()}')+',project='+json.dumps('corpus/p'+str(n))+',branch_or_version="vectors"}' for n in range(8))+']\n'
    profile+='[models.corpus_vectors]\nkind="embedding"\nendpoint='+json.dumps(f'http://127.0.0.1:{ready["address"][1]}/v1')+'\nmodel='+json.dumps(ready['model'])+'\ndimension=1536\nlocal=true\ntimeout="30s"\n'
    (root/'daemon.toml').write_text('[paths]\ndata_dir='+json.dumps(str(root/'data'))+'\nsocket_path='+json.dumps(str(endpoint))+'\n'+profile)
    with (root / 'daemon.log').open('xb') as log:
        daemon = subprocess.Popen(['nohup', *base, 'daemon', 'run'], stdin=subprocess.DEVNULL,
                                  stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    publish(root / 'daemon-process.json', process_identity(daemon.pid))
    ready_limit = time.monotonic() + 120
    while True:
        assert daemon.poll() is None, 'daemon exited during startup'
        if endpoint.exists() and cli('daemon', 'status', required=False):
            break
        assert time.monotonic() < ready_limit, 'daemon startup deadline'
        time.sleep(0.1)
    observed = {}
    for entry in pathlib.Path(f'/proc/{daemon.pid}/environ').read_bytes().split(b'\0'):
        key, sep, value = entry.partition(b'=')
        if key in (b'LANCE_FTS_NUM_SHARDS', b'LANCE_FTS_PARTITION_SIZE', b'MALLOC_MMAP_THRESHOLD_', b'GLIBC_TUNABLES', b'LD_PRELOAD', b'MALLOC_ARENA_MAX'):
            observed[key.decode()] = value.decode()
    assert observed == {'LANCE_FTS_NUM_SHARDS': '1', 'LANCE_FTS_PARTITION_SIZE': '32', 'MALLOC_ARENA_MAX': '2'}, observed
    publish(root / 'fts-environment.json', {'process': process_identity(daemon.pid), 'selected_environment': observed, 'basis': 'Exact daemon environment plus pinned Lance and installed glibc mallopt documentation; not runtime allocator introspection.'})
    initial = sample()
    assert initial['resources']['requested']['daemon_memory_target_mib'] == 512
    publish(root / 'initial-status.json', initial)
    index_start = time.monotonic()
    cli('index', 'sync', '--idempotency-key', 'pilot-index')
    job, wait_seconds = wait_job('pilot-index', config['index_timeout_s'], build=True)
    index_seconds = time.monotonic() - index_start
    indexed = cli('index', 'status')
    assert indexed['indexed_rows'] == len(oracle) and indexed['vector']['indexed_rows'] == len(vector_pairs)
    audit=(root/'lookup-events.bin').read_bytes()
    assert len(audit)==64*len(vector_pairs) and collections.Counter(audit[i:i+64] for i in range(0,len(audit),64))==collections.Counter(vector_pairs)
    publish(root/'index-vector-coverage.json',dict(expected=len(vector_pairs),returned=len(audit)//64,event_sha256=hashlib.sha256(audit).hexdigest(),exact_input_vector_multiset=True))
    publish(root / 'indexed-status.json', indexed)
    state.update(phase='verify', index_seconds=index_seconds)
    state['completed_units'].append('index'); publish(root / 'state.json', state)
    read_seconds = []
    verify_start = time.monotonic()
    for number, expected in enumerate(oracle, 1):
        clock = time.monotonic()
        reply = cli('memory', 'show', expected['id'])
        read_seconds.append(time.monotonic() - clock)
        assert reply['data']['state'] == 'active'
        memory = reply['data']['revision']['memory']
        assert memory['revision']['commit_seq'] == expected['revision']
        record = memory['record']; draft = record['draft']
        assert record['authority'] == 'delegated_approved' and record['approval'] is None
        assert hashlib.sha256(draft['claim'].encode()).hexdigest() == expected['claim_sha256']
        assert draft['scope']['project'] == 'corpus/' + expected['partition']
        assert draft['scope']['branch_or_version'] == ('vectors' if expected['vector_cohort'] else None)
        if number % 64 == 0:
            progress('verify', number, len(oracle), verify_start)
    search_receipts = []
    for partition, expected in sorted(witnesses.items()):
        scope_file = root / f'{partition}-scope.json'
        publish(scope_file, {'user': f'uid:{os.geteuid()}', 'project': 'corpus/' + partition, 'branch_or_version': None, 'session': None})
        name = 'pilot-search-' + partition
        cli('search', expected['query'], '--scope', scope_file, '--idempotency-key', name)
        job, seconds = wait_job(name, 120)
        output = json.loads(job['result']['output'])
        items = [i['memory'] for i in output['items']]
        assert any(i['revision']['key']['id'] == expected['id'] and i['revision']['commit_seq'] == expected['revision'] for i in items), ('expected lexical hit missing', partition)
        assert all(i['record']['draft']['scope']['project'] == 'corpus/' + partition for i in items)
        search_receipts.append({'partition': partition, 'query': expected['query'], 'expected': expected, 'seconds': seconds,
                                'receipt_id': job['result']['receipt_id'], 'hits': [i['revision'] for i in items]})
    assert (root/'lookup-events.bin').stat().st_size == 64*len(vector_pairs), 'keyword-only scopes called the embedding provider'
    vector_queries=[]
    for partition,expected in sorted(ann_witnesses.items()):
        scope_file=root/f'{partition}-vector-scope.json'
        publish(scope_file,dict(user=f'uid:{os.geteuid()}',project='corpus/'+partition,branch_or_version='vectors',session=None))
        name='pilot-vector-'+partition
        cli('search',expected['query'],'--scope',scope_file,'--idempotency-key',name)
        job,seconds=wait_job(name,120)
        output=json.loads(job['result']['output']);assert output['mode']=='hybrid'
        items=[i['memory'] for i in output['items']]
        assert any(i['revision']['key']['id']==expected['id'] and i['revision']['commit_seq']==expected['revision'] for i in items), ('vector self-hit missing',partition)
        assert all(i['record']['draft']['scope']['project']=='corpus/'+partition and i['record']['draft']['scope']['branch_or_version']=='vectors' for i in items)
        vector_queries.append(dict(partition=partition,id=expected['id'],seconds=seconds,receipt_id=job['result']['receipt_id'],model_identity=output['index']['vector']['model_identity']))
    assert (root/'lookup-events.bin').stat().st_size==64*(len(vector_pairs)+8)
    final = sample()
    publish(root / 'final-status.json', final)
    state['completed_units'].append('verify')
    result = {'status': 'pilot_pass_not_scale_acceptance', 'seed_records': total, 'memory_chunks': len(oracle),
              'unique_utf8_bytes': unique_bytes, 'seed_seconds': seed_seconds, 'index_seconds': index_seconds,
              'all_current_claim_hashes_verified': len(oracle), 'lexical_partition_witnesses': search_receipts,
              'vector_ingest_pairs':len(vector_pairs),'vector_scope_self_hits':vector_queries,'lookup_manifest_sha256':digest(root/'lookup-manifest.json'),
              'read_seconds': read_seconds, 'disk': {name: allocation(root / 'data' / name) for name in ('authority', 'search')},
              'limits': admission['limits']}
    state['phase'] = 'verified_awaiting_shutdown'
    progress('verified_awaiting_shutdown', len(oracle), len(oracle), verify_start)
except BaseException as error:
    state.update(phase='failed', error={'type': type(error).__name__, 'message': str(error)[:4096]})
    publish(root / 'failure.json', state)
    raise
finally:
    try:
        if seed and seed.poll() is None:
            if not seed.stdin.closed: seed.stdin.close()
            seed.wait(timeout=120)
        if daemon and daemon.poll() is None:
            cli('daemon', 'stop', required=False)
            try:
                daemon.wait(timeout=60)
            except subprocess.TimeoutExpired:
                daemon.send_signal(signal.SIGTERM)
                daemon.wait(timeout=30)
        if provider and provider.poll() is None:
            provider.send_signal(signal.SIGTERM)
            provider.wait(timeout=60)
        state['processes_terminal'] = {name:None if process is None else process.returncode for name,process in [('seed',seed),('daemon',daemon),('lookup',provider)]}
        if state['phase']=='verified_awaiting_shutdown':
            assert state['processes_terminal']==dict(seed=0,daemon=0,lookup=0)
            terminal=json.loads((root/'lookup-terminal.json').read_text())
            assert terminal['phase']=='stopped' and terminal['snapshot']['returned_vectors']==len(vector_pairs)+8 and terminal['snapshot']['failed_requests']==0
            assert terminal['audit_bytes']==64*(len(vector_pairs)+8)
            result['lookup_terminal']=terminal
            publish(root/'result.json',result)
            state['phase']='complete'
            progress('complete',len(oracle),len(oracle),verify_start)
    except BaseException as error:
        state.update(phase='failed',finalization_error={'type':type(error).__name__,'message':str(error)[:4096]})
        publish(root/'finalization-failure.json',state)
        raise
    finally:
        publish(root/'state.json',state)
        for stream in (commands,metrics):
            stream.flush();os.fsync(stream.fileno());stream.close()
print(json.dumps({'root':str(root),'state':state}),flush=True)
