"""Verify bounded reopen evidence, then remove only stopped task-owned data."""
import datetime,hashlib,json,math,os,pathlib,shutil,stat,subprocess
E=pathlib.Path(__file__).parent
root=pathlib.Path('.spike-work/mvp024-vector-pilot-r1').resolve(strict=True)
reopen=root/'reopen-r1'
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
    with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(pathlib.Path(p).read_text())
def save(p,v):
    with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
assert (root/'OWNER').read_text()=='akasha-otsuge:mvp024-vector-pilot-r1\n'
assert (reopen/'OWNER').read_text()=='akasha-otsuge:mvp024-vector-reopen-r1\n'
ad=read(root/'admission.json');a=read(reopen/'admission.json');s=read(reopen/'state.json');result=read(reopen/'result.json')
assert result['status']=='CORRECTED_QUERIES_AND_REOPEN_PASS' and s['phase']=='complete' and s['completed']==s['total']==16
assert s['terminal']==dict(daemon=0,lookup=0) and read(root/'state.json')['processes_terminal']==dict(seed=0,daemon=0,lookup=0)
assert read(root/'state.json')['error']['message']=="('expected lexical hit missing', 'p0')" and not (root/'result.json').exists()
assert result['original_failure_preserved'] and not result['seed_or_index_replayed']
assert a['original_admission_sha256']==sha(root/'admission.json') and a['config_sha256']==sha(root/'daemon.toml')
assert a['original_partial_verification_sha256']==sha(E/'mvp024-vector-pilot-r1-partial-verified.json')
assert a['driver_sha256']==sha(E/'mvp024-vector-reopen-r1.py') and a['provider_driver_sha256']==sha(E/'mvp024-lookup-reopen-r1.py')
assert ad['driver_sha256']==sha(E/'mvp024-vector-pilot-r1.py') and ad['lookup_source_sha256']==sha('spikes/data/precomputed.py')
assert a['head']==ad['head']==subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert not subprocess.check_output(['git','status','--porcelain'])
assert a['daemon_sha256']==sha('target/release/akasha-otsuge') and a['prior_index_builder_sha256']==ad['daemon_sha256'] and not a['same_daemon_binary']
assert ad['seeder_sha256']==sha('target/release/examples/corpus_seed')
assert read(root/'indexed-status.json')==read(reopen/'reopened-index.json')
kw=read(E/'mvp024-vector-keyword-oracle-r1.json')['witnesses'];vectors=read(root/'vector-oracle.json')['witnesses']
for kind,witnesses,branch in [('keyword',kw,None),('vector',vectors,'vectors')]:
    assert set(witnesses)=={'p'+str(i) for i in range(8)}
    for partition,w in witnesses.items():
        name='pilot-reopen-'+kind+'-'+partition;p=reopen/(name+'.json');j=read(p)
        assert j['state']=='succeeded' and j['error'] is None and sha(p)==s['units'][name]['terminal_sha256']
        out=json.loads(j['result']['output']);assert out['mode']==('keyword' if kind=='keyword' else 'hybrid')
        items=[i['memory'] for i in out['items']]
        assert any(m['revision']['key']['id']==w['id'] and m['revision']['commit_seq']==w['revision'] for m in items)
        assert all(m['record']['draft']['scope']['project']=='corpus/'+partition and m['record']['draft']['scope']['branch_or_version']==branch for m in items)
audit=(reopen/'lookup/lookup-events.bin').read_bytes()
assert audit==b''.join(hashlib.sha256(v['query'].encode()).digest()+bytes.fromhex(v['vector_sha256']) for _,v in sorted(vectors.items()))
helper=read(reopen/'lookup/lookup-terminal.json')
assert helper==result['lookup'] and helper['phase']=='stopped' and helper['snapshot']['requests']==8 and helper['snapshot']['returned_vectors']==8 and helper['snapshot']['failed_requests']==0 and not helper['snapshot']['live_model_inference']
assert helper['audit_bytes']==len(audit)==512 and helper['audit_sha256']==hashlib.sha256(audit).hexdigest()
metrics=read(reopen/'metrics.json');rss=[];cgroups=set()
for item in metrics:
    r=item['resources'];c=r['cgroup'];m=r['measurement']
    assert c['available'] and c['complete'] and c['enforced'] and m['complete']
    assert c['effective']==dict(daemon_memory_target_mib=512,daemon_peak_limit_mib=640,service_total_budget_mib=2048)
    assert c['daemon_group']['oom_kills']==0 and item['helper']['VmHWM']<=512*1024**2 and item['controller_peak_bytes']<=512*1024**2
    rss.append(m['daemon_group']['rss_bytes']);cgroups.add(c['path'])
assert len(rss)==17 and max(rss)==result['daemon_rss_max']<=640*1024**2
assert sorted(rss)[math.ceil(.99*len(rss))-1]==result['daemon_rss_p99']<=512*1024**2
cgroups.add(read(root/'initial-status.json')['resources']['cgroup']['path'])
assert all(not pathlib.Path(p).exists() for p in cgroups)
identities=[ad['process'],a['process']]
for base,names in [(root,['seed-process.json','daemon-process.json','lookup-process.json']),(reopen,['daemon-process.json','lookup-process.json'])]:
    identities.extend(read(base/n) for n in names)
for task in ('mvp024-vector-pilot-r1','mvp024-vector-reopen-r1'):
    t=read(E/(task+'.terminal.json'));assert sha(E/(task+'.log'))==t['log_sha256']
    assert (E/(task+'.collected.json')).exists()
    identities.append(read(E/(task+'.launch.json'))['process'])
for i in identities:
    p=pathlib.Path('/proc')/str(i['pid'])/'stat'
    if p.exists():assert p.read_text().rsplit(')',1)[1].split()[19]!=str(i['start_ticks'])
data=root/'data';socket=pathlib.Path(ad['socket_root']);tmp=pathlib.Path('/mnt/ssd/mirror-rootfs/home/obj/tmp/a15-cache-s0s9a8n9')
assert data.resolve()==data and data.is_dir() and not data.is_symlink()
assert socket.parent==tmp and socket.name.startswith('a24v-') and len(socket.name)==13 and socket.is_dir() and not socket.is_symlink()
files={}
for p in sorted(data.rglob('*')):
    assert not p.is_symlink()
    if p.is_file():
        st=p.stat();assert st.st_uid==os.getuid() and stat.S_ISREG(st.st_mode)
        files[str(p.relative_to(data))]=dict(bytes=st.st_size,allocated_bytes=st.st_blocks*512,sha256=sha(p))
metadata={}
for p in sorted(root.rglob('*')):
    if data in p.parents:continue
    assert not p.is_symlink()
    if p.is_file():metadata[str(p.relative_to(root))]=dict(bytes=p.stat().st_size,sha256=sha(p))
verification=dict(utc=now(),status='CORRECTED_REOPEN_PASS_WITH_ORIGINAL_PARTIAL_RUN_PRESERVED',head=a['head'],tree=a['tree'],
    result_sha256=sha(reopen/'result.json'),admission_sha256=sha(reopen/'admission.json'),original_partial_sha256=a['original_partial_verification_sha256'],
    checked_queries=16,index_snapshot_unchanged=True,lookup_audit_exact=True,daemon_rss_max=max(rss),daemon_rss_p99=result['daemon_rss_p99'],
    helper_highwater=helper['final_memory']['VmHWM'],valid_samples=len(rss),sampled_oom_kills=0,processes_absent=identities,
    cgroups_absent=sorted(cgroups),metadata=metadata,native_files=files,native_allocated_bytes=sum(x['allocated_bytes'] for x in files.values()),limits=a['limits'])
receipt=E/'mvp024-vector-reopen-r1-verified.json';save(receipt,verification)
known={(x['pid'],str(x['start_ticks']),x['comm']) for x in read(E/'mvp024-production-final-binary-r1-cleanup-admission.json')['excluded_unrelated_services']}
references=[];excluded=[];unknown=[];inspected=0;roots=[data,socket]
def matches(value):return any(value==str(r) or value.startswith(str(r)+'/') for r in roots)
for p in pathlib.Path('/proc').iterdir():
    if not p.name.isdigit():continue
    identity=None
    try:
        if p.stat().st_uid!=os.getuid():continue
        status=(p/'stat').read_text().rsplit(')',1)[1].split();identity=(int(p.name),status[19],(p/'comm').read_text().strip())
        if status[0]=='Z':continue
        inspected+=1
        for link in [p/'cwd',p/'exe',*list((p/'fd').iterdir())]:
            try:
                value=os.readlink(link)
                if matches(value):references.append(dict(pid=int(p.name),kind=link.name,path=value))
            except FileNotFoundError:pass
    except FileNotFoundError:pass
    except PermissionError:
        if identity in known:excluded.append(dict(pid=identity[0],start_ticks=identity[1],comm=identity[2],reason='Exact previously classified unrelated nondumpable service identity; no new exclusion'))
        else:unknown.append(dict(pid=int(p.name)))
assert not references and not unknown,dict(references=references,unknown=unknown)
for rel,expected in files.items():
    p=data/rel;assert p.stat().st_size==expected['bytes'] and sha(p)==expected['sha256']
admit=dict(utc=now(),roots=[str(p) for p in roots],verified_receipt_sha256=sha(receipt),owned_processes_and_cgroups_absent=True,
    native_files_reverified=len(files),native_allocated_bytes=verification['native_allocated_bytes'],own_uid_processes_inspected=inspected,
    accessible_references=references,excluded_unrelated_services=excluded,free_before_bytes=shutil.disk_usage('/mnt/ssd').free,
    scope='Only exact stopped pilot disposable data and owned socket; retain all source/corpus/cache and compact evidence.')
save(E/'mvp024-vector-pilot-r1-cleanup-admission.json',admit)
for p in roots:shutil.rmtree(p)
assert all(not p.exists() for p in roots)
done={**admit,'utc':now(),'removed':True,'free_after_bytes':shutil.disk_usage('/mnt/ssd').free,'free_delta_is_not_exact_reclaim_on_btrfs':True}
save(E/'mvp024-vector-pilot-r1-cleanup.json',done)
print(json.dumps(dict(status=verification['status'],queries=16,samples=len(rss),rss_max=max(rss),helper_highwater=verification['helper_highwater'],
    native_files=len(files),native_allocated_bytes=verification['native_allocated_bytes'],removed=True,excluded_known_services=len(excluded))))

