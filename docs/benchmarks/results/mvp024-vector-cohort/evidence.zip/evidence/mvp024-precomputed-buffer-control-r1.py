"""Read-only actual-data lookup diagnostic; no imported store or model inference."""
import datetime, hashlib, http.client, json, os, pathlib, resource, subprocess, sys, threading, time, tomllib

W = pathlib.Path.cwd()
E = pathlib.Path(__file__).parent
sys.path.insert(0, str(W / 'spikes/data'))
from download import publish
from precomputed import Lookup, VECTOR, body, server
from prepare_corpus import vector_fingerprint
sys.path.insert(0, str(W / 'spikes/helix'))
from run_case import digest, process_identity
import pyarrow.parquet as pq

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert len(sys.argv) in (2, 3) and head == sys.argv[1]
assert not subprocess.check_output(['git', 'status', '--porcelain'])
resume = len(sys.argv) == 3 and sys.argv[2] == '--resume'
assert len(sys.argv) == 2 or resume
root = (W / '.spike-work/mvp024-precomputed-buffer-control-r1').resolve()
baseline = json.loads((W / 'docs/benchmarks/results/full-corpus-manifest.json').read_text())
supp_root = (W / '.spike-work/mvp024-vector-supplement-r1').resolve(strict=True)
supp = json.loads((supp_root / 'candidate-manifest.json').read_text())
assert digest(supp_root / 'candidate-manifest.json') == '596c52593ca2dc971a588db52cc1527ac4a57e141148d2df01dd7ff690736cf3'
sources = [dict(path=str((W / '.spike-work/corpus-full-v1' / item['file']).resolve(strict=True)),
                size=item['source']['size'], sha256=item['source']['sha256'], layout='dbpedia')
           for item in baseline['corpus']['inputs'] if item['file'].startswith('vectors-')]
sources.append(dict(path=str(supp_root / supp['output']['file']), size=supp['output']['bytes'],
                    sha256=supp['output']['sha256'], layout='dictionary'))
model_pin = hashlib.sha256(encoded([dict(sha256=s['sha256'], layout=s['layout']) for s in sources])).hexdigest()
manifest = dict(model='retained-1536-' + model_pin, dimensions=1536, sources=sources)
identity = dict(head=head, script_sha256=digest(__file__), manifest_sha256=hashlib.sha256(encoded(manifest)).hexdigest(),
                code={n:digest(W/'spikes/data'/n) for n in ['precomputed.py','prepare_corpus.py','download.py']})
config_text = '[resources]\nmax_observed_rss_bytes=536870912\n[reliability]\nmax_attempts=5\nunit_timeout_s=3600\n'
if not resume:
    root.mkdir(mode=0o700)
    (root/'OWNER').write_text('akasha-otsuge:mvp024-precomputed-buffer-control-r1\n')
    (root/'run.toml').write_text(config_text)
    publish(root/'manifest.json', manifest)
    state = dict(identity=identity, started_utc=utc(), completed={}, epochs={}, launches=[], phase='admitted')
else:
    assert (root/'OWNER').read_text() == 'akasha-otsuge:mvp024-precomputed-buffer-control-r1\n'
    state = json.loads((root/'state.json').read_text())
    assert state['identity'] == identity and state['phase'] != 'complete'
    old = process_identity(state['process']['pid'])
    assert old is None or old['start_ticks'] != state['process']['start_ticks'] or old['state'] == 'Z'
    assert json.loads((root/'manifest.json').read_text()) == manifest
import fcntl
lock = (root/'run.lock').open('a')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
state['process'] = process_identity(os.getpid())
state['launches'].append(dict(utc=utc(), process=state['process'], resume=resume))
publish(root/'state.json', state)
started = time.monotonic()
last_unit = started
def progress(done, total, snapshot):
    global last_unit
    config = tomllib.loads((root/'run.toml').read_text())
    assert config['reliability']['max_attempts'] == 5
    assert 60 <= config['reliability']['unit_timeout_s'] <= 86400
    assert 256*1024**2 <= config['resources']['max_observed_rss_bytes'] <= 1024**3
    assert time.monotonic()-last_unit <= config['reliability']['unit_timeout_s']
    rss = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024
    assert rss <= config['resources']['max_observed_rss_bytes'], ('client memory ceiling', rss)
    epoch = hashlib.sha256(encoded(config)).hexdigest()
    state['epochs'][epoch] = config
    key = str(done)
    if key in state['completed']:
        assert state['completed'][key]['snapshot'] == snapshot
    else:
        state['completed'][key] = dict(snapshot=snapshot, attempts=1, epoch=epoch, utc=utc())
    state.update(phase='admitting', active_unit=done, config_epoch=epoch)
    publish(root/'state.json', state)
    elapsed = time.monotonic()-started
    publish(root/'progress.yaml', dict(completed=done,total=total,elapsed_s=elapsed,
        rate_per_s=done/elapsed,eta_s=None,active_unit=done,phase='admitting',process=state['process'],config_epoch=epoch))
    last_unit = time.monotonic()
    print(json.dumps(dict(completed=done,total=total,rss_peak_bytes=rss)),flush=True)

lookup = httpd = worker = None
try:
    from unittest.mock import patch
    original_reader = pq.ParquetFile
    with patch('precomputed.parquet.ParquetFile', side_effect=lambda path: original_reader(path, pre_buffer=False)):
        lookup = Lookup(manifest, progress)
    assert len(lookup.index) == 1000000 and lookup.excluded == 37
    httpd = server(lookup)
    worker = threading.Thread(target=httpd.serve_forever)
    worker.start()
    state['phase'] = 'http_oracles'
    publish(root/'state.json', state)
    witness = hashlib.sha256()
    checks = []
    for number, source in enumerate(sources):
        reader = pq.ParquetFile(source['path'])
        groups = [0, reader.num_row_groups-1] if source['layout']=='dbpedia' else [0]
        for group in groups:
            table = reader.read_row_group(group)
            offsets = range(table.num_rows) if source['layout']=='dictionary' else [table.num_rows//2]
            for offset in offsets:
                row = table.slice(offset,1).to_pylist()[0]
                text = body(row,source['layout'])
                assert len(text.encode()) <= 2048
                vector = row[VECTOR] if source['layout']=='dbpedia' else row['embedding']
                expected = vector_fingerprint(vector)
                request = dict(model=manifest['model'],input=[text],encoding_format='float')
                connection = http.client.HTTPConnection(*httpd.server_address,timeout=30)
                try:
                    connection.request('POST','/v1/embeddings',json.dumps(request))
                    response = connection.getresponse(); value=json.loads(response.read())
                    assert response.status == 200 and value['model'] == manifest['model']
                    assert len(value['data']) == 1 and value['data'][0]['index'] == 0
                    assert vector_fingerprint(value['data'][0]['embedding']) == expected
                finally:
                    connection.close()
                text_hash=hashlib.sha256(text.encode()).digest()
                witness.update(text_hash);witness.update(expected)
                checks.append(dict(source=number,row_group=group,row=offset,input_sha256=text_hash.hex(),vector_sha256=expected.hex()))
        reader.close()
        print(json.dumps(dict(phase='http_oracles',source=number,rss_peak_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024)),flush=True)
    snap = lookup.snapshot()
    peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024
    assert peak <= tomllib.loads((root/'run.toml').read_text())['resources']['max_observed_rss_bytes'], ('complete diagnostic memory ceiling', peak)
    assert len(checks)==89 and snap['returned_vectors']==89 and snap['failed_requests']==0
    assert snap['input_vector_witness_sha256']==witness.hexdigest()
    result = dict(status='ACTUAL_RETAINED_LOOKUP_DIAGNOSTIC_PASS',identity=identity,snapshot=snap,checks=checks,
        elapsed_s=time.monotonic()-started,rss_peak_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,
        limits=['Control changes only helper ParquetFile pre_buffer to false; independent oracle uses original defaults. No production daemon acceptance.','Helper observed process high-water RSS only; no enforced cgroup claim.',
                'Full source hashes checked; vector uniqueness comes from the separate census.',
                '89 actual retained-vector HTTP oracles; no live inference or paid API calls.'])
    publish(root/'result.json', result)
    state.update(phase='complete',completed_utc=utc(),result_sha256=digest(root/'result.json'))
except BaseException as error:
    state.update(phase='failed',error_type=type(error).__name__,error=str(error),failed_utc=utc())
    raise
finally:
    if httpd is not None:
        httpd.shutdown();worker.join(5);assert not worker.is_alive();httpd.server_close()
    if lookup is not None:lookup.close()
    state['consumers_stopped']=True
    publish(root/'state.json',state)
    publish(root/'progress.yaml',dict(completed=len(state['completed']),total=27,
        elapsed_s=time.monotonic()-started,rate_per_s=None,eta_s=0 if state['phase']=='complete' else None,
        active_unit=None,phase=state['phase'],process=state['process'],config_epoch=state.get('config_epoch')))
print(json.dumps({key:value for key,value in result.items() if key not in ['checks','identity']}))
