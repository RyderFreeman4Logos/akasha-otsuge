"""Select exact-null-scope lexical witnesses from independent retained source bytes."""
import collections, hashlib, json, pathlib, re, sys
import pyarrow.parquet as pq
W=pathlib.Path.cwd();E=pathlib.Path(__file__).parent
sys.path.insert(0,str(W/'spikes/data'))
from download import verify
from prepare_corpus import chunks
R=(W/'.spike-work/mvp024-vector-pilot-r1').resolve(strict=True)
admission=json.loads((R/'admission.json').read_text());binding=json.loads((R/'binding.json').read_text())
oracle=json.loads((R/'oracle.json').read_text());expected={m['id']:m for m in oracle['memories'] if not m['vector_cohort']}
assert len(expected)==7298
source=json.loads((R/'input-manifest.json').read_text())['inputs'][1]
verify(pathlib.Path(source['path']),dict(size=source['bytes'],sha256=source['sha256']))
binding_json=json.dumps(dict(source_manifest_sha256=binding['source_manifest_sha256'],observed_time_ms=binding['observed_time_ms']),separators=(',',':'))
seen=set();matched=set();records=0;frequencies=collections.defaultdict(collections.Counter);candidates=[]
for batch in pq.ParquetFile(source['path'],pre_buffer=False).iter_batches(batch_size=64,columns=['text']):
    for row in batch.to_pylist():
        for text in chunks(row['text']):
            encoded=text.encode();body_hash=hashlib.sha256(encoded).hexdigest()
            if body_hash in seen:continue
            seen.add(body_hash);records+=1
            key='fineweb:'+body_hash;partition='p'+str(hashlib.sha256(key.encode()).digest()[0]%8)
            source_id='corpus/'+hashlib.sha256(json.dumps([binding_json,key],ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
            offset=0
            while offset<len(encoded):
                end=min(offset+32768,len(encoded))
                while end<len(encoded) and encoded[end]&0xC0==0x80:end-=1
                claim=encoded[offset:end];memory_id=source_id+'/'+str(offset);memory=expected[memory_id]
                assert memory['claim_sha256']==hashlib.sha256(claim).hexdigest() and memory['partition']==partition
                matched.add(memory_id)
                terms=set(re.findall(r'\b[a-z]{8,40}\b',claim.decode().lower()));frequencies[partition].update(terms)
                if len(claim)<=4096:candidates.append((partition,memory,terms))
                offset=end
            if records==7168:break
        if records==7168:break
    if records==7168:break
assert matched==set(expected) and records==7168
witnesses={}
for partition,memory,terms in candidates:
    unique=sorted((word for word in terms if frequencies[partition][word]==1),key=lambda word:(-len(word),word))
    if unique and partition not in witnesses:
        witnesses[partition]=dict(id=memory['id'],revision=memory['revision'],claim_sha256=memory['claim_sha256'],query=unique[0],branch_or_version=None,source_term_document_frequency=1)
assert set(witnesses)=={f'p{n}' for n in range(8)}
result=dict(status='EXACT_SCOPE_WITNESSES_PREPARED',source_head=admission['head'],original_admission_sha256=hashlib.sha256((R/'admission.json').read_bytes()).hexdigest(),
            script_sha256=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),null_scope_claims_reconstructed=7298,source_records=7168,
            selection='first <=4096-byte claim in each exact null-branch scope with a unique 8..40 ASCII-letter term; longest term then lexical tie-break',witnesses=witnesses)
with (E/'mvp024-vector-keyword-oracle-r1.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({key:value for key,value in result.items() if key!='witnesses'}))
