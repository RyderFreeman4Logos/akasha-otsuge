import datetime,hashlib,json,pathlib,subprocess,zipfile
E=pathlib.Path(__file__).parent;W=pathlib.Path.cwd()
out=W/'docs/benchmarks/results/mvp024-vector-cohort'
candidates=set()
for base in [W,W.resolve(),pathlib.Path('/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge')]:
    for node in [base/'docs/benchmarks/results/mvp024-vector-cohort',base/'docs/plan']:
        for parent in [node,*node.parents]:
            for name in ['AGENTS.md','AGENTS.override.md']:candidates.add(str(parent/name))
existing=[p for p in sorted(candidates) if pathlib.Path(p).is_file()]
assert not existing,existing
census=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),candidates=sorted(candidates),existing=existing)
with (E/'mvp024-vector-cohort-parent-archive-instructions-r1.json').open('x') as f:json.dump(census,f,indent=2);f.write('\n')
assert not (W/'.spike-work/mvp024-vector-pilot-r1/data').exists()
assert json.loads((E/'mvp024-vector-pilot-r1-cleanup.json').read_text())['removed']
prefixes=['mvp024-vector-cohort','mvp024-precomputed','mvp024-vector-census','mvp024-vector-input','mvp024-vector-supplement','mvp024-vector-pilot','mvp024-vector-keyword','mvp024-vector-reopen','mvp024-lookup','mvp024-vector-canonical']
members={}
for p in sorted(E.iterdir()):
    if p.is_file() and any(p.name.startswith(k) for k in prefixes) and not p.name.endswith('.supervisor.log') and p.name!='mvp024-vector-cohort-archive-r1.py':
        members['evidence/'+p.name]=p
members['evidence/mvp024-vector-cohort-archive-r1.py']=pathlib.Path(__file__)
for name in ['mvp024-vector-supplement-r1','mvp024-vector-census-r1','mvp024-precomputed-real-r1','mvp024-precomputed-buffer-control-r1','mvp024-vector-pilot-r1']:
    root=(W/'.spike-work'/name).resolve(strict=True)
    for p in sorted(root.rglob('*')):
        assert not p.is_symlink(),p
        if not p.is_file() or p.suffix=='.parquet':continue
        assert 'data' not in p.relative_to(root).parts,p
        members['runs/'+name+'/'+str(p.relative_to(root))]=p
members['sources/full-corpus-manifest.json']=W/'docs/benchmarks/results/full-corpus-manifest.json'
out.mkdir(parents=True,exist_ok=True);archive=out/'evidence.zip';entries={}
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in sorted(members.items()):
        data=p.read_bytes();i=zipfile.ZipInfo(name,(2026,11,17,0,0,0));i.compress_type=zipfile.ZIP_DEFLATED;i.external_attr=0o100644<<16
        z.writestr(i,data);entries[name]=dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(entries)
    for name,item in entries.items():assert hashlib.sha256(z.read(name)).hexdigest()==item['sha256']
manifest=dict(source_head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),source_tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),
    archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),archive_bytes=archive.stat().st_size,members=entries,
    scope='Read-only source census, exact input lookup diagnostics including resource failure, focused seeder tests, original partial pilot, corrected reopen, and exact cleanup; no full-scale acceptance.')
with (out/'manifest.json').open('x') as f:json.dump(manifest,f,indent=2);f.write('\n')
print(json.dumps(dict(members=len(entries),archive_bytes=manifest['archive_bytes'],archive_sha256=manifest['archive_sha256'],instruction_candidates=len(candidates))))

