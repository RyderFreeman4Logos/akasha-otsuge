"""Read-only shard census; all writes are compact receipts in one owned run."""
import datetime, fcntl, hashlib, json, math, os, pathlib, struct, sys, time, tomllib
W = pathlib.Path('/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025')
sys.path.insert(0, str(W / 'spikes/data'))
from download import publish, verify
from prepare_corpus import chunks, vector_fingerprint
sys.path.insert(0, str(W / 'spikes/helix'))
from run_case import digest, process_identity
import pyarrow as pa
import pyarrow.parquet as pq

VECTOR = 'text-embedding-3-large-1536-embedding'

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()

def supplement(root):
    assert digest(root / 'candidate-manifest.json') == '596c52593ca2dc971a588db52cc1527ac4a57e141148d2df01dd7ff690736cf3'
    manifest = json.loads((root / 'candidate-manifest.json').read_text())
    for item in (manifest['source'], manifest['output']):
        verify(root / item['file'], {'size': item['bytes'], 'sha256': item['sha256']})
    raw = pq.read_table(root / manifest['source']['file']).to_pylist()
    selected = pq.read_table(root / manifest['output']['file']).to_pylist()
    assert len(selected) == len(manifest['rows']) == 37
    texts, vectors = set(), set()
    for row, proof in zip(selected, manifest['rows']):
        assert row['source_row'] == proof['source_row']
        source = raw[row['source_row']]
        values = source['embedding']
        assert source['word'] == row['word'] and len(values) == 3072
        assert all(map(math.isfinite, values)) and any(values)
        norm = math.sqrt(sum(v * v for v in values[:1536]))
        assert norm > 0
        derived = struct.pack('<1536f', *[v / norm for v in values[:1536]])
        assert list(struct.unpack('<1536f', derived)) == row['embedding']
        th = hashlib.sha256(row['word'].encode()).hexdigest()
        vh = vector_fingerprint(row['embedding']).hex()
        assert th == proof['word_sha256'] and vh == proof['derived_vector_float32_sha256']
        assert hashlib.sha256(struct.pack('<3072d', *values)).hexdigest() == proof['source_vector_float64_sha256']
        assert 0 < len(row['word'].encode()) <= 4096 and row['word'].strip()
        assert th not in texts and vh not in vectors
        texts.add(th); vectors.add(vh)
    return texts, vectors, manifest

def scan(path, item, text_hashes, vector_hashes, seen_vectors, batch_rows, timeout):
    started = time.monotonic()
    before = path.stat()
    verify(path, item['source'])
    vector_file = item['file'].startswith('vectors-')
    columns = ['_id', 'title', 'text', VECTOR] if vector_file else ['text']
    summary = dict(rows=0, eligible_vectors=0, excluded_vectors=[], checked_text_chunks=0, maximum_vector_input_bytes=0)
    witness = hashlib.sha256()
    for batch in pq.ParquetFile(path).iter_batches(batch_size=batch_rows, columns=columns):
        for row in batch.to_pylist():
            if time.monotonic() - started > timeout:
                raise TimeoutError('read-only unit deadline exceeded')
            summary['rows'] += 1
            if vector_file:
                body = row['title'] + '\n' + row['text']
                body_bytes = body.encode()
                th = hashlib.sha256(body_bytes).hexdigest()
                vh = vector_fingerprint(row[VECTOR]).hex()
                if vh in vector_hashes or vh in seen_vectors:
                    raise ValueError('duplicate vector in prospective cohort')
                if th in text_hashes:
                    raise ValueError('supplement text overlaps retained corpus')
                seen_vectors.add(vh)
                assert body.strip() and 0 < len(body_bytes) <= 128 * 1024
                summary['maximum_vector_input_bytes'] = max(summary['maximum_vector_input_bytes'], len(body_bytes))
                key = hashlib.sha256(('dbpedia:' + row['_id']).encode()).hexdigest()
                witness.update(bytes.fromhex(key + th + vh))
                if len(body_bytes) <= 4096:
                    summary['eligible_vectors'] += 1
                else:
                    summary['excluded_vectors'].append(dict(key_sha256=key, body_sha256=th, utf8_bytes=len(body_bytes)))
            else:
                for body in chunks(row['text']):
                    th = hashlib.sha256(body.encode()).hexdigest()
                    if th in text_hashes:
                        raise ValueError('supplement text overlaps retained corpus')
                    witness.update(bytes.fromhex(th))
                    summary['checked_text_chunks'] += 1
    after = path.stat()
    assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
    summary['content_witness_sha256'] = witness.hexdigest()
    return summary

def policy(root):
    value = tomllib.loads((root / 'config.toml').read_text())
    assert set(value) == {'resources', 'reliability'}
    assert set(value['resources']) == {'batch_rows'}
    assert set(value['reliability']) == {'max_attempts', 'unit_timeout_s'}
    assert type(value['resources']['batch_rows']) is int and 1 <= value['resources']['batch_rows'] <= 256
    assert value['reliability']['max_attempts'] == 5
    assert 60 <= value['reliability']['unit_timeout_s'] <= 86400
    return value, hashlib.sha256(encoded(value)).hexdigest()

def self_test():
    import tempfile
    with tempfile.TemporaryDirectory(prefix='akasha-vector-census-check-') as scratch:
        root = pathlib.Path(scratch)
        path = root / 'vectors-00000.parquet'
        rows = [{'_id': 'short', 'title': 'a', 'text': 'b', VECTOR: [1.0] + [0.0] * 1535},
                {'_id': 'long', 'title': 'a', 'text': 'b' * 4096, VECTOR: [0.0, 1.0] + [0.0] * 1534}]
        pq.write_table(pa.Table.from_pylist(rows), path)
        item = {'file': path.name, 'source': {'size': path.stat().st_size, 'sha256': digest(path)}}
        seen = set()
        result = scan(path, item, set(), set(), seen, 1, 60)
        assert result['rows'] == 2 and result['eligible_vectors'] == 1 and len(result['excluded_vectors']) == 1 and len(seen) == 2
        for texts, vectors, previous in [
            ({hashlib.sha256(b'a\nb').hexdigest()}, set(), set()),
            (set(), {vector_fingerprint(rows[0][VECTOR]).hex()}, set()),
            (set(), set(), seen),
        ]:
            try: scan(path, item, texts, vectors, previous, 2, 60)
            except ValueError: pass
            else: raise AssertionError('overlap accepted')
        path = root / 'text-00000.parquet'
        pq.write_table(pa.Table.from_pylist([{'text': 'word'}]), path)
        item = {'file': path.name, 'source': {'size': path.stat().st_size, 'sha256': digest(path)}}
        try: scan(path, item, {hashlib.sha256(b'word').hexdigest()}, set(), set(), 1, 60)
        except ValueError: pass
        else: raise AssertionError('text overlap accepted')
    print('PASS: actual parquet eligibility, oversized input, vector/text overlap and duplicate controls; fixture scratch removed')

def main():
    root = pathlib.Path(sys.argv[1]).resolve(strict=True)
    assert root.parent == (W / '.spike-work').resolve()
    assert (root / 'OWNER').read_text() == 'akasha-otsuge:mvp024-vector-census-r1\n'
    lock = os.fdopen(os.open(root / 'census.lock', os.O_CREAT | os.O_WRONLY | os.O_NOFOLLOW, 0o600), 'a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    resume = len(sys.argv) == 3 and sys.argv[2] == '--resume'
    assert len(sys.argv) == 2 or resume
    baseline_path = W / 'docs/benchmarks/results/full-corpus-manifest.json'
    assert digest(baseline_path) == '0b38c64fd5f5d77571ef9c76af4ccea298a96e76720f577d2d0b5c88adc43a66'
    baseline = json.loads(baseline_path.read_text())
    for name, sha in baseline['code_sha256'].items(): assert digest(W / 'spikes/data' / name) == sha
    corpus = (W / '.spike-work/corpus-full-v1').resolve(strict=True)
    supp = (W / '.spike-work/mvp024-vector-supplement-r1').resolve(strict=True)
    text_hashes, vector_hashes, supp_manifest = supplement(supp)
    inputs = baseline['corpus']['inputs']
    assert len(inputs) == 41 and sum(i['file'].startswith('vectors-') for i in inputs) == 26
    assert all(pathlib.Path(i['file']).name == i['file'] for i in inputs)
    identity = dict(script_sha256=digest(__file__), baseline_sha256=digest(baseline_path),
                    corpus=str(corpus), supplement_sha256=digest(supp / 'candidate-manifest.json'),
                    code=baseline['code_sha256'], python=sys.version.split()[0], pyarrow=pa.__version__,
                    policy='all original vector rows; 4096-byte selected inputs; full retained text-shard superset')
    state_path = root / 'state.json'
    if state_path.exists():
        assert resume, 'existing state requires explicit --resume'
        state = json.loads(state_path.read_text())
        assert state['identity'] == identity and state['phase'] != 'complete'
        old = process_identity(state['process']['pid'])
        assert old is None or old['start_ticks'] != state['process']['start_ticks'] or old['state'] == 'Z', 'original census is still running'
    else:
        assert not resume
        state = dict(identity=identity, started_utc=utc(), units={}, epochs={}, launches=[], phase='admitted')
    process = process_identity(os.getpid())
    state['process'] = process
    state['launches'].append(dict(utc=utc(), process=process, resume=resume))
    publish(state_path, state)
    seen_vectors = set()
    try:
        for number, item in enumerate(inputs):
            name = item['file']; cfg, epoch = policy(root)
            assert all(k in [i['file'] for i in inputs] for k in state['units'])
            state['epochs'].setdefault(epoch, cfg)
            state.update(active_unit=name, phase='revalidating_completed' if name in state['units'] else 'scanning', config_epoch=epoch)
            publish(state_path, state)
            elapsed = (datetime.datetime.now(datetime.timezone.utc) - datetime.datetime.fromisoformat(state['started_utc'])).total_seconds()
            publish(root / 'progress.yaml', dict(completed=len(state['units']), total=len(inputs), elapsed_s=elapsed,
                rate_per_s=len(state['units']) / elapsed if elapsed else 0, eta_s=None,
                eta_reason='unequal vector and text units', active_unit=name, process=process, config_epoch=epoch, phase=state['phase']))
            result = scan(corpus / name, item, text_hashes, vector_hashes, seen_vectors,
                          cfg['resources']['batch_rows'], cfg['reliability']['unit_timeout_s'])
            receipt = dict(input=item, result=result)
            if name in state['units']:
                assert receipt == state['units'][name]['receipt'], 'completed unit changed during read-only resume validation'
                assert hashlib.sha256(encoded(receipt)).hexdigest() == state['units'][name]['sha256']
            else:
                state['units'][name] = dict(receipt=receipt, sha256=hashlib.sha256(encoded(receipt)).hexdigest(),
                    config_epoch=epoch, completed_utc=utc(), attempts=1)
            publish(state_path, state)
            print(json.dumps(dict(unit=name, completed=len(state['units']), total=len(inputs), rows=result['rows'])), flush=True)
        units = [state['units'][i['file']]['receipt']['result'] for i in inputs]
        eligible = sum(u['eligible_vectors'] for u in units)
        excluded = [v for u in units for v in u['excluded_vectors']]
        assert len(seen_vectors) == 1000000 and eligible == 999963 and len(excluded) == 37
        report = dict(status='PROSPECTIVE_COHORT_VERIFIED_NOT_IMPORTED', identity=identity,
            baseline_unique_vectors_fresh=len(seen_vectors), selected_base_vectors=eligible,
            supplement_vectors=len(vector_hashes), prospective_unique_vectors=eligible + len(vector_hashes),
            oversized_excluded_from_vectors=excluded, inputs_verified=41, source_files_modified=False,
            historical_unique_utf8_bytes=baseline['corpus']['unique_content_utf8_bytes'],
            lexical_bytes_recounted=False, new_api_calls=0, complete_input_identity=baseline['corpus']['inputs'],
            limits=['Fresh vector uniqueness and supplemental text overlap checks; old lexical dedup count is inherited.',
                    'Text scan covers all rows in the final pinned shard, a superset of the old stop point.',
                    'Publisher input association does not prove an exact OpenAI API separator or output equivalence.',
                    'Production seeder cohort scopes, precomputed endpoint wiring, full imports and load acceptance remain pending.'])
        publish(root / 'result.json', report)
        state.update(phase='complete', active_unit=None, completed_utc=utc())
        publish(state_path, state)
        publish(root / 'progress.yaml', dict(completed=41,total=41,elapsed_s=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(state['started_utc'])).total_seconds(),rate_per_s=None,eta_s=0,active_unit=None,process=process,config_epoch=state['config_epoch'],phase='complete'))
    except BaseException as error:
        state.setdefault('failures', []).append(dict(utc=utc(), unit=state.get('active_unit'),
            error_type=type(error).__name__, error=str(error)))
        state.update(phase='failed', error_type=type(error).__name__, error=str(error), failed_utc=utc())
        publish(state_path, state)
        progress = json.loads((root / 'progress.yaml').read_text()) if (root / 'progress.yaml').exists() else dict(completed=len(state['units']), total=len(inputs))
        progress.update(phase='failed', error_type=type(error).__name__)
        publish(root / 'progress.yaml', progress)
        raise

if __name__ == '__main__':
    self_test() if sys.argv[1:] == ['--self-test'] else main()
