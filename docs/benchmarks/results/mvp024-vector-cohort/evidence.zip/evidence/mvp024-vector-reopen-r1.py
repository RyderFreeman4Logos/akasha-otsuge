"""Complete corrected query oracles on the stopped pilot store; no reimport/index."""
import datetime, hashlib, json, math, os, pathlib, resource, signal, subprocess, sys, time, tomllib
W=pathlib.Path.cwd();E=pathlib.Path(__file__).parent
sys.path.insert(0,str(W/'spikes/helix'))
from run_case import publish, process_identity, digest
old=(W/'.spike-work/mvp024-vector-pilot-r1').resolve(strict=True)
load=lambda name:json.loads((old/name).read_text())
original=load('admission.json');state0=load('state.json');index0=load('indexed-status.json')
assert state0['phase']=='failed' and state0['error']['message']=="('expected lexical hit missing', 'p0')"
assert state0['processes_terminal']==dict(seed=0,daemon=0,lookup=0)
for name in ['seed-process.json','daemon-process.json','lookup-process.json']:
    prior=load(name);current=process_identity(prior['pid'])
    assert current is None or current['start_ticks']!=prior['start_ticks']
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head==original['head'] and not subprocess.check_output(['git','status','--porcelain'])
build=json.loads((E/'mvp024-vector-reopen-build-r1.json').read_text())
binary=(W/'target/release/akasha-otsuge').resolve(strict=True)
assert build['head']==head and digest(binary)==build['daemon_sha256']
keyword=json.loads((E/'mvp024-vector-keyword-oracle-r1.json').read_text())
assert keyword['original_admission_sha256']==digest(old/'admission.json')
vectors=load('vector-oracle.json')['witnesses']
root=old/'reopen-r1';root.mkdir(mode=0o700)
(root/'OWNER').write_text('akasha-otsuge:mvp024-vector-reopen-r1\n')
lookup_root=root/'lookup';lookup_root.mkdir(mode=0o700)
(lookup_root/'OWNER').write_text('akasha-otsuge:mvp024-lookup-reopen-r1\n')
for name in ['lookup-manifest.json','lookup.toml']:(lookup_root/name).write_bytes((old/name).read_bytes())
port=load('lookup-ready.json')['address'][1]
endpoint=pathlib.Path(original['socket_root'])/'service.sock'
assert not endpoint.exists()
config_sha=digest(old/'daemon.toml')
base=[str(binary),'--config',str(old/'daemon.toml'),'--socket',str(endpoint)]
started=time.monotonic();daemon=provider=None
admission=dict(head=head,tree=build['tree'],original_admission_sha256=digest(old/'admission.json'),
    original_partial_verification_sha256=digest(E/'mvp024-vector-pilot-r1-partial-verified.json'),
    daemon_sha256=build['daemon_sha256'],prior_index_builder_sha256=original['daemon_sha256'],
    same_daemon_binary=build['same_binary'],config_sha256=config_sha,endpoint_port=port,
    keyword_oracle_sha256=digest(E/'mvp024-vector-keyword-oracle-r1.json'),driver_sha256=digest(__file__),
    provider_driver_sha256=digest(E/'mvp024-lookup-reopen-r1.py'),process=process_identity(os.getpid()),
    started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    no_seed_or_index_replay=True,limits=['Eight corrected keyword witnesses and eight vector self hits on the same persisted pilot.',
        'Earlier complete source/current/vector-pair checks remain evidence from the failed first run.',
        'Canonical release build command produces a different artifact at the same source; exact cause remains unclassified.',
        'Observed helper ceilings are separate from daemon cgroup enforcement; no full scale, load, ANN recall rate or recovery campaign.'])
publish(root/'admission.json',admission)
state=dict(phase='admitted',completed=0,total=16,process=admission['process'],units={})
publish(root/'state.json',state)
(root/'run.toml').write_text('[reliability]\nmax_attempts=1\nunit_timeout_s=120\n[resources]\nhelper_rss_ceiling_bytes=536870912\ncontroller_rss_ceiling_bytes=536870912\n')
epoch=digest(root/'run.toml');commands=(root/'commands.jsonl').open('x');metrics=[]
def progress():
    assert digest(root/'run.toml')==epoch
    elapsed=time.monotonic()-started;done=state['completed']
    publish(root/'state.json',state)
    publish(root/'progress.yaml',dict(completed=done,total=16,elapsed_s=elapsed,rate_per_s=done/elapsed,
        eta_s=elapsed*(16-done)/done if done else None,phase=state['phase'],active_unit=state.get('active_unit'),process=state['process'],config_epoch=epoch))
def cli(*args,required=True):
    result=subprocess.run([*base,*map(str,args)],stdin=subprocess.DEVNULL,capture_output=True,timeout=30)
    commands.write(json.dumps(dict(argv=list(map(str,args)),exit_code=result.returncode,stdout_sha256=hashlib.sha256(result.stdout).hexdigest(),stderr_sha256=hashlib.sha256(result.stderr).hexdigest()))+'\n');commands.flush();os.fsync(commands.fileno())
    if required:assert result.returncode==0,(args,result.stderr.decode()[:1024])
    return json.loads(result.stdout)['data'] if result.returncode==0 else None
def stable_index(value):
    return {key:value[key] for key in ['generation','lexical_watermark','indexed_rows']}, {key:value['vector'][key] for key in ['generation','model_identity','dimension','watermark','indexed_rows','embedding_scopes']}
def sample():
    status=cli('daemon','status');r=status['resources'];cg=r['cgroup'];measurement=r['measurement']
    assert cg['complete'] and cg['enforced'] and measurement['complete']
    assert cg['daemon_group']['high_bytes']==512*1024**2 and cg['daemon_group']['max_bytes']==640*1024**2 and cg['service_total']['max_bytes']==2048*1024**2
    assert cg['daemon_group']['oom_kills']==0
    rss=measurement['daemon_group']['rss_bytes'];assert rss<=640*1024**2
    assert provider.poll() is None
    helper={}
    for line in pathlib.Path(f'/proc/{provider.pid}/status').read_text().splitlines():
        key,_,value=line.partition(':')
        if key in ('VmRSS','VmHWM'):helper[key]=int(value.split()[0])*1024
    parent_peak=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024
    assert helper['VmHWM']<=512*1024**2 and parent_peak<=512*1024**2
    metrics.append(dict(resources=r,helper=helper,controller_peak_bytes=parent_peak))
    publish(root/'metrics.json',metrics)
def job(name):
    deadline=time.monotonic()+120
    while True:
        value=cli('job','show',name)
        if value['state'] in ('succeeded','failed','cancelled'):
            publish(root/(name+'.json'),value);assert value['state']=='succeeded',(name,value.get('error'))
            return value
        assert time.monotonic()<deadline,('query deadline',name)
        time.sleep(.02)
try:
    state['phase']='lookup_admission';progress()
    with (root/'lookup.log').open('xb') as log:
        provider=subprocess.Popen(['nohup',sys.executable,str(E/'mvp024-lookup-reopen-r1.py'),str(lookup_root),head,str(port)],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    publish(root/'lookup-process.json',process_identity(provider.pid))
    deadline=time.monotonic()+300
    while not (lookup_root/'lookup-ready.json').exists():
        assert provider.poll() is None,'lookup process failed'
        assert time.monotonic()<deadline,'lookup admission deadline'
        time.sleep(.2)
    ready=json.loads((lookup_root/'lookup-ready.json').read_text());assert ready['address'][1]==port
    with (root/'daemon.log').open('xb') as log:
        daemon=subprocess.Popen(['nohup',*base,'daemon','run'],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    publish(root/'daemon-process.json',process_identity(daemon.pid))
    deadline=time.monotonic()+120
    while not endpoint.exists() or not cli('daemon','status',required=False):
        assert daemon.poll() is None and time.monotonic()<deadline
        time.sleep(.1)
    index=cli('index','status');assert stable_index(index)==stable_index(index0)
    publish(root/'reopened-index.json',index);sample()
    for kind,witnesses,branch in [('keyword',keyword['witnesses'],None),('vector',vectors,'vectors')]:
        for partition,expected in sorted(witnesses.items()):
            name='pilot-reopen-'+kind+'-'+partition;state.update(phase='queries',active_unit=name);progress()
            memory=cli('memory','show',expected['id'])['data']['revision']['memory']
            assert memory['revision']['commit_seq']==expected['revision']
            draft=memory['record']['draft'];assert draft['scope']['project']=='corpus/'+partition and draft['scope']['branch_or_version']==branch
            if kind=='keyword':assert hashlib.sha256(draft['claim'].encode()).hexdigest()==expected['claim_sha256']
            else:assert draft['claim']==expected['query']
            scope_file=root/(name+'-scope.json');publish(scope_file,dict(user=f'uid:{os.geteuid()}',project='corpus/'+partition,branch_or_version=branch,session=None))
            cli('search',expected['query'],'--scope',scope_file,'--idempotency-key',name)
            terminal=job(name);output=json.loads(terminal['result']['output'])
            assert output['mode']==('keyword' if kind=='keyword' else 'hybrid')
            items=[i['memory'] for i in output['items']]
            assert any(i['revision']['key']['id']==expected['id'] and i['revision']['commit_seq']==expected['revision'] for i in items),(kind,partition,'self-hit missing')
            assert all(i['record']['draft']['scope']['project']=='corpus/'+partition and i['record']['draft']['scope']['branch_or_version']==branch for i in items)
            if kind=='keyword':assert (lookup_root/'lookup-events.bin').stat().st_size==0
            state['units'][name]=dict(expected=expected,receipt_id=terminal['result']['receipt_id'],mode=output['mode'],terminal_sha256=digest(root/(name+'.json')))
            state['completed']+=1;sample();progress()
    assert stable_index(cli('index','status'))==stable_index(index0)
    assert (lookup_root/'lookup-events.bin').stat().st_size==8*64
    rss=sorted(x['resources']['measurement']['daemon_group']['rss_bytes'] for x in metrics)
    assert rss[math.ceil(.99*len(rss))-1]<=512*1024**2
    state['phase']='verified_awaiting_shutdown';progress()
except BaseException as error:
    state.update(phase='failed',error_type=type(error).__name__,error=str(error));publish(root/'failure.json',state)
    raise
finally:
    try:
        if daemon and daemon.poll() is None:
            cli('daemon','stop',required=False)
            try:daemon.wait(timeout=60)
            except subprocess.TimeoutExpired:daemon.send_signal(signal.SIGTERM);daemon.wait(timeout=30)
        if provider and provider.poll() is None:provider.send_signal(signal.SIGTERM);provider.wait(timeout=60)
        state['terminal']={name:None if process is None else process.returncode for name,process in [('daemon',daemon),('lookup',provider)]}
        if state['phase']=='verified_awaiting_shutdown':
            assert state['terminal']==dict(daemon=0,lookup=0) and digest(old/'daemon.toml')==config_sha
            helper=json.loads((lookup_root/'lookup-terminal.json').read_text());assert helper['phase']=='stopped' and helper['snapshot']['returned_vectors']==8 and helper['snapshot']['failed_requests']==0
            audit=(lookup_root/'lookup-events.bin').read_bytes()
            expected=b''.join(hashlib.sha256(v['query'].encode()).digest()+bytes.fromhex(v['vector_sha256']) for _,v in sorted(vectors.items()))
            assert audit==expected
            result=dict(status='CORRECTED_QUERIES_AND_REOPEN_PASS',admission_sha256=digest(root/'admission.json'),keyword_witnesses=8,vector_self_hits=8,
                unchanged_index_generations_and_counts=True,lookup=helper,daemon_rss_max=max(rss),daemon_rss_p99=rss[math.ceil(.99*len(rss))-1],samples=len(metrics),
                original_failure_preserved=True,seed_or_index_replayed=False,elapsed_s=time.monotonic()-started,limits=admission['limits'])
            publish(root/'result.json',result);state['phase']='complete'
    except BaseException as error:
        state.update(phase='failed',finalization_error={'type':type(error).__name__,'message':str(error)});publish(root/'finalization-failure.json',state)
        raise
    finally:
        progress();commands.flush();os.fsync(commands.fileno());commands.close()
print(json.dumps(dict(root=str(root),phase=state['phase'],completed=state['completed'])))
