import pathlib,json,hashlib,math,struct,datetime,pyarrow as pa,pyarrow.parquet as pq
root=pathlib.Path('.spike-work/mvp024-vector-supplement-r1').resolve();p=root/'joy_knn.parquet'
assert hashlib.sha256(p.read_bytes()).hexdigest()=='76699cb6ccf4634c4ffb83d159f2183310564f0e29a4d646fc1dc71bb4028fde'
rows=pq.read_table(p).to_pylist();seen_text=set();seen_vectors=set();selected=[];identities=[]
for i,row in enumerate(rows):
 word=row['word'];vec=row['embedding'];assert isinstance(word,str) and 0<len(word.encode())<=4096
 assert len(vec)==3072 and all(map(math.isfinite,vec)) and any(vec)
 norm=math.sqrt(sum(x*x for x in vec[:1536]));assert norm>0
 packed=struct.pack('<1536f',*[x/norm for x in vec[:1536]]);short=list(struct.unpack('<1536f',packed))
 assert all(map(math.isfinite,short)) and any(short) and abs(sum(x*x for x in short)-1)<1e-6
 th=hashlib.sha256(word.encode()).hexdigest();vh=hashlib.sha256(packed).hexdigest()
 if th in seen_text or vh in seen_vectors:continue
 seen_text.add(th);seen_vectors.add(vh)
 if len(selected)==37:continue
 selected.append({'word':word,'source_row':i,'embedding':short})
 identities.append({'source_row':i,'word_sha256':th,'utf8_bytes':len(word.encode()),'source_vector_float64_sha256':hashlib.sha256(struct.pack('<3072d',*vec)).hexdigest(),'derived_vector_float32_sha256':vh})
assert len(selected)==37 and len({x['word_sha256'] for x in identities})==37 and len({x['derived_vector_float32_sha256'] for x in identities})==37
dest=root/'selected-37.parquet';assert not dest.exists()
table=pa.Table.from_pylist(selected,schema=pa.schema([('word',pa.string()),('source_row',pa.int64()),('embedding',pa.list_(pa.float32(),1536))]))
pq.write_table(table,dest,compression='zstd')
back=pq.read_table(dest).to_pylist();assert back==selected
lic=json.loads("{\"content\":\"<package id=\\\"words\\\" name=\\\"Word Lists\\\"\\n         webpage=\\\"http://en.wikipedia.org/wiki/Words_(Unix)\\\"\\n         license=\\\"public domain\\\"\\n         copyright=\\\"public domain\\\"\\n         unzip=\\\"1\\\"\\n         />\\n\",\"encoding\":\"utf-8\",\"sha\":\"f86a2dca21e1c601fb09943ab368973938e6c5d7\",\"display_url\":\"https://github.com/nltk/nltk_data/blob/gh-pages/packages/corpora/words.xml\",\"display_title\":\"words.xml\"}")
manifest={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'candidate_supplement_only; not admitted or scale acceptance','source':{'repository':'conwaychriscosmo/text-embedding-3-large-english-dictionary','revision':'b9028e30ff362937bb9799aa332f98c1b2cfcf6f','file':'joy_knn.parquet','bytes':3833798,'sha256':'76699cb6ccf4634c4ffb83d159f2183310564f0e29a4d646fc1dc71bb4028fde','license_declared':'apache-2.0','model_declared':'text-embedding-3-large','dimensions':3072},'word_source_license':{'url':lic['display_url'],'git_blob_sha':lic['sha'],'content':lic['content'],'sha256':hashlib.sha256(lic['content'].encode()).hexdigest()},'derivation':{'input_text':'unchanged word field; association supplied by dataset publisher','algorithm':'First 1536 source dimensions; divide by their L2 norm; convert once to little-endian float32','official_rule':'https://developers.openai.com/api/docs/guides/embeddings','dimensions':1536,'selection':'First 37 rows in retained source order unique by text SHA256 and derived float32 vector SHA256','api_output_equivalence':'Not asserted bit-for-bit with an API dimensions=1536 response','new_api_calls':0},'output':{'file':dest.name,'bytes':dest.stat().st_size,'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'rows':37},'rows':identities,'pending':['Verify cross-corpus text/vector uniqueness in complete streaming admission.','Verify actual production chunk input and complete cardinality with retained manifest.','Integrate selection and disclosure into reproducible corpus code only after current frozen maintenance gates/review.']}
with (root/'candidate-manifest.json').open('x') as f:json.dump(manifest,f,indent=2);f.write('\n')
print(json.dumps({'status':manifest['status'],'output':manifest['output'],'source_bytes_retained':p.stat().st_size,'selected_text_bytes':sum(x['utf8_bytes'] for x in identities),'max_text_bytes':max(x['utf8_bytes'] for x in identities),'cross_corpus_dedup':'pending'}))
