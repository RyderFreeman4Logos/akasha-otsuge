import datetime, hashlib, json, pathlib, time
import pyarrow.parquet as pq

W = pathlib.Path('/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025')
E = pathlib.Path('/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/.git/akasha-evidence')
start = time.monotonic()
seen = set()
rows = eligible = duplicates = 0
units = []
for n in range(26):
    path = W / f'.spike-work/corpus-full-v1/vectors-{n:05d}.parquet'
    before = path.stat()
    count = 0
    for batch in pq.ParquetFile(path).iter_batches(columns=['title', 'text'], batch_size=1024):
        for row in batch.to_pylist():
            body = (row['title'] + '\n' + row['text']).encode()
            rows += 1
            count += 1
            if len(body) > 4096:
                continue
            eligible += 1
            key = hashlib.sha256(body).digest()
            duplicates += key in seen
            seen.add(key)
    after = path.stat()
    assert (before.st_ino, before.st_size, before.st_mtime_ns) == (after.st_ino, after.st_size, after.st_mtime_ns)
    units.append({'file': path.name, 'rows': count})
    print(json.dumps({'completed': n + 1, 'total': 26, 'elapsed_s': time.monotonic() - start}), flush=True)
result = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              status='READONLY_TEXT_KEY_CENSUS', rows=rows, eligible=eligible,
              unique_eligible_inputs=len(seen), duplicate_eligible_inputs=duplicates,
              units=units, seconds=time.monotonic() - start,
              source_hash_revalidation='previous completed 41-shard census; unchanged-stat check during this read',
              scope='eligible DBpedia title plus newline plus text only; no imported store')
with (E / 'mvp024-vector-input-identity-r1.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: value for key, value in result.items() if key != 'units'}))
