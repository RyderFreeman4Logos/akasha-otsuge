"""Owned, stoppable benchmark provider with exact-input audit and separate RSS."""
import datetime, fcntl, hashlib, json, os, pathlib, resource, signal, subprocess, sys, time, tomllib

W = pathlib.Path.cwd()
sys.path.insert(0,str(W/'spikes/data'))
from download import publish
from precomputed import Lookup, server
from prepare_corpus import vector_fingerprint
sys.path.insert(0,str(W/'spikes/helix'))
from run_case import digest, process_identity

root=pathlib.Path(sys.argv[1]).resolve(strict=True)
assert len(sys.argv)==4 and (root/'OWNER').read_text()=='akasha-otsuge:mvp024-lookup-reopen-r1\n'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==sys.argv[2]
assert not subprocess.check_output(['git','status','--porcelain'])
lock=(root/'lookup.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert not (root/'lookup-state.json').exists(), 'existing lookup requires parent reconciliation'
manifest=json.loads((root/'lookup-manifest.json').read_text())
process=process_identity(os.getpid());started=time.monotonic();stop=False
state=dict(phase='admitted',head=sys.argv[2],process=process,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
           manifest_sha256=digest(root/'lookup-manifest.json'),script_sha256=digest(__file__),
           code_sha256=digest(W/'spikes/data/precomputed.py'),completed_sources=0,total_sources=len(manifest['sources']),epochs={})
publish(root/'lookup-state.json',state)
events=(root/'lookup-events.bin').open('xb')
metrics=(root/'lookup-metrics.jsonl').open('x')
def stopping(*_):
    global stop
    stop=True
signal.signal(signal.SIGTERM,stopping)
signal.signal(signal.SIGINT,stopping)

def observe():
    cfg=tomllib.loads((root/'lookup.toml').read_text())
    assert cfg['reliability']['max_attempts']==5 and 60 <= cfg['reliability']['unit_timeout_s'] <= 86400
    ceiling=cfg['resources']['rss_ceiling_bytes']
    assert 256*1024**2 <= ceiling <= 1024**3
    epoch=hashlib.sha256(json.dumps(cfg,sort_keys=True).encode()).hexdigest()
    state['epochs'][epoch]=cfg;state['config_epoch']=epoch
    current={}
    for line in pathlib.Path('/proc/self/status').read_text().splitlines():
        key,_,value=line.partition(':')
        if key in ('VmRSS','VmHWM'):current[key]=int(value.split()[0])*1024
    current['ru_maxrss_bytes']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024
    current.update(elapsed_s=time.monotonic()-started,epoch=epoch,phase=state['phase'])
    metrics.write(json.dumps(current)+'\n');metrics.flush();os.fsync(metrics.fileno())
    assert current['ru_maxrss_bytes'] <= ceiling and current['VmHWM'] <= ceiling, ('lookup helper memory ceiling',current)
    return current

def progress(done,total,snapshot):
    if stop:raise RuntimeError('lookup stopped during read-only admission')
    state.update(phase='admitting',completed_sources=done,snapshot=snapshot)
    memory=observe();publish(root/'lookup-state.json',state)
    publish(root/'lookup-progress.yaml',dict(completed=done,total=total,elapsed_s=time.monotonic()-started,
        rate_per_s=done/(time.monotonic()-started),eta_s=None,active_unit=done,phase=state['phase'],process=process,config_epoch=state['config_epoch'],memory=memory))

class AuditedLookup(Lookup):
    def respond(self,request):
        response=super().respond(request)
        for text,item in zip(request['input'],response['data']):
            events.write(hashlib.sha256(text.encode()).digest()+vector_fingerprint(item['embedding']))
        events.flush()
        return response

lookup=httpd=None
try:
    lookup=AuditedLookup(manifest,progress)
    assert len(lookup.index)==1000000 and lookup.excluded==37
    httpd=server(lookup,port=int(sys.argv[3]));httpd.timeout=0.5
    state.update(phase='serving',address=list(httpd.server_address))
    observe();publish(root/'lookup-state.json',state)
    publish(root/'lookup-ready.json',dict(process=process,address=state['address'],model=lookup.model,manifest_sha256=state['manifest_sha256']))
    last=0
    while not stop:
        httpd.handle_request()
        if time.monotonic()-last >= 1:
            memory=observe();events.flush();os.fsync(events.fileno())
            state['snapshot']=lookup.snapshot();publish(root/'lookup-state.json',state)
            publish(root/'lookup-progress.yaml',dict(completed=lookup.requests,total=None,elapsed_s=time.monotonic()-started,
                rate_per_s=lookup.requests/(time.monotonic()-started),eta_s=None,active_unit=None,phase=state['phase'],process=process,config_epoch=state['config_epoch'],memory=memory))
            last=time.monotonic()
    state.update(phase='stopped',snapshot=lookup.snapshot(),final_memory=observe())
except BaseException as error:
    state.update(phase='failed',error_type=type(error).__name__,error=str(error))
    raise
finally:
    if httpd is not None:httpd.server_close()
    if lookup is not None:lookup.close()
    events.flush();os.fsync(events.fileno());events.close()
    metrics.flush();os.fsync(metrics.fileno());metrics.close()
    state['audit_sha256']=digest(root/'lookup-events.bin')
    state['audit_bytes']=(root/'lookup-events.bin').stat().st_size
    state['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    publish(root/'lookup-state.json',state);publish(root/'lookup-terminal.json',state)
