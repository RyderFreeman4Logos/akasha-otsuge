import datetime, hashlib, json, os, pathlib, shutil, subprocess, sys, time

repo = pathlib.Path.cwd()
sys.path.insert(0, str(repo / 'spikes/helix'))
from run_case import digest, process_identity, publish

storage = pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023')
base = storage / 'fallback-full-retire-r1'
database = storage / 'fallback-full-compressed-r1/database'
frozen = repo / '.spike-work/retire-generation-r2'
source = json.loads((frozen / 'source.json').read_text())
assert digest(frozen / 'probe') == source['native_sha256']
for group in ['source_sha256', 'helpers_sha256']:
    for name, expected in source[group].items():
        assert digest(repo / name) == expected, name
base.mkdir()
(base / 'OWNER').write_text('akasha-otsuge MVP-003 full offline inactive generation retirement\n')
plan = json.loads((storage / 'fallback-full-prune-r2/witness-plan.json').read_text())
plan.update(binary=str(frozen / 'probe'), binary_sha256=source['native_sha256'],
            source_head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip())
publish(base / 'witness-plan.json', plan)
publish(base / 'admission.json', dict(controller=process_identity(os.getpid()), driver_sha256=digest(__file__),
    witness_sha256=digest(repo / '.git/akasha-evidence/full-prune-witness.py'),
    generation_controller_sha256=digest(repo / 'spikes/helix/run_generation.py'), source=source,
    task_start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), scope='offline generation1 retirement; active2 unchanged'))

def inventory(name):
    started = time.monotonic()
    components = {}
    for parent, dirs, files in os.walk(database, followlinks=False):
        assert not any((pathlib.Path(parent) / d).is_symlink() for d in dirs)
        for filename in files:
            path = pathlib.Path(parent) / filename
            assert not path.is_symlink()
            stat = path.stat()
            rel = path.relative_to(database).parts
            key = '/'.join(rel[:3]) if rel[0] == 'derived' else rel[0]
            item = components.setdefault(key, dict(files=0, logical_bytes=0, allocated_bytes=0))
            item['files'] += 1
            item['logical_bytes'] += stat.st_size
            item['allocated_bytes'] += stat.st_blocks * 512
    result = dict(database=str(database), components=components, free_bytes=shutil.disk_usage(database).free,
        files=sum(x['files'] for x in components.values()), allocated_bytes=sum(x['allocated_bytes'] for x in components.values()),
        measured_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), seconds=time.monotonic()-started,
        allocation_note='inode st_blocks is not exclusive Btrfs allocation; filesystem free includes concurrent host activity')
    publish(base / name, result)
    return result

def gone(identity):
    actual = process_identity(identity['pid'])
    assert actual is None or actual['start_ticks'] != identity['start_ticks'], identity

def collect_memory(path, unit, expected=None):
    events = [json.loads(line) for line in path.read_text().splitlines()]
    assert events[0]['limits']['memory.max'] == '671088640'
    assert events[0]['limits']['memory.swap.max'] == '0'
    assert events[0]['nofile_soft_hard'] == [8192, 8192]
    executions = [x for x in events if x['event'] == 'executable']
    exits = [x for x in events if x['event'] == 'exit']
    assert len(executions) == len(exits) == 1
    if expected is not None:
        assert executions[0]['sha256'] == expected
    gone(executions[0])
    assert exits[0]['code'] == exits[0]['native_code'] == 0
    scratch = exits[0]['scratch_cleanup']
    assert scratch['removed'] and not pathlib.Path(scratch['path']).exists()
    active = subprocess.check_output(['systemctl', '--user', 'show', unit, '-p', 'ActiveState', '--value'], text=True).strip()
    assert active == 'inactive', active
    samples = [x for x in events if x['event'] == 'sample']
    assert samples and all(x['memory_events'].get('oom', 0) == x['memory_events'].get('oom_kill', 0) == 0 for x in samples)
    rss = max(x['engine_rss_bytes'] for x in samples)
    assert rss <= 640 * 1024**2
    return dict(seconds=exits[0]['seconds'], rss_max_bytes=rss,
        cgroup_peak_bytes=max(x['cgroup_peak_bytes'] for x in samples), native=executions[0], unit=unit,
        unit_state=active, scratch_removed=True, exact_processes_gone=True, oom_events=0)

def witness(phase):
    unit = 'akasha-full-retire-' + phase + '-r1'
    command = ['systemd-run', '--user', '--quiet', '--wait', '--pipe', '--collect', '--unit=' + unit,
        '-p', 'MemoryMax=671088640', '-p', 'MemorySwapMax=0', '-p', 'LimitNOFILE=8192',
        '-p', 'RuntimeMaxSec=1800', '-p', 'Environment=MALLOC_MMAP_THRESHOLD_=131072',
        sys.executable, str(repo / 'spikes/measure.py'), str(base / (phase + '-memory.jsonl')),
        sys.executable, str(repo / '.git/akasha-evidence/full-prune-witness.py'), str(base), phase]
    publish(base / (phase + '-command.json'), command)
    with (base / (phase + '.log')).open('x') as log:
        subprocess.run(command, check=True, stdout=log, stderr=subprocess.STDOUT)
    result = json.loads((base / phase / 'result.json').read_text())
    assert result['status'] == 'passed' and result['commands'] == 42
    for name, expected in result['artifact_sha256'].items():
        assert digest(base / phase / name) == expected, name
    commands = json.loads((base / phase / 'commands.json').read_text())
    for entry in commands:
        assert entry['exit'] == 0 and not entry['timed_out']
        gone(entry['child'])
    gone(json.loads((base / phase / 'admission.json').read_text())['controller'])
    verified = collect_memory(base / (phase + '-memory.jsonl'), unit)
    verified.update(status='passed', artifacts_verified=True, commands=42, matches_before=phase == 'after')
    publish(base / phase / 'verified.json', verified)
    print(json.dumps(dict(phase=phase, commands=42, rss_max_bytes=verified['rss_max_bytes'])), flush=True)

witness('before')
before = inventory('disk-before.json')
assert before['free_bytes'] >= 81212254720
lifecycle = json.loads((base / 'before/001.stdout').read_text())
assert lifecycle['active'] == 2 and lifecycle['committed'] == 260472
assert lifecycle['text']['watermark'] == lifecycle['vector']['watermark'] == lifecycle['committed']
request = dict(op='retire_generation', generation=1, deadline_ms=int(time.time()*1000)+7200_000)
publish(base / 'retire-request.json', request)
config = f'''[run]
id = "fallback-full-retire-r1"
profile = "low"
seconds = 7200
[paths]
binary = "{frozen / 'probe'}"
database = "{database}"
request = "{base / 'retire-request.json'}"
output = "{base / 'retire'}"
[disk]
start_bytes = 81212254720
reserve_bytes = 81212254720
[reliability]
max_attempts = 1
'''
(base / 'retire.toml').write_text(config)
with (base / 'retire.log').open('x') as log:
    subprocess.run([sys.executable, str(repo / 'spikes/helix/run_generation.py'), str(base / 'retire.toml')],
                   check=True, stdout=log, stderr=subprocess.STDOUT)
state_path = base / 'retire/state.json'
state = json.loads(state_path.read_text())
assert state['phase'] == 'completed' and state['result']['status'] == 'passed'
gone(state['controller'])
for name, expected in state['result']['artifact_sha256'].items():
    assert digest(base / 'retire' / name) == expected, name
attempt = state['attempts'][-1]
verified = collect_memory(pathlib.Path(attempt['log']).with_name('memory.jsonl'), attempt['unit'], source['native_sha256'])
lines = pathlib.Path(attempt['log']).read_text().splitlines()
replies = [json.loads(line) for line in lines if line.startswith('{')]
assert len(replies) == 1
reply = replies[0]
assert reply == dict(generation=1, retired=True, deadline_ms=request['deadline_ms'], completed=2, total=2), reply
assert not any(database.joinpath('derived').glob('g1_*.lance'))
verified.update(status='passed', artifacts_verified=True, reply=reply, elapsed_s=state['result']['elapsed_s'])
publish(base / 'retire/verified.json', verified)
print(json.dumps(dict(phase='retire', seconds=verified['elapsed_s'], rss_max_bytes=verified['rss_max_bytes'])), flush=True)
state_hash = digest(state_path)
with (base / 'completed-reuse.stdout').open('x') as stdout, (base / 'completed-reuse.stderr').open('x') as stderr:
    subprocess.run([sys.executable, str(repo / 'spikes/helix/run_generation.py'), str(base / 'retire.toml'), '--resume'],
                   check=True, stdout=stdout, stderr=stderr)
assert digest(state_path) == state_hash
assert json.loads((base / 'completed-reuse.stdout').read_text()) == state['result']
publish(base / 'completed-reuse.json', dict(status='passed', state_unchanged=True, native_execution=False))
witness('after')
after = inventory('disk-after.json')
for name, value in before['components'].items():
    if name.startswith('derived/g2_'):
        assert value == after['components'][name], name
old_bytes = sum(v['allocated_bytes'] for k, v in before['components'].items() if k.startswith('derived/g1_'))
result = dict(status='passed_full_offline_retirement', generation=1, active=2, committed=lifecycle['committed'],
    before_witnesses=42, after_witnesses=42, exact_json_matches=True,
    authority_history_witnesses_unchanged=True, active_index_allocations_unchanged=True,
    authority_allocated_bytes_delta=after['components']['authority']['allocated_bytes']-before['components']['authority']['allocated_bytes'],
    retired_generation_allocated_bytes=old_bytes,
    free_bytes_before=before['free_bytes'], free_bytes_after=after['free_bytes'],
    free_bytes_delta=after['free_bytes']-before['free_bytes'], binary_sha256=source['native_sha256'],
    seconds=verified['elapsed_s'], rss_max_bytes=verified['rss_max_bytes'],
    cgroup_peak_bytes=verified['cgroup_peak_bytes'], artifacts_verified=True,
    completed_reuse_verified=True, exact_processes_gone=True, scratch_removed=True,
    not_proven=['online retirement', 'expired retirement deadline extension', 'concurrent full rebuild physical peak'])
publish(base / 'result.json', result)
print(json.dumps(result), flush=True)
