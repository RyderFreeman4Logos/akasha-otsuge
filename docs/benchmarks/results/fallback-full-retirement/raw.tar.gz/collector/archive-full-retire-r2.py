import hashlib, json, pathlib, shutil, subprocess, sys, tarfile
repo = pathlib.Path.cwd()
sys.path.insert(0, str(repo / 'spikes/helix'))
from run_case import digest, process_identity, publish
storage = pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023')
base = storage / 'fallback-full-retire-r2'
summary = json.loads((base / 'result.json').read_text())
assert summary['status'] == 'passed_full_offline_retirement'
for phase in ['before', 'after']:
    result = json.loads((base / phase / 'result.json').read_text())
    for name, expected in result['artifact_sha256'].items():
        assert digest(base / phase / name) == expected, name
state = json.loads((base / 'retire/state.json').read_text())
assert state['phase'] == 'completed'
for name, expected in state['result']['artifact_sha256'].items():
    assert digest(base / 'retire' / name) == expected, name
for name in ['admission.json', 'continuation-admission.json']:
    ident = json.loads((base / name).read_text())['controller']
    actual = process_identity(ident['pid'])
    assert actual is None or actual['start_ticks'] != ident['start_ticks']
copy = base / 'retire/probe'
assert digest(copy) == state['identity']['binary_sha256']
for proc in pathlib.Path('/proc').iterdir():
    if proc.name.isdigit():
        try:
            assert (proc / 'exe').resolve(strict=True) != copy.resolve(), proc.name
        except (OSError, RuntimeError):
            pass
size = copy.stat().st_size
copy.unlink()
publish(base / 'controller-copy-retired.json', dict(removed=str(copy), bytes=size, free_bytes=shutil.disk_usage(base).free,
    binary_sha256=state['identity']['binary_sha256'], note='Completed reuse verified before removing copied binary; this controller is retired. Frozen source binary retained.'))
files = {}
for prefix, path in [('failed-witness-r1', storage / 'fallback-full-retire-r1'), ('full-r2', base),
                     ('frozen', repo / '.spike-work/retire-generation-r2')]:
    for p in path.rglob('*'):
        if p.is_file() and p.name != 'probe' and '__pycache__' not in p.parts:
            files[prefix + '/' + str(p.relative_to(path))] = p
source = json.loads((repo / '.spike-work/retire-generation-r2/source.json').read_text())
for name, expected in source['source_sha256'].items():
    assert digest(repo / name) == expected
    assert hashlib.sha256(subprocess.check_output(['git', 'show', 'd0aa672:' + name])).hexdigest() == expected
    files['candidate-source/' + name] = repo / name
for name in ['full-prune-witness.py', 'full-retire-r1.py', 'full-retire-r2.py', 'full-retire-r2-continue.py',
             'full-retire-r1.log', 'full-retire-r2.log', 'full-retire-r2-continue.log', 'archive-full-retire-r2.py',
             'retire-publication.json', 'retire-exact-head-gate-r1.log']:
    files['collector/' + name] = repo / '.git/akasha-evidence' / name
out = repo / 'docs/benchmarks/results/fallback-full-retirement'
out.mkdir()
hashes = {name: digest(p) for name, p in sorted(files.items())}
archive = out / 'raw.tar.gz'
with tarfile.open(archive, 'w:gz') as tf:
    for name, p in sorted(files.items()): tf.add(p, arcname=name, recursive=False)
with tarfile.open(archive, 'r:gz') as tf:
    assert set(tf.getnames()) == set(hashes)
    for m in tf.getmembers(): assert hashlib.sha256(tf.extractfile(m).read()).hexdigest() == hashes[m.name]
publish(out / 'files.json', hashes)
summary.update(source_head='d0aa672e17045f98360725ddb0035a01e19f2e9c', archive_files=len(files),
    archive_bytes=archive.stat().st_size, archive_sha256=digest(archive),
    allocation_note='inode st_blocks is not exclusive Btrfs allocation; filesystem free includes concurrent host activity',
    failed_controls=['r1 service cwd omitted; import failed before opening database',
        'r2 before native42witnesses passed; collector mistook string zero for integer; fixed collector reused same receipts'],
    completed_controller_reuse='verified before retiring disposable binary copy; no later controller reuse claimed')
publish(out / 'summary.json', summary)
print(json.dumps({k:summary[k] for k in ['archive_files','archive_bytes','archive_sha256','seconds','free_bytes_delta']}))
