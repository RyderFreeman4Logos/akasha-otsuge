# Independent conventional review: changed mempal snapshot lineage

BASE_SHA=235c409e8c79766cef84da193d7f6b8338157d58
HEAD_SHA=014e15d6cc1c3119d6b16ab08d79a4b028e41249
TREE_SHA=46ac6632cef510642c4653055aa2da6cf2446802
VERDICT=PASS
ACTIONABLE_COUNT=0

Reviewed checkout: `/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025`.
Review date: 2026-11-10. This is an independent, conventional, source-grounded review of the entire specified base..HEAD range. No actionable new defect was identified. This verdict is not issue #25 closure, publication approval, fresh canonical-suite execution, or changed-private-data acceptance.

## Scope and instruction custody

The range contains exactly 90 paths and two commits: `8cff5480f058bca4aaa3e8d6bbaae9a595a1ca75` archives PR61 acceptance; `014e15d6cc1c3119d6b16ab08d79a4b028e41249` implements snapshot deltas and their regressions/documentation. Review was not narrowed to the final helper. The 90 paths comprise 16 production/test paths, six substantive documentation paths, and 68 archived evidence paths (including their manifests/readmes).

The supplied scope JSON's path set equals `git diff --name-only BASE HEAD`; all 90 SHA-256 values match the live files. HEAD and tree match the requested pins before and after validation. Status is empty; both tracked and staged diffs are empty. Final hashes again match all 90 scoped files.

All 74 exact instruction paths in the supplied census were checked against the live filesystem with symlink-aware existence checks, not Git tree lookup. All are absent. Independently deriving repository/parent/touched-directory AGENTS.md and CLAUDE.md paths from the actual changed-file set found no missing census entry. The supplied home, `/mnt/ssd`, and `/ssd` ancestor aliases were also checked. There were no live instruction files to resolve/read, and no instruction or source-scope mismatch. The per-path census and hash results are retained in the tests log. No .env file or private configuration was inspected.

## Source review and behavior

| Reviewed paths/seam | Source assessment |
| --- | --- |
| `src/main.rs`, `src/storage/mod.rs`, `src/storage/mempal.rs` | Help, offline dispatch and public export agree on the optional trailing `--previous PRIOR_ARCHIVE`. The original two-argument route still calls mapping-v2 conversion. Optional lineage/delta/identity fields are omitted when absent; changing the mapping-commit field from a static string to String does not change serialized bytes. Existing v2 chunking, grouping and deterministic resume remain in place. |
| `src/storage/mempal/reader.rs:118` and `:347` | The delta entry checks actual ordered PK declarations against the frozen table mapping. Identity hashes the table plus typed key cells, checks column/value lengths, and rejects NULL keys. Composite order is explicit; equal content under different keys stays distinct. SQLite stays pinned/read-only/immutable, with sidecar checks and final inode/metadata/hash verification. |
| `src/storage/mempal/incremental.rs:105`, `:173`, `:230` | Prior history is imported through the existing neutral importer. The latest migration is selected from the final outbox; backward links must decrease in sequence, preserve the root and satisfy the generation hash. Reconstruction checks frozen columns, evidence immutability, block order/size, row counts, stream bytes/hashes, key derivation and stable origins. V2 rowid-based origins are retained; newly seen typed keys receive a distinct root/key origin. |
| `src/storage/mempal/incremental.rs:368` | The generation hashes previous archive identity plus current source fingerprint. An identical latest physical snapshot seeds and returns the old history without a new migration commit. Returning later to older snapshot bytes has a different previous-archive identity and therefore a new generation. Row-value fingerprints distinguish semantic changes from rowid-only movement. The table union includes earlier tables; the missing-row scan emits deletion markers, including when an optional table disappears. Required missing schema tables are refused by the reader rather than silently retained. |
| `src/storage/mempal/projection.rs`, `src/domain/mod.rs:354`, `:397` | Changed eligible parts reuse logical memory IDs and use the prior revision as their expectation. New source IDs and proposal request IDs are generation-specific. Earlier source records remain immutable. Candidate generation checks the prior memory is an unverified mempal candidate. Removed/retired/constrained/blank/trailing parts are omitted from the retained set and withdrawn; withdrawal copies the old record and changes lifecycle, preserving claim, provenance and source/event facts. It creates no approval, human rejection, replacement original timestamp or adoption pointer. |
| `src/domain/review.rs:171`, `src/domain/schema.rs`, `src/domain/history.rs` | Pending reviews associated with the superseded proposal become Withdrawn. Their proposal linkage is retained. Current-memory validation accepts that lifecycle only for unverified mempal candidates; history reports Withdrawn explicitly and adoption resolution excludes it. Review-open rejects a withdrawn current revision; review-update cannot create or reopen Withdrawn; decision preview still requires an eligible pending review and current proposal. Reappearance creates a fresh candidate/review on the original memory lineage. |
| `src/storage/mempal/writer.rs`, `src/storage/archive.rs:194` | The shared archive sink routine preserves prior receipt contents, original clocks, original revision pointers and blob order while reconstructing offsets. New receipts use `mempal/z/` plus fixed-width sequence, sorting after the v2 hexadecimal prefix and earlier v3 requests. New revision `previous` comes from expected_revision. Buffered groups rebuild sequence-dependent references after flush. Delta stream blocks/counts/hash are intentionally distinct from the table's full-snapshot rows/bytes/hash. Existing prefix comparison, completed-manifest comparison and durable publication are preserved. |
| `src/storage/mempal/incremental/index.rs:24`, `:83`, `:157`; incremental runner `:537` | One disposable native store contains imported history and the auxiliary batched key index. No SQLite source copy or additional formal backend is introduced. An empty interrupted scratch directory is initialized only when it contains no data beyond the admission lock. Existing scratch data requires matching owner identity and admitted, pinned cleanup. Conversion clears the projection Arc, closes the store and drops it before scratch removal; close failure returns before cleanup. The owned scoped thread is joined. |
| `src/storage/import.rs` and existing importer callers | The only change here exposes the existing regular-file helper within storage. The source importer still validates file hashes, receipt/request hashes, revision expectations, offsets and immutable evidence; destination admission still checks common history and rejects longer imports after local writes or divergent histories. This protection was not replaced by the delta converter. |
| `tests/support/mempal.rs`, `tests/support/mempal_incremental.rs` | The maintained tests enter through the public CLI. Assertions cover update and immutable history, original receipt preservation, repeat, empty scratch bootstrap, truncated-prefix recovery, neutral export/import equality, latest-snapshot no-op, three-generation lifecycle, rowid movement, deletion, shortening, scope, retirement, equal-text distinct identities, reappearance, history/review transitions and NULL-key refusal/source preservation. These are meaningful integration assertions, not only helper-level checks. |

Boundedness was reviewed from source: source SQL row length is limited to 16 MiB; blocks to 32 KiB; reconstructed pending row data is checked against 128 MiB; accumulated lineage metadata against 32 MiB; the index batches 128 entries in a bounded native configuration. Writer/importer also enforce their existing per-revision/group limits. These checks are not evidence of stress behavior or a measured peak-memory guarantee. Resume rereads prior history/source and compares prefixes; it is not constant-time.

Reviewed documentation: `docs/domain.md`, `docs/history.md`, `docs/mempal-migration.md`, `docs/neutral-archive.md`, `docs/plan/todo.md`, and `docs/review.md`. Their lifecycle, lineage, CLI, recovery and acceptance-stage descriptions agree with the source. The plan and archived README statements that later gates/application/review were pending describe their committed point in development; supplied later receipts are separate evidence. Neither the documentation nor this review upgrades historical acceptance into changed-private-record proof.

## Archived and supplied evidence integrity

Both archives passed every declared member byte-length and SHA-256 check: 22 members in `mvp025-incremental-final`, 44 in `mvp025-snapshot-delta`. Compressed members decompress successfully. All 12 terminal-receipt log hashes match the decompressed raw logs; their collected terminal objects agree exactly. The historical independent report and tests-log raw digests also match their verified receipt.

The historical manifest's 12 `historical_source_sha256` entries were checked against Git blobs at **e4f973de0c963f7cc26d577f735da04739fb682e**, not current changed files. Its tree and merged base tree both equal `82e8ef59eab12c8bf79c1798c9f567f1da6008cd`. The delta manifest's 16 `candidate_file_sha256` entries match this candidate's live production/test files. The supplied canonical receipt's four referenced artifacts also match their SHA-256 pins. These checks plus scope verification total 190 initial checks, with no failure; raw-log/collection checks were recorded separately.

The delta evidence preserves rather than erases the following outcomes:

- Public `--previous` unsupported-option RED, followed by one public update/replay GREEN.
- Deletion RED (candidate remained candidate).
- The nominal lifecycle-green run actually failed third-generation import with INVALID_ARCHIVE; its receipt keeps exit 101. The ordering repair is visible in current writer source.
- Focused R1: 19 test passes, one child ignore, then Clippy failure.
- Unchanged-snapshot RED: an unnecessary migration commit was appended.
- Focused R2: missing-await compile error in the test harness, **not product RED**.
- Focused R3: 33 passes, two child ignores, then successful Clippy/diff checks.
- Empty-index bootstrap RED with STORAGE_IO.
- Final focused R4: four delta tests plus Clippy/diff checks passed after bootstrap repair.

Dirty-development admission HEADs identify the development parent, not a claim those dirty sources were committed. Final candidate source pins and the later exact-HEAD receipt are distinct. Historical PR61 failures, the lost original R1 report/reconstruction distinction, and unknown incident/admission-holder causes remain historical facts; this range does not establish their missing causality or introduce them as new defects.

The supplied `mvp025-delta-canonical-r1-verified.json` binds this HEAD/tree to `just check`, exit 0, 21 result rows, 599 Rust passes and 35 ignores including installed repetition. The raw log's result rows agree. This review checked its artifact integrity and did not rerun that suite, install anything or invoke live services.

The supplied `mvp025-delta-real-r1-public.json` reports PASS on the **original unchanged snapshot**, source/input preservation, identical output/repeat, six completed units, zero SQLite copies and zero provider contacts. It names the same candidate HEAD/tree and binary digest as the canonical receipt. This is receipt-level assessment only: no private source/archive was opened. It does not prove changed private records, resource stress, quality or native authentication.

## Fresh validation and limits

Executed exactly once through clean non-login `/bin/bash`:

```text
cargo test --locked --offline --test archive mempal::incremental::
```

Result: **4 passed, 0 failed, 0 ignored, 24 filtered out; exit 0**. Test execution reported 1.73 seconds. Cargo/rustc resolved to 1.99.1. The inherited shared SSD `CARGO_TARGET_DIR`, sccache wrapper and Rust environment were retained unchanged. No extra tests, new probes, fixtures, second worktree or target directory were added. The foreground command was awaited to completion.

The fresh tests do not directly exercise every source-reviewed branch: composite-key changes, optional-table disappearance, newly unmapped constraints/blank claims, exact return to an older physical fingerprint, large row/header limits and close-error retention are source-level assessments here, not fresh measured acceptance. No concrete unresolved source defect justified an additional targeted test. No new adversarial/red-team/Daybreak campaign, delegates, provider probes, SSH, GitHub writes or private-data work occurred.

Final verification found no remaining `akasha-archive-*` fixture directories in the inherited temporary directory and no readable live matching target archive-test/CLI executables. Fixture Drop removes directories; subprocess output calls and the converter's scoped thread are joined. All work owned by this review has terminated. No tracked files, branch, hooks or Git history were edited; no explicit cache operations or environment rerouting were performed. The authorized Cargo invocation used existing shared build infrastructure.

Report: `/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/.git/akasha-evidence/mvp025-delta-review-r1.md`
Fresh log: `/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/.git/akasha-evidence/mvp025-delta-review-r1-tests.log`
TEST_LOG_SHA256=7f5fb301c43a21b05822370decfebc8b257b3745defc2d45eb306d0e311a059e

No actionable findings. Source-review PASS and the four fresh test passes are limited to the frozen range and stated conventional review scope. Full canonical reruns, changed-private-data acceptance, stress/quality/authentication and publication were intentionally not performed.
