import pathlib,subprocess,sys,unittest
repo=pathlib.Path('/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp011')
sys.path.insert(0,str(repo/'scripts'))
import test_reference
old={'__file__':str(repo/'scripts/check_reference.py'),'__name__':'baseline_reference'}
exec(subprocess.check_output(['git','show','7356d17f0a373ade3520e6e1a1249fc52e17ba8d:scripts/check_reference.py'],cwd=repo),old)
test_reference.validate_snapshot=old['validate_snapshot']
suite=unittest.TestSuite([test_reference.ReferenceTests('test_coordinated_reseal_does_not_change_fixed_reference')])
result=unittest.TextTestRunner(verbosity=2).run(suite)
sys.exit(not result.wasSuccessful())
