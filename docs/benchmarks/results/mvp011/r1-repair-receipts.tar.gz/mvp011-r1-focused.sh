#!/usr/bin/env bash
set -euo pipefail
cargo fmt --all -- --check
cargo test --locked --test adapter --test adapter_budget --test adapter_context --test adapter_runner
cargo clippy --locked --all-targets -- -D warnings
python3 scripts/check_reference.py
python3 -m unittest discover -s scripts -p test_reference.py -v
git diff --check
