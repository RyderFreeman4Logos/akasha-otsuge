VERDICT: FAIL
ACTIONABLE_COUNT: 2

Independent native source review of MVP-011; whole origin/main...HEAD range. This is the authorized native fallback after the earlier Hermes transport failure, not a Hermes/CSA result. Two regressions in this range remain actionable. The supplied exact-HEAD canonical gate passed; it does not exercise or resolve these findings.

## Immutable candidate and instruction census

- Lexical checkout: `/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp011`.
- Resolved checkout: `/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp011`.
- Branch: `feat/mvp-011-adapter-contracts`.
- HEAD: `617636a7fe015c33f681d9b8f363cceedfc598ff`.
- Tree: `5480802011d0ba679b7d628f6f9b29de94eef6b6`.
- Base origin/main and merge-base: `dc8e27cd4329dcbc41cdf37cf63a4eafcee548c2`.
- Range: 29 files, 4,443 insertions and 16 deletions. The range and path list match the supplied `mvp011-review-scope.json`.
- Preflight and postflight Git status are clean. Postflight at `2026-10-28T06:35:23.319668+00:00` rechecked all identities, the exact path list, and every one of the 29 working-file byte sequences against its HEAD blob. `git diff --check origin/main...HEAD` passed.
- `readlink target` is exactly `/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/target` before and after review. No shared-target writer was started.

Before source reads, I used actual filesystem existence checks, including symlink entries, for AGENTS.md and CLAUDE.md at lexical and resolved checkout ancestors and all nested changed-file directories: 88 initial exact paths, none found. A supplementary census covered home-path aliases, the original repository, and relevant existing Capture/Domain/Storage/spec directories: 106 checks, overlapping the initial set, none found. The consolidated postflight census covered 194 distinct paths across these lexical/resolved locations and nested directories, again finding none. These counts come from the filesystem, not Git's tracked-file list. There were therefore no discovered instruction files to follow through symlinks and read.

I applied `native-code-review/SKILL.md` and its scope/attribution, foundations/evidence, boundaries/verdict, acceptance/isolation, types-only service contract, frozen artifact/receipt, source-pinned corpus and walking-skeleton review routes. The installed route set has no separately named benchmark-reference-freeze route; the source-pinned corpus and receipt-integrity routes supplied the applicable freeze checks.

## Findings

### R1 — MODERATE — Earlier runner timeout is replaced by a later workflow timeout

Location: `src/adapter/runner.rs:385-387` (new code in this range).

`RunSpec::new` constructs an effective runner deadline capped by the original workflow deadline at lines 349-353. The existing `Deadline::start` retains the layer of the earlier deadline (`src/config/deadline.rs:115-118`), and `expired()` returns that layer (lines 132-133). However, `RunSpec::check()` first calls `self.lease.check()?`. That reaches the original budget deadline check in `src/adapter/budget.rs:127-139`, before inspecting the effective runner deadline.

Concrete reachable failure: create a workflow deadline ending at t+30 seconds and a RunSpec whose own runner deadline ends at t+20 seconds. If an event/I/O wait or task scheduling delay causes the next check to occur after t+30, `spec.deadline().expired()` correctly identifies Runner, but `spec.check()` returns `WorkflowTimeout` from the lease check. The later parent expiration overwrites the earlier cause. Before t+30 the same spec returns `RunnerTimeout`, so attribution depends on when the caller resumes polling.

This contradicts the explicit `RunSpec::check` contract in `docs/adapters.md:61-67` and the accurate triggering-layer requirement in `docs/spec/09.md:36`. Host adapters are required to use this public check at admission and event/I/O waits; the contract matrix also calls it. The defect is in the new wrapper's ordering, not the pre-existing Deadline implementation. It is not an allegation that a real host runner has already been implemented or tested.

Minimal fix: preserve shared cancellation and poisoned-state rejection, but choose a timeout result from the already-capped RunSpec deadline so a later parent expiration cannot override its recorded trigger. Add public-API controlled-clock cases checking an earlier runner deadline after both deadlines have expired, an earlier workflow deadline, and cancellation precedence. Existing Deadline tests and the green adapter matrix do not cover this RunSpec case.

Evidence classification: deterministic source trace, not an executed behavioral RED. I did not run or add tests under the review's no-build/no-test constraint.

### R2 — MODERATE — S04's frozen denial oracle requires a successful no-hit result after revoking its read authority

Location: `docs/evaluation/reference-v1/tasks.jsonl:20`, task `S04` (new reference artifact in this range). Related scoring/validation: `docs/evaluation/reference-v1/README.md:42-45,63-72`; `scripts/check_reference.py:50-52`.

S04 fixes the caller scope to project Atlas, then requires `revoke_read_grant` after the first source read and before output. Its critical oracle requires `status: no_hit`. The reference README explicitly requires a real grant-revocation commit and holds final publication until that commit; statuses must agree with the oracle, and critical tasks without required items still must satisfy their denial oracle. The validator currently admits only found/no_hit/incomplete oracle statuses.

That oracle conflicts with the supported publication/permission contract. `Domain::permission` returns `READ_DENIED` when the caller's grant is absent or no longer covers the requested scope (`src/domain/history.rs:190-205`). `Domain::prepare_recall` unconditionally checks that live permission for the draft scope before selecting or persisting output (`src/domain/recall.rs:320-331`), including an empty no-hit draft. The new CapturedContext likewise rechecks live authority. After revoking the Atlas grant, a correctly denied run cannot publish a successful Atlas RecallReceipt. `docs/spec/03.md:164-174` distinguishes error from no_hit, requires a receipt for final successful results, and says failure is not a successful empty result.

Consequently a correct typed `READ_DENIED` result fails this frozen critical oracle. Mapping the denial to no_hit instead misrepresents the permission failure and cannot meet the existing successful-publication contract for the original scope. This is separate from A04's memory rescope case: there the caller can retain its scope grant while an individual result is filtered out. The existing Domain permission behavior is not a regression; the newly frozen S04 acceptance target is the defect. No production consult/final RecallReceipt implementation is claimed for MVP-011—the issue is that MVP-011 must freeze a sound target for the later implementation.

Minimal fix: preserve the original reference-v1 directory, digest and all 60 cases. Add a separately named, pinned erratum/reference artifact that makes the whole-grant-revocation outcome an explicit permission error with no protected content and no successful-result receipt; update the applicable scoring contract to accept that outcome for this case. Retain the revocation barrier and the critical denial requirement. Do not reseal v1, remove S04, globally relax permission checks, or silently normalize the failure to no_hit. When the public consult harness exists, exercise the barrier against the real permission/publication path.

Evidence classification: source-and-oracle contradiction, not an executed model-quality failure. Structural validation and content hashes do not establish that this denial status is semantically implementable.

## Full range read and contract coverage

I read every changed text file completely, including all 60 JSONL tasks, both receipt manifests, all tests and the external-crate matrix support. Both binary archives were examined by read-only streaming; no archive was extracted. Full changed scope:

```
README.md
docs/adapters.md
docs/benchmarks/results/mvp011/README.md
docs/benchmarks/results/mvp011/focused-receipts.tar.gz
docs/benchmarks/results/mvp011/freeze-pin-manifest.json
docs/benchmarks/results/mvp011/freeze-pin-receipts.tar.gz
docs/benchmarks/results/mvp011/manifest.json
docs/evaluation/reference-v1/README.md
docs/evaluation/reference-v1/manifest.json
docs/evaluation/reference-v1/profile.json
docs/evaluation/reference-v1/tasks.jsonl
docs/plan/progress.md
docs/plan/todo.md
scripts/check.sh
scripts/check_reference.py
scripts/test_reference.py
src/adapter/binding.rs
src/adapter/budget.rs
src/adapter/code.rs
src/adapter/context.rs
src/adapter/mod.rs
src/adapter/runner.rs
src/config/schema.rs
src/lib.rs
tests/adapter.rs
tests/adapter_budget.rs
tests/adapter_context.rs
tests/adapter_runner.rs
tests/support/adapter_matrix.rs
```

I also read the canonical MVP-011 issue, specs 03 and 09, and relevant existing Capture lineage/text verification, Storage serialized-read/commit behavior, Domain live-grant and RecallReceipt publication consumers, and deadline implementation/tests. This grounded the findings in real caller and storage behavior rather than only public type declarations.

The reviewed contracts and test witnesses cover:

- Runtime binding as an authenticated server assertion; immutable invocation reuse/conflict and restart loading; concurrent same-cwd callers; actual exact versus session binding separated from advertised capability.
- Real Storage/CapturedContext external-crate fixtures; original caller identity independent of selected runner; all 16 Caller x Runner roles; fixed caller fence, nested ancestor/grandchild cutoffs, sibling exclusion, forged-handle refusal and current grants.
- Pinned workspace directory identity, live read roots, openat2 beneath/no-magic-links, regular-file checks, bounded reads/searches, actual source hashes and metadata-change reporting.
- Bounded request/sequence/version JSONL framing, capability handshake and poisoned failure/EOF behavior; externally constructible typed source failures, without claiming all such failures are backed by a real host adapter.
- Shared starts/depth/read/output accounting, nonwaiting delegate admission, no counter reset through delegation, retained permit ownership, cancellation signaling, and the distinction between a typed terminal answer and process exit. R1 is the uncovered deadline-layer edge case.
- ToolPolicy as a pre-dispatch allowlist requirement. Post-execution Tool events are not accepted as enforcement, and same-UID arbitrary shell access remains an explicitly documented threat-model limitation.

The deferred work is correctly identified: real CLI Caller/Runner adapters belong to MVP-012 through MVP-015; production consult and final RecallReceipt integration belong to MVP-016; real cross-host interoperability, model quality/cost and long-run acceptance remain unexecuted. The supplied fixture results do not establish these deferred outcomes. I did not treat those stated boundaries as additional findings.

## Original gate and receipt attestation

I read the original admission, terminal, collected, verified and full log files under `/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/.git/akasha-evidence/`, and independently recomputed their sizes/hashes. This is verification of supplied evidence, not a fresh gate execution by the reviewer.

- Command: `bash scripts/check.sh`.
- Admission: `2026-10-28T06:10:43.060347+00:00`, PID 856734, start ticks 498574006, bound to the frozen HEAD.
- Terminal: exit 0, 114.15864764153957 seconds, `2026-10-28T06:12:37.215978+00:00`.
- Collection: `2026-10-28T06:13:07.906580+00:00`, identical terminal record, `process_absent: true`, classification passed.
- Verified receipt binds the exact HEAD/tree/base/branch and clean status listed above.

| Original artifact | Bytes | SHA-256 |
| --- | ---: | --- |
| mvp011-gate1.log | 24454 | d2379810dea01a0a372e21870b7381913b155fed10c9beaa0499fbb6cbb6b561 |
| mvp011-gate1.admission.json | 245 | 6ecf20806e12ae581d3da81ae804c3b8005997debe15e630422bab1e94de07b0 |
| mvp011-gate1.terminal.json | 237 | 45a26fc880d2bb165a4fc9d6ea5fc656cf92c060069cc50a9882618e3f883825 |
| mvp011-gate1.collected.json | 367 | 977812c408a64eb4696de99bfdd1d11c71fc39f352080c7266c86620fc5a2052 |
| mvp011-gate1-verified.json | 476 | 9b70c3f6673a996fe8b34aac12f8d66feb383937131dad8c733905f88e50a9d6 |

The log records 145 ordinary Rust tests (126 existing plus 19 adapter tests), 15 Python tests (8 existing plus 7 reference tests), and 36 separate installed-release daemon cases. The installed-release evidence identifies SHA-256 `f3a59bf368d4aacc02592c8cc37ac4c00561e324d35cc326d4ff96cb7e09e50f`, accessible control plus private/peer denial under actual UID 165536, and zero owned TCP sockets. I did not substitute these receipts for a current live-runtime/binary check, or combine separate daemon cases into the ordinary Rust test count. The ordinary ignored child harness/live-provider cases are not claimed as executed ordinary tests.

The two committed receipt archives contain 105 regular members totaling 125,871 uncompressed bytes. Streaming checks rejected traversal/absolute paths, duplicate names and nonregular members; every listed size and SHA-256 matched its manifest and original evidence file. JSON receipts parsed, terminal log hashes matched their complete log bytes, and collection records matched terminal records. Archive identities:

| Archive | Compressed bytes | Members | Uncompressed bytes | SHA-256 |
| --- | ---: | ---: | ---: | --- |
| focused-receipts.tar.gz | 16349 | 96 | 113841 | a000c1a5709fc6e79b609425c56da5f8267a83faa36786ac3057882f18da7f71 |
| freeze-pin-receipts.tar.gz | 3085 | 9 | 12030 | 5801bff0958a22406790249e27cc46ac6400098be22cbd206624c74499d28b48 |

Original setup failures remain present and labeled; unresolved imports, generic-bound/type errors, malformed fixture syntax and the missing initial reference manifest are not behavioral RED witnesses. Dirty development green receipts are not transferred to the final HEAD. The independent exact-HEAD gate above supplies the final gate evidence. The archived original-guard control demonstrates that the pre-fix verifier admitted coordinated resealing; the final seven-test reference suite supplies the fixed-guard evidence.

## Frozen reference integrity and limits

First freeze commit: `7356d17f0a373ade3520e6e1a1249fc52e17ba8d`.
Independent original manifest SHA-256: `6b6dffd7882dc703e393686d327f8aaae6becad1f5566e761b8cae8f4fad6ac7`.

All four current reference-v1 files are byte-identical to that freeze commit, including README and profile. The gate pins the independent original manifest digest before trusting artifact hashes; coordinated artifact-plus-manifest resealing or a version-bumped wipe cannot pass by updating the manifest alone. Its documented errata mechanism requires a new set.

I independently checked the 60 unique tasks, 31 critical tasks, 10 paired intents, source hashes, and the 56 required items (20 critical and 36 noncritical). Required claims/conditions are present in their named sources; authority labels, withdrawn/history distinctions, sibling/ancestor cases and hint-pair sameness were reviewed against the task data. The status conflict in S04 is R2; structural consistency and a frozen hash do not cure it. The reference profile and scoring rules are explicit, and model-quality, latency, token/cost and real-run outcomes are clearly unexecuted.

## Review limits and resource custody

No Cargo/just/build/test suite or gate was run by this reviewer; no model, provider, authentication, network call, real-host session or child transcript was inspected. Read-only Git/Python/source probes were used to check identities, bytes, archives and source reachability. No source, fixture, configuration, Git index, branch, worktree or shared target was modified. All short read-only command subprocesses completed; none was left running. No daemon, timer, sub-agent, scratch worktree or installed binary was created. The sole reviewer-written artifact is this report at the authorized evidence path. Final report hashing is performed externally after the postflight checks; the report does not embed its own digest.

VERDICT: FAIL
