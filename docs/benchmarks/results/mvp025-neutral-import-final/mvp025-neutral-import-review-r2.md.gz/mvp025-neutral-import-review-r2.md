VERDICT: PASS

No actionable introduced defect was found in the complete frozen offline-import leaf. R1 finding F1 is repaired. This verdict covers validated **offline import and storage-history restoration**, and does not approve issue #25 completion.

**Scope and frozen identity**

Repository: `/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025`

- Base, `origin/main` and merge base: `3b6bf74d57b275e154195571700d64406832c2d3`
- HEAD: `49aba7fd174a4a97cba6d958f62ed8b8cf5fb910`
- Tree: `3dfe4967065ea8fa236dd5d777b08995af64e24b`
- Branch: `feat/mvp-025-neutral-import`
- Reviewed range: complete `origin/main...HEAD`, all **96 changed files** across `415f50c` (export-closure archive), `a61acd9` (offline import) and `49aba7f` (publication-sync repair).

Source and Git state remained read-only. No edits, commits, worktrees, agents, publication, provider calls, broad gates, configuration changes or environment overrides were performed. Parent-owned WD was untouched. Native-child transcripts were not inspected. The report path was not written.

**Filesystem instructions**

Before source reads, actual filesystem checks established that logical and resolved repository paths agree. Both `AGENTS.md` and `CLAUDE.md` were absent at every ancestor:

`/`, `/mnt`, `/mnt/ssd`, `/mnt/ssd/mirror-rootfs`, its `home`, `home/obj`, `home/obj/project`, `home/obj/project/github`, `home/obj/project/github/RyderFreeman4Logos`, and the repository root.

A symlink-following filesystem scan, subsequently checked against changed-file parents, verified both names absent in applicable directories: `src`, `src/storage`, `tests`, `tests/support`, `docs`, `docs/plan`, `docs/benchmarks`, `docs/benchmarks/results`, and all three changed evidence-archive directories. These are filesystem absences, not Git-only checks or zero-line files. Local pinned-native source ancestors and applicable `src` instructions were also checked and absent.

**Findings and source audit**

There are **zero blocking introduced findings**. The following conclusions come from source tracing and evidence inspection as well as passing tests:

- **CLI:** `src/main.rs:685` routes the exact archive command through resolved configuration and profile selection, rejects `--socket`, preserves existing non-UTF-8 argument refusal, prints the manifest through fallible stdout handling, and propagates storage errors through structured stderr/nonzero exit handling.
- **Input validation:** `src/storage/import.rs:31` opens input files with `NOFOLLOW|NONBLOCK` and verifies regular-file type. Import checks canonical source/data overlap, bounds the manifest to 64 KiB and JSONL lines to 1 MiB including LF, enforces supported versions and exact manifest data-file names, and rejects unknown structured fields. Blobs are bounded individually and per batch; offsets, UTF-8, content hashes, complete file lengths/hashes, trailing data and request hashes are checked.
- **Identity and history:** receipt references must equal the normalized request’s references. Request IDs are strictly ordered; duplicate sequence ownership is refused through staged outbox identity, and chronological reconstruction requires every sequence. Predecessors must match each key’s actual preceding head. Evidence cannot acquire a predecessor. Original content, Unicode/NUL bytes, receipts, clocks and commit numbers are retained without manufacturing provenance or approval.
- **Native semantics:** the local SurrealKV checkout and inspected `transaction.rs`, `lsm.rs` and `lockfile.rs` bytes match pin `4338a790c8edc56ef5ea1e46157427af4815be3c`. Explicit `set_at` timestamps and inclusive historical `get_at` semantics support request-key staging followed by chronological `head = seq+1` reconstruction. This agrees with `Storage::at(..., at+1)`.
- **Transactions and replay:** staged revisions, receipt, outbox and clock are written atomically with immediate durability. Resume verifies saved identities before continuing. Completed replay validates original records without rebuilding heads or replacing later local writes. The focused roundtrip checks historical points 0–3, a later sequence-4 write, reopening and identical replay.
- **Ownership and publication:** the importer validates its exclusive lock’s type, UID, link count and `0600` mode. Native locking separately excludes concurrent database owners. Resumed stages require current-UID `0700` and an exact manifest-bound identity. Unknown or incomplete ownership markers are refused. Invalid-archive cleanup is confined to a recognized unpublished stage after successful native close; other failures retain it. Publication closes native storage, checks format metadata, syncs the stage and uses `RENAME_NOREPLACE`.
- **Failure handling:** validation, native-close, cleanup, publication, parent-sync and stdout failures remain nonzero results. Cancellation cannot produce an import success response; inspected native transaction/drop behavior and resumable staging support interruption recovery. Direct cancellation of the import future itself was not separately injected.
- **Runtime isolation:** `src/daemon.rs:656` refuses imported storage before configuration, grants, jobs or notification recovery. Provider-client/listener construction precedes refusal, but dispatch and scheduling are not entered. Two focused startup attempts return `IMPORTED_RUNTIME_DISABLED`, remove the owned socket and preserve application sequence.
- **Compatibility:** stricter `CommitReceipt`/`RevisionRef` deserialization was traced through receipt lookup, idempotency, export/outbox, capture, domain records, configuration/model-result archives and retrieval consumers. Supported in-tree producers serialize the existing field sets. No introduced supported-format compatibility break was identified; imported record content remains opaque original bytes.

**R1 repair**

At `src/storage/import.rs:266`, parent-directory sync is now unconditional after successful validation/native close and optional publication. Identical completed replay therefore retries the durability step that R1 found missing.

The public CLI regression constructs a real completed owned stage and sets its parent to `0300`: rename remains possible while opening the parent for fsync fails. Both attempts now return `STORAGE_IO` with empty stdout. Restoring `0700` permits successful replay with the original sequence and receipt. Permission restoration is scoped for cleanup. The archived pre-repair test failed at **attempt 1**, establishing the causal contrast without a timing race.

The unchanged historical [R1 FAIL report](https://github.com/RyderFreeman4Logos/akasha-otsuge/pull/58#issuecomment-6760298646) retains actual final SHA-256:

`e1ee890b289fec8c2e1589f58d2877602cdf4f8f8a0ef94418349b6fff964b1c`

That digest matches its retained runtime/publication receipts. Embedded `588a8414…` identifies earlier bytes and remains explicitly documented as a discrepancy; it was not substituted or rewritten.

**Fresh focused commands**

Each command ran **once**, sequentially, without retry:

| Command | Result | Exit | Elapsed |
|---|---|---:|---:|
| `cargo test --locked --test archive --test cli --test storage` | 9 archive + 5 CLI + 17 storage passed | 0 | 1.197452s |
| `cargo test --locked --lib storage::crash_tests::killed_archive_import_resumes_staging_heads_and_publication_without_duplicates -- --exact --nocapture` | 1 passed; all four SIGKILL phases | 0 | 0.767525s |

The four phases were `import-staged`, `import-head`, `import-before-publish` and `import-published`; each reported signal 9, recovered sequence 3 and zero duplicate commits.

Complete combined output and numeric statuses are retained in [the focused log](/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/.git/akasha-evidence/mvp025-neutral-import-review-r2-tests.log): **6,103 bytes**, SHA-256 `9902df25fd707a8b7379e0e6f7bf9b2d7b2ebd1a67ac7bf934b13a39021636d8`.

Cargo reported version `1.99.1`. Inherited Rust toolchain, target directory, `RUSTC_WRAPPER`, SSD `TMPDIR` and sccache socket settings were preserved. Mise’s denied cache-write warnings remain in the log; both commands exited zero. No review test process or archive/import-crash fixture remained.

**Canonical R2 evidence — verified, not rerun**

The canonical recipe is `just check` → `bash scripts/check.sh`: plan/reference checks, Python and Node tests, formatting, locked all-target Clippy, locked workspace tests/release build, capture/installed-daemon checks, help/version and diff checks.

The supplied receipt matches the frozen base/HEAD/tree and clean admission. It records exit **0** in **441.409719s**. Recounting the retained log yields **21 Rust result rows, 551 passes, zero failures and 32 ignored**, including installed repeats; each daemon run has 157 passes and 7 ignored. The log also records 34 Python tests and passed installed lifecycle/private-UID/peer-UID checks with zero TCP sockets.

Verified receipt SHA-256: `eef34766956f080074e460e6b515a498e055e8d1a359b1ac855cd74e69ef8a57`.

All referenced artifact hashes match:

| Artifact | SHA-256 |
|---|---|
| Admission | `08aa70612a5c3b34bd74516269967aa9a221671bd979875009c8b1d724da95a6` |
| Terminal | `5086bab4fa81dfd4738988aa6d9e283063d4aaf439249de3909e1c9e24845194` |
| Collected | `440a093ccd0afa242b905156bb7aaef0de9cdb2624057221ad11b72fc598b233` |
| Complete log | `0cc6a747b72cb59cbc30ffd808073e3ebcfd0ed3a9fad23a3ad1446439ef25fd` |

This is exact-candidate retained canonical evidence, separate from fresh focused testing and successor hosted CI.

**Archive custody**

Exact member sets, every member’s length/hash, gzip integrity and source bindings verified:

| Archive | Manifest SHA-256 | Members / bytes | Source binding |
|---|---|---:|---|
| Neutral import | `e2af219cc0434e2ec8e4597f33f47519e33b284e4cfc24000241c4bb8a7308ce` | 46 / 73,868 | 10 hashes via `git show a61acd9:PATH` |
| Export final | `946f2cde9bf36ac18a725861659cda39f271f7c3580e8174db5d3d36ae0d3474` | 15 / 70,708 | 7 hashes via `git show 7ad2aab:PATH` |
| R1 repair | `2b36ef3f653546e34059f0b0fdfef15f871a9c10f1a1685fb4697bd7abba1538` | 22 / 72,607 | 3 current source hashes |

Archived raw-log hashes match terminal receipts; collected terminal objects match standalone terminals. Historical results remain distinct:

- Missing-command RED: exit 101 after compilation.
- GREEN R1: compilation failure, exit 101—not behavioral RED.
- R2: six archive tests passed.
- Cleanup/daemon RED: exit 101; R3 subsequently passed seven archive tests.
- R4: focused tests and Clippy passed.
- Unowned-stage RED: exit 101; R5 subsequently passed.
- Permissions RED: exit 101; final R6 passed **31 tests plus Clippy in 49.658s**.
- F1 RED: exit 101 at attempt 1; repair GREEN passed **32 tests plus Clippy in 108.782s**.

The foreign-stage fixture explicitly uses `0700` and asserts `IMPORT_CONFLICT`, so permission refusal cannot mask missing identity.

PR #57’s export closure does not close #25. Historical main CI **42760179799** belongs to `3b6bf74`; retained import R1 canonical/CI success belongs to `a61acd9`. Neither is promoted to repair validation. The runtime explorer’s report hash and five Git blobs verify at frozen `415f50c`; it remains a recommendation, not implemented runtime initialization or real migration proof. Foreign mempal discovery was not repeated.

**Preexisting observations and final attestation**

Native open/recovery’s physical-file effects and existing CLI/configuration policies predate this leaf. No separate preexisting actionable defect is asserted. Historical FAILs, unknown provenance/approval facts and outstanding acceptance gaps retain their original classifications.

Final HEAD remains `49aba7fd174a4a97cba6d958f62ed8b8cf5fb910`; tree remains `3dfe4967065ea8fa236dd5d777b08995af64e24b`; `origin/main` and merge base remain `3b6bf74d57b275e154195571700d64406832c2d3`. Tracked/untracked status is clean, all 96 changed files equal frozen HEAD, and the range diff check passes.

Skipped: canonical rerun, successor CI/live acceptance, additional fault injection and future runtime/mempal/incremental leaves.
Risk: SIGKILL is not power-loss or ENOSPC proof; archive hashes establish integrity, not source authentication. Issue #25 remains open.

VERDICT: PASS