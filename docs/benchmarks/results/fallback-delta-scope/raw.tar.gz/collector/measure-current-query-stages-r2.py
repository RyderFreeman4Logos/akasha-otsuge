import fcntl,json,os,pathlib,statistics,struct,sys,time
repo=pathlib.Path('/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge')
sys.path.insert(0,str(repo/'spikes/fallback'))
from check_real_search import run_native
from run_case import digest,process_identity,publish
storage=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023')
database=storage/'fallback-full-compressed-r1/database';output=storage/'fallback-full-query-stage-r2/queries'
binary=repo/'.spike-work/query-stage-r2/probe';fixture=pathlib.Path('/tmp/akasha-otsuge-storage-20261022/mixed-query-population-full-v1/queries.json')
identity=dict(binary_sha256=digest(binary),fixture_sha256=digest(fixture),script_sha256=digest(__file__),database=str(database),generation=2)
lock=(database/'.akasha-case-owner.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
for name in ['.akasha-case-owner.json','.akasha-generation-owner.json']:
 owner=json.loads((database/name).read_text());assert json.loads((pathlib.Path(owner['output'])/'state.json').read_text())['phase']=='completed'
assert (database/'OWNER').read_text()=='akasha-otsuge MVP-003 fallback database\n'
output.mkdir();(output/'OWNER').write_text('akasha-otsuge read-only current query stage diagnostic\n')
publish(output/'admission.json',dict(identity=identity,controller=process_identity(os.getpid()),cache='existing warm state, no cold-preparation claim'))
records=[];stages=[];started=time.monotonic()
def call(label,request):
 p=output/(label+'.json');publish(p,request)
 stdout,stderr=run_native([str(binary),str(database),'--generation',str(p)],output,records)
 assert records[-1]['exit']==0 and not records[-1]['timed_out'],(label,stderr[-2000:])
 for line in stderr.decode().splitlines():
  if line.startswith('QUERY_STAGE:'):stages.append(dict(label=label,**json.loads(line.removeprefix('QUERY_STAGE:'))))
 return json.loads(stdout)
base=call('status',dict(op='status',generation=2));initial=call('before',dict(op='lifecycle_status',generation=2));assert initial['active']==2
population=json.loads(fixture.read_text());sidecar=fixture.parent/population['vector_file']['name'];assert digest(sidecar)==population['vector_file']['sha256']
queries={}
for q in population['queries']:
 if q.get('vector_offset') is not None:queries.setdefault(q['partition'],q)
assert len(queries)==8
prior=json.loads((storage/'fallback-full-sustained-r2/low/request.json').read_text());principal=prior['run_id'];completed=0
with sidecar.open('rb') as vectors:
 for repeat in range(2):
  for scope in range(8):
   q=queries[f'p{scope}'];vectors.seek(q['vector_offset']);vector=list(struct.unpack('<1536f',vectors.read(6144)))
   for mode,clause in [('bm25',dict(term=q['term'])),('ann',dict(vector=vector))]:
    request=dict(op='query_current',generation=2,bundle=base['bundle'],principal=principal,scope=scope,**clause)
    result=call(f'r{repeat}-p{scope}-{mode}',request)
    assert result['hits'] and all(h['partition']==f'p{scope}' for h in result['hits'])
    completed+=1;elapsed=time.monotonic()-started
    publish(output/'progress.json',dict(completed=completed,total=32,elapsed_s=elapsed,rate_per_s=completed/elapsed,eta_s=(32-completed)*elapsed/completed,controller=process_identity(os.getpid())))
final=call('after',dict(op='lifecycle_status',generation=2));assert final==initial
for rec in records:
 now=process_identity(rec['child']['pid']);assert now is None or now['start_ticks']!=rec['child']['start_ticks']
publish(output/'stages.json',stages)
assert len(stages)==64
summary=[]
for table in sorted({r['table'] for r in stages}):
 rows=[r for r in stages if r['table']==table]
 summary.append(dict(table=table,samples=len(rows),**{key:statistics.mean(r[key] for r in rows) for key in ['connect_s','open_s','execute_s','stream_s','drop_s','total_s']}))
result=dict(status='passed_diagnostic',summary=summary,queries=32,seconds=time.monotonic()-started,committed=final['committed'],native_commands=len(records),artifact_sha256={p.name:digest(p) for p in output.iterdir() if p.is_file()})
publish(output/'state.json',dict(phase='completed',identity=identity,result=result));print(json.dumps({k:v for k,v in result.items() if k!='artifact_sha256'}))
