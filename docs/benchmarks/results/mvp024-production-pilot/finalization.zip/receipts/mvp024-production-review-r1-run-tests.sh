#!/bin/bash
set -u
set -o noclobber
exec > /home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/.git/akasha-evidence/mvp024-production-review-r1-tests.log 2>&1
run() {
  printf '\nCOMMAND:'; printf ' %q' "$@"; printf '\n'
  "$@"
  result=$?
  printf '\nEXIT: %s\n' "$result"
}
run cargo test --locked --offline --lib retrieval::tests
run cargo test --locked --offline --test daemon retrieval_tests::
run cargo test --locked --offline --example corpus_seed
run cargo clippy --workspace --all-targets --locked --offline -- -D warnings
run python3 -m unittest discover -s scripts -p test_daemon_command.py -v
