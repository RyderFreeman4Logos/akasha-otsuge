import datetime,hashlib,json,pathlib,subprocess,time
E=pathlib.Path(__file__).parent
W=pathlib.Path('/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025')
git=lambda *a:subprocess.check_output(['git',*a],cwd=W,text=True).strip()
gate=json.loads((E/'mvp024-production-canonical-r2-verified.json').read_text())
scope=json.loads((E/'mvp024-production-review-r2-scope.json').read_text())
assert gate['head']==git('rev-parse','HEAD')==scope['head'] and gate['tree']==git('rev-parse','HEAD^{tree}')==scope['tree']
assert gate['clean_before_after'] and not git('status','--porcelain')
assert git('rev-parse','origin/main')==scope['base']
for name,sha in scope['source_sha256'].items():assert hashlib.sha256((W/name).read_bytes()).hexdigest()==sha
pin=json.loads((E/'mvp020-review-runtime-r2.json').read_text())
for key in ['binary','companion']:assert hashlib.sha256(pathlib.Path(pin[key]).read_bytes()).hexdigest()==pin[key+'_sha256']
stem='mvp024-production-review-r1'
report=E/(stem+'.md')
assert not report.exists() and not (E/(stem+'.final.txt')).exists()
cmd=[pin['binary'],'exec','--sandbox','workspace-write','--add-dir',str(E.resolve()),'--add-dir','/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/target','--add-dir','/mnt/ssd/mirror-rootfs/home/obj/tmp/a15-cache-s0s9a8n9','--ephemeral','--json','--color','never','--cd',str(W),'--output-last-message',str(E/(stem+'.final.txt')),'-']
start=time.monotonic()
with (W/'.review/mvp024-production-r1-brief.md').open('rb') as brief,(E/(stem+'.stdout')).open('xb') as out,(E/(stem+'.stderr')).open('xb') as err:
 child=subprocess.Popen(cmd,stdin=brief,stdout=out,stderr=err,start_new_session=True)
 rc=child.wait()
events=[]
for line in (E/(stem+'.stdout')).open():
 try:v=json.loads(line)
 except ValueError:continue
 if v.get('type') in ['thread.started','turn.completed','turn.failed','error']:events.append(v)
receipt={'exit_code':rc,'seconds':time.monotonic()-start,'events':events,'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'clean_after':not git('status','--porcelain'),'report_exists':report.exists(),'report_sha256':hashlib.sha256(report.read_bytes()).hexdigest() if report.exists() else None,'transport':'independent Codex exec; configured Hermes endpoint previously unavailable','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runtime':pin}
for key in ['binary','companion']:assert hashlib.sha256(pathlib.Path(pin[key]).read_bytes()).hexdigest()==pin[key+'_sha256']
with (E/(stem+'.exit.json')).open('x') as f:json.dump(receipt,f,indent=2)
print(json.dumps(receipt),flush=True)
raise SystemExit(rc)
