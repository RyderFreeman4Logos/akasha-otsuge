"""Package the published predecessor's final receipts outside the frozen checkout."""
import hashlib
import json
import pathlib
import subprocess
import zipfile

e = pathlib.Path(__file__).parent
members = {}
for path in sorted(e.glob('mvp024-production-*')):
    if path.is_file() and any(part in path.name for part in (
        'canonical-r2', 'review-', 'ci-', 'merge-r1', 'publication-final', 'push-r1',
    )):
        assert path.suffix not in ['.stdout', '.stderr']
        members['receipts/' + path.name] = path.read_bytes()
members['receipts/' + pathlib.Path(__file__).name] = pathlib.Path(__file__).read_bytes()
pin = 'e5746acbaffbd6189fca51f9248249fb6d1f6585'
for name in ['Cargo.toml', 'examples/corpus_seed.rs', 'src/retrieval.rs', 'src/retrieval/vector.rs',
             'src/retrieval/tests.rs', 'tests/support/daemon_retrieval.rs', 'src/retrieval/batch.rs',
             'scripts/check_daemon_command.py', 'scripts/test_daemon_command.py']:
    members[f'source/{pin}/{name}'] = subprocess.check_output(['git', 'show', f'{pin}:{name}'])
notes = {
    'scope': 'PR67 final canonical, independent conventional review, public readbacks, hosted CI and merge; small corpus pilot only.',
    'head': pin,
    'merge': 'b71b18d9b959c4b2214405da812570ff1d39d772',
    'tree': '01fd393b623cec1cceb7ed4e62bcd8fbd3f6fa46',
    'gate': '633 Rust executions / 39 ignores, Python35, Node7, installed lifecycle/UID/TCP checks; canonical and hosted receipts remain distinct.',
    'review': 'First wrapper invocation had a Python syntax error before provider dispatch; the corrected second launch completed the one independent review. PASS / zero actionable findings / 37 fresh tests. Parent citation addendum preserves corrections without rewriting the original report.',
    'ci': 'Actual synthetic merge checkout 550a67c and final merge b71b18d have exactly the reviewed tree. CI missed the new Cargo-manifest cache key, then saved it after success.',
    'transport_cleanup': 'Raw native reviewer stdout/stderr were removed only after exit, exact report publication/readback and hash retention; report, tests, usage metadata and all failure receipts remain.',
    'limits': 'Original failed census observation remains unclassified. Issue65 stays open; no full scale, ANN, recovery, memory-improvement or Daybreak claim. Follow-up pruning and Mempal lock leaves are separate.',
}
members['scope-and-custody.json'] = (json.dumps(notes, indent=2) + '\n').encode()
target = e / 'mvp024-production-final-evidence.zip'
with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(members.items()):
        info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
manifest = {'schema_version': 1, 'reviewed_head': pin, 'merge': notes['merge'],
            'zip_sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'zip_bytes': target.stat().st_size,
            'members': {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in sorted(members.items())}}
(e / 'mvp024-production-final-evidence-manifest.json').open('x').write(json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None and sorted(archive.namelist()) == sorted(members)
    for name, item in manifest['members'].items():
        data = archive.read(name)
        assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
print(json.dumps({'files': len(members), 'zip_bytes': manifest['zip_bytes'], 'zip_sha256': manifest['zip_sha256']}))
