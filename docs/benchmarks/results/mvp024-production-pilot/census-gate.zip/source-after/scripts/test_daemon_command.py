import json
import os
import pathlib
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

from check_daemon_command import command, identity, owned_daemons


class CommandOwnership(unittest.TestCase):
    def test_owned_census_identity_survives_normal_scheduling_changes(self):
        with tempfile.TemporaryDirectory(prefix='akasha-command-census-') as root:
            proc = pathlib.Path(root) / '123'
            proc.mkdir()
            base = [sys.executable, '--config', str(pathlib.Path(root) / 'config')]
            (proc / 'cmdline').write_bytes(
                b'\0'.join(os.fsencode(arg) for arg in [*base, 'daemon', 'run']) + b'\0')
            (proc / 'exe').symlink_to(sys.executable)
            with patch('check_daemon_command.pathlib.Path.iterdir', return_value=[proc]), \
                    patch('check_daemon_command.identity', side_effect=[
                        (111, 'S'), (111, 'R'), (112, 'S'), (111, 'Z'), None]):
                original = owned_daemons(base)
                self.assertEqual(len(original), 1)
                self.assertEqual(owned_daemons(base), original)
                self.assertNotEqual(owned_daemons(base), original)
                self.assertEqual(owned_daemons(base), [])
                self.assertEqual(owned_daemons(base), [])

    def test_proc_identity_disappearance_is_terminal_but_access_failure_is_not(self):
        for error in (FileNotFoundError(), ProcessLookupError()):
            with patch('check_daemon_command.pathlib.Path.read_text', side_effect=error):
                self.assertIsNone(identity(123))
        with patch('check_daemon_command.pathlib.Path.read_text', side_effect=PermissionError()):
            with self.assertRaises(PermissionError):
                identity(123)

    def test_timeout_collects_the_owned_subprocess_group(self):
        with tempfile.TemporaryDirectory(prefix='akasha-command-timeout-') as root:
            witness = pathlib.Path(root) / 'child.json'
            script = '''
import json,pathlib,subprocess,sys,time
p=subprocess.Popen([sys.executable,'-c','import time; time.sleep(60)'])
fields=pathlib.Path(f'/proc/{p.pid}/stat').read_text().rsplit(')',1)[1].split()
pathlib.Path(sys.argv[1]).write_text(json.dumps([p.pid,int(fields[19])]))
time.sleep(60)
'''
            try:
                with self.assertRaises(subprocess.TimeoutExpired):
                    command([sys.executable, '-c', script, str(witness)], timeout=2)
                pid, start = json.loads(witness.read_text())
                end = time.monotonic() + 2
                while (current := identity(pid)) and current[0] == start and current[1] != 'Z':
                    if time.monotonic() >= end:
                        self.fail('timed command left its child running')
                    time.sleep(0.01)
            finally:
                if witness.exists():
                    pid, start = json.loads(witness.read_text())
                    if (current := identity(pid)) and current[0] == start and current[1] != 'Z':
                        os.kill(pid, signal.SIGKILL)
                        end = time.monotonic() + 2
                        while (current := identity(pid)) and current[0] == start and current[1] != 'Z':
                            assert time.monotonic() < end
                            time.sleep(0.01)


if __name__ == '__main__':
    unittest.main()
