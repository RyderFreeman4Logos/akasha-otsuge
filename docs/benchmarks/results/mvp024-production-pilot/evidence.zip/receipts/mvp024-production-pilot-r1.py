"""One bounded real-corpus pilot; preserves failures and refuses implicit replay."""
import datetime
import hashlib
import json
import os
import pathlib
import re
import select
import signal
import subprocess
import sys
import tempfile
import time
import tomllib

import pyarrow.parquet as pq

W = pathlib.Path.cwd()
E = pathlib.Path(__file__).parent
sys.path.insert(0, str(W / 'spikes/helix'))
from run_case import publish, process_identity, digest
sys.path.insert(0, str(W / 'spikes/data'))
from download import verify
from prepare_corpus import chunks

root = (W / '.spike-work/mvp024-production-pilot-r1').resolve()
root.mkdir(mode=0o700)
socket_root = pathlib.Path(tempfile.mkdtemp(prefix='a24p-', dir=os.environ['TMPDIR']))
endpoint = socket_root / 'service.sock'
assert len(os.fsencode(endpoint)) < 108
config_text = '''[execution]
vector_source_rows = 128
text_source_records = 896
index_timeout_s = 1800
command_timeout_s = 30
[reliability]
max_attempts = 1
reason = "Local durable effects; no automatic retry of ambiguous execution"
'''
(root / 'pilot.toml').write_text(config_text)
config = tomllib.loads(config_text)['execution']
epoch = hashlib.sha256(config_text.encode()).hexdigest()
started = time.monotonic()
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert not subprocess.check_output(['git', 'status', '--porcelain']), 'commit the pilot seed component first'
binary = (W / 'target/release/akasha-otsuge').resolve(strict=True)
seeder = (W / 'target/release/examples/corpus_seed').resolve(strict=True)
assert digest(binary) == '9b058b37553f9cf590d7f0062ad2baaec29e4a18b5f35e1a429b753c8df868f1'
assert not subprocess.check_output(['git', 'diff', '84428714a378bc849895c8f3ff4af6ed6af6e1c9', 'HEAD', '--', 'src']), 'daemon source differs from its retained gate'
inventory = json.loads((W / 'spikes/data/sources.json').read_text())['sources']
inputs = []
for group, prefix in enumerate(('vectors', 'text')):
    item = inventory[group]['files'][0]
    path = (W / f'.spike-work/corpus-full-v1/{prefix}-00000.parquet').resolve(strict=True)
    verify(path, item)
    inputs.append({'path': str(path), 'sha256': item['sha256'], 'bytes': item['size'],
                   'repository': inventory[group]['repository'], 'revision': inventory[group]['revision'],
                   'license': inventory[group]['license']})
manifest = {'schema_version': 1, 'inputs': inputs, 'subset': config,
            'selection': 'first 128 DBpedia rows then first 896 unique FineWeb 65536-byte UTF8 chunks',
            'scope_partition': 'sha256(original key)[0] modulo 8',
            'vectors': 0, 'kind': 'lexical_production_pilot_not_full_acceptance'}
publish(root / 'input-manifest.json', manifest)
binding = {'source_manifest_sha256': digest(root / 'input-manifest.json'),
           'observed_time_ms': int(time.time() * 1000)}
publish(root / 'binding.json', binding)
admission = {'head': head, 'daemon_source_pin': '84428714a378bc849895c8f3ff4af6ed6af6e1c9',
             'socket_root': str(socket_root),
             'daemon_sha256': digest(binary), 'seeder_sha256': digest(seeder),
             'seeder_source_sha256': digest(W / 'examples/corpus_seed.rs'),
             'driver_sha256': digest(pathlib.Path(__file__)), 'config_epoch': epoch,
             'process': process_identity(os.getpid()), 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'input_manifest_sha256': binding['source_manifest_sha256'],
             'resume': 'No automatic controller replay; existing root refused, partial receipts retained.',
             'limits': ['1024 real source records; no full 50 GB/100-client/ANN acceptance.',
                        'Seed is offline production Domain. Index and reads use the production daemon CLI.',
                        'No model inference, synthetic embeddings, faults or adversarial cases.',
                        'Process/file caches are not evicted; this is not a cold-cache result.']}
publish(root / 'admission.json', admission)
state = {'admission_sha256': digest(root / 'admission.json'), 'completed_units': [], 'phase': 'seed', 'error': None}
publish(root / 'state.json', state)
oracle = []
witnesses = {}
seen = set()
unique_bytes = 0
seed = daemon = None
commands = (root / 'commands.jsonl').open('x')
metrics = (root / 'metrics.jsonl').open('x')

def progress(phase, completed, total, phase_start):
    elapsed = time.monotonic() - phase_start
    publish(root / 'progress.json', {'phase': phase, 'completed': completed, 'total': total,
        'elapsed_s': elapsed, 'campaign_elapsed_s': time.monotonic() - started,
        'rate_per_s': completed / elapsed if elapsed else None,
        'eta_s': elapsed * (total - completed) / completed if completed else None,
        'config_epoch': epoch, 'process': admission['process']})

def records():
    rows = 0
    for batch in pq.ParquetFile(inputs[0]['path']).iter_batches(batch_size=64, columns=['_id', 'title', 'text']):
        for row in batch.to_pylist():
            yield {'key': 'dbpedia:' + row['_id'], 'body': row['title'] + '\n' + row['text']}, 1
            rows += 1
            if rows == config['vector_source_rows']:
                break
        if rows == config['vector_source_rows']:
            break
    rows = 0
    local_seen = set()
    for batch in pq.ParquetFile(inputs[1]['path']).iter_batches(batch_size=64, columns=['text']):
        for row in batch.to_pylist():
            for body in chunks(row['text']):
                sha = hashlib.sha256(body.encode()).hexdigest()
                if sha in local_seen:
                    continue
                local_seen.add(sha)
                yield {'key': 'fineweb:' + sha, 'body': body}, 0
                rows += 1
                if rows == config['text_source_records']:
                    return

base = [str(binary), '--config', str(root / 'daemon.toml'), '--socket', str(endpoint)]

def cli(*args, required=True):
    clock = time.monotonic()
    result = subprocess.run([*base, *map(str, args)], stdin=subprocess.DEVNULL, capture_output=True,
                            timeout=config['command_timeout_s'])
    entry = {'argv': list(map(str, args)), 'seconds': time.monotonic() - clock,
             'exit_code': result.returncode, 'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
             'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()}
    commands.write(json.dumps(entry) + '\n'); commands.flush()
    if required:
        assert result.returncode == 0, (args[:2], result.returncode, result.stderr.decode()[:2048])
    if result.returncode:
        return None
    return json.loads(result.stdout)['data']

def sample():
    value = cli('daemon', 'status')
    metrics.write(json.dumps({'elapsed_s': time.monotonic() - started, 'resources': value['resources']}) + '\n')
    metrics.flush(); os.fsync(metrics.fileno())
    return value

def wait_job(name, limit, build=False):
    start = time.monotonic()
    while True:
        job = cli('job', 'show', name)
        if job['state'] in ('succeeded', 'failed', 'cancelled'):
            publish(root / f'{name}-terminal.json', job)
            assert job['state'] == 'succeeded', (name, job.get('error'))
            return job, time.monotonic() - start
        assert time.monotonic() - start < limit, ('unit deadline', name)
        if build:
            indexed = cli('index', 'status')
            progress('index', indexed['indexed_rows'], len(oracle), start)
            sample()
        time.sleep(1 if build else 0.02)

def allocation(path):
    total = files = apparent = 0
    for directory, _, names in os.walk(path):
        for name in names:
            st = (pathlib.Path(directory) / name).stat()
            total += st.st_blocks * 512; apparent += st.st_size; files += 1
    return {'allocated_bytes': total, 'apparent_bytes': apparent, 'files': files}

try:
    phase_start = time.monotonic()
    total = config['vector_source_rows'] + config['text_source_records']
    with (root / 'seed.stderr').open('xb') as err, (root / 'acks.jsonl').open('x') as acks:
        seed = subprocess.Popen(['nohup', str(seeder), str(root / 'data'), str(root / 'binding.json')],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=err, start_new_session=True)
        publish(root / 'seed-process.json', process_identity(seed.pid))
        progress('seed', 0, total, phase_start)
        for number, (row, separators) in enumerate(records(), 1):
            row['partition'] = 'p' + str(hashlib.sha256(row['key'].encode()).digest()[0] % 8)
            encoded = row['body'].encode()
            body_hash = hashlib.sha256(encoded).hexdigest()
            if body_hash not in seen:
                seen.add(body_hash); unique_bytes += len(encoded) - separators
            seed.stdin.write((json.dumps(row, ensure_ascii=False) + '\n').encode()); seed.stdin.flush()
            assert select.select([seed.stdout], [], [], 120)[0], 'seed acknowledgement deadline'
            ack_bytes = seed.stdout.readline(4097)
            assert 0 < len(ack_bytes) <= 4096, 'missing or oversized seed acknowledgement'
            ack = json.loads(ack_bytes)
            assert ack['body_sha256'] == body_hash and ack['utf8_bytes'] == len(encoded)
            assert ack['key_sha256'] == hashlib.sha256(row['key'].encode()).hexdigest()
            offset = 0
            for memory_id, seq in ack['memories']:
                end = min(offset + 32768, len(encoded))
                while end < len(encoded) and encoded[end] & 0xC0 == 0x80:
                    end -= 1
                body = encoded[offset:end].decode()
                oracle.append({'id': memory_id, 'revision': seq, 'claim_sha256': hashlib.sha256(encoded[offset:end]).hexdigest(),
                               'partition': row['partition'], 'source_id': ack['source_id'], 'source_revision': ack['source_revision'],
                               'start': offset, 'end': end})
                words = re.findall(r'\b[A-Za-z]{8,40}\b', body)
                if words and row['partition'] not in witnesses:
                    witnesses[row['partition']] = {'id': memory_id, 'revision': seq, 'query': max(words, key=len)}
                offset = end
            assert offset == len(encoded), 'source not fully covered by seed memories'
            acks.write(ack_bytes.decode())
            if number % 64 == 0:
                acks.flush(); os.fsync(acks.fileno())
                progress('seed', number, total, phase_start)
        seed.stdin.close()
        assert seed.wait(timeout=120) == 0, 'seed process failed; see retained stderr'
        assert number == total and len(witnesses) == 8
        acks.flush(); os.fsync(acks.fileno())
    seed_seconds = time.monotonic() - phase_start
    publish(root / 'oracle.json', {'memories': oracle, 'witnesses': witnesses, 'unique_utf8_bytes': unique_bytes})
    state.update(phase='index', seed_seconds=seed_seconds, seed_records=total, memories=len(oracle), unique_utf8_bytes=unique_bytes)
    state['completed_units'].append('seed'); publish(root / 'state.json', state)
    (root / 'daemon.toml').write_text('[paths]\ndata_dir=' + json.dumps(str(root / 'data')) + '\nsocket_path=' + json.dumps(str(endpoint)) + '\n')
    with (root / 'daemon.log').open('xb') as log:
        daemon = subprocess.Popen(['nohup', *base, 'daemon', 'run'], stdin=subprocess.DEVNULL,
                                  stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    publish(root / 'daemon-process.json', process_identity(daemon.pid))
    ready_limit = time.monotonic() + 120
    while True:
        assert daemon.poll() is None, 'daemon exited during startup'
        if endpoint.exists() and cli('daemon', 'status', required=False):
            break
        assert time.monotonic() < ready_limit, 'daemon startup deadline'
        time.sleep(0.1)
    initial = sample()
    assert initial['resources']['requested']['daemon_memory_target_mib'] == 512
    publish(root / 'initial-status.json', initial)
    index_start = time.monotonic()
    cli('index', 'sync', '--idempotency-key', 'pilot-index')
    job, wait_seconds = wait_job('pilot-index', config['index_timeout_s'], build=True)
    index_seconds = time.monotonic() - index_start
    indexed = cli('index', 'status')
    assert indexed['indexed_rows'] == len(oracle) and indexed['vector'] is None
    publish(root / 'indexed-status.json', indexed)
    state.update(phase='verify', index_seconds=index_seconds)
    state['completed_units'].append('index'); publish(root / 'state.json', state)
    read_seconds = []
    verify_start = time.monotonic()
    for number, expected in enumerate(oracle, 1):
        clock = time.monotonic()
        reply = cli('memory', 'show', expected['id'])
        read_seconds.append(time.monotonic() - clock)
        assert reply['data']['state'] == 'active'
        memory = reply['data']['revision']['memory']
        assert memory['revision']['commit_seq'] == expected['revision']
        record = memory['record']; draft = record['draft']
        assert record['authority'] == 'delegated_approved' and record['approval'] is None
        assert hashlib.sha256(draft['claim'].encode()).hexdigest() == expected['claim_sha256']
        assert draft['scope']['project'] == 'corpus/' + expected['partition']
        if number % 64 == 0:
            progress('verify', number, len(oracle), verify_start)
    search_receipts = []
    for partition, expected in sorted(witnesses.items()):
        scope_file = root / f'{partition}-scope.json'
        publish(scope_file, {'user': f'uid:{os.geteuid()}', 'project': 'corpus/' + partition, 'branch_or_version': None, 'session': None})
        name = 'pilot-search-' + partition
        cli('search', expected['query'], '--scope', scope_file, '--idempotency-key', name)
        job, seconds = wait_job(name, 120)
        output = json.loads(job['result']['output'])
        items = [i['memory'] for i in output['items']]
        assert any(i['revision']['key']['id'] == expected['id'] and i['revision']['commit_seq'] == expected['revision'] for i in items), ('expected lexical hit missing', partition)
        assert all(i['record']['draft']['scope']['project'] == 'corpus/' + partition for i in items)
        search_receipts.append({'partition': partition, 'query': expected['query'], 'expected': expected, 'seconds': seconds,
                                'receipt_id': job['result']['receipt_id'], 'hits': [i['revision'] for i in items]})
    final = sample()
    publish(root / 'final-status.json', final)
    state['completed_units'].append('verify')
    result = {'status': 'pilot_pass_not_scale_acceptance', 'seed_records': total, 'memory_chunks': len(oracle),
              'unique_utf8_bytes': unique_bytes, 'seed_seconds': seed_seconds, 'index_seconds': index_seconds,
              'all_current_claim_hashes_verified': len(oracle), 'lexical_partition_witnesses': search_receipts,
              'read_seconds': read_seconds, 'disk': {name: allocation(root / 'data' / name) for name in ('authority', 'search')},
              'limits': admission['limits']}
    publish(root / 'result.json', result)
    state['phase'] = 'complete'
    progress('complete', len(oracle), len(oracle), verify_start)
except BaseException as error:
    state.update(phase='failed', error={'type': type(error).__name__, 'message': str(error)[:4096]})
    publish(root / 'failure.json', state)
    raise
finally:
    if seed and seed.poll() is None:
        seed.stdin.close()
        seed.wait(timeout=120)
    if daemon and daemon.poll() is None:
        cli('daemon', 'stop', required=False)
        try:
            daemon.wait(timeout=60)
        except subprocess.TimeoutExpired:
            daemon.send_signal(signal.SIGTERM)
            daemon.wait(timeout=30)
    state['processes_terminal'] = {'seed': None if seed is None else seed.returncode, 'daemon': None if daemon is None else daemon.returncode}
    publish(root / 'state.json', state)
    for stream in (commands, metrics):
        stream.flush(); os.fsync(stream.fileno()); stream.close()
print(json.dumps({'root': str(root), 'state': state}), flush=True)
