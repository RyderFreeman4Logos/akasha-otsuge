"""Compact immutable receipts; never include native data or private runtime state."""
import hashlib
import json
import pathlib
import subprocess
import zipfile

w = pathlib.Path.cwd()
e = pathlib.Path(__file__).parent
destination = w / 'docs/benchmarks/results/mvp024-production-pilot'
destination.mkdir(parents=True, exist_ok=False)
members = {}

def add(name, data):
    assert name not in members and not name.startswith('/') and '..' not in pathlib.PurePosixPath(name).parts
    members[name] = data

prefixes = ('mvp024-corpus-', 'mvp024-production-', 'mvp024-index-batch-')
for path in sorted(e.iterdir()):
    if path.name.startswith(prefixes) and path.is_file():
        add('receipts/' + path.name, path.read_bytes())
add('receipts/' + pathlib.Path(__file__).name, pathlib.Path(__file__).read_bytes())
for ordinal in (1, 2):
    root = w / f'.spike-work/mvp024-production-pilot-r{ordinal}'
    verified = json.loads((e / f'mvp024-production-pilot-r{ordinal}-verified.json').read_text())
    assert not (root / 'data').exists()
    for name, expected in sorted(verified['metadata_sha256'].items()):
        assert pathlib.Path(name).name == name
        data = (root / name).read_bytes()
        assert hashlib.sha256(data).hexdigest() == expected, name
        add(f'pilot-r{ordinal}/{name}', data)

source_paths = ['Cargo.toml', 'examples/corpus_seed.rs', 'src/retrieval.rs',
                'src/retrieval/vector.rs', 'src/retrieval/tests.rs',
                'tests/support/daemon_retrieval.rs']
pins = ['b191b01fd5e0ad054460f42a2b75290cd1175bf3', 'b179076350ff7edf4ab724eba3be0007a656a051']
for pin in pins:
    paths = source_paths + (['src/retrieval/batch.rs'] if pin == pins[1] else [])
    for name in paths:
        add(f'source/{pin}/{name}', subprocess.check_output(['git', 'show', f'{pin}:{name}']))

notes = {
    'scope': 'Committed streaming seed component and bounded native mutation batches; paired 1024-source-record lexical pilot only.',
    'historical_failures': [
        'Seed r1/r2/r3 failed at compilation (private APIs, unsupported SHA2 formatting, then unused scaffold). They are harness failures, not product RED.',
        'Seed r4 ran one unchanged oracle and failed on the absent seed component; green r1 passes that oracle.',
        'Index batch r1 ran both complete native cases: lexical 18 versions and vector 19 exceeded the predeclared maximum of 8. Both then pass unchanged.',
        'The source-shard scan completed successfully, but its parent wrapper rejected the launcher response before arming WD. The exact rejected response was not retained. An early-yield response is an inference, not proven causality. Subsequent launches use a non-login Bash and longer launcher wait.',
    ],
    'custody': [
        'All dirty-attempt admissions retain their actual parent HEAD and diff/untracked hashes. Parent HEAD is not the identity of uncommitted candidate code.',
        'Committed predecessor and successor source preimages are included. Not every intermediate dirty scaffold/tree is reconstructable from this archive.',
        'Paired input manifests, policy TOML, binding timestamps, all acknowledgements and the complete claim/query oracle match byte for byte.',
        'Seeder executable is held identical across arms; daemon executables are separately pinned. Cache eviction and independent repetitions were not performed.',
        'Both native stores and both socket directories were removed only after exit/readback verification. Compressed source shards and shared build artifacts remain.',
    ],
    'remaining': ['50 GB/full lexical coverage, million real vectors, 100000 changes, 100 clients, full latency and ordinary recovery acceptance remain open in #65.',
                  'Thirty-seven whole-document vectors need a verified input/generation policy beyond the present 4096-byte mean policy.',
                  'RSS sampled peak increased in this single pair; no memory improvement or full-scale extrapolation is claimed.',
                  'Further derived-index disk growth/reclamation must be measured before full-corpus admission.',
                  'Daybreak/new adversarial campaigns remain owner-deferred.'],
}
add('scope-and-custody.json', (json.dumps(notes, indent=2) + '\n').encode())

target = destination / 'evidence.zip'
with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(members.items()):
        info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
manifest = {'schema_version': 1, 'source_pins': pins, 'zip_sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
            'zip_bytes': target.stat().st_size,
            'members': {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in sorted(members.items())}}
(destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None and sorted(archive.namelist()) == sorted(members)
    for name, item in manifest['members'].items():
        data = archive.read(name)
        assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
print(json.dumps({'archive': str(destination), 'files': len(members), 'zip_bytes': manifest['zip_bytes'],
                  'zip_sha256': manifest['zip_sha256'], 'uncompressed_bytes': sum(len(x) for x in members.values())}))
