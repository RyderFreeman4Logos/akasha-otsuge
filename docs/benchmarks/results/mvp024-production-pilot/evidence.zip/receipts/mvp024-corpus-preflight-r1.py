"""Read-only retained-shard verification and production input shape census."""
import collections
import datetime
import hashlib
import json
import os
import pathlib
import subprocess
import sys
import time

import pyarrow
import pyarrow.parquet as pq

W = pathlib.Path.cwd()
E = pathlib.Path(__file__).parent
sys.path.insert(0, str(W / 'spikes/helix'))
from run_case import publish, process_identity

start = time.monotonic()
source = W / 'spikes/data/sources.json'
inventory = json.loads(source.read_text())['sources']
root = (W / '.spike-work/corpus-full-v1').resolve(strict=True)
admission = {
    'schema_version': 1, 'purpose': 'read_only_hash_and_shape_census_not_acceptance',
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'sources_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'script_sha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
    'root': str(root), 'process': process_identity(os.getpid()),
    'python': sys.version.split()[0], 'pyarrow': pyarrow.__version__,
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'counts': [26, 16], 'retry': 'none; read-only partial records retained',
}
out = E / 'mvp024-corpus-preflight-r1-result.json'
if out.exists():
    raise FileExistsError(out)
publish(E / 'mvp024-corpus-preflight-r1-input.json', admission)
units = []
counts = collections.Counter()
shape = collections.Counter()
for group, total in enumerate(admission['counts']):
    for index, item in enumerate(inventory[group]['files'][:total]):
        path = root / f"{'vectors' if group == 0 else 'text'}-{index:05d}.parquet"
        elapsed = time.monotonic() - start
        publish(E / 'mvp024-corpus-preflight-r1-progress.json', {
            'completed': len(units), 'total': 42, 'elapsed_s': elapsed,
            'rate_per_s': len(units) / elapsed if elapsed else None,
            'eta_s': elapsed * (42 - len(units)) / len(units) if units else None,
            'active_unit': path.name, 'config_epoch': admission['sources_sha256'],
            'process': admission['process'],
        })
        before = path.stat()
        assert before.st_size == item['size'], path.name
        with path.open('rb') as stream:
            digest = hashlib.file_digest(stream, 'sha256').hexdigest()
        assert digest == item['sha256'], path.name
        unit = {'file': path.name, 'size': before.st_size, 'sha256': digest,
                'source_path': item['path'], 'source_revision': inventory[group]['revision']}
        parquet = pq.ParquetFile(path)
        unit['source_rows'] = parquet.metadata.num_rows
        if group == 0:
            local = collections.Counter()
            for batch in parquet.iter_batches(batch_size=256, columns=['title', 'text']):
                for row in batch.to_pylist():
                    body = (row['title'] + '\n' + row['text']).encode('utf-8')
                    local['rows'] += 1
                    local['utf8_bytes'] += len(body)
                    local['over_4096'] += len(body) > 4096
                    local['over_32768'] += len(body) > 32768
                    local['max_bytes'] = max(local['max_bytes'], len(body))
            unit['shape'] = dict(local)
            max_bytes = max(shape['max_bytes'], local['max_bytes'])
            shape.update(local)
            shape['max_bytes'] = max_bytes
        after = path.stat()
        assert (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) == (
            after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns), path.name
        counts['verified_bytes'] += before.st_size
        units.append(unit)
        publish(E / 'mvp024-corpus-preflight-r1-state.json', {'admission': admission, 'units': units})
        print(json.dumps({'verified': path.name, 'completed': len(units), 'total': 42}), flush=True)
elapsed = time.monotonic() - start
publish(out, {'admission': admission, 'units': units, 'counts': dict(counts),
              'vector_document_shape': dict(shape), 'elapsed_s': elapsed,
              'limits': ['Hashes and source shape only; no product import/index/load acceptance.',
                         'Embedding columns not decoded; nonzero/uniqueness not reverified here.']})
publish(E / 'mvp024-corpus-preflight-r1-progress.json', {
    'completed': 42, 'total': 42, 'elapsed_s': elapsed, 'rate_per_s': 42 / elapsed,
    'eta_s': 0, 'active_unit': None, 'config_epoch': admission['sources_sha256'],
    'process': admission['process'],
})
print(json.dumps({'result': str(out), 'counts': dict(counts), 'shape': dict(shape)}), flush=True)
