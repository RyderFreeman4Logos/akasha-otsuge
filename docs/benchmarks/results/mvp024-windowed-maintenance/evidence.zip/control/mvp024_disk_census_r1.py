"""Sample a changing owned tree; retry only a disappearing-entry race."""
import pathlib
import stat
import time


def snapshot(root):
    pending = [root]
    seen = set()
    allocated = apparent = files = directories = 0
    while pending:
        path = pending.pop()
        entry = path.lstat()
        identity = entry.st_dev, entry.st_ino
        if identity in seen:
            continue
        seen.add(identity)
        if stat.S_ISDIR(entry.st_mode):
            directories += 1
            pending.extend(path.iterdir())
        elif stat.S_ISREG(entry.st_mode):
            files += 1
        else:
            raise ValueError('unexpected non-file in owned data tree: '+str(path))
        allocated += entry.st_blocks * 512
        apparent += entry.st_size
    return dict(allocated_bytes=allocated, apparent_bytes=apparent,
                files=files, directories=directories)


def census(root):
    root = pathlib.Path(root)
    races = []
    for attempt in range(5):
        try:
            result = snapshot(root)
            return dict(result, attempts=attempt+1, disappearing_entries=races,
                        atomic_snapshot=False)
        except FileNotFoundError as error:
            races.append(dict(attempt=attempt+1, path=str(error.filename)))
            if attempt == 4:
                error.add_note('Five complete censuses encountered disappearing entries; no partial size accepted: '+repr(races))
                raise
            time.sleep(.02 * 2**attempt)


def self_test(directory):
    import subprocess
    import tempfile
    from unittest.mock import patch
    cases = []
    with tempfile.TemporaryDirectory(prefix='a24d-',dir=directory) as temporary:
        root = pathlib.Path(temporary)
        keep = root/'keep';keep.write_bytes(b'x'*100)
        linked = root/'linked';linked.hardlink_to(keep)
        exact = int(subprocess.check_output(['du','-s','-B1',str(root)],text=True).split()[0])
        assert census(root)['allocated_bytes'] == exact
        assert census(root)['files'] == 1
        cases.append('stable_allocation_and_hardlink_identity')
        victim = root/'removed';victim.write_bytes(b'x')
        original = pathlib.Path.lstat
        def racing(path, *args, **kwargs):
            if path == victim and victim.exists():
                victim.unlink()
            return original(path,*args,**kwargs)
        with patch.object(pathlib.Path,'lstat',racing):
            measured = census(root)
        assert measured['attempts'] == 2 and len(measured['disappearing_entries']) == 1
        assert measured['allocated_bytes'] == exact and measured['files'] == 1
        cases.append('actual_unlink_between_directory_enumeration_and_stat')
        with patch.object(pathlib.Path,'lstat',side_effect=PermissionError('fixture')) as mocked:
            try:census(root)
            except PermissionError:assert mocked.call_count == 1
            else:raise AssertionError('permanent error hidden')
        cases.append('permanent_error_not_retried')
        with patch.object(pathlib.Path,'lstat',side_effect=FileNotFoundError(2,'fixture','owned')) as mocked:
            try:census(root)
            except FileNotFoundError as error:
                assert mocked.call_count == 5 and error.__notes__
            else:raise AssertionError('unstable census accepted')
        cases.append('bounded_exhaustion_no_partial_result')
    assert not root.exists()
    return dict(status='CENSUS_FIXTURE_PASS_ONLY', cases=cases, owned_fixture_removed=True)


if __name__ == '__main__':
    import json,os,sys
    assert sys.argv[1:] == ['--self-test']
    print(json.dumps(self_test(os.environ['TMPDIR'])))
