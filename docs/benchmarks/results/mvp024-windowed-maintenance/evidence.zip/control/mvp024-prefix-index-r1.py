"""Same-store prefix current/original oracles, followed by measured native indexing."""
import collections, datetime, fcntl, hashlib, json, os, pathlib, re, resource, shutil, signal, socket, struct, subprocess, sys, tempfile, time, tomllib
sys.dont_write_bytecode = True
E = pathlib.Path(__file__).parent
W = pathlib.Path.cwd()
sys.path[:0] = [str(E), str(W/'spikes/data'), str(W/'spikes/helix')]
from download import publish
from prepare_corpus import records, vector_fingerprint
from run_case import process_identity
from mvp024_import_protocol_r2 import encode, digest, project, receipts, source_id, spans, verify_ack

def sha(path):
    with pathlib.Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

def exact_absent(identity):
    current = process_identity(identity['pid'])
    return current is None or current['start_ticks'] != identity['start_ticks']

def receive(stream):
    def read(n):
        data = bytearray()
        while len(data) < n:
            part = stream.recv(n-len(data))
            if not part:
                raise EOFError('daemon frame ended early')
            data.extend(part)
        return bytes(data)
    size = struct.unpack('!I', read(4))[0]
    assert 0 < size <= 2*1024**2, 'invalid IPC size'
    return json.loads(read(size))

def rpc(command, request_id):
    deadline_ms = int(time.time()*1000)+10000
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as stream:
        stream.settimeout(10)
        stream.connect(str(endpoint))
        _, peer_uid, _ = struct.unpack('3i',stream.getsockopt(socket.SOL_SOCKET,socket.SO_PEERCRED,12))
        assert peer_uid == os.geteuid()
        hello = receive(stream)
        assert hello['protocol_version'] == 1 and hello['max_message_bytes'] == 2*1024**2
        assert 'error' not in hello, hello
        raw = encode(dict(protocol_version=1, request_id=request_id, deadline_ms=deadline_ms, command=command))
        stream.sendall(struct.pack('!I',len(raw))+raw)
        reply = receive(stream)
        assert reply['schema_version'] == 1 and reply['request_id'] == request_id and reply['sequence'] == 1
        assert 'error' not in reply, (command['op'],reply.get('error'))
        return reply['data']

def cli(*args, required=True):
    result = subprocess.run([*base,*map(str,args)],stdin=subprocess.DEVNULL,capture_output=True,timeout=30)
    if required:
        assert result.returncode == 0, (args[:2],result.returncode,result.stderr.decode()[:1000])
    if result.returncode:
        return None
    return json.loads(result.stdout)['data']

def configuration():
    raw = (root/'run.toml').read_bytes()
    value = tomllib.loads(raw.decode())
    assert value['reliability']['max_attempts'] == 1
    assert value['reliability']['oracle_unit_timeout_s'] >= 600
    assert value['reliability']['index_timeout_s'] >= 43200
    assert value['resources'] == dict(data_ceiling_bytes=4*1024**3,free_reserve_bytes=30*1024**3,helper_rss_ceiling_bytes=512*1024**2)
    epoch = digest(raw)
    path = root/'epochs'/f'{epoch}.toml'
    if path.exists():
        assert path.read_bytes() == raw
    else:
        with path.open('xb') as stream:
            stream.write(raw);stream.flush();os.fsync(stream.fileno())
        fd=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(fd)
        finally:os.close(fd)
    return value,epoch

def progress(phase,completed,total,since,**extra):
    elapsed = time.monotonic()-since
    value = dict(phase=phase,completed=completed,total=total,elapsed_s=elapsed,
        rate_per_s=completed/elapsed if completed else None,
        eta_s=elapsed*(total-completed)/completed if completed else None,
        config_epoch=epoch,process=admission['process'],**extra)
    publish(root/'progress.json',value)
    state.update(phase=phase,last_progress=value)
    publish(root/'state.json',state)

def sample():
    assert daemon.poll() is None, 'daemon exited'
    value = cli('daemon','status')
    group = value['resources']['cgroup']
    assert group['enforced'] and group['complete'], group
    assert group['daemon_group']['high_bytes'] == 512*1024**2
    assert group['daemon_group']['max_bytes'] == 640*1024**2
    assert group['service_total']['max_bytes'] == 2048*1024**2
    proc = {}
    for line in pathlib.Path(f'/proc/{daemon.pid}/status').read_text().splitlines():
        key,_,raw = line.partition(':')
        if key in ('VmRSS','VmHWM','RssAnon','RssFile','RssShmem','VmSwap'):
            proc[key] = int(raw.split()[0])*1024
    events = dict((k,int(v)) for k,v in (line.split() for line in (pathlib.Path(group['daemon_group']['path'])/'memory.events').read_text().splitlines()))
    allocated = int(subprocess.check_output(['du','-s','-B1',str(import_root/'data')],text=True).split()[0])
    own = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024
    helper = None
    if provider is not None:
        assert provider.poll() is None, 'lookup exited'
        helper = {}
        for line in pathlib.Path(f'/proc/{provider.pid}/status').read_text().splitlines():
            key,_,raw = line.partition(':')
            if key in ('VmRSS','VmHWM'):helper[key]=int(raw.split()[0])*1024
    measurement = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase=state['phase'],
        resources=value['resources'],daemon_proc=proc,daemon_events=events,controller_peak_bytes=own,lookup=helper,
        allocated_data_bytes=allocated,free_bytes=shutil.disk_usage(root).free)
    metrics.write(json.dumps(measurement)+'\n');metrics.flush();os.fsync(metrics.fileno())
    assert proc['VmHWM'] <= 640*1024**2 and events['oom_kill'] == 0, ('daemon memory',measurement)
    assert own <= cfg['resources']['helper_rss_ceiling_bytes']
    assert helper is None or helper['VmHWM'] <= cfg['resources']['helper_rss_ceiling_bytes']
    assert allocated <= cfg['resources']['data_ceiling_bytes'] and measurement['free_bytes'] >= cfg['resources']['free_reserve_bytes']
    return value

def wait_job(name,deadline,indexing=False):
    started = time.monotonic()
    while True:
        job = cli('job','show',name)
        if job['state'] in ('succeeded','failed','cancelled'):
            publish(root/(name+'-terminal.json'),job)
            assert job['state'] == 'succeeded', (name,job.get('error'))
            return job
        assert time.time() < deadline, ('original job deadline expired',name)
        if indexing:
            status = cli('index','status')
            vector = status.get('vector') or {}
            progress('indexing',vector.get('indexed_rows',0),import_result['vector_cohort'],started,
                lexical_completed=status['indexed_rows'],lexical_total=import_result['claims'],index_status=status)
            sample()
        time.sleep(5 if indexing else .05)

assert sys.argv[1:] == ['--run']
head = subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head == 'a177d6e23568b627ec9eef593d88289bc8634041'
assert not subprocess.check_output(['git','status','--porcelain'])
assert all(os.environ.get(k) is None for k in ('LD_PRELOAD','MALLOC_MMAP_THRESHOLD_','GLIBC_TUNABLES','MALLOC_ARENA_MAX','LANCE_FTS_NUM_SHARDS','LANCE_FTS_PARTITION_SIZE'))
import_root = (W/'.spike-work/mvp024-production-import-r1').resolve(strict=True)
verified_path = E/'mvp024-production-import-prefix-r1-verified.json'
verified = json.loads(verified_path.read_text())
assert verified['status'] == 'PREFIX_IMPORT_VERIFIED_NOT_FULL_ACCEPTANCE' and verified['head'] == head
import_result = verified['import_result']
import_lock = (import_root/'controller.lock').open('a')
fcntl.flock(import_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert all(exact_absent(x) for x in verified['processes_absent'].values())
assert sha(import_root/'admission.json') == import_result['admission_sha256']
for name,value in verified['data_members'].items():
    path = import_root/'data'/name
    assert path.stat().st_size == value['bytes'] and sha(path) == value['sha256']
units,chain,total = receipts(import_root,import_result['admission_sha256'],11428868)
assert chain == import_result['journal_chain_sha256'] and total == 65536
binding = json.loads((import_root/'binding.json').read_text())
manifest_path = W/'.spike-work/mvp024-full-preparation-source-r1/verified-manifest.json'
assert sha(manifest_path) == '88f767e86e790b0a1714b229bc0b3d047724ee7f2479596624c9daffacb9fd5d'
manifest = json.loads(manifest_path.read_text())
for name,value in manifest['code_sha256'].items():assert sha(W/'spikes/data'/name) == value
binary = (W/'target/release/akasha-otsuge').resolve(strict=True)
binary_sha = sha(binary)
assert binary_sha == '4c29824abf0e2466fae4e0c32e2f1a37d5635bd5621244f6ff1ab2fec4f8ac1e'
assert shutil.disk_usage(import_root).free >= 30*1024**3
root = (W/'.spike-work/mvp024-production-prefix-index-r1').resolve()
root.mkdir(mode=0o700)
(root/'OWNER').write_text('akasha-otsuge:mvp024-production-prefix-index-r1\n')
(root/'epochs').mkdir();(root/'current-units').mkdir()
socket_root = pathlib.Path(tempfile.mkdtemp(prefix='a24x-',dir=os.environ['TMPDIR']))
endpoint = socket_root/'service.sock'
assert len(os.fsencode(endpoint)) < 108
config_text = '[reliability]\nmax_attempts=1\noracle_unit_timeout_s=1800\nindex_timeout_s=43200\n[resources]\ndata_ceiling_bytes=4294967296\nfree_reserve_bytes=32212254720\nhelper_rss_ceiling_bytes=536870912\n'
(root/'run.toml').write_text(config_text)
cfg,epoch = configuration()
admission = dict(head=head,tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),
    daemon_sha256=binary_sha,driver_sha256=sha(__file__),provider_sha256=sha(E/'mvp024-prefix-lookup-r1.py'),
    lookup_source_sha256=sha(W/'spikes/data/precomputed.py'),protocol_sha256=sha(E/'mvp024_import_protocol_r2.py'),
    verified_import_sha256=sha(verified_path),config_epoch=epoch,import_root=str(import_root),
    process=process_identity(os.getpid()),socket_root=str(socket_root),utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    limits='65536-record prefix only; default 512/640/2048 MiB enforced daemon/service limits; lookup/controller separately observed 512 MiB. No full-corpus/load/recovery acceptance.',
    recovery='No automatic retry or new effects on an existing run. Preserve original per-unit/job deadlines; reconcile existing durable IDs after interruption.',
    retention='Preserve the existing production import store for later index/oracles/resume; remove only the exact owned socket after consumers exit.')
publish(root/'admission.json',admission)
state = dict(phase='admitted',completed_units=[],admission_sha256=sha(root/'admission.json'))
publish(root/'state.json',state)
lookup_manifest = json.loads((W/'.spike-work/mvp024-precomputed-real-r1/manifest.json').read_text())
publish(root/'lookup-manifest.json',lookup_manifest)
(root/'lookup.toml').write_text('[resources]\nrss_ceiling_bytes=536870912\n[reliability]\nmax_attempts=5\nunit_timeout_s=3600\n')
provider = daemon = None
metrics = (root/'metrics.jsonl').open('x')
base = [str(binary),'--config',str(root/'daemon.toml'),'--socket',str(endpoint)]
result = None
try:
    with (root/'lookup.log').open('xb') as log:
        provider = subprocess.Popen(['nohup',sys.executable,str(E/'mvp024-prefix-lookup-r1.py'),str(root),head],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    publish(root/'lookup-process.json',process_identity(provider.pid))
    lookup_deadline = time.time()+1800
    publish(root/'lookup-admission.json',dict(deadline_unix_s=lookup_deadline))
    while not (root/'lookup-ready.json').exists():
        assert provider.poll() is None, 'lookup failed before readiness'
        assert time.time() < lookup_deadline, 'lookup admission deadline'
        time.sleep(.2)
    ready = json.loads((root/'lookup-ready.json').read_text())
    assert ready['process']['pid'] == provider.pid
    profile = '[retrieval]\nembedding="corpus_vectors"\nembedding_scopes=['+','.join('{user='+json.dumps(f'uid:{os.geteuid()}')+',project='+json.dumps('corpus/p'+str(n))+',branch_or_version="vectors"}' for n in range(8))+']\n'
    profile += '[models.corpus_vectors]\nkind="embedding"\nendpoint='+json.dumps(f'http://127.0.0.1:{ready["address"][1]}/v1')+'\nmodel='+json.dumps(ready['model'])+'\ndimension=1536\nlocal=true\ntimeout="30s"\n'
    (root/'daemon.toml').write_text('[paths]\ndata_dir='+json.dumps(str(import_root/'data'))+'\nsocket_path='+json.dumps(str(endpoint))+'\n'+profile)
    with (root/'daemon.log').open('xb') as log:
        daemon = subprocess.Popen(['nohup',*base,'daemon','run'],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    publish(root/'daemon-process.json',process_identity(daemon.pid))
    deadline = time.time()+120
    while not (endpoint.exists() and cli('daemon','status',required=False)):
        assert daemon.poll() is None and time.time() < deadline, 'daemon admission failed'
        time.sleep(.1)
    observed = {}
    for item in pathlib.Path(f'/proc/{daemon.pid}/environ').read_bytes().split(b'\0'):
        key,sep,value = item.partition(b'=')
        if key in (b'LANCE_FTS_NUM_SHARDS',b'LANCE_FTS_PARTITION_SIZE',b'MALLOC_ARENA_MAX',b'MALLOC_MMAP_THRESHOLD_',b'LD_PRELOAD',b'GLIBC_TUNABLES'):
            observed[key.decode()] = value.decode()
    assert observed == dict(LANCE_FTS_NUM_SHARDS='1',LANCE_FTS_PARTITION_SIZE='32',MALLOC_ARENA_MAX='2')
    publish(root/'daemon-environment.json',observed)
    publish(root/'initial-status.json',sample())
    expected_pairs = [];witnesses = {};lexical = {};claim_count = source_count = 0
    stats = {};iterator = records(W/'.spike-work/corpus-full-v1',manifest['source_counts'],stats,root/'source-progress.json')
    read_start = time.monotonic();progress('current_and_original',0,total,read_start)
    for number,original in enumerate(iterator,1):
        row = project(original);encoded = row['body'].encode();sid = source_id(binding,row['key'])
        unit_number = (number-1)//4096
        if (number-1)%4096 == 0:
            cfg,epoch = configuration()
            deadline = time.time()+cfg['reliability']['oracle_unit_timeout_s']
            publish(root/'current-inflight.json',dict(first=number,deadline_unix_s=deadline,config_epoch=epoch))
            input_hash = hashlib.sha256();acks_hash = hashlib.sha256();oracle_hash = hashlib.sha256();original_hash = hashlib.sha256()
        assert time.time() < deadline, 'original oracle-unit deadline expired'
        input_hash.update(encode(row)+b'\n')
        scope = dict(user=f'uid:{os.geteuid()}',project='corpus/'+row['partition'],branch_or_version='vectors' if row['vector_cohort'] else None,session=None)
        memories = [];source_revision = None
        for start,end in spans(row['body']):
            mid = f'{sid}/{start}'
            reply = rpc(dict(op='memory_show',id=mid,at=None),f'prefix-current-{number}-{start}')
            if number == 1 and start == 0:
                assert cli('memory','show',mid) == reply, 'CLI/IPC current projection differs'
            assert reply['data']['state'] == 'active'
            memory = reply['data']['revision']['memory'];record = memory['record'];draft = record['draft']
            assert record['authority'] == 'delegated_approved' and record['approval'] is None
            assert draft['claim'].encode() == encoded[start:end] and draft['scope'] == scope
            references = draft['source_spans'];assert len(references) == 1
            revision = references[0]['revision']
            assert source_revision is None or source_revision == revision
            source_revision = revision
            assert references == [dict(event_id=sid,revision=revision,content_sha256=digest(encoded),start=start,end=end)]
            assert memory['revision']['key']['id'] == mid
            memories.append([mid,memory['revision']['commit_seq']]);claim_count += 1
        ack = dict(key_sha256=digest(row['key'].encode()),body_sha256=digest(encoded),source_id=sid,
            source_revision=source_revision,memories=memories,utf8_bytes=len(encoded))
        raw = encode(ack)+b'\n';info = verify_ack(row,binding,raw)
        acks_hash.update(raw);oracle_hash.update(bytes.fromhex(info['oracle_sha256']))
        offset = 0;actual_body = hashlib.sha256()
        while offset < len(encoded):
            body = rpc(dict(op='original_show',range=dict(event_id=sid,revision=source_revision,start=offset,end=len(encoded))),f'prefix-original-{number}-{offset}')
            end = body['end']
            assert body['start'] == offset and offset < end <= len(encoded)
            assert body['output'].encode() == encoded[offset:end] and body['output_sha256'] == digest(encoded[offset:end])
            assert body['scope'] == scope and body['total_bytes'] == len(encoded) and body['requested_end'] == len(encoded)
            assert body['truncated'] == (end < len(encoded))
            assert body['reference'] == dict(event_id=sid,revision=source_revision,content_sha256=digest(encoded),start=offset,end=end)
            actual_body.update(body['output'].encode());offset=end
        assert actual_body.digest() == hashlib.sha256(encoded).digest()
        original_hash.update(actual_body.digest());source_count += 1
        if row['vector_cohort']:
            pair = hashlib.sha256(encoded).digest()+vector_fingerprint(original['embedding'])
            expected_pairs.append(pair)
            if len(encoded)<=2048 and row['body'].strip()==row['body'] and row['partition'] not in witnesses:
                witnesses[row['partition']] = dict(id=memories[0][0],revision=memories[0][1],query=row['body'],scope=scope)
        else:
            words = re.findall(r'\b[A-Za-z]{8,40}\b',row['body'])
            if words and row['partition'] not in lexical:
                lexical[row['partition']] = dict(id=memories[0][0],revision=memories[0][1],query=max(words,key=len),scope=scope)
        if number%1024 == 0:
            progress('current_and_original',number,total,read_start);sample()
        if number%4096 == 0:
            expected = units[unit_number]
            assert input_hash.hexdigest() == expected['input_sha256']
            assert acks_hash.hexdigest() == expected['acks_sha256']
            assert oracle_hash.hexdigest() == expected['oracle_sha256']
            publish(root/'current-units'/f'{unit_number:08d}.json',dict(first=expected['first'],last=number,
                input_sha256=input_hash.hexdigest(),acks_sha256=acks_hash.hexdigest(),oracle_sha256=oracle_hash.hexdigest(),
                original_body_hashes_sha256=original_hash.hexdigest(),config_epoch=epoch,deadline_unix_s=deadline,completed_unix_s=time.time()))
        if number == total:break
    iterator.close()
    assert claim_count == import_result['claims'] and source_count == total
    assert len(expected_pairs) == import_result['vector_cohort'] and len(witnesses) == 8
    publish(root/'oracles.json',dict(sources=source_count,claims=claim_count,vector_pairs=len(expected_pairs),
        original_readback_complete=True,ack_digest_matches_all_import_units=True,
        vector_pair_stream_sha256=digest(b''.join(expected_pairs)),vector_witnesses=witnesses,lexical_witnesses=lexical))
    state['completed_units'].append('current_and_original');publish(root/'state.json',state)
    cfg,epoch = configuration()
    name = 'prefix-index-r1';deadline = time.time()+cfg['reliability']['index_timeout_s']
    publish(root/'index-admission.json',dict(id=name,deadline_unix_s=deadline,config_epoch=epoch,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    index_start = time.monotonic()
    cli('index','sync','--idempotency-key',name)
    wait_job(name,deadline,indexing=True)
    index_seconds = time.monotonic()-index_start
    status = cli('index','status')
    assert status['indexed_rows'] == claim_count and status['vector']['indexed_rows'] == len(expected_pairs)
    audit = (root/'lookup-events.bin').read_bytes()
    assert len(audit) == 64*len(expected_pairs)
    assert collections.Counter(audit[i:i+64] for i in range(0,len(audit),64)) == collections.Counter(expected_pairs)
    publish(root/'index-coverage.json',dict(status=status,index_seconds=index_seconds,expected_vectors=len(expected_pairs),
        actual_vectors=len(audit)//64,exact_input_vector_multiset=True,index_audit_sha256=digest(audit)))
    state['completed_units'].append('index');publish(root/'state.json',state)
    search_receipts = []
    for kind,selected in [('lexical',lexical),('vector',witnesses)]:
        for partition,expected in sorted(selected.items()):
            scope_path = root/f'{kind}-{partition}-scope.json';publish(scope_path,expected['scope'])
            name = f'prefix-{kind}-{partition}'
            cli('search',expected['query'],'--scope',scope_path,'--idempotency-key',name)
            job = wait_job(name,time.time()+120)
            output = json.loads(job['result']['output']);items = [item['memory'] for item in output['items']]
            assert any(item['revision']['key']['id']==expected['id'] and item['revision']['commit_seq']==expected['revision'] for item in items), ('self-hit missing',kind,partition)
            assert all(item['record']['draft']['scope']==expected['scope'] for item in items)
            if kind == 'vector':assert output['mode']=='hybrid'
            search_receipts.append(dict(kind=kind,partition=partition,id=expected['id'],receipt_id=job['result']['receipt_id'],mode=output['mode']))
        assert (root/'lookup-events.bin').stat().st_size == 64*(len(expected_pairs)+(8 if kind=='vector' else 0))
    publish(root/'search-coverage.json',search_receipts)
    publish(root/'final-status.json',sample())
    assert sha(binary) == binary_sha and subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == head
    assert not subprocess.check_output(['git','status','--porcelain'])
    result = dict(status='PREFIX_VERIFIED_NOT_FULL_ACCEPTANCE',sources=source_count,claims=claim_count,vectors=len(expected_pairs),
        index_seconds=index_seconds,current_and_original_units=len(units),search_witnesses=len(search_receipts),retained_import_store=str(import_root/'data'))
    state['completed_units'].append('search');state['phase']='awaiting_shutdown'
except BaseException as error:
    state.update(phase='failed',error=dict(type=type(error).__name__,message=str(error)[:3000]))
    publish(root/'failure.json',state)
    raise
finally:
    cleanup_errors = []
    for name,child in [('daemon',daemon),('lookup',provider)]:
        try:
            if child is not None and child.poll() is None:
                if name == 'daemon':cli('daemon','stop',required=False)
                else:child.send_signal(signal.SIGTERM)
                try:child.wait(timeout=120)
                except subprocess.TimeoutExpired:
                    publish(root/f'{name}-shutdown-timeout.json',dict(pid=child.pid,action='SIGTERM after original 120-second graceful drain'))
                    child.send_signal(signal.SIGTERM);child.wait(timeout=180)
            publish(root/f'{name}-process-terminal.json',dict(exit_code=None if child is None else child.returncode))
        except BaseException as error:
            cleanup_errors.append(dict(process=name,type=type(error).__name__,message=str(error)))
    metrics.flush();os.fsync(metrics.fileno());metrics.close()
    try:
        assert not cleanup_errors, cleanup_errors
        for child in (daemon,provider):
            if child is not None:assert child.poll() is not None
        entries = list(socket_root.iterdir())
        assert all(path.name in ('daemon.lock','service.sock') for path in entries), [p.name for p in entries]
        if (socket_root/'daemon.lock').exists():
            handle=(socket_root/'daemon.lock').open('a');fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB)
        for path in entries:path.unlink()
        socket_root.rmdir()
        if result is not None:
            assert daemon.returncode == 0 and provider.returncode == 0
            lookup_terminal=json.loads((root/'lookup-terminal.json').read_text())
            assert lookup_terminal['phase']=='stopped' and lookup_terminal['snapshot']['failed_requests']==0
            assert lookup_terminal['audit_bytes']==64*(result['vectors']+8)
            result.update(socket_removed=not socket_root.exists(),lookup_terminal_sha256=sha(root/'lookup-terminal.json'))
            publish(root/'result.json',result);state['phase']='complete'
            progress('complete',total,total,read_start)
    except BaseException as error:
        state.update(phase='failed',cleanup_error=dict(type=type(error).__name__,message=str(error)))
        publish(root/'cleanup-failure.json',state)
        raise
    finally:publish(root/'state.json',state)
print(json.dumps(result))
