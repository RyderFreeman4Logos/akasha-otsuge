"""Same-store prefix current/original oracles, followed by measured native indexing."""
import collections, datetime, fcntl, hashlib, json, os, pathlib, re, resource, shutil, signal, socket, struct, subprocess, sys, tempfile, time, tomllib
sys.dont_write_bytecode = True
E = pathlib.Path(__file__).parent
W = pathlib.Path.cwd()
sys.path[:0] = [str(E), str(W/'spikes/data'), str(W/'spikes/helix')]
from download import publish
from prepare_corpus import records, vector_fingerprint
from run_case import process_identity
from mvp024_import_protocol_r2 import encode, digest, project, receipts
from mvp024_disk_census_r1 import census

def sha(path):
    with pathlib.Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

def exact_absent(identity):
    current = process_identity(identity['pid'])
    return current is None or current['start_ticks'] != identity['start_ticks']

def cli(*args, required=True):
    result = subprocess.run([*base,*map(str,args)],stdin=subprocess.DEVNULL,capture_output=True,timeout=30)
    if required:
        assert result.returncode == 0, (args[:2],result.returncode,result.stderr.decode()[:1000])
    if result.returncode:
        return None
    return json.loads(result.stdout)['data']

def configuration():
    raw = (root/'run.toml').read_bytes()
    value = tomllib.loads(raw.decode())
    assert value['reliability']['max_attempts'] == 1
    assert value['reliability']['oracle_unit_timeout_s'] >= 600
    assert value['reliability']['index_timeout_s'] >= 43200
    assert value['resources'] == dict(data_ceiling_bytes=4*1024**3,free_reserve_bytes=30*1024**3,helper_rss_ceiling_bytes=512*1024**2)
    epoch = digest(raw)
    path = root/'epochs'/f'{epoch}.toml'
    if path.exists():
        assert path.read_bytes() == raw
    else:
        with path.open('xb') as stream:
            stream.write(raw);stream.flush();os.fsync(stream.fileno())
        fd=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(fd)
        finally:os.close(fd)
    return value,epoch

def progress(phase,completed,total,since,**extra):
    elapsed = time.monotonic()-since
    baseline = extra.pop('baseline',0)
    advanced = completed-baseline
    assert advanced >= 0
    value = dict(phase=phase,completed=completed,total=total,elapsed_s=elapsed,
        previous_completed=baseline,rate_per_s=advanced/elapsed if advanced else None,
        eta_s=elapsed*(total-completed)/advanced if advanced else None,
        config_epoch=epoch,process=admission['process'],**extra)
    publish(root/'progress.json',value)
    state.update(phase=phase,last_progress=value)
    publish(root/'state.json',state)

def sample():
    assert daemon.poll() is None, 'daemon exited'
    value = cli('daemon','status')
    group = value['resources']['cgroup']
    assert group['enforced'] and group['complete'], group
    assert group['daemon_group']['high_bytes'] == 512*1024**2
    assert group['daemon_group']['max_bytes'] == 640*1024**2
    assert group['service_total']['max_bytes'] == 2048*1024**2
    proc = {}
    for line in pathlib.Path(f'/proc/{daemon.pid}/status').read_text().splitlines():
        key,_,raw = line.partition(':')
        if key in ('VmRSS','VmHWM','RssAnon','RssFile','RssShmem','VmSwap'):
            proc[key] = int(raw.split()[0])*1024
    events = dict((k,int(v)) for k,v in (line.split() for line in (pathlib.Path(group['daemon_group']['path'])/'memory.events').read_text().splitlines()))
    disk = census(import_root/'data')
    allocated = disk['allocated_bytes']
    own = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024
    helper = None
    if provider is not None:
        assert provider.poll() is None, 'lookup exited'
        helper = {}
        for line in pathlib.Path(f'/proc/{provider.pid}/status').read_text().splitlines():
            key,_,raw = line.partition(':')
            if key in ('VmRSS','VmHWM'):helper[key]=int(raw.split()[0])*1024
    measurement = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),phase=state['phase'],
        resources=value['resources'],daemon_proc=proc,daemon_events=events,controller_peak_bytes=own,lookup=helper,
        allocated_data_bytes=allocated,disk_census=disk,free_bytes=shutil.disk_usage(root).free)
    metrics.write(json.dumps(measurement)+'\n');metrics.flush();os.fsync(metrics.fileno())
    assert proc['VmHWM'] <= 640*1024**2 and events['oom_kill'] == 0, ('daemon memory',measurement)
    assert own <= cfg['resources']['helper_rss_ceiling_bytes']
    assert helper is None or helper['VmHWM'] <= cfg['resources']['helper_rss_ceiling_bytes']
    assert allocated <= cfg['resources']['data_ceiling_bytes'] and measurement['free_bytes'] >= cfg['resources']['free_reserve_bytes']
    return value

def wait_job(name,deadline,indexing=False):
    started = time.monotonic()
    while True:
        job = cli('job','show',name)
        if job['state'] in ('succeeded','failed','cancelled'):
            publish(root/(name+'-terminal.json'),job)
            assert job['state'] == 'succeeded', (name,job.get('error'))
            return job
        assert time.time() < deadline, ('original job deadline expired',name)
        if indexing:
            status = cli('index','status')
            vector = status.get('vector') or {}
            progress('indexing',vector.get('indexed_rows',0),import_result['vector_cohort'],started,
                lexical_completed=status['indexed_rows'],lexical_total=import_result['claims'],index_status=status,baseline=initial_index['vector']['indexed_rows'])
            sample()
        time.sleep(5 if indexing else .05)

assert sys.argv[1:] == ['--run']
head = subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert head == 'a177d6e23568b627ec9eef593d88289bc8634041'
assert not subprocess.check_output(['git','status','--porcelain'])
assert all(os.environ.get(k) is None for k in ('LD_PRELOAD','MALLOC_MMAP_THRESHOLD_','GLIBC_TUNABLES','MALLOC_ARENA_MAX','LANCE_FTS_NUM_SHARDS','LANCE_FTS_PARTITION_SIZE'))
import_root = (W/'.spike-work/mvp024-production-import-r1').resolve(strict=True)
verified_path = E/'mvp024-production-import-prefix-r1-verified.json'
verified = json.loads(verified_path.read_text())
assert verified['status'] == 'PREFIX_IMPORT_VERIFIED_NOT_FULL_ACCEPTANCE' and verified['head'] == head
import_result = verified['import_result']
import_lock = (import_root/'controller.lock').open('a')
fcntl.flock(import_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
assert all(exact_absent(x) for x in verified['processes_absent'].values())
assert sha(import_root/'admission.json') == import_result['admission_sha256']
old = (W/'.spike-work/mvp024-production-prefix-index-r1').resolve(strict=True)
prior_path = E/'mvp024-production-prefix-index-r1-verified-failure.json'
prior = json.loads(prior_path.read_text())
assert prior['status'] == 'FAILED_DISAPPEARING_FILE_CENSUS_FULL_INDEX_UNVERIFIED'
assert prior['source_head'] == head and prior['original_exit_code'] == 1
assert all(exact_absent(x) for x in prior['processes_absent'].values())
assert sha(old/'oracles.json') == prior['oracles_sha256']
assert sha(old/'lookup-events.bin') == prior['lookup_audit_sha256']
assert sha(old/'daemon.toml') == prior['original_daemon_config_sha256']
assert time.time() < prior['original_index_admission']['deadline_unix_s']
for name,value in prior['data_members'].items():
    path = import_root/'data'/name
    assert path.stat().st_size == value['bytes'] and sha(path) == value['sha256']
units,chain,total = receipts(import_root,import_result['admission_sha256'],11428868)
assert chain == import_result['journal_chain_sha256'] and total == 65536
binding = json.loads((import_root/'binding.json').read_text())
manifest_path = W/'.spike-work/mvp024-full-preparation-source-r1/verified-manifest.json'
assert sha(manifest_path) == '88f767e86e790b0a1714b229bc0b3d047724ee7f2479596624c9daffacb9fd5d'
manifest = json.loads(manifest_path.read_text())
for name,value in manifest['code_sha256'].items():assert sha(W/'spikes/data'/name) == value
binary = (W/'target/release/akasha-otsuge').resolve(strict=True)
binary_sha = sha(binary)
assert binary_sha == '4c29824abf0e2466fae4e0c32e2f1a37d5635bd5621244f6ff1ab2fec4f8ac1e'
assert shutil.disk_usage(import_root).free >= 30*1024**3
root = (W/'.spike-work/mvp024-production-prefix-index-r2').resolve()
root.mkdir(mode=0o700)
(root/'OWNER').write_text('akasha-otsuge:mvp024-production-prefix-index-r2\n')
(root/'epochs').mkdir();(root/'current-units').mkdir()
socket_root = pathlib.Path(json.loads((old/'admission.json').read_text())['socket_root'])
assert not socket_root.exists()
socket_root.mkdir(mode=0o700)
endpoint = socket_root/'service.sock'
assert len(os.fsencode(endpoint)) < 108
config_text = '[reliability]\nmax_attempts=1\noracle_unit_timeout_s=1800\nindex_timeout_s=43200\n[resources]\ndata_ceiling_bytes=4294967296\nfree_reserve_bytes=32212254720\nhelper_rss_ceiling_bytes=536870912\n'
(root/'run.toml').write_text(config_text)
cfg,epoch = configuration()
admission = dict(head=head,tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],text=True).strip(),
    daemon_sha256=binary_sha,driver_sha256=sha(__file__),provider_sha256=sha(E/'mvp024-prefix-lookup-r2.py'),
    lookup_source_sha256=sha(W/'spikes/data/precomputed.py'),protocol_sha256=sha(E/'mvp024_import_protocol_r2.py'),
    census_sha256=sha(E/'mvp024_disk_census_r1.py'),prior_failure_sha256=sha(prior_path),
    original_absolute_index_deadline_unix_s=prior['original_index_admission']['deadline_unix_s'],
    continuation='Completed current/original units are reused without re-execution. Only unfinished index work continues in a new sync job after the prior job is confirmed INDEX_INTERRUPTED. This is not native job resume or full recovery acceptance.',
    verified_import_sha256=sha(verified_path),config_epoch=epoch,import_root=str(import_root),
    process=process_identity(os.getpid()),socket_root=str(socket_root),utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    limits='65536-record prefix only; default 512/640/2048 MiB enforced daemon/service limits; lookup/controller separately observed 512 MiB. No full-corpus/load/recovery acceptance.',
    recovery='No automatic retry or new effects on an existing run. Preserve original per-unit/job deadlines; reconcile existing durable IDs after interruption.',
    retention='Preserve the existing production import store for later index/oracles/resume; remove only the exact owned socket after consumers exit.')
publish(root/'admission.json',admission)
state = dict(phase='admitted',completed_units=[],admission_sha256=sha(root/'admission.json'))
publish(root/'state.json',state)
lookup_manifest = json.loads((W/'.spike-work/mvp024-precomputed-real-r1/manifest.json').read_text())
publish(root/'lookup-manifest.json',lookup_manifest)
(root/'lookup.toml').write_text('[resources]\nrss_ceiling_bytes=536870912\n[reliability]\nmax_attempts=5\nunit_timeout_s=3600\n')
provider = daemon = None
metrics = (root/'metrics.jsonl').open('x')
base = [str(binary),'--config',str(old/'daemon.toml'),'--socket',str(endpoint)]
old_ready = json.loads((old/'lookup-ready.json').read_text())
original_port = old_ready['address'][1]
result = None
try:
    with (root/'lookup.log').open('xb') as log:
        provider = subprocess.Popen(['nohup',sys.executable,str(E/'mvp024-prefix-lookup-r2.py'),str(root),head,str(original_port)],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    publish(root/'lookup-process.json',process_identity(provider.pid))
    lookup_deadline = time.time()+1800
    publish(root/'lookup-admission.json',dict(deadline_unix_s=lookup_deadline))
    while not (root/'lookup-ready.json').exists():
        assert provider.poll() is None, 'lookup failed before readiness'
        assert time.time() < lookup_deadline, 'lookup admission deadline'
        time.sleep(.2)
    ready = json.loads((root/'lookup-ready.json').read_text())
    assert ready['process']['pid'] == provider.pid
    assert ready['address'] == old_ready['address'] and ready['model'] == old_ready['model']
    (root/'daemon.toml').write_bytes((old/'daemon.toml').read_bytes())
    assert sha(root/'daemon.toml') == prior['original_daemon_config_sha256']
    with (root/'daemon.log').open('xb') as log:
        daemon = subprocess.Popen(['nohup',*base,'daemon','run'],stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    publish(root/'daemon-process.json',process_identity(daemon.pid))
    deadline = time.time()+120
    while not (endpoint.exists() and cli('daemon','status',required=False)):
        assert daemon.poll() is None and time.time() < deadline, 'daemon admission failed'
        time.sleep(.1)
    observed = {}
    for item in pathlib.Path(f'/proc/{daemon.pid}/environ').read_bytes().split(b'\0'):
        key,sep,value = item.partition(b'=')
        if key in (b'LANCE_FTS_NUM_SHARDS',b'LANCE_FTS_PARTITION_SIZE',b'MALLOC_ARENA_MAX',b'MALLOC_MMAP_THRESHOLD_',b'LD_PRELOAD',b'GLIBC_TUNABLES'):
            observed[key.decode()] = value.decode()
    assert observed == dict(LANCE_FTS_NUM_SHARDS='1',LANCE_FTS_PARTITION_SIZE='32',MALLOC_ARENA_MAX='2')
    publish(root/'daemon-environment.json',observed)
    publish(root/'initial-status.json',sample())
    previous_job = cli('job','show','prefix-index-r1')
    publish(root/'previous-job.json',previous_job)
    assert previous_job['state'] == 'failed' and previous_job['error'] == 'INDEX_INTERRUPTED', ('prior job needs classification',previous_job['state'],previous_job.get('error'))
    initial_index = cli('index','status')
    publish(root/'reopened-index.json',initial_index)
    assert initial_index['indexed_rows'] < total and initial_index['vector']['indexed_rows'] < import_result['vector_cohort']
    old_events = (old/'lookup-events.bin').read_bytes()
    assert len(old_events)%64 == 0
    replay_count = len(old_events)//64-initial_index['vector']['indexed_rows']
    assert 0 <= replay_count <= 32, ('unclassified prior embedding duplication',replay_count)
    oracles = json.loads((old/'oracles.json').read_text())
    witnesses = oracles['vector_witnesses'];lexical = oracles['lexical_witnesses']
    source_count = oracles['sources'];claim_count = oracles['claims']
    assert source_count == claim_count == total
    for name,expected in prior['current_unit_sha256'].items():assert sha(old/'current-units'/name) == expected
    expected_pairs = [];stats = {};read_start = time.monotonic()
    iterator = records(W/'.spike-work/corpus-full-v1',manifest['source_counts'],stats,root/'source-progress.json')
    progress('revalidate_completed_input_only',0,total,read_start)
    try:
        for number,original in enumerate(iterator,1):
            if (number-1)%4096 == 0:unit_hash = hashlib.sha256()
            row = project(original);unit_hash.update(encode(row)+b'\n')
            if row['vector_cohort']:
                expected_pairs.append(hashlib.sha256(row['body'].encode()).digest()+vector_fingerprint(original['embedding']))
            if number%4096 == 0:
                assert unit_hash.hexdigest() == units[(number-1)//4096]['input_sha256']
                progress('revalidate_completed_input_only',number,total,read_start)
            if number == total:break
    finally:iterator.close()
    assert number == total and len(expected_pairs) == oracles['vector_pairs']
    assert digest(b''.join(expected_pairs)) == oracles['vector_pair_stream_sha256']
    assert len(set(expected_pairs)) == len(expected_pairs)
    old_pairs = [old_events[i:i+64] for i in range(0,len(old_events),64)]
    assert not (collections.Counter(old_pairs)-collections.Counter(expected_pairs))
    publish(root/'reused-oracles.json',dict(original_oracles_sha256=prior['oracles_sha256'],original_current_unit_sha256=prior['current_unit_sha256'],
        imported_source_prefix_revalidated=True,source_or_current_reads_reexecuted=False,prior_provider_calls=len(old_pairs),
        prior_published_vector_rows=initial_index['vector']['indexed_rows'],possible_unwatermarked_vectors=replay_count))
    state['completed_units'].append('prior_current_and_original_reused');publish(root/'state.json',state)
    cfg,epoch = configuration()
    name = 'prefix-index-continue-r1';deadline = prior['original_index_admission']['deadline_unix_s']
    assert time.time() < deadline
    publish(root/'index-admission.json',dict(id=name,deadline_unix_s=deadline,config_epoch=epoch,utc=datetime.datetime.now(datetime.timezone.utc).isoformat()))
    index_start = time.monotonic()
    cli('index','sync','--idempotency-key',name)
    wait_job(name,deadline,indexing=True)
    index_seconds = time.monotonic()-index_start
    status = cli('index','status')
    assert status['indexed_rows'] == claim_count and status['vector']['indexed_rows'] == len(expected_pairs)
    audit = (root/'lookup-events.bin').read_bytes()
    assert len(audit)%64 == 0
    new_pairs = [audit[i:i+64] for i in range(0,len(audit),64)]
    aggregate = collections.Counter(old_pairs)+collections.Counter(new_pairs)
    expected_counter = collections.Counter(expected_pairs)
    assert not (expected_counter-aggregate), 'expected input-vector pair missing'
    assert not (set(aggregate)-set(expected_counter)), 'unexpected input-vector pair'
    extra = aggregate-expected_counter
    assert sum(extra.values()) == replay_count
    assert not (extra-collections.Counter(old_pairs[-32:])), 'repeat outside prior interrupted batch'
    assert len(old_pairs)+len(new_pairs) == len(expected_pairs)+replay_count
    publish(root/'embedding-replay-reconciliation.json',dict(prior_calls=len(old_pairs),new_calls=len(new_pairs),
        expected_unique_vectors=len(expected_pairs),observed_replays=replay_count,all_pairs_match=True,
        original_audit_sha256=digest(old_events),new_audit_sha256=digest(audit)))
    publish(root/'index-coverage.json',dict(status=status,index_seconds=index_seconds,expected_vectors=len(expected_pairs),
        actual_vectors=len(expected_counter),provider_calls_in_this_attempt=len(audit)//64,exact_unique_input_vector_set=True,classified_replays=replay_count,index_audit_sha256=digest(audit)))
    state['completed_units'].append('index');publish(root/'state.json',state)
    search_receipts = []
    for kind,selected in [('lexical',lexical),('vector',witnesses)]:
        for partition,expected in sorted(selected.items()):
            scope_path = root/f'{kind}-{partition}-scope.json';publish(scope_path,expected['scope'])
            name = f'prefix-{kind}-{partition}'
            cli('search',expected['query'],'--scope',scope_path,'--idempotency-key',name)
            job = wait_job(name,time.time()+120)
            output = json.loads(job['result']['output']);items = [item['memory'] for item in output['items']]
            assert any(item['revision']['key']['id']==expected['id'] and item['revision']['commit_seq']==expected['revision'] for item in items), ('self-hit missing',kind,partition)
            assert all(item['record']['draft']['scope']==expected['scope'] for item in items)
            if kind == 'vector':assert output['mode']=='hybrid'
            search_receipts.append(dict(kind=kind,partition=partition,id=expected['id'],receipt_id=job['result']['receipt_id'],mode=output['mode']))
        assert (root/'lookup-events.bin').stat().st_size == len(audit)+64*(8 if kind=='vector' else 0)
    publish(root/'search-coverage.json',search_receipts)
    publish(root/'final-status.json',sample())
    assert sha(binary) == binary_sha and subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip() == head
    assert not subprocess.check_output(['git','status','--porcelain'])
    result = dict(status='PREFIX_INDEX_CONTINUATION_PASS_NOT_FULL_ACCEPTANCE',sources=source_count,claims=claim_count,vectors=len(expected_pairs),
        continuation_index_seconds=index_seconds,current_and_original_units_reused=len(units),search_witnesses=len(search_receipts),retained_import_store=str(import_root/'data'),
        original_failure_preserved=True,original_absolute_deadline_unix_s=deadline,classified_embedding_replays=replay_count,
        wall_span_from_first_index_admission_s=time.time()-datetime.datetime.fromisoformat(prior['original_index_admission']['utc']).timestamp())
    state['completed_units'].append('search');state['phase']='awaiting_shutdown'
except BaseException as error:
    state.update(phase='failed',error=dict(type=type(error).__name__,message=str(error)[:3000]))
    publish(root/'failure.json',state)
    raise
finally:
    cleanup_errors = []
    for name,child in [('daemon',daemon),('lookup',provider)]:
        try:
            if child is not None and child.poll() is None:
                if name == 'daemon':cli('daemon','stop',required=False)
                else:child.send_signal(signal.SIGTERM)
                try:child.wait(timeout=120)
                except subprocess.TimeoutExpired:
                    publish(root/f'{name}-shutdown-timeout.json',dict(pid=child.pid,action='SIGTERM after original 120-second graceful drain'))
                    child.send_signal(signal.SIGTERM);child.wait(timeout=180)
            publish(root/f'{name}-process-terminal.json',dict(exit_code=None if child is None else child.returncode))
        except BaseException as error:
            cleanup_errors.append(dict(process=name,type=type(error).__name__,message=str(error)))
    metrics.flush();os.fsync(metrics.fileno());metrics.close()
    try:
        assert not cleanup_errors, cleanup_errors
        for child in (daemon,provider):
            if child is not None:assert child.poll() is not None
        entries = list(socket_root.iterdir())
        assert all(path.name in ('daemon.lock','service.sock') for path in entries), [p.name for p in entries]
        if (socket_root/'daemon.lock').exists():
            handle=(socket_root/'daemon.lock').open('a');fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB)
        for path in entries:path.unlink()
        socket_root.rmdir()
        if result is not None:
            assert daemon.returncode == 0 and provider.returncode == 0
            lookup_terminal=json.loads((root/'lookup-terminal.json').read_text())
            assert lookup_terminal['phase']=='stopped' and lookup_terminal['snapshot']['failed_requests']==0
            assert lookup_terminal['audit_bytes']==len(audit)+64*8
            result.update(socket_removed=not socket_root.exists(),lookup_terminal_sha256=sha(root/'lookup-terminal.json'))
            publish(root/'result.json',result);state['phase']='complete'
            progress('complete',total,total,read_start)
    except BaseException as error:
        state.update(phase='failed',cleanup_error=dict(type=type(error).__name__,message=str(error)))
        publish(root/'cleanup-failure.json',state)
        raise
    finally:publish(root/'state.json',state)
print(json.dumps(result))
