"""Seal an intentionally discontinued native prefix without claiming full acceptance."""
import datetime,fcntl,hashlib,json,math,os,pathlib,shutil,stat,subprocess,sys,time
sys.dont_write_bytecode=True
W,E=pathlib.Path.cwd(),pathlib.Path(__file__).parent
sys.path.insert(0,str(W/'spikes/helix'))
from run_case import publish,process_identity
R=(W/'.spike-work/mvp024-production-prefix-index-r2').resolve()
I=(W/'.spike-work/mvp024-production-import-r1').resolve()
OUT=(W/'.spike-work/mvp024-production-prefix-index-r2-seal-r1').resolve()
OUT.mkdir(mode=0o700);(OUT/'OWNER').write_text('akasha-otsuge:mvp024-production-prefix-index-r2-seal-r1\n')
def sha(path):
    with pathlib.Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='a177d6e23568b627ec9eef593d88289bc8634041'
assert not subprocess.check_output(['git','status','--porcelain'])
lock=(I/'controller.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
identities=dict(primary=json.loads((E/'mvp024-production-prefix-index-r2.launch.json').read_text())['process'],
    controller=json.loads((R/'admission.json').read_text())['process'],
    daemon=json.loads((R/'daemon-process.json').read_text()),lookup=json.loads((R/'lookup-process.json').read_text()))
for identity in identities.values():
    current=process_identity(identity['pid'])
    assert current is None or str(current['start_ticks'])!=str(identity['start_ticks'])
assert json.loads((E/'mvp024-production-prefix-index-r2.terminal.json').read_text())['exit_code']==1
job=json.loads((R/'prefix-index-continue-r1-terminal.json').read_text())
assert job['state']=='cancelled' and job['error']=='CANCELLED' and job['cancel_requested']
assert all(json.loads((R/(name+'-process-terminal.json')).read_text())['exit_code']==0 for name in ('daemon','lookup'))
assert not (R/'cleanup-failure.json').exists()
assert not pathlib.Path(json.loads((R/'admission.json').read_text())['socket_root']).exists()
failure=json.loads((R/'failure.json').read_text())
assert failure['completed_units']==['prior_current_and_original_reused']
assert not (R/'result.json').exists()
started=time.monotonic()
publish(OUT/'admission.json',dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),process=process_identity(os.getpid()),
    source_head='a177d6e23568b627ec9eef593d88289bc8634041',driver_sha256=sha(__file__),
    stopped_baseline_terminal_sha256=sha(E/'mvp024-production-prefix-index-r2.terminal.json'),
    cancellation_admission_sha256=sha(E/'mvp024-production-prefix-index-r2-parent-stop-admission.json'),
    input_manifest_sha256=sha(I/'admission.json'),max_attempts=1,scope='Read-only closed-store digest seal, no index or workload completion claim.'))
paths=sorted(p for p in (I/'data').rglob('*') if p.is_file())
inventory={};allocated=0
for number,path in enumerate(paths,1):
    before=path.lstat();assert stat.S_ISREG(before.st_mode) and not path.is_symlink()
    value=dict(bytes=before.st_size,allocated_bytes=before.st_blocks*512,sha256=sha(path))
    after=path.lstat();assert (before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_ino,after.st_size,after.st_mtime_ns)
    inventory[str(path.relative_to(I/'data'))]=value;allocated+=value['allocated_bytes']
    if number%256==0 or number==len(paths):
        elapsed=time.monotonic()-started
        publish(OUT/'progress.json',dict(phase='closed_store_hashes',completed=number,total=len(paths),elapsed_s=elapsed,
            rate_per_s=number/elapsed,eta_s=(len(paths)-number)*elapsed/number,process=process_identity(os.getpid())))
assert allocated<=4*1024**3 and shutil.disk_usage(I).free>=30*1024**3
samples=[]
with (R/'metrics.jsonl').open() as stream:
    for line in stream:
        assert line.endswith('\n');samples.append(json.loads(line))
assert samples
assert all(all(v['daemon_events'].get(k,0)==0 for k in ('oom','oom_kill','oom_group_kill')) for v in samples)
rss=sorted(v['daemon_proc']['VmRSS'] for v in samples)
lookup=json.loads((R/'lookup-terminal.json').read_text())
assert lookup['phase']=='stopped' and lookup['snapshot']['failed_requests']==0
assert (R/'lookup-events.bin').stat().st_size%64==0
control_files={name:dict(bytes=(R/name).stat().st_size,sha256=sha(R/name)) for name in (
    'admission.json','run.toml','daemon.toml','failure.json','state.json','progress.json',
    'metrics.jsonl','lookup-events.bin','lookup-terminal.json','prefix-index-continue-r1-terminal.json',
    'daemon-process.json','lookup-process.json','daemon-process-terminal.json','lookup-process-terminal.json')}
result=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='PARENT_STOPPED_INCOMPLETE_BASELINE_WITH_CLEAN_SHUTDOWN',
    source_head='a177d6e23568b627ec9eef593d88289bc8634041',job_state='cancelled',job_error='CANCELLED',
    stop_reason='Measured sustained reclaim and physical-read amplification; original deadline preserved; operator chose maintenance repair.',
    original_absolute_deadline_unix_s=json.loads((R/'admission.json').read_text())['original_absolute_index_deadline_unix_s'],
    last_observed_progress=failure['last_progress'],last_observed_is_not_offline_final_status=True,
    resource_samples=len(samples),sampled_rss_p99_bytes=rss[math.ceil(.99*len(rss))-1],sampled_rss_max_bytes=max(rss),
    sampled_vmhwm_max_bytes=max(v['daemon_proc']['VmHWM'] for v in samples),all_sampled_oom_zero=True,
    resource_coverage='Index-period samples only; no full workload, required duration, shutdown-tail or full acceptance claim.',
    lookup_terminal=lookup,partial_lookup_records=(R/'lookup-events.bin').stat().st_size//64,
    all_partial_lookup_pairs_independently_reconciled=False,
    retained_store=str(I/'data'),data_members=inventory,allocated_data_bytes=allocated,
    free_bytes=shutil.disk_usage(I).free,processes_absent=identities,socket_removed=True,
    receipts=control_files,prior_failure_preserved=True,full_index_verified=False,search_witnesses_executed=False,
    original_import_prefix='65536 sources imported and all current/original reads verified before indexing; unchanged authority source code.',
    collection_seconds=time.monotonic()-started)
publish(E/'mvp024-production-prefix-index-r2-verified-stopped.json',result)
publish(OUT/'result.json',dict(status=result['status'],evidence_sha256=sha(E/'mvp024-production-prefix-index-r2-verified-stopped.json'),
    files=len(inventory),allocated_data_bytes=allocated,elapsed_s=time.monotonic()-started))
print(json.dumps({k:v for k,v in result.items() if k not in ('data_members','receipts','last_observed_progress','lookup_terminal','processes_absent')},ensure_ascii=False))

