use arrow_array::{ArrayRef, FixedSizeListArray, RecordBatch, RecordBatchIterator, StringArray, UInt64Array, types::Float32Type};
use arrow_schema::{DataType, Field, Schema};
use futures::TryStreamExt;
use lancedb::{
    DistanceType, ObjectStoreRegistry, Session, Table,
    index::{Index as NativeIndex, scalar::BTreeIndexBuilder, vector::IvfFlatIndexBuilder},
    query::{ExecutableQuery, QueryBase, Select, VectorQuery},
    table::{OptimizeAction, OptimizeOptions},
};
use std::{cmp::Ordering, fs, path::Path, sync::Arc, time::Instant};

const ROWS: usize = 8192;
const DIM: usize = 384;
const WAVES: usize = 130;
const LIMIT: usize = 100;
fn values(row: usize) -> Vec<f32> {
    let mut seed = (row as u64 + 1).wrapping_mul(0x9e3779b97f4a7c15);
    (0..DIM).map(|_| {
        seed ^= seed >> 12; seed ^= seed << 25; seed ^= seed >> 27;
        let bits = seed.wrapping_mul(0x2545f4914f6cdd1d);
        ((bits >> 40) as f32 / (1_u32 << 23) as f32) - 1.0
    }).collect()
}
fn scope(row: usize) -> String { format!("{:064x}", row % 8) }
async fn build(table: &Table) {
    let schema = table.schema().await.unwrap();
    for wave in 0..WAVES {
        let r = wave*ROWS/WAVES..(wave+1)*ROWS/WAVES;
        let vector = FixedSizeListArray::from_iter_primitive::<Float32Type, _, _>(
            r.clone().map(|i| Some(values(i).into_iter().map(Some).collect::<Vec<_>>())), DIM as i32);
        let cols: Vec<ArrayRef> = vec![
            Arc::new(StringArray::from(r.clone().map(|i| format!("{i:064x}")).collect::<Vec<_>>())),
            Arc::new(StringArray::from(r.clone().map(|i| format!("row-{i}")).collect::<Vec<_>>())),
            Arc::new(UInt64Array::from(r.clone().map(|i| (1+i) as u64).collect::<Vec<_>>())),
            Arc::new(StringArray::from(r.clone().map(scope).collect::<Vec<_>>())),
            Arc::new(vector),
        ];
        let batch = RecordBatch::try_new(schema.clone(), cols).unwrap();
        let reader=Box::new(RecordBatchIterator::new(vec![Ok(batch)],schema.clone())) as Box<dyn arrow_array::RecordBatchReader+Send>;
        table.add(reader).execute().await.unwrap();
        if wave==0 {
            table.create_index(&["scope"],NativeIndex::BTree(BTreeIndexBuilder::default())).execute().await.unwrap();
            table.create_index(&["vector"],NativeIndex::IvfFlat(IvfFlatIndexBuilder::default().num_partitions(5).distance_type(DistanceType::Cosine).sample_rate(16).max_iterations(20))).execute().await.unwrap();
        } else {
            table.optimize(OptimizeAction::Index(OptimizeOptions::append())).await.unwrap();
        }
    }
}
fn query(table: &Table, v: &[f32], mode: &str, project: usize) -> VectorQuery {
    let q=table.query().only_if(format!("scope = '{}'",scope(project))).select(Select::Columns(vec!["id".into(),"revision".into()]))
        .limit(LIMIT).nearest_to(v).unwrap().distance_type(DistanceType::Cosine).nprobes(16);
    match mode { "pre"|"cpu2" => q, "post" => q.postfilter(), "flat"=>q.bypass_vector_index(), "adaptive"=>q.minimum_nprobes(1).unwrap(), _ => panic!("mode") }
}
fn top(project:usize, q:&[f32]) -> Vec<usize> {
    let mut scores:Vec<_>=(project..ROWS).step_by(8).map(|r|{
        let v=values(r);let d:f64=v.iter().zip(q).map(|(a,b)| f64::from(*a)*f64::from(*b)).sum();
        let norm=v.iter().map(|x| f64::from(*x).powi(2)).sum::<f64>().sqrt();
        (r,d/norm)
    }).collect();
    scores.sort_by(|(a,x),(b,y)| y.partial_cmp(x).unwrap_or(Ordering::Equal).then(a.cmp(b)));scores.into_iter().take(LIMIT).map(|(id,_)|id).collect()
}
fn main(){
    tokio::runtime::Builder::new_current_thread().enable_all().build().unwrap().block_on(run());
}
fn snapshot() -> serde_json::Value {
    let cgroups=fs::read_to_string("/proc/self/cgroup").unwrap();
    let rel=cgroups.lines().find_map(|line|line.strip_prefix("0::")).unwrap();
    let group=Path::new("/sys/fs/cgroup").join(rel.trim_start_matches('/'));
    serde_json::json!({
        "proc_io":fs::read_to_string("/proc/self/io").unwrap(),
        "status":fs::read_to_string("/proc/self/status").unwrap().lines().filter(|x| ["VmRSS:","VmHWM:","RssAnon:","RssFile:","Threads:"].iter().any(|k|x.starts_with(k))).collect::<Vec<_>>(),
        "memory_current":fs::read_to_string(group.join("memory.current")).unwrap().trim(),
        "memory_peak":fs::read_to_string(group.join("memory.peak")).unwrap().trim(),
        "memory_events":fs::read_to_string(group.join("memory.events")).unwrap(),
        "memory_pressure":fs::read_to_string(group.join("memory.pressure")).unwrap(),
    })
}
fn stage(msg: &str) {
    eprintln!("phase {msg} {:?}", std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap());
}
async fn run() {
    stage("process-entered");
    let args:Vec<_>=std::env::args().collect();let phase=&args[1];let root=Path::new(&args[2]);let out=Path::new(&args[3]);
    assert_eq!(fs::read_to_string(root.join("OWNER")).unwrap(),"akasha-otsuge:mvp024-query-memory-fixture-r1\n");
    let bytes=512_usize<<20;
    let session=Session::new(bytes/32,bytes/64,Arc::new(ObjectStoreRegistry::default())).with_spill_store(Arc::new(lance_io::spill::LocalSpillStore::with_cap((bytes/8)as u64).unwrap()));
    stage("open-connection");
    let db=lancedb::connect(root.join("store130").to_str().unwrap()).session(Arc::new(session)).execute().await.unwrap();
    if phase=="build" {
        let schema=Arc::new(Schema::new(vec![Field::new("key",DataType::Utf8,false),Field::new("id",DataType::Utf8,false),Field::new("revision",DataType::UInt64,false),Field::new("scope",DataType::Utf8,false),Field::new("vector",DataType::FixedSizeList(Arc::new(Field::new("item",DataType::Float32,true)),DIM as i32),false)]));
        let t=db.create_empty_table("vectors",schema).execute().await.unwrap();
        build(&t).await;let index=t.list_indices().await.unwrap().into_iter().find(|idx|idx.columns==["vector"]).unwrap();
        let stats=t.index_stats(&index.name).await.unwrap().unwrap();assert_eq!(stats.num_indexed_rows,ROWS);assert_eq!(stats.num_unindexed_rows,0);
        println!("indexed={} unindexed={} stats={stats:?}", stats.num_indexed_rows,stats.num_unindexed_rows);return;
    }
    stage("open-table");
    let table=db.open_table("vectors").execute().await.unwrap(); stage("table-opened");let mut receipts=Vec::new();
    for project in 0..1 {
        let v=values(ROWS+project);let initial=snapshot(); let before=Instant::now();
        stage("native-query-execute");
        let stream=query(&table,&v,phase,project).execute().await.unwrap();
        stage("native-result-stream");
        let batches=stream.try_collect::<Vec<_>>().await.unwrap();
        stage("native-rows-collected");
        let elapsed=before.elapsed().as_secs_f64();let final_state=snapshot();
        let mut actual=Vec::new();
        for b in &batches{
            let ids=b.column_by_name("id").unwrap().as_any().downcast_ref::<StringArray>().unwrap();
            let revisions=b.column_by_name("revision").unwrap().as_any().downcast_ref::<UInt64Array>().unwrap();
            for row in 0..b.num_rows() {
                let id:usize=ids.value(row).strip_prefix("row-").unwrap().parse().unwrap();assert_eq!(id%8,project);assert_eq!(revisions.value(row),id as u64+1);
                assert!(!actual.contains(&id));actual.push(id)
            }
        }
        let expected=top(project,&v);let matches=actual.iter().filter(|id|expected.contains(id)).count();
        if phase=="pre"||phase=="cpu2"||phase=="flat" {assert_eq!(matches,LIMIT);}
        if project==0 {
            let q=query(&table,&v,phase,project);fs::write(out.join(format!("{phase}-plan.txt")),q.explain_plan(true).await.unwrap()).unwrap();
        }
        receipts.push(serde_json::json!({"scope":project,"elapsed_s":elapsed,"initial":initial,"query_complete":final_state,"count":actual.len(),"oracle_overlap":matches,"ids":actual}));
    }
    fs::write(out.join(format!("{phase}-results.json")),serde_json::to_vec_pretty(&receipts).unwrap()).unwrap();
}
