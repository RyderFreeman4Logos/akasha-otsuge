# R3 prefix measurements and replay

The recorded daemon came from commit `4b9545216449d0ea6202785ae1e748f0711f8ffa`, tree `0dab27c263f5ff0745189910b9feb6de5e65257d`. The prefix used 65,536 DBpedia sources. The production run finished its index and eight keyword jobs. The client then timed out observing the first hybrid job, and the daemon required SIGKILL. A separate session reopened the same index and verified eight hybrid results. The first job was durable and recovered as `failed/PROVIDER_INTERRUPTED`.

## Verify the published measurements

Extract the archive into an empty directory and run `python3 verify.py` there. Python 3.11 or later checks every member against `manifest.json`, recomputes nearest-rank RSS P99 and I/O deltas from 1,350 samples, and compares exact top-20 revisions to the first 20 native candidates for 32 queries. Each row in the sample CSV records cumulative process I/O counters in bytes. The 32 query keys are identified by SHA-256. Revisions identify individual memories in this sealed prefix.

To verify the original controller receipts and every candidate ID and scope against retained data, use the following commands from the extracted directory. Set `EVIDENCE` to the local receipt directory and `SCRATCH` to the retained experiment workspace. `--corpus` requires PyArrow. The exact-cosine replay accepts the original 32-query binary or a byte-identical reconstruction from public data. It streams both public source shards into the included Rust reference and keeps about 65,000 identifiers in RAM. No database is opened.

```sh
python3 verify.py --evidence-root "$EVIDENCE" --scratch-root "$SCRATCH"
rustc --edition=2024 -O ann_oracle.rs -o exact-cosine
python3 verify.py --corpus "$SCRATCH/corpus-full-v1" --oracle ./exact-cosine \
  --query-input "$SCRATCH/ann-oracle-full-v1/query-input.bin"
```

For a public-data replay, obtain the two prefix shards and the query shards listed in `observations.json` at the recorded dataset revision. Use their `local` filenames. Run `python3 restore-queries.py SHARD_DIR query-input.bin` to regenerate the query keys and vector bytes. It checks every selected key and float32 vector against its individual digest, then checks the whole binary. Use this file with `--query-input` and the shard directory with `--corpus`. The verifier checks their entire SHA-256, reconstructs the ordered input/vector digest, verifies all 3,200 candidate IDs and their scopes, then compares every rank of the 32 reference lists. The published slice contains revision numbers and hashes. Original text, query vectors and embedding outputs remain in the operator's data.

## Reproduce the 130-delta staged control

Use a disposable checkout at the recorded commit with its pinned Cargo.lock, Linux cgroup v2 and a user systemd instance. Set `PACKAGE` to the extracted directory and `FIXTURE` to a new writable directory. The commands build the included measured Rust probe, generate 8,192 deterministic 384-dimensional rows across eight scopes and run the first scoped ANN query in separate processes. The fixture creates 130 IVF deltas and uses a top-100 exact-cosine reference. The temporary checkout is the only checkout updated by these instructions.

```sh
mkdir -p examples
cp "$PACKAGE/replay130.rs" examples/prefix_control_130.rs
cargo build --locked --release --example prefix_control_130
PROBE="$(pwd)/target/release/examples/prefix_control_130"
mkdir "$FIXTURE"
printf '%s\n' 'akasha-otsuge:mvp024-query-memory-fixture-r1' > "$FIXTURE/OWNER"
mkdir "$FIXTURE/build"
systemd-run --user --scope --quiet -p MemoryHigh=512M -p MemoryMax=640M -p MemorySwapMax=0 \
  "$PROBE" build "$FIXTURE" "$FIXTURE/build"
systemd-run --user --scope --quiet -p MemoryHigh=512M -p MemoryMax=640M -p MemorySwapMax=0 \
  python3 "$PACKAGE/control.py" "$PROBE" "$FIXTURE" "$FIXTURE/normal"
systemd-run --user --scope --quiet -p MemoryHigh=512M -p MemoryMax=640M -p MemorySwapMax=0 \
  python3 "$PACKAGE/control.py" "$PROBE" "$FIXTURE" "$FIXTURE/pressure" --pressure
```

The staged control used a 65-second bound and a 488 MiB touched allocation in the pressured process group. The earlier paired control used a 105-second bound. Each run used a fresh process and Lance session, while the kernel page cache stayed shared. The resource composition, dimensions and number of rows differ from the real daemon. An interrupted observation yields a censored duration. Host timing can vary on replay.

## Native run custody

Only the original operator can audit the closed database inventories, the sampled cgroups and the full provider event files using the retained workspace. The rebuild used `index rebuild --idempotency-key prefix-index-rebuild-r3`. The reopened daemon issued eight fresh scoped `search QUERY --scope FILE --idempotency-key KEY` jobs. The independent read-only ANN measurement used the ignored test `retrieval::vector::measure_prefix_ann_before_rank_fusion` under 1,792/2,048 MiB soft/hard limits, before rank fusion. The hot-query failure had no kernel observer during the affected interval. The four later kernel samples belong to the reopened run.

The hash inventory records the R3, recovery and scoring drivers and their raw input/output receipts under logical `evidence/` and `scratch/` paths. Running the optional local check compares bytes at exactly these paths. Full native builds, the live provider and the 50 GB / 100-client workload are outside the portable replay. The measured 131,072-row import has a separate seal. Its incremental index and search acceptance were pending at this measurement.
