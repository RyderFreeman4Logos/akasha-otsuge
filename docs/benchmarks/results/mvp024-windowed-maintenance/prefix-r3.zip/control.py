"""Run the staged synthetic query in a fresh, externally enforced cgroup."""
import argparse,json,os,subprocess,time
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('probe',type=Path);p.add_argument('fixture',type=Path);p.add_argument('output',type=Path)
p.add_argument('--pressure',action='store_true');a=p.parse_args()
rel=next(line[3:] for line in Path('/proc/self/cgroup').read_text().splitlines() if line.startswith('0::'))
cg=Path('/sys/fs/cgroup')/rel.lstrip('/')
assert int((cg/'memory.high').read_text())==512<<20 and int((cg/'memory.max').read_text())==640<<20
a.output.mkdir()
pressure=bytearray(488<<20 if a.pressure else 0)
for n in range(0,len(pressure),4096):pressure[n]=1
env=dict(os.environ,MALLOC_ARENA_MAX='2',LANCE_FTS_NUM_SHARDS='1',LANCE_FTS_PARTITION_SIZE='32')
env.pop('LANCE_CPU_THREADS',None)
def events():return {k:int(v) for k,v in (s.split() for s in (cg/'memory.events').read_text().splitlines())}
begin=events();t=time.monotonic()
with (a.output/'stage.log').open('xb') as log:
    child=subprocess.Popen([a.probe.resolve(),'pre',a.fixture.resolve(),a.output.resolve()],env=env,stdout=log,stderr=subprocess.STDOUT)
    censored=False
    try:code=child.wait(timeout=65)
    except subprocess.TimeoutExpired:
        censored=True;child.terminate()
        try:code=child.wait(timeout=10)
        except subprocess.TimeoutExpired:child.kill();code=child.wait()
end=events()
print(json.dumps(dict(exit=code,censored=censored,elapsed_s=time.monotonic()-t,pressure_bytes=len(pressure),
                    cgroup_peak_bytes=int((cg/'memory.peak').read_text()),event_deltas={k:end[k]-v for k,v in begin.items()})))
