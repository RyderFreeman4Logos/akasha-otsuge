"""Verify the publication without a database. Optional modes use the retained evidence or public source shards."""
import argparse
import collections
import csv
import hashlib
import json
import math
import os
import struct
import subprocess
import tempfile
from pathlib import Path

if not __debug__:
    raise SystemExit("verification requires Python assertions")
ROOT=Path(__file__).resolve().parent
def sha(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def enc(obj):return json.dumps(obj,ensure_ascii=False,separators=(',',':')).encode()
def digest(raw):return hashlib.sha256(raw).hexdigest()
def package_manifest():
    manifest=json.loads((ROOT/'manifest.json').read_bytes())
    assert set(manifest)=={p.name for p in ROOT.iterdir() if p.is_file() and p.name!='manifest.json'}
    for name,bound in manifest.items():
        p=ROOT/name
        assert not p.is_symlink() and p.stat().st_size==bound['bytes'] and sha(p)==bound['sha256'],name
def offline(j):
    totals=collections.Counter()
    assert len(j['ann']['queries'])==32
    for query in j['ann']['queries']:
        exact,candidates=query['exact_revisions'],query['candidate_revisions']
        assert len(set(exact))==len(exact)==20 and len(set(candidates))==len(candidates)==100
        hits=len(set(exact)&set(candidates[:20]))
        assert hits==query['hits']
        totals[query['project']]+=hits
    assert totals=={f'p{i}':80 for i in range(8)}
    assert sum(totals.values())==j['ann']['hits']==640
    with (ROOT/'index-samples.csv').open(newline='') as f:
        samples=[[int(n) for n in row] for row in list(csv.reader(f))[1:]]
    assert len(samples)==j['resources']['samples']==1350
    def percentile(c):return sorted(s[c] for s in samples)[math.ceil(.99*len(samples))-1]
    for col,name in [(1,'group_rss'),(2,'service_rss'),(3,'leader_rss')]:
        assert j['resources'][name]=={'p99_bytes':percentile(col),'max_bytes':max(v[col] for v in samples)}
    assert max(v[4] for v in samples)==j['resources']['leader_hwm_max']
    assert all(v[7:]==[0,0,0] for v in samples)
    assert all(x[0]<=y[0] and x[5]<=y[5] and x[6]<=y[6] for x,y in zip(samples,samples[1:]))
    assert samples[-1][5]-samples[0][5]==j['resources']['io_physical_read_delta']
    assert samples[-1][6]-samples[0][6]==j['resources']['io_physical_write_delta']
    assert math.isclose(max(b[0]-a[0] for a,b in zip(samples,samples[1:]))/1e6,j['resources']['max_sample_gap_s'],abs_tol=.000002)
    index=j['index'];failure=j['hot_search'];rec=j['reopened_search'];growth=j['growth']
    assert (index['indexed_rows'],index['vector_rows'],index['watermark'],index['eligible_vectors'])==(65536,65531,225057,65531)
    assert index['audit_bytes']==65532*64 and index['prefix_audit_sha256']==j['source']['pair_stream_sha256']
    assert len(j['keywords'])==8 and len({r['case'] for r in j['keywords']})==8
    assert failure['client_error']=='IPC_TIMEOUT' and failure['forced_stop']==['SIGTERM','SIGKILL'] and failure['daemon_exit']==-9
    assert rec['old_state']=='failed' and rec['old_error']=='PROVIDER_INTERRUPTED'
    assert sorted(q['partition'] for q in rec['jobs'])==[f'p{i}' for i in range(8)]
    assert all(q['mode']=='hybrid' and q['state']=='succeeded' and q['generation']==index['vector_generation'] for q in rec['jobs'])
    assert j['ann']['table']=='memory_vector_'+index['vector_generation'] and j['ann']['version']==4491
    assert growth['records']==growth['claims']==131072 and growth['units']==32 and growth['vector_cohort']==131063
    assert growth['incremental_index_pending'] and growth['after_search_digest']==growth['before_search_digest']
    for k in ('paired','staged'):
        normal,pressure=j['control'][k]
        assert (normal['exit'],normal['top100_oracle_hits'])==(0,[100])
        assert pressure['exit']==-15 and pressure['helper_process_anon_base']==488*2**20 and pressure['memory_events']['oom_kill']==0
    print('1350 index samples, 8 keyword jobs, 8 reopened hybrid jobs, ANN recall@20 640/640, and 131072 authority records')
def local(j,ev,scratch):
    for ref,bound in j['files'].items():
        group,rel=ref.split('/',1);root=ev if group=='evidence' else scratch
        assert group in ('evidence','scratch') and sha(root/rel)==bound,ref
    path=scratch/'mvp024-production-prefix-rebuild-r3/lookup-events.bin'
    raw=path.read_bytes()
    assert len(raw)==j['index']['audit_bytes'] and digest(raw[:-64])==j['index']['prefix_audit_sha256']
    assert len({raw[k:k+32] for k in range(0,len(raw)-64,64)})==65531
    print('Local controller, seal and observer file hashes match. Original 65531 index pairs are unique.')
def source(j,path,oracle,queries):
    import pyarrow.parquet as pq
    from contextlib import ExitStack
    seen={};audit=hashlib.sha256();n=0
    key_to_rev={};nearest={}
    with tempfile.TemporaryDirectory() as work, ExitStack() as contexts:
        temp=Path(work);proc=None
        if oracle:
            assert sha(queries)==j['source']['query_input_sha256']
            (temp/'unit-0.bin').symlink_to('/dev/stdin')
            output=contexts.enter_context((temp/'exact.tsv').open('wb'))
            proc=subprocess.Popen([str(oracle.resolve()),str(queries.resolve()),str(temp),'1','65531',str(temp/'progress.json')],stdin=subprocess.PIPE,stdout=output)
            contexts.callback(lambda: (proc.kill(),proc.wait()) if proc.poll() is None else None)
            proc.stdin.write(struct.pack('<I',65531))
        for pin in j['source']['shards']:
            f=path/pin['local'];assert f.stat().st_size==pin['size'] and sha(f)==pin['sha256']
            col='text-embedding-3-large-1536-embedding'
            for batch in pq.ParquetFile(f,pre_buffer=False).iter_batches(batch_size=64,columns=['_id','title','text',col]):
                for row in batch.to_pylist():
                    n+=1
                    key='dbpedia:'+row['_id'];k=key.encode();part=hashlib.sha256(k).digest()[0]%8
                    body=(row['title']+'\n'+row['text']).encode()
                    if len(body)<=4096:
                        vec=struct.pack('<1536f',*row[col])
                        audit.update(hashlib.sha256(body).digest()+hashlib.sha256(vec).digest())
                        bind=j['source']['binding'];bound=enc({'source_manifest_sha256':bind['source_manifest_sha256'],'observed_time_ms':bind['observed_time_ms']}).decode()
                        sid='corpus/'+digest(enc([bound,key]))+'/0';rev=2*n+1;seen[rev]=(sid,part)
                        if proc:
                            key_to_rev[key]=rev
                            proc.stdin.write(struct.pack('<BH',part,len(k))+k+vec)
                    if n==65536:break
                if n==65536:break
            if n==65536:break
        assert n==65536 and len(seen)==65531 and audit.hexdigest()==j['source']['pair_stream_sha256']
        if proc:
            proc.stdin.close();assert proc.wait()==0
            for line in (temp/'exact.tsv').read_text().splitlines():
                number,rank,hex_key,_=line.split('\t')
                ranks=nearest.setdefault(int(number),[])
                assert int(rank)==len(ranks)
                ranks.append(key_to_rev[bytes.fromhex(hex_key).decode()])
        for number,q in enumerate(j['ann']['queries']):
            p=int(q['project'][1:]);pairs=[]
            for rev in q['candidate_revisions']:
                ident,scope=seen[rev];assert scope==p;pairs.append([ident,rev])
            assert digest(enc(pairs))==q['candidate_id_revision_sha256']
            if proc:assert nearest[number]==q['exact_revisions']
    print('Source pair stream and all raw ANN candidate identities/scopes match.'+(' All 32 exact cosine lists match.' if oracle else ''))
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--corpus',type=Path);p.add_argument('--oracle',type=Path);p.add_argument('--query-input',type=Path)
p.add_argument('--evidence-root',type=Path);p.add_argument('--scratch-root',type=Path)
a=p.parse_args()
if bool(a.evidence_root)!=bool(a.scratch_root) or bool(a.query_input)!=bool(a.oracle) or (a.oracle and not a.corpus):p.error('supply both local roots or both oracle arguments and a corpus')
package_manifest();data=json.loads((ROOT/'observations.json').read_bytes());offline(data)
if a.evidence_root:local(data,a.evidence_root,a.scratch_root)
if a.corpus:source(data,a.corpus,a.oracle,a.query_input)
