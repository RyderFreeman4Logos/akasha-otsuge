"""Reconstruct the 32 frozen vectors from the named public parquet rows."""
import argparse,hashlib,json,struct
from pathlib import Path
import pyarrow.parquet as pq

p=argparse.ArgumentParser(description=__doc__);p.add_argument('shards',type=Path);p.add_argument('new_query_input',type=Path)
args=p.parse_args();j=json.loads((Path(__file__).parent/'observations.json').read_text());out=[None]*32
assert not args.new_query_input.exists()
col='text-embedding-3-large-1536-embedding'
for pin in j['source']['query_shards']:
    wanted={r['source_row']:(i,r) for i,r in enumerate(j['ann']['queries']) if r['source_file']==pin['local']}
    assert wanted
    source=args.shards/pin['local'];assert source.stat().st_size==pin['size']
    table=pq.ParquetFile(source,pre_buffer=False);ordinal=0
    for batch in table.iter_batches(batch_size=64,columns=['_id',col]):
        for row in batch.to_pylist():
            if ordinal in wanted:
                i,q=wanted.pop(ordinal)
                key=('dbpedia:'+row['_id']).encode()
                vector=struct.pack('<1536f',*row[col])
                assert hashlib.sha256(key).hexdigest()==q['query_key_sha256']
                assert hashlib.sha256(vector).hexdigest()==q['query_vector_sha256']
                out[i]=struct.pack('<BH',int(q['project'][1:]),len(key))+key+vector
            ordinal+=1
        if not wanted:break
    assert not wanted
data=struct.pack('<I',len(out))+b''.join(out)
assert hashlib.sha256(data).hexdigest()==j['source']['query_input_sha256']
with args.new_query_input.open('xb') as f:f.write(data)
print(f'{len(out)} frozen vectors, {len(data)} bytes, SHA-256 {hashlib.sha256(data).hexdigest()}')
