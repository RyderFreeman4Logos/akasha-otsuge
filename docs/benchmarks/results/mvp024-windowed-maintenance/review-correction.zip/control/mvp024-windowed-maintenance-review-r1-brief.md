Perform one independent conventional code review now. Do not stop at a plan.
Use the native-code-review skill directly. Hermes already failed earlier in this
task; do not retry it, spawn another reviewer, or start Daybreak/red-team work.

Repository: /mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025
Range: origin/main...HEAD, frozen base a177d6e23568b627ec9eef593d88289bc8634041
Head: c861c262518d43d92d2b861318e48989dcee5f9a
Tree: e952f5888a30ab5e1df318034086b2980ee335a7
Scope: four Rust paths plus directly related baseline evidence, prior publication
receipts and TODO. The parent scope and canonical receipt are immutable inputs:
/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/.git/akasha-evidence/mvp024-windowed-maintenance-parent-scope-r1.json
/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/.git/akasha-evidence/mvp024-windowed-maintenance-parent-instructions-r1.json
/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/.git/akasha-evidence/mvp024-windowed-maintenance-canonical-r1-verified.json

Before source inspection, verify applicable live AGENTS.md, AGENTS.override.md and
CLAUDE.md paths through their symlinks. The parent checked 255 candidate paths and
found none. Independently check the relevant paths. Do not overwrite parent inputs.
Re-attest branch, base, HEAD, tree, clean status, patch digest and canonical log hash.
Do not repeat the entire canonical gate or create another worktree or build target.

The behavior change moves per-batch native index optimization to maintenance after
32 existing publication windows, or at completion. Each authority window stays at
32 transactions. Compaction precedes index optimization. A per-table native-version
cache skips repeated maintenance for metadata-only work. The daemon serializes Sync
and Rebuild through index_builder. Old-version pruning still requires exclusive
cache ownership; compaction itself can coexist with readers.

Audit the actual callers, vector lifecycle, query behavior for unindexed rows,
authorization/cancellation/lease checks, restart and partial maintenance semantics,
version-cache invalidation, writer/read concurrency and bounded resource options.
Read the pinned native API implementation when needed. Check what the regression
actually proves, including unchanged authority progress and old-version readers.
Do not assume the small diagnostics prove production-scale memory or performance.

The prior 65,536-source baseline was deliberately cancelled after sustained reclaim
and read amplification. It is not a passing baseline. The retained closed store is
sealed separately. The old fragmented index needs a native Rebuild after this leaf.
Full corpus, 100-client duration, changed-source importer transition and ANN recall
remain open. Check evidence claims, archive digests/membership and representative
underlying result fields. Full raw child transcripts are not review inputs.

The exact canonical gate must have PASS before this process starts. Its receipt
provides the compiled test artifact identity. Prefer a focused fresh execution of
that exact native test binary under this review's temporary directory, avoiding a
redundant Cargo build or the known read-only shared-target prerequisite. A focused
run must select actual tests. Preserve any blocked prerequisite or failed probe;
do not fabricate fresh Rust success. No parent-owned baseline database may be opened.

Source files, Git state, parent evidence and configuration are read-only. Write
only under the assigned review output directory and the assigned private SSD test
directory passed by the launcher. Preserve routing, model, reasoning and compression
defaults. Do not use interactive agents or contact people. Keep artifacts small.
Remove only your exact disposable fixtures after their consumers exit.

Output directory:
/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/.git/akasha-evidence/mvp024-windowed-maintenance-review-r1
Report: the output directory's report.md
Require both first and last report lines to be exactly VERDICT: PASS or VERDICT: FAIL.
For each finding, include origin (REGRESSION or PRE-EXISTING), severity, source
path/line, evidence and consequence. Only regressions are actionable. PASS requires
zero actionable findings for this review contract. Include exact identities, fresh
checks and counts, evidence limitations, provider identity if available, and final
source/fixture custody. Hash the final report only after its bytes are final.
If essential evidence is unavailable, state that explicitly without claiming PASS.
