VERDICT: FAIL

ACTIONABLE_COUNT: 1

Independent conventional native review, using native-code-review directly after the reported Hermes failure. No Hermes retry, other reviewer, Daybreak, red-team run, external communication, source edit, build or full-gate rerun. This is native Codex review evidence, not a Hermes/provider-tier verdict. The session identifies the reviewer as Codex; an independently verified serving model/provider identifier is unavailable.

## Frozen scope and prerequisites

Repository: `/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp025`.

- Branch: `fix/mvp-024-windowed-maintenance`.
- Range: `origin/main...HEAD`.
- origin/main and independently computed merge base: `a177d6e23568b627ec9eef593d88289bc8634041`.
- HEAD: `c861c262518d43d92d2b861318e48989dcee5f9a`.
- Tree: `e952f5888a30ab5e1df318034086b2980ee335a7`.
- Exact serialization: `git diff --binary --full-index origin/main...HEAD`; 8,423,813 bytes; SHA-256 `d3bac399d0edebd6b989014bfb479c985c65b4a709d406f4132ba053162d5fd7`.
- One commit, 11 changed paths: four Rust paths, directly related baseline/publication archives and manifests, README claims and TODO. Traced surrounding batch, query, submission and native API implementations.
- Clean preflight and postflight. All 20 parent-scoped file hashes match both working files and frozen HEAD blobs. `git diff --check origin/main...HEAD` exits 0.

Before product-source inspection, independently tested all 255 exact live instruction candidates supplied in the parent instruction inventory using filesystem existence, symlink and resolved-path checks. These include logical home, `/mnt/ssd` and `/ssd` ancestors and scoped descendants for `AGENTS.md`, `AGENTS.override.md` and `CLAUDE.md`. None exists, and none is a dangling symlink. `instructions.json` records every logical and resolved path; there was no instruction file requiring a content/line-count receipt. Parent scope, instructions and canonical receipt were read-only inputs and were not overwritten.

The exact canonical `just check` had already completed with PASS before this review. Its terminal receipt records exit 0. Independently recomputed canonical log SHA-256: `097eee8bbecb828459c4eeda5e703604f94117519b61293bc86f13406f7afef4`. The supplied verified receipt records 653 Rust executions, 39 intentional ignores, 35 Python tests, seven Node tests and installed lifecycle/UID checks. This prior canonical result remains distinct from the fresh focused execution and from this failing source review.

## Actionable finding

### R1 — REGRESSION / MODERATE: maintain the writer's vector generation, not the replaceable query cache

Primary source: `src/retrieval.rs:309-312`. Related callers: `src/daemon/retrieval.rs:202-229`, `src/retrieval.rs:375-391`, `src/daemon/retrieval/search.rs:47-58,117-126`, `src/daemon/jobs.rs:1194-1206`.

`maintain_tables` obtains its vector table from the current `self.vector` cache. That cache is not owned exclusively by the index builder: `vector_index` replaces it whenever a caller requests another generation. Search calls that helper without taking `index_builder`. Submission deliberately pins searches to the previous active vector configuration while a new generation is being built (`query_vector_snapshot`, `src/daemon/retrieval.rs:37-55`). Thus different-generation searches are reachable normal behavior.

Concrete interleaving:

1. Sync for generation B obtains an `Arc<VectorIndex>` for B and awaits B's `sync_batch`. The cache mutex has already been released; the builder mutex serializes writers only.
2. A search pinned to the still-active generation A obtains A through `vector_index`, replacing the shared cache with A. B's existing Arc continues its batch normally.
3. B publishes its final vector progress. The daemon calls `maintain_tables`, which locks the cache and compacts/optimizes A (or skips A if already maintained), not B.
4. The daemon resets the maintenance counter and can activate B and return success. B's newly appended rows have received no final index optimization. The same interleaving can skip intermediate B maintenance windows.

Consequence: the change's mandatory window/completion maintenance can target the wrong native table during a supported model-generation transition. B may remain dependent on a growing flat scan after successful Sync, defeating the maintenance/resource behavior this leaf introduces. Native unindexed-row fallback preserves searchability; this finding does not claim missing rows or data corruption.

Attribution: the cache replacement and old-generation query behavior predate this range, but the merge-base vector `sync_batch` optimized `self.table` directly after each changed batch. Removing that optimization and relying on a later read of the replaceable cache introduces the missed-maintenance path. The lexical-only new regression cannot detect it. This is a source-established interleaving, not a claimed fresh failing runtime reproduction.

Recommendation: retain the exact writer vector Arc across its batch and pass that generation's table to maintenance; do not rediscover the maintenance target through a cache that searches replace. Add a deterministic test that switches the cache to A while B is held by the writer, then verifies B receives completion maintenance and A's reader remains usable.

## Remaining behavioral audit

- Publication bounds remain 32 authority transactions in both lexical and vector `sync_batch`; the daemon counts 32 such windows or completion. Maintenance does not publish authority progress. Metadata-only completion records remain governed by the existing checked commit path.
- Sync and Rebuild hold `index_builder` across the loop. Lexical table writes and same-generation vector writes are serialized through those production callers. Search holds an Index Arc and may run alongside compaction. The vector cache mutex remains held throughout maintenance, delaying new vector-cache acquisition; it does not retroactively pin the writer's generation, as R1 explains.
- Native maintenance checks owner permission and current running state/lease, cancellation, stopping and workflow expiry before each table and again between compaction and index optimization. Native operations are awaited to completion, not cancelled midway. Authorization can change during an individual native operation; no new claim of instantaneous interruption is justified. Final job handling rechecks lease, cancellation, authorization and timeout.
- Cache entries start at zero on open/reopen; normal native table versions are nonzero. The maintained version is saved only after both native operations succeed. Later mutations change the native version. Partial lexical success followed by vector failure is retried per table; failure before the store leaves that table eligible for another attempt. Restart resets the cache and retries maintenance on subsequent Sync. There is no durable all-tables maintenance transaction or guarantee that bounded compaction drains every eligible fragment.
- Compaction precedes optimization. Pinned LanceDB `b1b080b97c3edd2fd9f2aae8a3b71ff19487b1f8`, `rust/lancedb/src/table/optimize.rs`, clones the dataset, commits compaction and updates the handle; Compact does not invoke old-version cleanup. Index optimization similarly operates on a dataset snapshot. Lance 13.0.0's scanner includes uncovered fragments for ordinary vector/FTS queries; these callers do not enable `fast_search`. Existing indexed vectors retain ANN semantics; this is not an exact-recall claim.
- Pruning remains separate and requires the search-cache lock, pointer equality and exactly two Index Arc owners. A query's additional Index Arc prevents pruning. `delete_unverified=false` and tagged-old-version refusal remain intact. Rebuild retains its exclusive cache-ownership refusal before dropping old tables.
- Compaction explicitly bounds source fragments to 64, live source rows to 1,024, source bytes to 256 MiB, concurrent compaction tasks to one, scan batches to 2–16 rows and scan I/O buffers to 1–8 MiB. Output fragment/group targets are 512/128 rows and file targets 1–32 MiB. Native source-budget planning truncates whole tasks and can select no work if its first task exceeds a cap. These knobs do not bound total process RSS or all index-optimization work; default index optimization is not constrained by the compaction source budget. Native query caches/spill and FTS creation budgets are unchanged.

## Fresh execution and what it proves

Executed the supplied canonical artifact directly, without Cargo or a new target:

`/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge/target/debug/deps/akasha_otsuge-e164ed1c3c279b3d retrieval:: --test-threads=1 --nocapture`

Binary SHA-256 independently matched: `e8e754da21a3943147aa681a4a2d3a2036c71de2dabaf47c5f080843ad1bafd4`.

CWD and TMPDIR were the assigned private SSD directory `/mnt/ssd/mirror-rootfs/home/obj/tmp/a15-cache-s0s9a8n9/mvp024-windowed-maintenance-review-r1`. Exit 0; 10 passed, zero failed, one intentional crash-child ignore, 103 filtered out; 10.40 seconds. The selected set includes the daemon lease/pruning test and the new maintenance regression. The replay test invokes its supervised crash child internally; the ignored standalone child is not falsely counted as a direct pass.

`focused.log` SHA-256: `072d112a03b740b0d17bc9ec6857c3b489582a3dca00c03c02afce7fad5bc170`; exact argv, location, elapsed time and exit are in `focused.json`.

The new 128-memory lexical regression proves last-row search before and after maintenance, denied maintenance leaves version unchanged, fragment count falls, authority sequence/status stay unchanged, a separately checked-out old version still returns all 128 IDs, repeated maintenance does not change the version, and reopen preserves search/watermark. It does not assert vector optimization, the 32-window daemon schedule, cache-generation switching, mid-operation revocation, concurrent interleavings, or crash during maintenance. Its old-reader check is after compaction on a held snapshot, not a scheduled simultaneous reader stress test. Existing replay tests cover publication crash checkpoints, not the new maintenance seam.

No fresh Rust probe failed or was blocked. Initial generic `python` invocation emitted mise read-only cache-write warnings but completed the identity checks; later inspection used `/usr/bin/python3`. No shared-target build prerequisite was attempted, and no failed historical probe was rewritten as success.

## Evidence and claim audit

All members were hashed in memory without extracting databases or child transcripts:

- Windowed maintenance archive: 129 unique members, exact manifest membership, 5,714,889 bytes, SHA-256 `c5f5f6a56b77ec69560ccb79b1479c34720b7b076cbb468f237ef288f282c028`.
- Prior final-publication archive: 235 unique members, exact manifest membership, 839,936 bytes, SHA-256 `cc5d898942aaf3541c05cd871f61830d3ba5f30971a74b57d7574c7f259c55de`.
- Nested native diagnostic archive: 113 members, comprising its manifest and all 112 verified manifest entries. Sizes and SHA-256 match throughout. See `archives.json` and `archive-detail.json`.

Representative underlying fields agree with the bounded claims: prefix import reports 65,536 records/claims and 65,531 vector-cohort entries, `full_production_acceptance=false` and `indexes_built=false`; R2 terminal job is `cancelled/CANCELLED`, not succeeded. Its seal explicitly says `full_index_verified=false`, search witnesses were not executed, partial lookup pairs are not fully reconciled, and the last observation is not final offline status. The inventory has 14,079 entries summing to 2,354,728,960 allocated bytes. This review checked the sealed inventory only and did not reopen or re-hash the retained database.

Independently parsed all 2,787 archived R2 resource rows: sampled RSS maximum 540,213,248 bytes, nearest-rank P99 524,890,112, maximum VmHWM 551,141,376; sampled OOM/oom_kill counters are zero. The check-in records 727,467,528,192 physical read bytes over approximately 1,570.937 seconds and 0.856 recent vectors/s. These samples do not establish workload-duration or shutdown-tail acceptance.

Native diagnostic result fields preserve 2,040 surviving rows after the synthetic deletion cases, five fragments per table, exact row digests and reopen success. The wide-row result records 384 rows / 119,537,664 logical body bytes, 24 fragments unchanged with the 64-MiB cap, three with the 256-MiB cap, and VmHWM 626,792 kB. These are synthetic native API observations, not production-scale speed, steady-state memory or ANN-recall evidence.

Prior publication receipts record PR #75 merged at the frozen base and tree `89de21fb856fe342430bc0f7a9a54464bf64f477`; archived canonical and hosted CI receipts distinguish reviewed HEAD from the CI merge checkout and record 652 Rust executions, 35 Python and seven Node tests. Prior review's first/last markers are PASS and its hash is `e68db768b26b2c5a47c2bce7e3e7b09f76f598649d4ba953ede98bc778a6eb70`. These are checked historical archive receipts, not a fresh remote publication verification or a verdict transferable to this leaf.

README/TODO retain the deliberately stopped baseline, required native Rebuild, full corpus, 100-client duration, changed-source importer transition and ANN-recall limitations. No new evidence-claim regression was found. Full raw child transcripts were not consumed as review inputs.

## Final custody and limitations

`preflight.json`, `postflight.json` and the instruction inventory retain source identities and file attestations. Source, Git state, parent evidence and configuration remain unchanged. The fresh native test process exited; its exact `akasha-index-*` and daemon fixtures were cleaned by their owners after use. No review-created database remains. Launcher-owned `.agents`, `.aws`, `.codex`, `.git`, synthetic-mount and Node-cache entries were left untouched. Only this assigned output directory received durable review artifacts; native fixtures used the assigned SSD directory. No baseline database was opened and no process outside the focused test's ownership was stopped.

Skipped the full canonical rerun, new compilation, production rebuild, load/recall runs and a new compiled race harness, as required by scope. R1 is source-proven and remains actionable despite the green focused tests; production-scale performance and memory remain unqualified.

VERDICT: FAIL
