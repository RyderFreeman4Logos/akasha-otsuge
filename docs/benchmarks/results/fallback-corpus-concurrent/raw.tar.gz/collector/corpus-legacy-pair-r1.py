import hashlib,json,pathlib,shutil,subprocess,sys,time
repo=pathlib.Path.cwd();sys.path.insert(0,str(repo/'spikes/helix'))
from run_case import digest,process_identity,publish
base=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023').resolve()
source_case=base/'fallback-corpus-concurrent-legacy-r2/case'
state=json.loads((source_case/'state.json').read_text());verified=json.loads((source_case/'verified.json').read_text())
assert verified['exact_processes_gone'] and verified['scratch_removed'] and state['phase']=='completed'
source=pathlib.Path(state['identity']['database']);assert source.is_dir() and not source.is_symlink()
assert (source/'OWNER').read_text()=='akasha-otsuge MVP-003 fallback database\n'
root=base/'fallback-corpus-legacy-pair-r1';root.mkdir();(root/'OWNER').write_text('akasha-otsuge MVP-003 bounded legacy comparison\n')
started=time.monotonic()
def inventory(p):
 return {str(f.relative_to(p)):digest(f) for f in sorted(p.rglob('*')) if f.is_file()}
assert sum(p.stat().st_size for p in source.rglob('*') if p.is_file())<1024**3
before=inventory(source);publish(root/'initial-files.json',before)
records=[]
for label,binary in [('new',repo/'.spike-work/corpus-corrections-r2/probe'),('old',repo/'.spike-work/retire-generation-r2/probe')]:
 target=root/(label+'-fixture');target.mkdir();(target/'OWNER').write_text('akasha-otsuge MVP-003 disposable paired workload database\n')
 database=target/'database'
 subprocess.run(['cp','-a','--reflink=auto',str(source),str(database)],check=True)
 assert inventory(database)==before
 config=state['identity']['config'];original=(base/'fallback-corpus-concurrent-legacy-r2/case.toml').read_text()
 text=original.replace(config['run']['id'],'legacy-pair-r1').replace(config['paths']['binary'],str(binary)).replace(config['paths']['database'],str(database)).replace(config['paths']['output'],str(root/label))
 path=root/(label+'.toml');path.write_text(text)
 records.append(dict(label=label,binary_sha256=digest(binary),config_sha256=digest(path),fixture=str(target),output=str(root/label)))
assert inventory(source)==before
publish(root/'admission.json',dict(controller=process_identity(__import__('os').getpid()),source=str(source),source_state_sha256=digest(source_case/'state.json'),initial_files_sha256=digest(root/'initial-files.json'),records=records,scope='one sequential new-then-old comparison; byte-identical initial database and same run_id; elapsed host/cache differences remain uncontrolled'))
for i,record in enumerate(records):
 label=record['label'];publish(root/'progress.json',dict(phase=label,completed=i,total=2,elapsed_s=time.monotonic()-started))
 with (root/(label+'.log')).open('x') as log:
  result=subprocess.run([sys.executable,str(repo/'.spike-work/corpus-corrections-r2/helix/run_case.py'),str(root/(label+'.toml'))],stdout=log,stderr=subprocess.STDOUT)
 record['exit']=result.returncode
 with (root/(label+'-verify.log')).open('x') as log:
  checked=subprocess.run([sys.executable,str(repo/'.git/akasha-evidence/verify-full-case.py'),record['output'],record['binary_sha256']],stdout=log,stderr=subprocess.STDOUT)
 assert checked.returncode==0
 s=json.loads((pathlib.Path(record['output'])/'state.json').read_text());record['status']=s['result']['status'];record['failures']=s['result']['engine']['failures'];record['operations']=s['result']['engine']['snapshot']['operations']
 publish(root/'records.json',records)
for record in records:
 target=pathlib.Path(record['fixture']);assert target.parent==root and not target.is_symlink()
 assert (target/'OWNER').read_text()=='akasha-otsuge MVP-003 disposable paired workload database\n'
 shutil.rmtree(target);assert not target.exists()
publish(root/'result.json',dict(status='passed' if all(r['exit']==0 for r in records) else 'failed',records=records,seconds=time.monotonic()-started,cleanup=True))
publish(root/'progress.json',dict(phase='completed',completed=2,total=2,elapsed_s=time.monotonic()-started,eta_s=0))
print(json.dumps(dict(records=[{k:r[k] for k in ['label','exit','status','failures']} for r in records],seconds=time.monotonic()-started)))
raise SystemExit(0 if all(r['exit']==0 for r in records) else 1)
