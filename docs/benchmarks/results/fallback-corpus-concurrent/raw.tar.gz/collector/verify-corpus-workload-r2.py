import datetime,json,pathlib,subprocess,sys
repo=pathlib.Path.cwd();sys.path.insert(0,str(repo/'spikes/helix'))
from run_case import digest,process_identity,publish
base=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023').resolve()
for name in ['fallback-corpus-concurrent-green-r2','fallback-corpus-concurrent-legacy-r2','fallback-corpus-concurrent-legacy-baseline-r1']:
 root=base/name;admission=json.loads((root/'admission.json').read_text());commands=json.loads((root/'commands.json').read_text());case=json.loads((root/'case/verified.json').read_text())
 identities=[admission['controller']];units=[];scratches=[]
 for record in commands:
  assert record['exit']==0
  unit=next(x.split('=',1)[1] for x in record['command'] if x.startswith('--unit='));units.append(unit)
  es=[json.loads(l) for l in (root/(record['name']+'-memory.jsonl')).read_text().splitlines()]
  natives=[e for e in es if e['event']=='executable'];exits=[e for e in es if e['event']=='exit'];assert len(natives)==len(exits)==1
  assert natives[0]['sha256']==admission['binary_sha256'] and exits[0]['code']==0 and exits[0]['native_code']==0
  identities+=natives;scratches.append(exits[0]['scratch_cleanup'])
  assert all(int(e['memory_events'].get('oom_kill',0))==0 for e in es if e['event']=='sample')
 units.append(case['unit']);identities+=list(case['identities'].values())
 for ident in identities:
  current=process_identity(ident['pid']);assert current is None or current['start_ticks']!=ident['start_ticks']
 for unit in units:
  active=subprocess.run(['systemctl','--user','show',unit,'-p','ActiveState','--value'],capture_output=True,text=True,check=True).stdout.strip();assert active in {'inactive','failed'}
 for s in scratches:assert s['removed'] and not pathlib.Path(s['path']).exists()
 temporary=pathlib.Path(admission['temporary_root']);assert temporary.parent==pathlib.Path('/tmp') and temporary.name.startswith('akasha-generation-workload-')
 report=dict(verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),native_sha256=admission['binary_sha256'],commands=len(commands),status=case['status'],exact_processes_gone=True,units_gone=True,scratch_removed=True,temporary=str(temporary),fixture_removed=not temporary.exists(),case_verified_sha256=digest(root/'case/verified.json'),artifact_sha256={str(p.relative_to(root)):digest(p) for p in root.rglob('*') if p.is_file() and p.name!='verified.json'})
 publish(root/'verified.json',report);print(name,{k:report[k] for k in ['commands','status','fixture_removed']})
