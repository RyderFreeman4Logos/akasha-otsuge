import hashlib,json,pathlib,sys,tarfile
repo=pathlib.Path.cwd();sys.path.insert(0,str(repo/'spikes/helix'))
from run_case import digest,publish
storage=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023');files={}
def add_tree(prefix,root):
 for p in root.rglob('*'):
  if p.is_file() and p.name!='probe' and '__pycache__' not in p.parts:
   assert not p.is_symlink();files[prefix+'/'+str(p.relative_to(root))]=p
for prefix,name in [('native-red','fallback-corpus-concurrent-red-r1'),('native-failed-r1','fallback-corpus-concurrent-green-r1'),('native-green-r2','fallback-corpus-concurrent-green-r2'),('legacy-failed-r2','fallback-corpus-concurrent-legacy-r2'),('legacy-baseline','fallback-corpus-concurrent-legacy-baseline-r1'),('legacy-identical-input-pair','fallback-corpus-legacy-pair-r1')]:add_tree(prefix,storage/name)
for version in ['r1','r2']:add_tree('frozen-'+version,repo/'.spike-work'/('corpus-corrections-'+version))
add_tree('frozen-native-red',repo/'.spike-work/corpus-concurrent-red-r1')
source=json.loads((repo/'.spike-work/corpus-corrections-r2/source.json').read_text());assert digest(repo/'.spike-work/corpus-corrections-r2/probe')==source['native_sha256']
for group in ['source_sha256','helpers_sha256','compatibility_source_sha256']:
 for name,want in source[group].items():assert digest(repo/name)==want,name;files['candidate-source/'+name]=repo/name
collector=repo/'.git/akasha-evidence'
for pattern in ['corpus-concurrent-*.log','corpus-concurrent-host-comparison.json','corpus-concurrent-self-review-r2.md','corpus-legacy-pair-r1.py','corpus-legacy-pair-r1.log','verify-corpus-workload-r2.py','verify-full-case.py','archive-corpus-concurrent-r2.py']:
 for p in collector.glob(pattern):files['collector/'+p.name]=p
out=repo/'docs/benchmarks/results/fallback-corpus-concurrent';out.mkdir();archive=out/'raw.tar.gz';hashes={n:digest(p) for n,p in sorted(files.items())}
with tarfile.open(archive,'w:gz') as tf:
 for n,p in sorted(files.items()):tf.add(p,arcname=n,recursive=False)
with tarfile.open(archive,'r:gz') as tf:
 assert set(tf.getnames())==set(hashes)
 for m in tf.getmembers():assert hashlib.sha256(tf.extractfile(m).read()).hexdigest()==hashes[m.name],m.name
publish(out/'files.json',hashes)
green=json.loads((storage/'fallback-corpus-concurrent-green-r2/result.json').read_text());verified=json.loads((storage/'fallback-corpus-concurrent-green-r2/verified.json').read_text());pair=json.loads((storage/'fallback-corpus-legacy-pair-r1/result.json').read_text())
assert green['status']=='passed_diagnostic_only' and len(green['rebuild_controls'])==10 and verified['fixture_removed']
failed=json.loads((storage/'fallback-corpus-concurrent-legacy-r2/case/state.json').read_text())['result']
summary=dict(status='passed_diagnostic_only',source_parent=source['parent'],native_sha256=source['native_sha256'],archive_files=len(files),archive_bytes=archive.stat().st_size,archive_sha256=digest(archive),seconds=green['seconds'],native=green['case'],controls=green['rebuild_controls'],release_units=11,controller_units=8,fallback_and_helix_release_clippy='passed',exact_processes_units_scratch_verified=True,disposable_fixtures_removed=True,
 failures_retained=['old native rejects corrections field','r1 treated one-based ordinals as zero-based and failed original restoration; write/current latency also failed','r2 ordinary60s failed BM25 window rate at55/60'],legacy_failed=dict(status=failed['status'],failures=failed['engine']['failures'],operations=failed['engine']['snapshot']['operations']),legacy_comparison=pair,
 comparison_limits='One new-then-old observation per binary; identical initial file hashes and run_id, host/cache/order differences uncontrolled. Earlier failed run stays failed; no causal equivalence or confidence interval.',review='Implementing-agent self-review only',not_proven=['full-size concurrent rebuild','full build/recovery low resource bound','vectorized candidate corrections during build','physical rebuild disk peak'])
publish(out/'summary.json',summary);print({k:summary[k] for k in ['status','archive_files','archive_bytes','archive_sha256','seconds']})
