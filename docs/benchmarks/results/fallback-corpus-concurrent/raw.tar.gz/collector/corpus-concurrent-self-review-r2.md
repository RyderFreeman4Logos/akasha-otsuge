# Implementing-agent self-review: corpus-candidate workload

Verdict: PASS for this opt-in diagnostic feature; storage acceptance remains open.
This is not an independent review or a causal performance comparison.

Scope: shared native workload admission/operations/final oracle, fallback original
source lookup and derived checks, rejected-Helix compatibility stub, controller
identity/snapshot/resume/independent oracle, native fixture, oracle unit and docs.
No new dependency, client class, production backend, or relaxed threshold.

- Eight bounded unique original unvectorized corpus IDs, all scopes, protected
  query IDs excluded. Native authority content and initial search hit must match.
- Existing clients use one-based ordinals; (ordinal-1)%4 restores each original.
  Initial native failure and the corrected oracle RED are preserved.
- Immutable correction bytes are snapshotted, fsynced and hashed; tampered source
  and copied snapshot fail completed reuse. Native admission also validates them.
- Search candidates are checked against acknowledged revisions at their actual
  authority validation point. Final derived heads and original restoration match.
- Full-mode oracle requires all eight scopes' corrections plus both completed
  search types inside the build interval. Diagnostic mode reports actual overlap.
- Default operation paths add no I/O when corrections are absent. The original
  60s BM25 throughput miss remains a failure. A bounded new-then-old comparison
  starts from byte-identical database files and one request identity; both pass.
  Host scheduling/cache effects remain uncontrolled; no equivalence claim.
- 160s native fixture, ten tamper controls, eleven release units, fallback and
  Helix release all-targets Clippy, and eight controller units pass on frozen r2.
  Every completed receipt/artifact hash, exact process/unit exit and scratch was
  collected. Disposable success/failure fixture databases are removed.

Limits: small-fixture performance, unvectorized concurrent candidates only;
no full build/recovery/disk-bound pass yet. Root exact-HEAD gate and publication
are separate next steps. Original throughput failure is not overwritten.
