import datetime, hashlib, json, os, pathlib, shutil, subprocess, sys, uuid
root=pathlib.Path.cwd();e=root/'.git/akasha-evidence';binary=root/'.spike-work/fallback-search-r2/probe';binary.parent.mkdir(mode=0o700);shutil.copy2(root/'target/storage-spike/release/akasha-fallback-probe',binary)
a=json.loads((e/'fallback-search-r1-admission.json').read_text());unit='akasha-fallback-search-'+uuid.uuid4().hex
command=[('--unit='+unit) if v.startswith('--unit=') else v.replace('fallback-search-r1','fallback-search-r2') for v in a['command']]
a.update(command=command,unit=unit,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(e/'fallback-search-r2-admission.json').write_text(json.dumps(a,indent=2)+'\n')
s=json.loads((e/'wd-state.json').read_text());s['tasks'].append({'name':'fallback-search-r2','unit':unit,'progress':'/tmp/akasha-otsuge-storage-20261022/fallback-search-r2/progress.json'});(e/'wd-state.json').write_text(json.dumps(s,indent=2,sort_keys=True)+'\n')
with (e/'fallback-search-r2.log').open('xb') as output:r=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
(e/'fallback-search-r2-terminal.json').write_text(json.dumps({'exit':r.returncode,'unit':unit})+'\n');sys.exit(r.returncode)
