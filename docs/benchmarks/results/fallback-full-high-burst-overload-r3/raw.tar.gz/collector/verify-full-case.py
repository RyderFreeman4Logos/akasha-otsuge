import datetime,json,pathlib,subprocess,sys
sys.path.insert(0,str(pathlib.Path('spikes/helix').resolve()))
from run_case import digest,process_identity,publish,verify_requests

root=pathlib.Path(sys.argv[1]).resolve();expected=sys.argv[2]
state=json.loads((root/'state.json').read_text());result=state['result']
assert state['phase']=='completed',state['phase']
assert state['identity']['binary_sha256']==expected
for name,want in result['artifact_sha256'].items():assert digest(root/name)==want,name
assert verify_requests(root)==result['content_oracle']
events=[json.loads(line) for line in (root/'memory.jsonl').read_text().splitlines()]
native=[e for e in events if e['event']=='executable'];exits=[e for e in events if e['event']=='exit']
assert len(native)==len(exits)==1 and native[0]['sha256']==expected
assert exits[0]==result['exit']
for ident in [state['controller'],native[0]]:
 actual=process_identity(ident['pid'])
 assert actual is None or actual['start_ticks']!=ident['start_ticks'],ident
unit=subprocess.run(['systemctl','--user','show',state['unit'],'-p','ActiveState','--value'],check=True,capture_output=True,text=True).stdout.strip()
assert unit in {'inactive','failed'},unit
scratch=exits[0]['scratch_cleanup'];assert scratch['removed'] and not pathlib.Path(scratch['path']).exists()
engine=result['engine'];snapshot=engine['snapshot']
report=dict(verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status=result['status'],seconds=exits[0]['seconds'],
 rss_p99_bytes=result['rss_p99_bytes'],rss_max_bytes=result['rss_max_bytes'],content_oracle=result['content_oracle'],
 failures=engine['failures'],operations=snapshot['operations'],derived=snapshot['derived'],drain_s=engine['drain_s'],
 identities=dict(native=native[0],controller=state['controller']),unit=state['unit'],unit_state=unit,
 artifacts_verified=True,exact_processes_gone=True,scratch_removed=True,collector_sha256=digest(__file__))
publish(root/'verified.json',report)
print(json.dumps({k:report[k] for k in ['status','seconds','rss_p99_bytes','rss_max_bytes','failures','operations','derived','drain_s','artifacts_verified','exact_processes_gone','scratch_removed']}))
cold=result['cold_cache'];assert cold is None or isinstance(cold,dict)
print(json.dumps(dict(requests=result['content_oracle']['requests'],distinct_commits=result['content_oracle']['distinct_commits'],
 cold={k:cold[k] for k in ['files','resident_pages_before','resident_pages_after','seconds']} if cold is not None else None,unit=state['unit'])))
