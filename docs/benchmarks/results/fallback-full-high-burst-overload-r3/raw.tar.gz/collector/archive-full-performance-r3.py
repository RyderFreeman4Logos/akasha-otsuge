import hashlib, io, json, pathlib, subprocess, sys, tarfile

repo=pathlib.Path.cwd();sys.path.insert(0,str(repo/'spikes/helix'))
from run_case import digest,publish,verify_requests
root=pathlib.Path('/ssd/mirror-rootfs/home/obj/akasha-otsuge-storage-20261023/fallback-full-sustained-r3')
frozen=repo/'.spike-work/delta-scope-r1';source=json.loads((frozen/'source.json').read_text())
assert digest(frozen/'probe')==source['native_sha256']
files={};cases={};blobs={}
for case in ['high','burst','overload']:
    p=root/case;s=json.loads((p/'state.json').read_text());r=s['result'];v=json.loads((p/'verified.json').read_text())
    assert s['phase']=='completed' and r['status']==v['status']=='passed'
    assert s['identity']['binary_sha256']==source['native_sha256']
    assert verify_requests(p)==r['content_oracle']
    for name,want in r['artifact_sha256'].items():assert digest(p/name)==want,name
    assert v['exact_processes_gone'] and v['scratch_removed']
    cases[case]={k:v[k] for k in ['seconds','rss_p99_bytes','rss_max_bytes','failures','operations','derived','drain_s','content_oracle']}
    cases[case]['cold_cache']=r['cold_cache']
    for file in p.rglob('*'):
        if file.is_file():files[case+'/'+str(file.relative_to(p))]=file
    for name in [case+'.toml',case+'-environment.json']:
        files['admission/'+name]=root/name
for name in ['environment.json','high-host-supplement.json']:
    files['admission/'+name]=root/name
for p in frozen.rglob('*'):
    if p.is_file() and p.name!='probe' and '__pycache__' not in p.parts:
        files['frozen/'+str(p.relative_to(frozen))]=p
for name,want in source['source_sha256'].items():
    content=subprocess.check_output(['git','show','7fba9f0:'+name]);assert hashlib.sha256(content).hexdigest()==want,name
    blobs['candidate-source/'+name]=content
for name in ['full-sustained-high-r3.log','full-burst-r3.log','full-overload-r3.log','verify-full-case.py','archive-full-performance-r3.py','wd-checkin-20261024T0443.json']:
    files['collector/'+name]=repo/'.git/akasha-evidence'/name
out=repo/'docs/benchmarks/results/fallback-full-high-burst-overload-r3';out.mkdir()
hashes={name:digest(p) for name,p in sorted(files.items())}
hashes.update({name:hashlib.sha256(b).hexdigest() for name,b in blobs.items()})
archive=out/'raw.tar.gz'
with tarfile.open(archive,'w:gz') as tf:
    for name,p in sorted(files.items()):tf.add(p,arcname=name,recursive=False)
    for name,b in sorted(blobs.items()):
        member=tarfile.TarInfo(name);member.size=len(b);tf.addfile(member,io.BytesIO(b))
with tarfile.open(archive,'r:gz') as tf:
    assert set(tf.getnames())==set(hashes)
    for m in tf.getmembers():assert hashlib.sha256(tf.extractfile(m).read()).hexdigest()==hashes[m.name],m.name
publish(out/'files.json',hashes)
summary=dict(status='passed',source_head='7fba9f0a5c4b69f20cf2c26cdd0826ef5857322c',binary_sha256=source['native_sha256'],clients=100,
    archive_files=len(hashes),archive_bytes=archive.stat().st_size,archive_sha256=digest(archive),artifacts_verified=True,
    cases=cases,exact_processes_gone=True,scratch_removed=True,
    environment_note='Campaign environment retained; per-case free space/load/config captured. High host supplement was captured during the run and is explicitly labelled, not a pre-run snapshot. One1.008s missing-operation RED and tiny Python units ran alongside high; no Cargo build or full native fixture.',
    not_proven=['fresh uninterrupted bounded full build','direct low interrupted full build recovery','full actual corpus-candidate mutation with concurrent query/build','inactive-generation retirement','concurrent peak disk bound'])
publish(out/'summary.json',summary)
print({k:summary[k] for k in ['archive_files','archive_bytes','archive_sha256','binary_sha256']})
