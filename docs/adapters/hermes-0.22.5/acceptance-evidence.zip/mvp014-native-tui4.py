from pathlib import Path
import contextlib, datetime, fcntl, hashlib, json, os, pty, select, shutil, signal, sqlite3, struct, subprocess, tempfile, termios, time
import yaml
E=Path(__file__).parent
W=Path('/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp014')
N=Path('/home/obj/.hermes/hermes-agent')
B=W/'target/debug/akasha-otsuge'
H='/home/obj/.local/bin/hermes'
root=Path(tempfile.mkdtemp(prefix='a14-tui-',dir='/mnt/ssd/mirror-rootfs/home/obj/tmp'))
homes={mode:Path(tempfile.mkdtemp(prefix='akasha-tui-'+mode+'-',dir='/home/obj/.hermes/profiles')) for mode in ('in_process','host')}
base={k:os.environ[k] for k in ('HOME','USER','LOGNAME','LANG') if k in os.environ}
base.update(PATH='/usr/bin:/bin',PYTHONDONTWRITEBYTECODE='1',HERMES_DISABLE_LAZY_INSTALLS='1',TERM='xterm-256color')
assert all(shutil.which(n,path=base['PATH']) is None for n in ('codex','claude','pi'))
launchers={str(N/'.hermes/bin'/n):hashlib.sha256((N/'.hermes/bin'/n).read_bytes()).hexdigest() for n in ('hermes','hermes-acp')}
(E/'mvp014-native-tui4.owned.json').write_text(json.dumps({'root':str(root),'homes':{k:str(v) for k,v in homes.items()},'launchers':launchers},indent=2)+'\n')
children=[];logs=[];masters={};clients={};gateways={};envs={};results={};daemon=None
def checkpoint(phase,**fields):
    r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':phase,**fields}
    (E/'mvp014-native-tui4.progress.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
def launch(args,env,cwd,name):
    log=(root/(name+'.log')).open('wb');logs.append(log)
    p=subprocess.Popen(args,env=env,cwd=cwd,stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True);children.append(p);return p
def cli(*args):
    p=subprocess.run([str(B),'--config',str(root/'akasha.toml'),'--socket',str(root/'daemon.sock'),*args],env=base,capture_output=True,timeout=45)
    assert p.returncode==0,('akasha_cli',args,p.returncode)
    return json.loads(p.stdout)['data']
def public_result(mode):
    active=list((root/mode/'tmp').glob('hermes-tui-active-session-*.json'))
    assert len(active)<=1,('ambiguous_active_session',mode)
    if not active:return None
    try:sid=json.loads(active[0].read_text()).get('session_id')
    except json.JSONDecodeError:return None
    if not sid:return None
    db=homes[mode]/'state.db'
    if not db.exists():return None
    with sqlite3.connect(db.as_uri()+'?mode=ro',uri=True,timeout=1) as c:
        rows=c.execute('SELECT role,content,tool_name,tool_calls FROM messages WHERE session_id=? AND active=1 ORDER BY id',(sid,)).fetchall()
    replies=[];errors=[];finals=0
    for role,content,tool,calls in rows:
        if role=='tool' and tool=='akasha_consult':
            try:reply=json.loads(content or '')
            except json.JSONDecodeError:reply={}
            if 'data' in reply:replies.append(reply['data'])
            if isinstance(reply.get('error'),dict):errors.append(reply['error'].get('code'))
        if role=='assistant' and content and not calls:finals+=1
    if not finals:return None
    assert len(replies)==1 and not errors,('native_tui_binding',mode,len(replies),errors)
    b=replies[0]
    assert b['caller']['session']==sid and b['caller']['profile']=='hermes/'+hashlib.sha256(os.fsencode(homes[mode].resolve())).hexdigest()
    assert b['requested_cursor']==b['available_cursor']
    return {'session':sid,'profile':b['caller']['profile'],'invocation':b['invocation_id'],'cursor':b['requested_cursor'],'public_rows':len(rows)}
try:
    model=yaml.safe_load(Path('/home/obj/.hermes/config.yaml').read_text())['model']
    model={k:v for k,v in model.items() if k in ('default','model','provider','context_length')}
    for mode,home in homes.items():
        area=root/mode;area.mkdir();(area/'workspace').mkdir();(area/'tmp').mkdir()
        envs[mode]=base|{'HERMES_HOME':str(home),'TMPDIR':str(area/'tmp')}
        config={'updates':{'check':False},'model':model,'plugins':{'enabled':['akasha-otsuge'],'isolation':mode},'tools':{'tool_search':{'enabled':'off'}},'terminal':{'cwd':str(area/'workspace')},'agent':{'max_turns':8,'run_budget_seconds':180},'gateway':{'standalone':True,'auto_multiplex_migration':False},'sessions':{'max_export_messages':128},'telemetry':{'shared_metrics':{'enabled':False,'send':False,'offer_version':2}}}
        (home/'config.yaml').write_text(yaml.safe_dump(config));(home/'config.yaml').chmod(0o600)
    (root/'akasha.toml').write_text('[paths]\ndata_dir='+json.dumps(str(root/'data'))+'\nsocket_path='+json.dumps(str(root/'daemon.sock'))+'\n[access]\nread_roots=['+','.join(json.dumps(str(p)) for p in [root,*homes.values()])+']\n')
    daemon=launch([str(B),'--config',str(root/'akasha.toml'),'daemon','run'],base,root,'daemon')
    end=time.monotonic()+30
    while not (root/'daemon.sock').exists():
        assert daemon.poll() is None and time.monotonic()<end,'daemon_readiness';time.sleep(.05)
    for mode,home in homes.items():
        cli('adapter','install','hermes','--binary',H,'--home',str(home))
        p=launch([H,'gateway','run','--quiet','--no-supervise','--external-supervisor'],envs[mode],root/mode/'workspace','gateway-'+mode);gateways[mode]=p
        end=time.monotonic()+90
        while True:
            assert p.poll() is None,('gateway_early_exit',mode,p.returncode)
            try:state=json.loads((home/'gateway_state.json').read_text())
            except (FileNotFoundError,json.JSONDecodeError):state={}
            if state.get('pid')==p.pid and state.get('gateway_state') in ('running','degraded'):break
            assert time.monotonic()<end,('gateway_readiness_deadline',mode)
            time.sleep(.1)
        checkpoint('gateway_ready',mode=mode,pid=p.pid)
    for mode in homes:
        master,slave=pty.openpty();fcntl.ioctl(slave,termios.TIOCSWINSZ,struct.pack('HHHH',36,140,0,0))
        def terminal():
            os.setsid();fcntl.ioctl(0,termios.TIOCSCTTY,0)
        prompt='Synthetic '+mode+' acceptance: I prefer small files. Call akasha_consult exactly once with hint preferences. Then answer Caller checked. Do not call any other tool.'
        p=subprocess.Popen([H,'chat','--tui','--toolsets','akasha','--ignore-rules','--in',str(root/mode/'workspace')],env=envs[mode],cwd=root/mode/'workspace',stdin=slave,stdout=slave,stderr=slave,preexec_fn=terminal)
        os.close(slave);os.set_blocking(master,False);masters[mode]=master;clients[mode]=p;children.append(p)
    checkpoint('two_tuis_started',pids={k:p.pid for k,p in clients.items()})
    end=time.monotonic()+240;byte_counts={k:0 for k in homes};sent=set();typed={};entered=set()
    while len(results)<2 or any(p.poll() is None for p in clients.values()):
        ready,_,_=select.select(list(masters.values()),[],[],.1)
        for mode,fd in masters.items():
            if fd in ready:
                with contextlib.suppress(BlockingIOError,OSError):byte_counts[mode]+=len(os.read(fd,65536))
        for mode,p in clients.items():
            if mode not in typed:
                active=list((root/mode/'tmp').glob('hermes-tui-active-session-*.json'))
                assert len(active)<=1,'ambiguous_active_session'
                if active:
                    with contextlib.suppress(json.JSONDecodeError):
                        if json.loads(active[0].read_text()).get('session_id'):
                            prompt='Synthetic '+mode+' acceptance: I prefer small files. Call akasha_consult exactly once with hint preferences. Then answer Caller checked. Do not call any other tool.'
                            os.write(masters[mode],b'\x1b[200~'+prompt.encode()+b'\x1b[201~');typed[mode]=time.monotonic()
            elif mode not in entered and time.monotonic()-typed[mode]>=.3:
                os.write(masters[mode],b'\r');entered.add(mode);checkpoint('interactive_prompt_submitted',mode=mode)
            if mode not in results:
                result=public_result(mode)
                if result:
                    results[mode]=result;checkpoint('tui_binding_verified',mode=mode,**result)
            if mode in results and mode not in sent:
                os.write(masters[mode],b'\x04');sent.add(mode)
            assert p.poll() is None or (mode in results and p.returncode==0),('tui_early_exit',mode,p.returncode,byte_counts[mode])
        assert time.monotonic()<end,('tui_deadline',list(results),byte_counts)
    assert len({r['invocation'] for r in results.values()})==2 and len({r['profile'] for r in results.values()})==2
    end=time.monotonic()+30
    while True:
        jobs=cli('job','list')['items'];states=[j['state'] for j in jobs]
        assert not any(s in ('failed','cancelled') for s in states),('capture_job_failure',states)
        if len(jobs)>=2 and all(s=='succeeded' for s in states):break
        assert time.monotonic()<end,('capture_jobs_deadline',states)
        time.sleep(.1)
    checkpoint('tuis_and_capture_complete',jobs=len(jobs),pty_bytes=byte_counts)
    for p in gateways.values():p.send_signal(signal.SIGTERM)
    for p in gateways.values():p.wait(timeout=45)
    cli('daemon','stop');daemon.wait(timeout=30);assert daemon.returncode==0
    assert {p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in launchers}==launchers
    allocated=sum(p.lstat().st_blocks*512 for area in [root,*homes.values()] for p in area.rglob('*') if p.is_file())
    result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':'two_simultaneous_actual_authenticated_native_TUI_Callers','model':model,'results':results,'capture_jobs':len(jobs),'interactive_pty_input':True,'other_clis_absent':True,'native_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=N,text=True).strip(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),'allocated_bytes':allocated}
    (E/'mvp014-native-tui4.result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
finally:
    for p in reversed(children):
        if p.poll() is None:
            p.send_signal(signal.SIGTERM)
            try:p.wait(timeout=45)
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    for fd in masters.values():os.close(fd)
    for log in logs:log.close()
    alive=[]
    for proc in Path('/proc').iterdir():
        if not proc.name.isdecimal():continue
        try:
            cwd=(proc/'cwd').readlink();state=(proc/'stat').read_text().rsplit(') ',1)[1].split()[0]
            if state!='Z' and any(cwd==a or a in cwd.parents for a in (root,*homes.values())):alive.append(int(proc.name))
        except (OSError,ValueError):pass
    assert not alive,('owned processes remain; retain scratch',alive)
    for home in homes.values():shutil.rmtree(home)
    shutil.rmtree(root);print(json.dumps({'scratch_removed':True,'profiles_removed':True}),flush=True)
