import os, sys, pathlib, json, subprocess, tempfile, shutil, hashlib, datetime
E=pathlib.Path(__file__).parent
W=pathlib.Path('/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp014')
root=pathlib.Path(os.environ['AKASHA_EXPORT_FIXTURE_ROOT'])
sys.dont_write_bytecode=True
try:
 home=root/'home';home.mkdir(mode=0o700,exist_ok=True);work=root/'workspace';work.mkdir(exist_ok=True)
 # HERMES_HOME is the controller-owned native profile alias; keep it across re-exec.
 os.environ['HERMES_DISABLE_LAZY_INSTALLS']='1'
 os.environ['PYTHONDONTWRITEBYTECODE']='1'
 sys.path.insert(0,'/home/obj/.hermes/hermes-agent')
 import hermes_bootstrap
 from hermes_state import SessionDB
 db=SessionDB(home/'state.db')
 sid='20261029_021600_a00001';child='20261029_021601_a00002'
 db.create_session(sid,'cli',model='synthetic-fixture',profile_name='custom',cwd=str(work),system_prompt='PRIVATE_CONFIG_SENTINEL')
 db.append_message(sid,'user','Original public preference: use small files.',message_uid='m_user',timestamp=1793240160.0)
 db.append_message(sid,'assistant','Public working explanation.',message_uid='m_assistant',reasoning='PRIVATE_REASONING_SENTINEL',timestamp=1793240161.0)
 db.append_message(sid,'assistant',None,tool_calls=[{'id':'call_alpha','type':'function','function':{'name':'read_file','arguments':'{"path":"project.txt"}'}}],message_uid='m_toolcall',timestamp=1793240162.0)
 db.append_message(sid,'tool','Synthetic file contents.',tool_name='read_file',tool_call_id='call_alpha',message_uid='m_toolresult',timestamp=1793240163.0)
 db.append_message(sid,'assistant','Answer before interruption.',message_uid='m_tail',timestamp=1793240164.0)
 snapshots={}
 def export(name,session):
  dest=root/(name+'.jsonl')
  r=subprocess.run(['/home/obj/.local/bin/hermes','sessions','export',str(dest),'--session-id',session,'--format','jsonl'],capture_output=True,timeout=45)
  assert r.returncode==0,(r.returncode,r.stderr.decode()[-1500:])
  data=dest.read_text();rows=[json.loads(s) for s in data.splitlines()];assert len(rows)==1 and rows[0]['id']==session
  snapshots[name]=data
 export('root-before',sid)
 tail=db.get_messages(sid)[-1]
 db.archive_and_compact(sid,[{'role':'user','content':'Summary of earlier public turns.','_compressed_summary':True,'message_uid':'m_summary','timestamp':1793240165.0},tail],tail_count=1)
 db.append_message(sid,'user','New question after compaction.',message_uid='m_after',timestamp=1793240166.0)
 export('root-compacted',sid)
 db.create_session(child,'delegate_task',parent_session_id=sid,model='synthetic-fixture',profile_name='custom',cwd=str(work))
 db.append_message(child,'user','Child task with its own provenance.',message_uid='m_child',timestamp=1793240167.0)
 export('child',child)
 db.close()
 out=W/'tests/fixtures/hermes/0.22.5';out.mkdir(parents=True,exist_ok=True)
 manifest={'native_version':'0.22.5+1914.gfdb04a0','installed_commit':'fdb04a00c1626acb589552f5634a383e2b4beccc','kind':'canonical_cli_export_of_synthetic_SessionDB_fixture','not_authenticated_model_acceptance':True,'files':{}}
 for name,data in snapshots.items():
  data=data.replace(str(root),'/synthetic/fixture')
  (out/(name+'.jsonl')).write_text(data)
  manifest['files'][name+'.jsonl']={'sha256':hashlib.sha256(data.encode()).hexdigest(),'bytes':len(data.encode()),'messages':len(json.loads(data)['messages'])}
 (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print(json.dumps(manifest))
finally:
 print(json.dumps({'fixture_body_ended':True,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}),flush=True)
