from pathlib import Path
import contextlib, datetime, hashlib, json, os, shutil, signal, socket, subprocess, sys, tempfile, time
E=Path(__file__).parent
W=Path('/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp014')
N=Path('/home/obj/.hermes/hermes-agent')
B=W/'target/debug/akasha-otsuge'
PY='/home/obj/.hermes/tools/python-3.14.9+20261021-linux-x64/bin/python3'

def cli(root,*args):
    p=subprocess.run([str(B),'--config',str(root/'akasha.toml'),'--socket',str(root/'daemon.sock'),*args],capture_output=True,timeout=20)
    assert p.returncode==0,(args,p.returncode,p.stderr.decode()[-1500:])
    return json.loads(p.stdout)['data']

def child():
    root=Path(os.environ['AKASHA_NATIVE_PLUGIN_ROOT']);home=Path(os.environ['HERMES_HOME'])
    sys.path.insert(0,str(N));sys.dont_write_bytecode=True
    from hermes_constants import get_default_hermes_root
    from pm.environments import install_state_dir
    assert get_default_hermes_root()==Path('/home/obj/.hermes')
    owner=Path('/home/obj/.hermes/installs')/install_state_dir(N).name
    assert install_state_dir(N).resolve()==owner.resolve()
    import hermes_bootstrap
    from hermes_state import SessionDB
    from agent.runtime_cwd import set_session_cwd,reset_session_cwd
    from hermes_cli.plugins import get_plugin_manager,get_pre_tool_call_directive
    from hermes_cli.lifecycle import invoke_hook
    from tools.registry import registry
    db=SessionDB(home/'state.db');sid='20261029_040000_a01401'
    db.create_session(sid,'cli',model='synthetic-fixture',profile_name=home.name,cwd=str(root/'workspace'))
    db.append_message(sid,'user','Synthetic preference: keep files small.',message_uid='user',timestamp=1793246400.0)
    args={'hint':'preferences'}
    db.append_message(sid,'assistant',None,message_uid='call',timestamp=1793246401.0,tool_calls=[{'id':'call_alpha','type':'function','function':{'name':'akasha_consult','arguments':json.dumps(args)}}])
    manager=get_plugin_manager();token=set_session_cwd(str(root/'workspace'))
    try:
        manager.discover_and_load()
        info=[p for p in manager.list_plugins() if p['name']=='akasha-otsuge']
        assert len(info)==1 and info[0]['enabled'] and not info[0]['error'],info
        directive,message=get_pre_tool_call_directive('akasha_consult',args,session_id=sid,task_id='native-task',turn_id='native-turn',tool_call_id='call_alpha')
        assert directive is None,(directive,message)
        response=registry.dispatch('akasha_consult',args,session_id=sid,task_id='native-task')
        response=json.loads(response) if isinstance(response,str) else response
        assert 'data' in response,response
        bound=response['data'];assert bound['caller']['session']==sid and bound['requested_cursor']==3,bound
        assert bound['caller']['profile']=='hermes/'+hashlib.sha256(os.fsencode(home.resolve())).hexdigest()
        db.append_message(sid,'tool','Synthetic bound result.',tool_name='akasha_consult',tool_call_id='call_alpha',message_uid='result',timestamp=1793246402.0)
        db.append_message(sid,'assistant','Partial answer before interruption.',message_uid='partial',timestamp=1793246403.0)
        invoke_hook('on_session_end',session_id=sid,task_id='native-task',turn_id='native-turn',completed=False,failed=False,interrupted=True)
        from hermes_cli.plugins_state import PluginState
        status=PluginState(info[0]['key']).get('capture')
        assert 'error' not in status,status
        end=time.monotonic()+30
        while True:
            job=cli(root,'job','show',status['job_id'])
            if job['state']=='succeeded':break
            assert job['state']!='failed' and time.monotonic()<end,job
            time.sleep(.05)
        print(json.dumps({'profile':home.name,'isolation':os.environ['AKASHA_NATIVE_PLUGIN_MODE'],'plugin_loaded':True,'binding':{'id':bound['invocation_id'],'cursor':bound['requested_cursor'],'profile':bound['caller']['profile']},'interrupted_capture':'succeeded'}),flush=True)
    finally:
        manager.unload();reset_session_cwd(token);db.close()

def controller():
    root=Path(tempfile.mkdtemp(prefix='a14-plugin-',dir='/mnt/ssd/mirror-rootfs/home/obj/tmp'))
    homes={mode:Path(tempfile.mkdtemp(prefix='akasha-plugin-'+mode+'-',dir='/home/obj/.hermes/profiles')) for mode in ('in_process','host')}
    launcher_paths=[N/'.hermes/bin'/name for name in ('hermes','hermes-acp')]
    launcher_hashes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in launcher_paths}
    owned={'root':str(root),'homes':{k:str(v) for k,v in homes.items()},'launcher_hashes':launcher_hashes,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    (E/'mvp014-native-plugin3.owned.json').write_text(json.dumps(owned,indent=2)+'\n')
    daemon=None;probe=None
    try:
        (root/'workspace').mkdir()
        (root/'akasha.toml').write_text('[paths]\ndata_dir='+json.dumps(str(root/'data'))+'\nsocket_path='+json.dumps(str(root/'daemon.sock'))+'\n[access]\nread_roots=['+','.join(json.dumps(str(p)) for p in [root,*homes.values()])+']\n')
        with (root/'daemon.log').open('wb') as log:
            daemon=subprocess.Popen([str(B),'--config',str(root/'akasha.toml'),'daemon','run'],stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True)
        end=time.monotonic()+20
        while not (root/'daemon.sock').exists():
            assert daemon.poll() is None and time.monotonic()<end,'daemon readiness'
            time.sleep(.05)
        rows=[]
        for mode in ('in_process','host'):
            home=homes[mode]
            (home/'config.yaml').write_text('plugins:\n  enabled: [akasha-otsuge]\n  isolation: '+mode+'\nterminal:\n  cwd: '+json.dumps(str(root/'workspace'))+'\nsessions:\n  max_export_messages: 64\n')
            cli(root,'adapter','install','hermes','--binary','/home/obj/.local/bin/hermes','--home',str(home))
            env=os.environ|{'HERMES_HOME':str(home),'HERMES_DISABLE_LAZY_INSTALLS':'1','PYTHONDONTWRITEBYTECODE':'1','AKASHA_NATIVE_PLUGIN_ROOT':str(root),'AKASHA_NATIVE_PLUGIN_MODE':mode}
            with (root/(mode+'.log')).open('wb') as log:
                probe=subprocess.Popen([PY,'-I',str(Path(__file__)),'--child'],env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True,cwd=root/'workspace')
                try:rc=probe.wait(timeout=150)
                except subprocess.TimeoutExpired:
                    os.killpg(probe.pid,signal.SIGKILL);probe.wait();raise
            data=(root/(mode+'.log')).read_text()
            assert rc==0,(mode,rc,data[-6000:])
            rows.extend(json.loads(line) for line in data.splitlines() if line.startswith('{"profile"'))
            assert len(rows)==(('in_process','host').index(mode)+1),data[-1500:]
            cli(root,'adapter','uninstall','hermes','--home',str(home))
        assert len({r['binding']['id'] for r in rows})==2
        cli(root,'daemon','stop');daemon.wait(timeout=30);assert daemon.returncode==0
        seen=set();allocated=0;files=0
        for parent,dirs,names in (entry for area in [root,*homes.values()] for entry in os.walk(area,followlinks=False)):
            for name in names:
                s=(Path(parent)/name).lstat();key=(s.st_dev,s.st_ino)
                if key not in seen:allocated+=s.st_blocks*512;files+=1;seen.add(key)
        assert {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in launcher_paths}==launcher_hashes,'native launchers changed'
        result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':'native_plugin_and_canonical_export_with_synthetic_SessionDB','not_authenticated_model_acceptance':True,'native_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=N,text=True).strip(),'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),'binary_sha256':hashlib.sha256(B.read_bytes()).hexdigest(),'rows':rows,'allocated_bytes':allocated,'files':files,'dependency_state_shared':True}
        (E/'mvp014-native-plugin3.result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
    finally:
        if probe is not None and probe.poll() is None:os.killpg(probe.pid,signal.SIGKILL);probe.wait()
        if daemon is not None and daemon.poll() is None:
            with contextlib.suppress(Exception):cli(root,'daemon','stop');daemon.wait(timeout=30)
            if daemon.poll() is None:os.killpg(daemon.pid,signal.SIGKILL);daemon.wait()
        for home in homes.values():
            assert home.parent==Path('/home/obj/.hermes/profiles') and home.name.startswith('akasha-plugin-')
            shutil.rmtree(home)
        shutil.rmtree(root)
        print(json.dumps({'scratch_removed':not root.exists(),'profiles_removed':all(not h.exists() for h in homes.values()),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}),flush=True)

if __name__=='__main__':
    if sys.argv[1:]==['--child']:child()
    else:controller()
