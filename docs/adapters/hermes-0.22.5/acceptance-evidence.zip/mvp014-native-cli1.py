from pathlib import Path
import contextlib, datetime, hashlib, json, os, shutil, signal, subprocess, tempfile, time
import yaml
E=Path(__file__).parent
W=Path('/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp014')
N=Path('/home/obj/.hermes/hermes-agent')
B=W/'target/debug/akasha-otsuge'
H='/home/obj/.local/bin/hermes'
root=Path(tempfile.mkdtemp(prefix='a14-cli-',dir='/mnt/ssd/mirror-rootfs/home/obj/tmp'))
home=Path(tempfile.mkdtemp(prefix='akasha-caller-cli-',dir='/home/obj/.hermes/profiles'))
(root/'workspace').mkdir()
env={k:os.environ[k] for k in ('HOME','USER','LOGNAME','LANG') if k in os.environ}
env.update(PATH='/usr/bin:/bin',HERMES_HOME=str(home),TMPDIR=str(root),PYTHONDONTWRITEBYTECODE='1',HERMES_DISABLE_LAZY_INSTALLS='1')
assert all(shutil.which(n,path=env['PATH']) is None for n in ('codex','claude','pi'))
launchers={str(N/'.hermes/bin'/n):hashlib.sha256((N/'.hermes/bin'/n).read_bytes()).hexdigest() for n in ('hermes','hermes-acp')}
(E/'mvp014-native-cli1.owned.json').write_text(json.dumps({'root':str(root),'home':str(home),'launchers':launchers},indent=2)+'\n')
daemon=gateway=client=None
logs=[]
def launch(args,name):
    f=(root/(name+'.log')).open('wb');logs.append(f)
    return subprocess.Popen(args,env=env,cwd=root/'workspace',stdin=subprocess.DEVNULL,stdout=f,stderr=f,start_new_session=True)
def cli(*args):
    p=subprocess.run([str(B),'--config',str(root/'akasha.toml'),'--socket',str(root/'daemon.sock'),*args],env=env,capture_output=True,timeout=45)
    assert p.returncode==0,('akasha_cli',args,p.returncode,p.stderr.decode()[-1000:])
    return json.loads(p.stdout)['data']
def checkpoint(phase,**fields):
    r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phase':phase,**fields}
    (E/'mvp014-native-cli1.progress.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
try:
    model=yaml.safe_load(Path('/home/obj/.hermes/config.yaml').read_text())['model']
    model={k:v for k,v in model.items() if k in ('default','model','provider','context_length')}
    config={'updates':{'check':False},'model':model,'plugins':{'enabled':['akasha-otsuge'],'isolation':'in_process'},'tools':{'tool_search':{'enabled':'off'}},'terminal':{'cwd':str(root/'workspace')},'agent':{'max_turns':8,'run_budget_seconds':180},'gateway':{'standalone':True,'auto_multiplex_migration':False},'sessions':{'max_export_messages':128}}
    (home/'config.yaml').write_text(yaml.safe_dump(config));(home/'config.yaml').chmod(0o600)
    (root/'akasha.toml').write_text('[paths]\ndata_dir='+json.dumps(str(root/'data'))+'\nsocket_path='+json.dumps(str(root/'daemon.sock'))+'\n[access]\nread_roots=['+','.join(json.dumps(str(p)) for p in [root,home])+']\n')
    daemon=launch([str(B),'--config',str(root/'akasha.toml'),'daemon','run'],'daemon')
    end=time.monotonic()+30
    while not (root/'daemon.sock').exists():
        assert daemon.poll() is None and time.monotonic()<end,'daemon_not_ready';time.sleep(.05)
    cli('adapter','install','hermes','--binary',H,'--home',str(home));checkpoint('plugin_installed')
    gateway=launch([H,'gateway','run','--quiet','--no-supervise','--external-supervisor'],'gateway')
    checkpoint('gateway_started',pid=gateway.pid)
    end=time.monotonic()+90
    while True:
        assert gateway.poll() is None,('gateway_exited_before_readiness',gateway.returncode)
        try:state=json.loads((home/'gateway_state.json').read_text())
        except (FileNotFoundError,json.JSONDecodeError):state={}
        if state.get('pid')==gateway.pid and state.get('gateway_state') in ('running','degraded'):break
        assert time.monotonic()<end,('gateway_readiness_deadline',state.get('gateway_state'))
        time.sleep(.1)
    checkpoint('gateway_ready',pid=gateway.pid,state=state['gateway_state'])
    prompt=root/'request.txt';prompt.write_text('Synthetic acceptance: I prefer small files. Call akasha_consult exactly once with hint preferences. Then answer Caller checked. Do not call any other tool.');prompt.chmod(0o600)
    client=launch([H,'chat','--oneshot','--query-file',str(prompt),'--format','stream-json','--toolsets','akasha','--ignore-rules','--in',str(root/'workspace')],'client')
    rc=client.wait(timeout=230)
    rows=[]
    for s in (root/'client.log').read_text().splitlines():
        if s.startswith('{'):
            with contextlib.suppress(json.JSONDecodeError):rows.append(json.loads(s))
    finals=[r for r in rows if r.get('type')=='result']
    tools=[r for r in rows if r.get('type')=='tool_result' and r.get('name')=='akasha_consult']
    errors=[];bindings=[]
    for row in tools:
        try:reply=json.loads(row.get('output',''))
        except json.JSONDecodeError:reply={}
        if 'data' in reply:bindings.append(reply['data'])
        if isinstance(reply.get('error'),dict):errors.append(reply['error'].get('code'))
    checkpoint('client_terminal',exit_code=rc,finals=len(finals),tool_results=len(tools),bindings=len(bindings),error_codes=errors,final_errors=any('error' in f for f in finals))
    assert rc==0 and len(finals)==1 and finals[0]['exit_code']==0 and len(bindings)==1,('native_caller_failed',rc,len(finals),len(bindings),errors)
    bound=bindings[0];assert bound['caller']['profile']=='hermes/'+hashlib.sha256(os.fsencode(home.resolve())).hexdigest()
    assert bound['caller']['session']==finals[0]['session_id'] and bound['requested_cursor']==bound['available_cursor']
    jobs=cli('job','list');checkpoint('binding_verified',binding_id=bound['invocation_id'],cursor=bound['requested_cursor'],jobs_shape=type(jobs).__name__)
    gateway.send_signal(signal.SIGTERM);gateway.wait(timeout=45);gateway=None
    cli('daemon','stop');daemon.wait(timeout=30);assert daemon.returncode==0;daemon=None
    assert {p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in launchers}==launchers
    result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':'actual_authenticated_native_CLI_Caller','model':model,'binding':{'id':bound['invocation_id'],'cursor':bound['requested_cursor'],'profile':bound['caller']['profile']},'other_clis_absent':True,'native_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=N,text=True).strip(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()}
    (E/'mvp014-native-cli1.result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
finally:
    for child in (client,gateway,daemon):
        if child is not None and child.poll() is None:
            child.send_signal(signal.SIGTERM)
            try:child.wait(timeout=45)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
    for log in logs:log.close()
    alive=[]
    for proc in Path('/proc').iterdir():
        if not proc.name.isdecimal():continue
        try:
            cwd=(proc/'cwd').readlink();state=(proc/'stat').read_text().rsplit(') ',1)[1].split()[0]
            if state!='Z' and any(cwd==a or a in cwd.parents for a in (root,home)):alive.append(int(proc.name))
        except (OSError,ValueError):pass
    assert not alive,('owned processes remain; retain scratch',alive)
    shutil.rmtree(home);shutil.rmtree(root);print(json.dumps({'scratch_removed':True,'profile_removed':True}),flush=True)
