from pathlib import Path
import contextlib, datetime, hashlib, json, os, shutil, signal, subprocess, tempfile, time
import yaml
E=Path(__file__).parent
W=Path('/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp014')
N=Path('/home/obj/.hermes/hermes-agent')
B=W/'target/debug/akasha-otsuge'
artifacts=[json.loads(s) for s in (E/'mvp014-runner-native-entry-build3.log').read_text().splitlines() if s.startswith('{')]
T=Path(next(a['executable'] for a in artifacts if a.get('reason')=='compiler-artifact' and a.get('target',{}).get('name')=='hermes' and a.get('executable')))
root=Path(tempfile.mkdtemp(prefix='a14-runner-',dir='/mnt/ssd/mirror-rootfs/home/obj/tmp'))
homes={mode:Path(tempfile.mkdtemp(prefix='akasha-runner-'+mode+'-',dir='/home/obj/.hermes/profiles')) for mode in ('in_process_a','in_process_b')}
launchers={str(N/'.hermes/bin'/n):hashlib.sha256((N/'.hermes/bin'/n).read_bytes()).hexdigest() for n in ('hermes','hermes-acp')}
owned={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root':str(root),'homes':{m:str(h) for m,h in homes.items()},'launchers':launchers}
(E/'mvp014-native-runner4.owned.json').write_text(json.dumps(owned,indent=2)+'\n')
child=None
try:
    model=yaml.safe_load(Path('/home/obj/.hermes/config.yaml').read_text())['model']
    model={k:v for k,v in model.items() if k in ('default','model','provider','context_length')}
    assert model.get('default') and model.get('provider')
    rows=[]
    for mode,home in homes.items():
        config={'updates':{'check':False},'model':model,'plugins':{'enabled':['akasha-otsuge'],'isolation':'in_process'},'tools':{'tool_search':{'enabled':'off'}},'terminal':{'cwd':str(root)},'agent':{'max_turns':8}}
        (home/'config.yaml').write_text(yaml.safe_dump(config));(home/'config.yaml').chmod(0o600)
        profile_env=os.environ|{'HERMES_HOME':str(home),'HERMES_DISABLE_LAZY_INSTALLS':'1','PYTHONDONTWRITEBYTECODE':'1'}
        installed=subprocess.run([str(B),'--socket',str(root/'unused.sock'),'adapter','install','hermes','--binary','/home/obj/.local/bin/hermes','--home',str(home)],capture_output=True,timeout=40,env=profile_env)
        assert installed.returncode==0,installed.stderr.decode()[-1500:]
        env=profile_env|{'PATH':'/usr/bin:/bin','TMPDIR':str(root),'PYTHONDONTWRITEBYTECODE':'1','HERMES_DISABLE_LAZY_INSTALLS':'1','AKASHA_HERMES_BINARY':'/home/obj/.local/bin/hermes','AKASHA_HERMES_HOME':str(home),'AKASHA_HERMES_ACCEPTANCE_SECONDS':'180'}
        assert all(shutil.which(n,path=env['PATH']) is None for n in ('codex','claude','pi'))
        path=root/(mode+'.log');start=time.monotonic()
        with path.open('wb') as log:
            child=subprocess.Popen([str(T),'--exact','runner::installed_native_runner_roundtrip','--ignored','--nocapture'],env=env,cwd=root,stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True)
            try:rc=child.wait(timeout=220)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid,signal.SIGKILL);child.wait();raise
        text=path.read_text();assert rc==0,(mode,rc,text[-3000:])
        rows.append({'mode':mode,'profile':home.name,'seconds':time.monotonic()-start,'test_log_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'four_tools':True,'other_clis_absent':True})
        print(json.dumps({'completed':len(rows),'total':2,'last':rows[-1]}),flush=True)
        (E/'mvp014-native-runner4.progress.json').write_text(json.dumps(rows,indent=2)+'\n')
        undone=subprocess.run([str(B),'adapter','uninstall','hermes','--home',str(home)],capture_output=True,timeout=10);assert undone.returncode==0,undone.stderr.decode()
    seen=set();allocated=0;files=0
    for parent,dirs,names in (entry for area in [root,*homes.values()] for entry in os.walk(area,followlinks=False)):
        for name in names:
            s=(Path(parent)/name).lstat();key=(s.st_dev,s.st_ino)
            if key not in seen:allocated+=s.st_blocks*512;files+=1;seen.add(key)
    assert {p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in launchers}==launchers
    result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':'actual_authenticated_native_Hermes_Runner_with_synthetic_captured_context','model':model,'rows':rows,'allocated_bytes':allocated,'files':files,'test_binary_sha256':hashlib.sha256(T.read_bytes()).hexdigest(),'product_binary_sha256':hashlib.sha256(B.read_bytes()).hexdigest(),'native_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=N,text=True).strip(),'source_patch_sha256':hashlib.sha256(subprocess.check_output(['git','diff','HEAD'],cwd=W)).hexdigest(),'changed_file_sha256':{n:hashlib.sha256((W/n).read_bytes()).hexdigest() for n in set(subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=W,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=W,text=True).splitlines())}}
    (E/'mvp014-native-runner4.result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
finally:
    if child is not None and child.poll() is None:os.killpg(child.pid,signal.SIGKILL);child.wait()
    alive=[]
    for proc in Path('/proc').iterdir():
        if not proc.name.isdecimal():continue
        try:
            cwd=(proc/'cwd').readlink()
            state=(proc/'stat').read_text().rsplit(') ',1)[1].split()[0]
            if state!='Z' and any(cwd==area or area in cwd.parents for area in [root,*homes.values()]):alive.append(int(proc.name))
        except (OSError,ValueError):pass
    assert not alive, ('owned native processes still active; scratch retained',alive)
    for home in homes.values():
        assert home.parent==Path('/home/obj/.hermes/profiles') and home.name.startswith('akasha-runner-');shutil.rmtree(home)
    shutil.rmtree(root)
    print(json.dumps({'scratch_removed':not root.exists(),'profiles_removed':all(not h.exists() for h in homes.values())}),flush=True)
