from pathlib import Path
import contextlib, datetime, hashlib, json, os, shutil, signal, subprocess, sys, tempfile, time
E=Path(__file__).parent
W=Path('/mnt/ssd/mirror-rootfs/home/obj/project/github/RyderFreeman4Logos/akasha-otsuge-mvp014')
N=Path('/home/obj/.hermes/hermes-agent')
B=W/'target/debug/akasha-otsuge'
PY='/home/obj/.hermes/tools/python-3.14.9+20261021-linux-x64/bin/python3'
if sys.argv[1:]==['--policy']:
    sys.path.insert(0,str(N));sys.dont_write_bytecode=True
    import hermes_bootstrap
    from hermes_cli.plugins import get_plugin_manager,get_pre_tool_call_directive
    manager=get_plugin_manager();manager.discover_and_load()
    try:
        info=[p for p in manager.list_plugins() if p['name']=='akasha-otsuge']
        assert len(info)==1 and info[0]['enabled'] and not info[0]['error'],'native_plugin_not_loaded'
        denied=['terminal','write_file','patch','read_file','web_extract','web_search','delegate_task','mcp_other_tool']
        for name in denied:
            assert get_pre_tool_call_directive(name,{},session_id='synthetic',task_id='acceptance',turn_id='one',tool_call_id='attempt')==('block','TOOL_DENIED'),name
        for name in ('context_describe','context_list','context_read','context_search'):
            assert get_pre_tool_call_directive(name,{},session_id='synthetic',task_id='acceptance',turn_id='one',tool_call_id='allowed')==(None,None),name
        print(json.dumps({'native_pre_tool_guard':True,'denied':denied,'four_context_tools_allowed':True}),flush=True)
    finally:manager.unload()
    sys.exit(0)
import yaml
artifacts=[json.loads(s) for s in (E/'mvp014-native-controls-build.log').read_text().splitlines() if s.startswith('{')]
T=Path(next(a['executable'] for a in artifacts if a.get('reason')=='compiler-artifact' and a.get('target',{}).get('name')=='hermes' and a.get('executable')))
root=Path(tempfile.mkdtemp(prefix='a14-controls-',dir='/mnt/ssd/mirror-rootfs/home/obj/tmp'))
home=Path(tempfile.mkdtemp(prefix='akasha-controls-',dir='/home/obj/.hermes/profiles'))
base={k:os.environ[k] for k in ('HOME','USER','LOGNAME','LANG') if k in os.environ}
base.update(PATH='/usr/bin:/bin',HERMES_HOME=str(home),TMPDIR=str(root),PYTHONDONTWRITEBYTECODE='1',HERMES_DISABLE_LAZY_INSTALLS='1',AKASHA_HERMES_BINARY='/home/obj/.local/bin/hermes',AKASHA_HERMES_HOME=str(home))
assert all(shutil.which(n,path=base['PATH']) is None for n in ('codex','claude','pi'))
launchers={str(N/'.hermes/bin'/n):hashlib.sha256((N/'.hermes/bin'/n).read_bytes()).hexdigest() for n in ('hermes','hermes-acp')}
(E/'mvp014-native-controls1.owned.json').write_text(json.dumps({'root':str(root),'home':str(home),'launchers':launchers},indent=2)+'\n')
child=None
try:
    model=yaml.safe_load(Path('/home/obj/.hermes/config.yaml').read_text())['model']
    model={k:v for k,v in model.items() if k in ('default','model','provider','context_length')}
    cfg={'updates':{'check':False},'model':model,'plugins':{'enabled':['akasha-otsuge'],'isolation':'in_process'},'tools':{'tool_search':{'enabled':'off'}},'terminal':{'cwd':str(root)},'agent':{'max_turns':8}}
    (home/'config.yaml').write_text(yaml.safe_dump(cfg));(home/'config.yaml').chmod(0o600)
    installed=subprocess.run([str(B),'--socket',str(root/'unused.sock'),'adapter','install','hermes','--binary','/home/obj/.local/bin/hermes','--home',str(home)],env=base,capture_output=True,timeout=40)
    assert installed.returncode==0,('native_install',installed.returncode)
    rows=[]
    commands=[('policy',[PY,'-I',str(Path(__file__)),'--policy'],base|{'AKASHA_HERMES_RUN_SOCKET':'akasha-'+'a'*64,'AKASHA_HERMES_RUN_TOKEN':'b'*64})]
    commands.extend((name,[str(T),'--exact','runner::'+name,'--ignored','--nocapture'],base) for name in ('installed_native_rejects_unissued_context','installed_native_cancellation_ends_executor_after_context_tool'))
    for name,argv,env in commands:
        path=root/(name+'.log');start=time.monotonic()
        with path.open('wb') as log:
            child=subprocess.Popen(argv,env=env,cwd=root,stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True)
            try:rc=child.wait(timeout=220)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid,signal.SIGKILL);child.wait();raise
        row={'case':name,'exit_code':rc,'seconds':time.monotonic()-start,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
        if name=='policy' and rc==0:
            row['guards']=next(json.loads(s) for s in path.read_text().splitlines() if s.startswith('{"native_pre_tool_guard"'))
        rows.append(row)
        (E/'mvp014-native-controls1.progress.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'completed':len(rows),'total':3,'rows':rows},indent=2)+'\n');print(json.dumps(row),flush=True)
        if rc!=0:
            # Rust assertions are acceptance output; native child stdout is deliberately not printed.
            if name!='policy':print(path.read_text()[-4000:],flush=True)
            raise AssertionError(('native_control_failed',name,rc))
    assert {p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in launchers}==launchers
    allocated=sum(p.lstat().st_blocks*512 for area in (root,home) for p in area.rglob('*') if p.is_file())
    result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kind':'actual_native_tool_guards_and_authenticated_Runner_denial_cancellation','rows':rows,'model':model,'allocated_bytes':allocated,'test_binary_sha256':hashlib.sha256(T.read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(B.read_bytes()).hexdigest(),'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),'test_source_sha256':hashlib.sha256((W/'tests/support/hermes_runner.rs').read_bytes()).hexdigest(),'native_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=N,text=True).strip()}
    (E/'mvp014-native-controls1.result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
finally:
    if child is not None and child.poll() is None:os.killpg(child.pid,signal.SIGKILL);child.wait()
    alive=[]
    for proc in Path('/proc').iterdir():
        if not proc.name.isdecimal():continue
        try:
            cwd=(proc/'cwd').readlink();state=(proc/'stat').read_text().rsplit(') ',1)[1].split()[0]
            if state!='Z' and any(cwd==a or a in cwd.parents for a in (root,home)):alive.append(int(proc.name))
        except (OSError,ValueError):pass
    assert not alive,('owned processes remain; scratch retained',alive)
    shutil.rmtree(home);shutil.rmtree(root);print(json.dumps({'scratch_removed':True,'profile_removed':True}),flush=True)
